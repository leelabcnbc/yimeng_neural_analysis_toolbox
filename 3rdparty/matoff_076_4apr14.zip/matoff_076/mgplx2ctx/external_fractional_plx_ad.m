function [freq,n,ts,fn,ad]=external_fractional_plx_ad(data_filename,chan)
%  
% 
%  Get A/D data from external analog data ( .MAT files). Based on fractional_plx_ad
% a. mitz  13 sept 2007
% a. mitz  25 mar  2008  add an alternative way to calculate fractional sample rate
% a. mitz   7 apr 2009   modified for use with external analog files
try
   [freq,n,ts,fn,ad] = external_plx_ad(data_filename,chan);
catch
   freq=1;
   n=[];
   ts=0;
   fn=[];
   ad=[];
end;

if length(ts) < 2   % fragmented?
   return;            % no, just return
end

% estimate the fractional sample rate = 
%     number of samples before the start of the last fragment / duration of all but last fragment
fractional_sample_rate=sum(fn(1:end-1))/(ts(end)-ts(1));

% is fractional sample rate adjacent to the integer sample rate reported by the plx_ad function?
if (fractional_sample_rate >= freq & fractional_sample_rate < (freq+1)) | ...
   (fractional_sample_rate > (freq-1) & fractional_sample_rate <= freq) 
   freq=fractional_sample_rate;    % yes, defragment and change sample rate to fractional value
   fn=n;
   ts=ts(1);
   return;
end

% is fraction sample rate an integer value?
difference = fractional_sample_rate-round(fractional_sample_rate);
if abs(difference) < 1E-10
   freq=round(fractional_sample_rate);   % yes, defragment and change sample rate to fractional value
   fn=n;
   ts=ts(1);
   return;
end

% is there a better way to calculate fractional sample rate?
a=diff(ts);
fractional_sample_rate= fn(2)/a(2);

% adjacent to the integer sample rate reported by the plx_ad function?
if (fractional_sample_rate >= freq & fractional_sample_rate < (freq+1)) | ...
   (fractional_sample_rate > (freq-1) & fractional_sample_rate <= freq) 
   freq=fractional_sample_rate;    % yes, defragment and change sample rate to fractional value
   fn=n;
   ts=ts(1);
   return;
end

% an integer value?
difference = fractional_sample_rate-round(fractional_sample_rate);
if abs(difference) < 1E-10
   freq=round(fractional_sample_rate);   % yes, defragment and change sample rate to fractional value
   fn=n;
   ts=ts(1);
   return;
end



return;
