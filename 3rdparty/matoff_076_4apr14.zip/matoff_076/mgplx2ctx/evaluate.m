function [worst,worst_count]=evaluate(data_filename,mapping_filename,cortex_filename,options)
% 
%    Similar to mplx2ctx.m, but just evaluates the Plexon file
%
%  Input parameters
%    data_filename      name of the Plexon data file, usually ends with .plx
%    mapping_filename   text "mapping" file to mark trials and correlate spike channel numbers with event codes
%    cortex_filename    place holder, not used
%    options            cell array of options 
%  Output parameters
%    worst              error level of worst error(s)   0 is the worst error, see list of error levels below
%    worst_count        number of errors at this level
%
%   For use with a GUI
%     options{1}  'GUI Handles'  
%     options{2}= handle for file number in gui 
%     options{3}= handle for trial number in gui   
%     options{4}= path string for output file
%     options{5}= handle to "include analog" check box
%     options{6}= handle to decimate value (This option is no longer used)
%     options{7}= handle to message box  (This option is no longer used)
%
%   For use on the command line
%     options{1} = 'NOANALOG'       to exclude analog (otherwise it is included).
%     options{2} = 'progress.txt'   optional name of file for progress reports
%     options{3} = reporting level   'ALL'  'MOST'  'WARNINGS'  'ERRORS'  (threshold errorlevels: 4, 3, 2, 1)
%     options{4} = 'ALPHAOMEGA'      suppress analog fragmentation warnings
%
%   Example of command line use:
%     options{1}='ANALOG';
%     options{2}='prelesion_plx2ctx.txt';
%     options{3}='MOST';
%     evaluate('r021a.plx','rusty.map','R021A',options);
%
%       Error levels / Reporting levels
%
% Error level 0 (reporting level = 'ERRORS')
%    parse_mapping_file() failed
%    Unacceptable analog mapping (e.g., two Plexon channels map to one Cortex channel)
%    Error trying to read Plexon file (spikes, analog, or events)
%    Mapping file sets the two EOG channels to different decimation values
%    Fragmented analog data and allow_fragmented is zero
%
% Error level 1 (reporting level = 'WARNINGS')
%    Mapping file includes a spike channel that is empty or nearly empty
%    Mapping of analog data to Cortex channel that cannot be save (not EPP or EOG chans 3 and 4)
%    Same Plexon channel is mapped to both EOG X and EOG Y
%    Analog data fills less than 2% of each trial (on average)
%    Analog excluded because single Cortex channel is multiply mapped
%    EPP or External analog channel is listed in mapping file, but no data found
%    No EOG mapping took place
%
%
% Error level 2  (reporting level = 'MOST')
% (Informational messages do not affect worst_count)
%    General information about analog channels and mapping
%    List of Plexon analog channels not mapped to EOG
%    One or both EOG channels are also mapped to EPP channels
%
% Error level 3 (reporting level = 'ALL')
%    Detailed reporting of the mapping file
%
%
%
%
%  Required library:
%   Matlab up to version 2007a mexPlex.dll (November 2006 or later) and Plexon MATLAB Client Development Kit 
%   Matlab version 2008a and above: mexPlex.mexw32 and Plexon MATLAB Client Development Kit 
%
%   A. Mitz
% v 0.36    5 May 2007  based on mgplx2ctx v 0.36
% v 0.37    7 May 2007  statistics and event code analysis of trials
% v 0.38    7 May 2007  lists all events. lists all active analog channels w/sample rates and sample counts
% v 0.39   23 May 2007  analog was reported as empty when not.  fixed. now reports data and mapping file names
% v 0.40   14 Mar 2008  flags when the same Cortex channel is assigned to two different plexon channels
% v 0.41    3 Jun 2008  support for EPP
% v 0.42    5 Jun 2008  more graceful exit if an analog channel is mapped more than once
% v 0.44    9 Jun 2008  EPP is now analyzed. EOG is now on channels 3 and 4 (not 1 and 2). More EOG and EPP reporting.
% v 0.45   26 Jun 2008  Renumber Plexon channels to start from Channel 1
% v 0.46   27 Jun 2008  Reformat spike listing. Explicit warning for Analog Stop/Start times that don't allow saving of analog
% v 0.47   14 Oct 2008  Never report a value over 100% of trial with analog
% v 0.48   26 Nov 2008  Disable Java accelerator when calling parse_trials(). Did same in mplx2ctx back in Dec 2007.
% v 0.49   30 Mar 2009  Introduce external analog channels
% v 0.50    6 Apr 2009  More reporting of external analog channels
% v 0.51    none
% v 0.52   21 May 2009  EOG decimation moved to mapping file. 
% v 0.53    8 Sep 2009  Implement progress output text file
% v 0.54   12 Sep 2009  worst, worst_count, allow_fragmented, minimum_number_of_spikes
% v 0.55   13 Sep 2009  Check to see if all EPP mapping entries found data in the Plexon or external analog file
% v 0.56   14 Sep 2009  fclose of progress file. fixed reporting of mapped EPP without matching analog data
% v 0.57   15 Sep 2009  Tweaks of error checking and reporting. Add list of errorlevels in comments.
% v 0.58   18 Sep 2009  Was always indicating a EOG mapping error. fixed.
% v 0.59   29 Sep 2009  xdecimate and ydecimate were being selected wrongly. fixed.
% v 0.60    8 Dec 2009  fix external analog problem
% v 0.61   19 Apr 2011  small bug when analog is not supposed to be included
% v 0.62    4 Apr 2014  improved some messages to the user
% v 0.63    4 Apr 2014  supports unit names with different prefixes. e.g., sig000 and eNeu000

version='0.63';

% initialize output variables
worst=5;
worst_count=0;

% fullread
%    =0 to handle a maximum of 4 sorted templates (1 unsorted, 4 sorted = 5 rows) per electrode
%    =1 to handle a maximum of 27 templates (1 unsorted, 26 sorted = 27 rows) per electrode
fullread=1;  

% The original mplx2ctx, used Cortex channels 1 and 2 for EOG X and EOG Y
% cortex_x_channel = 1
% cortex_y_channel = 2
% After version 0.44 mplx2ctx uses Cortex channels 3 and 4.
cortex_x_channel=3;
cortex_y_channel=4;

% Allow fragmented analog
allow_fragmented=false;      % set to 'true' for Plexon file created by Alpha Omega 

% Set this to the minimum number of spikes for a useful spike channel
minimum_number_of_spikes=100;

MAX_EOG_SIZE=65534;   % must be an even number less than 65535

pfid=1;        % default progress reports to standard output
errorlevel=4;  % default progress information
fid_cortex=-1;
starting_file_number=1;

% some debug options
dump_mapping_parameters=0;
debug_trial_codes=0;
debug_spike_times=0;
debug_channel_ordering=0;
warnings=1;
show_headers=0;

% error conditions
analog_multiply_mapped=0;
% warning conditions
xy_same_plexon_channel=0;

fprintf('-- evaluate for mgplx2ctx  v%s ---',version);

if isempty(data_filename) 
   fprintf(' No data file name given. \n');
   return;
end

if isempty(mapping_filename)
   fprintf('No mapping file name specified.\n');
end

[plx_path,plx_base_name,plx_ext]=fileparts(data_filename);
if ~strcmpi(plx_ext, '.plx')
   fprintf('WARNING. Data file name does not have the .PLX extention\n');
end
external_filename=fullfile(plx_path,[plx_base_name '.mat']); % if there is an external file, this would be the name

fprintf('Evaluating %s \nusing mapping file %s\n',data_filename,mapping_filename);

% Were we called from a GUI?
gui_support=0;
if ~isempty(options)
  if strcmpi(options{1},'GUI Handles')   % GUI support (rather than command line support)
     gui_support=1;
     file_number_handle=options{2};
     trial_number_handle=options{3};
     cortex_file_path_handle=options{4};
     include_analog_checkbox_handle=options{5};
%     decimate_value_handle=options{6};   % decimate now comes from mapping file only
     starting_file_number=str2double(get(file_number_handle,'String'));
     if get(include_analog_checkbox_handle,'Value')==0
       include_analog=0;
     else
       include_analog=1;
     end % if get(include_analog_
  else   % command line support (rather than GUI support)
     include_analog=1;
     if strcmpi(options{1},'NOANALOG') 
        include_analog=0;
     end % NOANALOG

     if length(options) > 1 && ~isempty(options{2}) % open progress report file
        pfid=fopen(options{2},'a');  % append to file
        if pfid== -1
            fprintf(1,'Error opening the file for progress reporting!\n');
            pfid=1;
        end
     end % open progress report file

     if length(options) > 1 && ~isempty(options{3})
        if strcmpi(options{3},'ALL') 
           errorlevel=4;
        elseif strcmpi(options{3},'MOST') 
           errorlevel=3;
        elseif strcmpi(options{3},'WARNINGS') 
           errorlevel=2;
        elseif strcmpi(options{3},'ERRORS')  
           errorlevel=1;
        else
           errorlevel=4;  % default
        end % option 'ALL' 'MOST' ...
     end % length(options) > 1 &&

     % don't flag fragmentation as an error if using Alpha-Omega style Plexon file 
     if strcmpi(options{4},'ALPHAOMEGA')  
        allow_fragmented=true;
     end
  end % if GUI support
end % if any options
     

if pfid > 1
   fprintf(pfid,'\n-- mplx2ctx evaluator  v%s ---',version);
   fprintf(pfid,'Evaluating %s \nusing mapping file %s\n',data_filename,mapping_filename);
end

% The timestamp matrix returned by plx_info() has these columns
template_name=['unsorted'; 'unit A  ';'unit B  ';'unit C  ';'unit D  ';...
  'unit E  ';'unit F  ';'unit G  ';'unit H  ';'unit I  ';'unit J  ';'unit K  ';...
  'unit L  ';'unit M  ';'unit N  ';'unit O  ';'unit P  ';'unit Q  ';'unit R  ';...
  'unit S  ';'unit T  ';'unit U  ';'unit V  ';'unit W  ';'unit X  ';'unit Y  ';'unit Z  ' ];

% read the plx2ctx mapping file
% M  holds start, stop and other scalar information
% S  spike channel information:  electrode number | template number | event code 
% A  analog channel information: 3 columns: Plexon analog channel number (1 to n)  
%                                           EOG channel assignment (1=x, 2=y)
%                                           Decimation rate
% E  EPP analog channel information: 4 columns  
%                 plexon chan : EPP chan : decimate value : source (0 = PLX, 1 = MAT file)
%      This program adds 5th column:  0=analog data not found   1=analog data found
[M, A, S, E]=parse_mapping_file(mapping_filename);

if isempty(M) 
   [worst, worst_count]=worst_error(worst, worst_count,0); % worst of the worst
   if errorlevel > 0
      fprintf(pfid,'Cannot read or understand mapping file\n');
   end
   valid_mapping=0;
else 
   valid_mapping=1;
end

if valid_mapping==1
   if ~isempty(M.ignore_events)
      if errorlevel > 3
         fprintf(pfid,'Ignore codes:');
      end
      for i=1:length(M.ignore_events)
         if errorlevel > 3
            fprintf(pfid,'  %d',M.ignore_events(i));
         end
      end  % for i=1:length
      if errorlevel > 3
         fprintf(pfid,'\n');
      end
   end % if ~isempty
   if errorlevel > 3
      fprintf(pfid,'  ---   Mapping file assignments  ---\n');
      fprintf(pfid,'Plexon start / stop:  %3d / %-3d \n',M.plexon_start_code,M.plexon_stop_code);
      fprintf(pfid,'Cortex start / stop:  %3d / %-3d \n',M.cortex_start_code,M.cortex_stop_code);
      fprintf(pfid,'Analog start / stop:  %3d / %-3d \n',M.analog_start_code,M.analog_stop_code);
      if M.time_divisor == -1
         fprintf(pfid,'Number of analog bits: %d\nEOG Time divisor: 1:1\n',M.analog_bits);
      else
         fprintf(pfid,'Number of analog bits: %d\nEOG Time divisor: %d\n',M.analog_bits,M.time_divisor);
      end
      fprintf(pfid,'Electrode channels/templates that have been assigned event codes\n');
      fprintf(pfid,'Electrode      Template    Event Code\n');
      for i=1:size(S,1)
         if S(i,3) > 0
            fprintf(pfid,'   %2d         %s        %5d\n',S(i,1),template_name(S(i,2)+1,:),S(i,3));
         end
      end % for i=1:size(S,1)
    end
   if errorlevel > 3
      fprintf('Analog Channel Mapping\n');
   end
   % EOG channels 
   chans34_used=0;
   for i=1:size(A,1)
      if A(i,2) > 0  % is this Cortex channel mapped to a Plexon channel?
         index_mapped_channels=find(A(:,2)==A(i,2));
         if length(index_mapped_channels)==1   % see if one Cortex channel is mapped to two different Plexon channels (error)
            if errorlevel > 2
               fprintf(pfid,'Plexon analog channel %2d  ==> Cortex EOG channel %d   decimated 1:%d',A(i,1),A(i,2),A(i,3));
            end
            if (A(i,2) ~= 3) && (A(i,2) ~= 4)
               if errorlevel > 2
                  fprintf(pfid,'  (Not saved in Cortex file)');
               end
            else
               if A(i,2)==3
                  if errorlevel > 2
                     fprintf(pfid,'  Will be saved as X');
                  end
               else
                  if errorlevel > 2
                     fprintf(pfid,'  Will be saved as Y');
                  end
               end
               chans34_used=1;  % flag a real EOG channel
            end
            if errorlevel > 2
               fprintf(pfid,'\n');
            end
         elseif  length(index_mapped_channels) > 1
            if i==index_mapped_channels(1) % Make error report when multiple mapping is first encountered
               [worst, worst_count]=worst_error(worst, worst_count,0);  % the worst of the worst
               if errorlevel > 0
                  fprintf(pfid,'Error: Two or more Plexon channels are mapped to Cortex channel %d. \n',A(i,2));
               end
               analog_multiply_mapped=1;
               for imc=1:length(index_mapped_channels)
                  if errorlevel > 2
                     fprintf(pfid,'Plexon analog channel %2d  ==> Cortex EOG channel %d  decimated 1:%d\n',A(index_mapped_channels(imc),1),A(i,2),A(i,3));
                  end
               end
            end % if i=index_mapped_channels(1)
         end % if length(index_mapped_channels)
      else
         if errorlevel > 2
            fprintf(pfid,'Warning: Plexon analog channel %2d  ==> Not mapped to either Cortex EOG channel\n',A(i,1));
         end
      end % if A(i,2) > 0
   end % for i=1:size(A,1)
   if errorlevel > 2
      fprintf(pfid,'\n');
   end

   % EPP channels, which come from both Plexon and External analog sources
   for i=1:size(E,1)
      if E(i,2) > 0
         if  length(find(E(:,2)==E(i,2))) > 1   % Attempt to have two different Plexon or External analog channels mapped to same EPP channel?
            [worst, worst_count]=worst_error(worst, worst_count,0);
            if errorlevel > 0
               fprintf(pfid,'Error: Two or more analog channels are mapped to the same Cortex EPP channel. Fix mapping file.\n');
               analog_multiply_mapped=1;
            end
            if E(i,4)==0
               if errorlevel > 2
                  fprintf(pfid,'Plexon analog channel %2d  ==> Cortex EPP channel %d   decimated 1:%d ****** mapped more than once\n',E(i,1),E(i,2),E(i,3));
               end
            else 
               if errorlevel > 2
                  fprintf(pfid,'External analog channel %2d  ==> Cortex EPP channel %d   decimated 1:%d ****** mapped more than once\n',E(i,1),E(i,2),E(i,3));
               end
            end
         else
            if E(i,4)==0
               if errorlevel > 2
                  fprintf(pfid,'Plexon analog channel %2d  ==> Cortex EPP channel %d   decimated 1:%d\n',E(i,1),E(i,2),E(i,3));
               end
            else
               if errorlevel > 2
                  fprintf(pfid,'External analog channel %2d  ==> Cortex EPP channel %d   decimated 1:%d\n',E(i,1),E(i,2),E(i,3));
               end
            end
         end
      else
         if errorlevel > 2
            fprintf(pfid,' Analog channel %2d  ==> Not mapped to EPP\n',E(i,1));
         end
      end % if E(i,2) > 0
   end % for i=1:size(E,1)

end % if valid_mapping==1

% It is possible to have an incomplete or out-of-order list of electrodes, 
%      e.g.  sig001, sig004, sig009

% PLXinfo(n)=
%      .name         sig001                                        actual channel name
%      .number       1                                             channel number based on XXXnnn (XXX removed)
%      .counts      [ unsorted  unitA  unitB  unitC ... unitZ ]    any zeros are place holders
%
% PIindex   [PLXinfo(1).number  PLXinfo(2).number PLXinfo(3).number ... ];
%     find(PIindex==n)   finds the PLXinfo index for electrode # n   
%     that is, PLXinfo(find(PIindex==n))   gives the data for electrode # n
%
% find, in order, the electrodes in the data file

PIindex=[];
try
   [electrode_count,names] = plx_chan_names(data_filename);
catch 
    [worst, worst_count]=worst_error(worst, worst_count,0);  % the worst of the worst
    if errorlevel > 0
       fprintf(pfid,'\n Error opening datafile. Quitting.\n');
    end  
    if pfid > 1
       fclose(pfid);
    end
    return;
end

% Standard Plexon names are sig001, sig002, sig003.  However, the prefix to these names
% can be modified by different programs. They might be eNur001, eNur002, etc. 
% Find at which character the numeric part starts. We assume the channel
% name always ends with a 3 digit numeric part.

if errorlevel > 2
   fprintf(pfid,'\nSpike channels found in Plexon Data file\n');  % header
end
[raw_count,rawchans] = plx_chanmap(data_filename);   % each electrode has a raw channel number
for entry_number=1:electrode_count
   PLXinfo(entry_number).name=names(entry_number,:);
   PLXinfo(entry_number).number=str2double(names(entry_number,end-2:end));  % example: 'sig001' ==> 1
   PLXinfo(entry_number).rawchan=rawchans(entry_number);  % example: sig005 might be rawchan 2
   PIindex=[PIindex PLXinfo(entry_number).number];
end
if errorlevel > 2
   fprintf(pfid,'       [chan] [Plex chan] [position] [spike counts for  ]\n');
   fprintf(pfid,'[entry][name] [ number  ] [ in file] [each unit/template]\n');
end
% find out how many time stamps each unit has
[tscounts, wfcounts, number_of_events] = plx_info(data_filename, fullread);
empty_channels=[];
for tsc=2:length(tscounts(1,:))
   counts=tscounts(:,tsc)';  % transpose column list of counts to row 
   nonz=find(counts~=0);     % remove trailing zeros
   if ~isempty(nonz)
      counts=counts(1:nonz(end));
      PLXinfo(tsc-1).counts=counts;  % spike count for each unit on this electrode
      if errorlevel > 2
         fprintf(pfid,'%2d     %s   sig%03d        %2d     ',tsc-1,PLXinfo(tsc-1).name,PLXinfo(tsc-1).number,PLXinfo(tsc-1).rawchan);
      end
      for c=1:length(counts)
         if errorlevel > 2
            fprintf(pfid,'%d  ',counts(c));
         end
      end
      if errorlevel > 2
         fprintf(pfid,'\n');
      end
   else  % no units at all on this electrode
      PLXinfo(tsc-1).counts=[0 0]; 
      empty_channels=[empty_channels PLXinfo(tsc-1).number];  % keep a list
%      if errorlevel > 3
%         fprintf(pfid,'%2d     %s   sig%03d        %2d     no spikes\n',tsc-1,PLXinfo(tsc-1).name,PLXinfo(tsc-1).number,PLXinfo(tsc-1).rawchan);    
%      end
   end
end

% Are any mapped spike channels nearly empty? If so, it is a mapping error.
for i=1:size(S,1)
   if S(i,3) > 0  % find a mapped spike channel (event code > 0)
      mapped_chan=S(i,1);  % Plexon channel number   (1-512)
      mapped_template=S(i,2); % Plexon template number (0 to 26, 0 is unsorted)
      index_into_PLXinfo=find(PIindex==mapped_chan);  % pointer to the Plexon channel
      if isempty(index_into_PLXinfo)
          spike_counts=[0 0 0];
      else
          spike_counts= PLXinfo(index_into_PLXinfo).counts; % array of spike counts
      end
      if length(spike_counts) > mapped_template  % find spike count for this template
         spike_count=spike_counts(mapped_template+1);
      else
         spike_count=0;
      end

      % Now test to see if there are enough spikes
      if spike_count < minimum_number_of_spikes
         [worst, worst_count]=worst_error(worst, worst_count,1);  % Bad. This unit does not have enough spikes to analyze
         if errorlevel > 1
            fprintf(pfid,'You have mapped an empty or nearly empty spike channel: S %d,%d : %d\n',S(i,1),S(i,2),S(i,3));
         end
      end % spike_count < minimum_number_of_spikes
   end % if S(i,3)
end % for i=1:size(S,1)


if ~isempty(empty_channels)
   line_size=0;
   if errorlevel > 3
      fprintf(pfid,'The following Plexon channels have no spikes:\n');
   end
   for tsc=1:length(empty_channels)
      if line_size==0
         line_size=7;
         if errorlevel > 3
            fprintf(pfid,'\n');
         end
      end
      if errorlevel > 3
         fprintf(pfid,'   sig%03d',empty_channels(tsc));
      end
      line_size=line_size-1;
   end
   if errorlevel > 3
      fprintf(pfid,'\n');
   end
end 

% Terminate here if the mapping file was not valid
if valid_mapping==0 
 % redundant  [worst, worst_count]=worst_error(worst, worst_count,0);  % the worst of the worst
   if errorlevel > 0
      fprintf(pfid,'Cannot continue without a valid mapping file\n -- Done --\n');
   end
   if pfid > 1
      fclose(pfid);
   end
   return;
end

fprintf(pfid,'\nSearching trials...\n');

% organize all event codes into trials
% T(trial).    trial data for trial number n after running parse_trials()
%      T(trial).start_time   time (seconds) that trial n began
%      T(trial).stop_time    time that the trial ended
%      T(trial).events       event codes for all events in that trial
%      T(trial).times        timestamps for the event codes
%      T(trial).file_number  file number for this trial starting from 0
%      T(trial).analog_start_time  
%      T(trial).analog_stop_time
%
feature accel off;  % Circumvent a bug in the MATLAB Java accellerator (MATLAB V7.3 and later)
[T]=parse_trials(data_filename,M);
feature accel on;   % Circumvent a bug in the MATLAB Java accellerator (MATLAB V7.3 and later)
if length(T) < 2
   [worst, worst_count]=worst_error(worst, worst_count,0);  % the worst of the worst
   if errorlevel > 0
      fprintf(pfid,' No useable data found in data file. Error occurred while trying find events.\n -- Done --\n');
   end
   if pfid > 1
      fclose(pfid);
   end
   return;
end

if errorlevel > 2
   fprintf(pfid,' Collecting statistics about the trials\n');
end
% Collect some statistics about the trials
ntrials=length(T)-1;   % number of trials
sum_trial_duration=0;  % to calculate average trial duration
sum_analog_duration=0; % to calculate average analog recording duration
count_analog=0;
all_codes=[];          % to make a list of all codes used
for trial=1:ntrials    % all but last trial (pseudo trial)
   sum_trial_duration=sum_trial_duration + (T(trial).stop_time-T(trial).start_time);
   if  (T(trial).analog_start_time >= 0) && (T(trial).analog_stop_time > 0)
      sum_analog_duration=sum_analog_duration + (T(trial).analog_stop_time - T(trial).analog_start_time);
      count_analog=count_analog+1;
   end
   all_codes=[all_codes unique(T(trial).events)];
   all_codes=unique(all_codes);
end
ave_trial_duration= sum_trial_duration/ntrials;   % average trial duration
if count_analog > 0
   ave_analog_duration=sum_analog_duration/count_analog; % average duration of analog recordings
else
   ave_analog_duration=0;
end
pct_analog=ave_analog_duration/ave_trial_duration*100;
if errorlevel > 2
   fprintf(pfid,' Average trial duration= %8.2f seconds\n Average percent of trial that has analog data: %4.1f percent\n',ave_trial_duration,floor(pct_analog));
end
if pct_analog < 2
   [worst, worst_count]=worst_error(worst, worst_count,1);  % error level of 1 
   if errorlevel > 1
      fprintf(pfid,'On average, analog data fills less than 2%% of each trial. Possibilities:\n');
      fprintf(pfid,'   The MAP file did not request analog data processing. \n');
      fprintf(pfid,'   You might want to check analog Start and Stop codes in the MAP file.\n');
      fprintf(pfid,'   There may be no analog data. \n');
   end
end
if errorlevel > 2
   fprintf(pfid,' The following event codes were found in the trials:');
end
all_codes=sort(all_codes);
line_size=0;
for c=1:length(all_codes)
   if line_size==0
      line_size=10;
      if errorlevel > 2
         fprintf(pfid,'\n');
      end
   end
   if errorlevel > 2
      fprintf(pfid,'  %4d',all_codes(c));
   end
   line_size=line_size-1;
end
if errorlevel > 2
   fprintf(pfid,'\n');
end

if errorlevel > 3
   fprintf(pfid,' Sorting trial data\n');
end
% sort trials (spike data has been omitted)
for trial=1:length(T)-1    % all but last trial (pseudo trial)
   [T(trial).times,sort_index] = sort(T(trial).times);
   T(trial).events=T(trial).events(sort_index);
end
if errorlevel > 3
   fprintf(pfid,' Sorted\n');
end

% go through a series of tests before deciding if there will be analog data

if analog_multiply_mapped
   if errorlevel > 1
      fprintf(pfid,'Cannot process analog data because a Cortex channel is mapped multiple times.\n');
   end
   include_analog=0;
end

if include_analog==1 && isempty(A)
    fprintf(pfid,'MAP file does not request any analog data.\n');
    include_analog=0;
end

if include_analog==1
   if ~isempty (E)
      E(:,5)=0;  % initialize E 5th column (analog data not yet found)
   end
   % look for EOG data 
   if errorlevel > 3
      fprintf(pfid,'\nLooking at Plexon file analog data...\n');
   end
   [number_of_analog_channels,sample_counts]=plx_adchan_samplecounts(data_filename);
   psc= length(find(sample_counts > 0));   
   if errorlevel > 2
      fprintf(pfid,'Plexon file has %d analog channels, %d with data\n',number_of_analog_channels,psc);
   end

   xrow=find(A(:,2)==cortex_x_channel);   % x data is Cortex channel 3, find Plexon channel number 
   yrow=find(A(:,2)==cortex_y_channel);   % y data is Cortex channel 4
   xdecimate=A(xrow,3); 
   ydecimate=A(yrow,3);
   
   if ~isempty(find((A(:,2) ~= cortex_x_channel) & (A(:,2) ~= cortex_y_channel),1))
      [worst, worst_count]=worst_error(worst, worst_count,1);  
      if errorlevel > 1
         fprintf(pfid,'One or more Plexon analog channel is mapped to Cortex channel that cannot be saved. (Only chans 3 and 4 can be saved.)\n');
      end
   end
   

   if A(xrow,1)==A(yrow,1)
      xy_same_plexon_channel=1;
      [worst, worst_count]=worst_error(worst, worst_count,1);  % error level of 1
      if errorlevel > 1
         fprintf(pfid,'Warning: Both X and Y analog channels are mapped to the same Plexon Channel\n');
      end
   end
   
   if xdecimate ~= ydecimate
      [worst, worst_count]=worst_error(worst, worst_count,0);  % the worst of the worst
      if errorlevel > 0
         fprintf(pfid,'ERROR: X and Y EOG channels have different decimation values (%d and %d). Analog data will not be saved.\n',xdecimate,ydecimate);
      end
      include_analog=0;
   end
   
  
   for chann=1:number_of_analog_channels    % for each possible Plexon channel
      if sample_counts(chann) > 0
         [xadfreq, xn, xts, xfn, xad] = fractional_plx_ad(data_filename,chann-1);  % Plexon channel number is 0 based
         decimate_fraction=1;
         if xn < 2 && length(xts) > 0 && ~allow_fragmented 
            [worst, worst_count]=worst_error(worst, worst_count,0); 
            include_analog=0;
            if errorlevel > 0
               fprintf(pfid,'Error: Fragmented analog data not allowed. (To change this, see allow_fragmented option).\n');
            end
         end
         if xn < 2   % Any analog data?
            if errorlevel > 3
               fprintf(pfid,'Plexon channel %2d is empty\n',chann);
            end
         elseif A(xrow,1)==(chann)
            if xy_same_plexon_channel
               if errorlevel > 2
                  fprintf(pfid,'Plexon Channel %2d has %d samples in %d fragment(s) <== BOTH EOG Channels 3 and 4 (X & Y)\n',chann,xn,length(xts));
               end
            else
               if errorlevel > 2
                  fprintf(pfid,'Plexon Channel %2d has %d samples in %d fragment(s) <== Cortex EOG Channel 3 (X) \n',chann,xn,length(xts));
               end
            end
         elseif A(yrow,1)==(chann)
            if errorlevel > 2
               fprintf(pfid,'Plexon Channel %2d has %d samples in %d fragment(s) <== Cortex EOG Channel 4 (Y) \n',chann,xn,length(xts));
            end
         else
            if errorlevel > 2
               fprintf(pfid,'Plexon Channel %2d has %d samples in %d fragment(s)',chann,xn,length(xts));
            end
            for i=1:size(E,1)
               if E(i,1)==(chann) && E(i,4)==0   % match Plexon channel with EPP channel
                  E(i,5)=1;  % data found
                  if errorlevel > 2
                     fprintf(pfid,' <== Cortex EPP Channel %d', E(i,2));
                  end
                  decimate_fraction=E(i,3);
                  break; 
               end
            end
            if errorlevel > 2
               fprintf(pfid,'\n');
            end
         end
         if ~isempty(xad)
            if decimate_fraction==1
               if errorlevel > 2
                  fprintf(pfid,'   Sample rate: %9.4f, Range: %7.2f to %7.2f\n',xadfreq,min(xad),max(xad));
               end
            else
               if errorlevel > 2
                  fprintf(pfid,'   Sample rate: %9.4f, Range: %7.2f to %7.2f decimated 1:%d (%9.4f)\n',xadfreq,min(xad),max(xad),...
                           decimate_fraction,xadfreq/decimate_fraction);
               end
            end
         end
      else
         if  A(xrow,1)==(chann)
            if errorlevel > 2
               fprintf(pfid,'Plexon channel %2d      IS EMPTY                     <=== Cortex channel 3 (EOG X)\n',chann);
            end
         end
         if A(yrow,1)==(chann)
            if errorlevel > 2
               fprintf(pfid,'Plexon channel %2d      IS EMPTY                     <=== Cortex channel 4 (EOG Y)\n',chann);
            end
         end
      end % if sample_counts(chann+1) > 0
   end % for chann=1:

   if chans34_used==0
      [worst, worst_count]=worst_error(worst, worst_count,1);  % error level of 1
      if errorlevel > 1
         fprintf(pfid,'\nWarning: Cortex EOG channels 3 and 4 were not mapped. No EOG data will be saved.\n\n');
      end
   else
      if ~isempty(E) && ~isempty(A)
         if ~isempty(find(E(:,1)== A(xrow,1) | E(:,1)== A(yrow,1), 1))
            [worst, worst_count]=worst_error(worst, worst_count,2);  % error level of 2
            if errorlevel > 2
               fprintf(pfid,'\nOne or both EOG channels are also mapped to EPP channels\n');
            end
         end
      end
   end

   if errorlevel > 3
      fprintf(pfid,'\nLooking for analog data in external analog file...\n');
   end
   
   if ~isempty (E) && ~isempty(find(E(:,4)==1, 1))   % do any of the requested channels come from an external analog file?
      [x_number_of_analog_channels,x_sample_counts]=external_plx_adchan_samplecounts(external_filename);
      xsc= length(find(x_sample_counts > 0));
      if errorlevel > 2
         fprintf(pfid,'There is an external analog file that has %d analog channels with data:\n',xsc);
      end
      Gx=read_external_ad(external_filename,[]);  % fetch external analog data
      if ~isempty(Gx)
         for gi=1:length(Gx)   % look at each external analog channel
            if errorlevel > 2
               fprintf(pfid,'External analog entry %d is Plexon channel %2d. It has %d samples in %d fragment(s)',gi,Gx(gi).ch+1,Gx(gi).n,length(Gx(gi).ts));
            end
            for i=1:size(E,1)  % Hunt for a matching EPP mapping entry
               if E(i,1)==Gx(gi).ch+1 && E(i,4)==1   % is this EPP mapping entry for the external analog file?
                   E(i,5)=1;    % Yes: data found for this mapping file entry
                  if errorlevel > 2
                     fprintf(pfid,' <== Cortex EPP Channel %d', E(i,2));
                  end
                  decimate_fraction=E(i,3);
                  break; 
               end
            end
            if errorlevel > 2            
               fprintf(pfid,'\n');
            end
            if decimate_fraction==1
               if errorlevel > 2
                  fprintf(pfid,'   Sample rate: %9.4f, Range: %7.2f to %7.2f\n',xadfreq,min(xad),max(xad));
               end
            else
               if errorlevel > 2
                  fprintf(pfid,'   Sample rate: %9.4f, Range: %7.2f to %7.2f decimated 1:%d (%9.4f)\n',xadfreq,min(xad),max(xad),...
                              decimate_fraction,xadfreq/decimate_fraction);
               end
            end
         end
      end
      clear Gx;  % discard potentially large analog arrays
   end  % if ~isempty(E)

   % Check to see if analog data was found for all EPP map entries
   if ~isempty(E) 
      not_found_list=find(E(:,5)==0);   % mapping entries where the analog data was not found
      for nf=not_found_list'  % this will not iterate at all if data was found for all the EPP entries
         [worst, worst_count]=worst_error(worst, worst_count,1); 
         if errorlevel > 1
            if E(nf,4)==0
               fprintf(pfid,'No analog data found in Plexon file for EPP map entry: E %d: %d : %d\n',E(nf,1),E(nf,2),E(nf,3));
            else
               fprintf(pfid,'No analog data found in External Analog file for EPP map entry: X %d: %d : %d\n',E(nf,1),E(nf,2),E(nf,3));
            end
         end % errorlevel >2
      end % for nf=not_found_list
   end % if ~isempty(E)

end  % if include_analog==1

if errorlevel > 2
   fprintf(pfid,' --- Evaluate Done -- worst error %d, count %d\n',worst,worst_count);
end

if pfid > 1
   fclose(pfid);
end

% ------------------------------------- worst function -------------------------
%
function [new_worst, new_worst_count]=worst_error(current_worst, current_worst_count,this_error)
%  Keep a count of how many times the worst error occurred. 
%  See if this new error adds to or is worst than the previous worst error
%  0 is the very worst     5 is the least worst
%
   if this_error < current_worst
      new_worst_count=1;
      new_worst=this_error;
   elseif this_error == current_worst
      new_worst_count=current_worst_count+1;
      new_worst=current_worst;
   else
      new_worst_count=current_worst_count;
      new_worst=current_worst;   
   end
   