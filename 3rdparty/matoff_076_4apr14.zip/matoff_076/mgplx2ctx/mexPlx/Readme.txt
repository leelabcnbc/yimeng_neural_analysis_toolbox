Use mexPlex.dll for Matlab prior to Version 7.1
Use mexPlx.mexw32 for Matlab version 7.1 and higher
Putting both into the main mgplx2ctx directory will generate
warnings, but programs will still work properly.