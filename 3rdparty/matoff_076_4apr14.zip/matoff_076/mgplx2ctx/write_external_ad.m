function write_external_ad(filename, F)
% write_external_ad(filename): Write a structure to an external analog file
%
%   A. Mitz  7 April 2009
%
%  write_external_ad(filename, F)
%
% INPUT:
%   filename with .mat extension
%   Structure of length n    n = length(ch)
%   F(i).ch        0-based channel number of entry i, note: channel number is 1 less than Plexon channel number
%   F(i).adfreq    digitization frequency 
%   F(i).n         total number of A/D data points 
%   F(i).ts        array of fragment timestamps (one timestamp per fragment, in seconds)
%   F(i).fn        number of data points in each fragment
%   F(i).ad        a/d values
% 
% OUTPUT:
%   none

E=F;

% some error checking
chans=[];
if ~isempty(F)
   % over lapping channel number?
   for i=1:length(F)
      ch=F(i).ch;
      if ~isempty(find(chans==ch, 1))
         fprintf('Error storing external A/D. Channel number %d used more than once\n',ch);
      end
      chans=[chans ch];
   end
   if length(F(i).ad) ~= F(i).n
       fprintf('Error storing external A/D. Size of data array does not match number of data points on channel number %d\n',ch);
   end
end
save(filename, 'E');

