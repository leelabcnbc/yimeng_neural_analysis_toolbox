function [success]=mplx2ctx(data_filename,mapping_filename,cortex_filename,options)
% 
% mplx2ctx   Plexon PLX file to Cortex file converter for MATLAB
%
%
%
%  mplx2ctx is essentially the same as the plx2ctx (DOS) and wplx2ctx (Windows) programs written in C++
%  The MATLAB version will be easier to maintain. This version is also the engine for the MATLAB
%  GUI version "mgplx2ctx".  It is designed for both command-line and GUI operation.
%
%  data_filename      name of the Plexon data file, usually ends with .plx
%  mapping_filename   text "mapping" file to mark trials and correlate spike channel numbers with event codes
%  cortex_filename    Do not include an extension, it will be added automatically starting from .1
%  options            cell array of options
%     General format:  options{1}  options name (string)  options{2}=value,  options{3}=value ...
%
%  returns   1 if no errors in the operation, 0 otherwise.
%
%   For use with a GUI
%     options{1}  'GUI Handles'  
%            options{2}= handle for file number in gui 
%            options{3}= handle for trial number in gui   
%            options{4}= path string for output file
%            options{5}= handle to "include analog" check box
%            options{6}= handle to decimate value (This option is no longer used)
%            options{7}= handle to message box  (This option is no longer used)
%
%   For use on the command line
%     options{1} = 'NOANALOG'       to exclude analog (otherwise it is included).
%     options{2} = 'progress.txt'   optional name of file for progress reports
%     options{3} = reporting level   'ALL'  'MOST'  'WARNINGS'  'ERRORS'  (threshold errorlevels: 4, 3, 2, 1)
%     options{4} = 'ALPHAOMEGA'      suppress analog fragmentation warnings
%     options{5} = 'NOOVERFLOW'      EOG overflow is an error
%     mplx2ctx('r021a.plx','rusty.map','R021A',options);
%  Required library:
%   mexPlex.dll (November 2006 or later) and MATLAB wrapper programs from the Plexon Client SDK in the matlab path
%   mexPlex.mexw32 will be used by Matlab 7.1 and later versions
%
%   A. Mitz
% v 0.01    11 Feb 2006  pre-alpha. reads map file and parses trials
% v 0.02    12 Feb 2006  adds spikes to trials and finds analog data
% v 0.03    12 Feb 2006  fixed spike channel number problem
% v 0.04    14 Feb 2006  fixed parse_trials so cortex start/stop codes are included in each trial
% v 0.05    14 Feb 2006  cortex header is being written
% v 0.06    14 Feb 2006  arrays being written
% v 0.07    15 Feb 2006  fixing bugs in the writing of Cortex records
% v 0.08    16 Feb 2006  first functioning version
% v 0.10     1 Mar 2006  introduced 'options' command line option
% v 0.11     2 Mar 2006  improved channel reporting, fixed file number assignment
% v 0.12     6 Mar 2006  faster calculation of analog sample times
% v 0.20     6 Mar 2006  creates a bunch of temporary Cortex files before adding EOG data
% v 0.21     7 Mar 2006  fixed handling of files that cannot be spit into trials by the mapping options
% v 0.22    11 Mar 2006  include or exclude analog options
% v 0.23    13 Mar 2006  Check for too many A/D values
% v 0.24    15 Mar 2006  Updated for GUI version 0.5
% v 0.25    16 Mar 2006  Decimate analog
% v 0.26    17 Mar 2006  Efficient handling of files without analog
% v 0.27    22 Mar 2006  handles bad mapping file
% v 0.28    26 Mar 2006  handles fractional a/d rates
% v 0.29     9 Apr 2006  Reworked how it matches the electrode name with the entry in the data file
% v 0.30    11 Apr 2006  introduced variable PLXinfo
% v 0.31    12 Apr 2006  Expand to handle 26 sorted units
% v 0.32     9 Nov 2006  Check for valid analog data earlier in processing. Supports IGNOREEVENTS in mapping file
% v 0.33    10 Nov 2006  plx_ts() required raw channels now supplied by new SDR function: plx_chanmap().
% v 0.34    30 Nov 2006  More error checking, less reporting to GUI. Report first and last trial of each spike
% v 0.35     8 Dec 2006  Removed bug that reduced the number of electrodes by 1
% v 0.36    23 Jan 2007  Tolerates missing entries in the mapping file better.
% v 0.37     8 May 2007  Remove test messages to GUI. 
% v 0.38     4 Dec 2007  Better command line support
% v 0.39     6 Dec 2007  Better debug reporting
% v 0.40    20 Dec 2007  "feature accel off" added just before parse_trials to circumvent a Jave accelerator bug in MATLAB
% v 0.41    14 Mar 2008  If only one analog channel has data, the other one is given all zeros
% v 0.42     5 Jun 2008  Support for EPP channels with individual decimation
% v 0.43     6 Jun 2008  EPP not stored correctly, yet.
% v 0.44     9 Jun 2008  EPP stored properly. Cortex channels 3 and 4 now used for EOG (no longer channels 1 and 2)
% v 0.45    10 Jun 2008  Fixed bug with analog stop time
% v 0.46    26 Jun 2008  Plexon analog channels now mapped as 1 to n (was 0 to n)
% v 0.47    14 Oct 2008  A/D values near the allowed amplitude limits are truncated, rather than re-scaling all analog values
% v 0.48    28 Oct 2008  Fixed error in truncating EOG buffer length when too many samples fit in the time range 
% v 0.49    11 Nov 2008  When resizing EOG array, it was possible to create a fractional array size. Fixed with FLOOR. 
% v 0.50    30 Mar 2009  Introduce external analog channels
% v 0.51     6 Apr 2009  Implement source element of E array for external analog channels
% v 0.52    21 May 2009  Decimation of EOG data now controlled by mapping file. Removed from GUI
% v 0.53     8 Sep 2009  Fixed some missing semicolons at the end of lines.
% v 0.54    18 Sep 2009  EOG overflow option (NOOVERFLOW) and reporting level option
% v 0.55    22 Sep 2009  fixed crash when both EOG X and EOG Y channels are missing
% v 0.56     9 Oct 2009  fixed crash when Plexon PAUSE RECORDING was used, causing too little analog data in a trial
% v 0.57     8 Dec 2009  parse_mapping_file now allows spaces before a command in the mapping file
% v 0.58     4 Apr 2014  bugs found working on files converted from TDT
% v 0.59     4 Apr 2014  fileparts() no longer supports VERSN number, so it has been removed from the call. it was not used.
% v 0.60     4 Apr 2014  supports unit names with different prefixes. e.g., sig000 and eNeu000

version='0.60';

% fullread
%    =0 to handle a maximum of 4 sorted templates (1 unsorted, 4 sorted = 5 rows) per electrode
%    =1 to handle a maximum of 27 templates (1 unsorted, 26 sorted = 27 rows) per electrode
fullread=1;  

% The original mplx2ctx, used Cortex channels 1 and 2 for EOG X and EOG Y
% cortex_x_channel = 1
% cortex_y_channel = 2
% After version 0.44 mplx2ctx uses Cortex channels 3 and 4.
cortex_x_channel=3;
cortex_y_channel=4;

% Allow fragmented analog
allow_fragmented=false;      % set to 'true' for Plexon file created by Alpha Omega 

MAX_12BIT_SIGNED_INTEGER= 2^11-1;   %  = 2047, largest 11 bit integer (12th bit is sign bit)

MAX_EOG_POINTER_SIZE=65534;   % must be an even number less than 65535 (largest 16 bit unsigned integer)
MAX_EPP_SIZE=65534;   

starting_file_number=1;
fid_cortex=-1;
pfid=1;        % default progress reports to standard output
errorlevel=3;  % default progress information
success=1;     % optimistic
decimate=1;    % new default
no_eog_overflow=false;  % allow overflow

% some debug options
dump_mapping_parameters=0;
debug_spike_times=0;
debug_file_handles=0;
debug_channel_ordering=0;
debug_decimation=0;
show_headers=0;

if debug_file_handles
   list_open_files; %#ok<UNRCH>
end

fprintf('\n-- mplx2ctx v%s  for file: %s\n',version,data_filename);
if isempty(data_filename) 
   fprintf('No data file specified.\n');
   success=0;
   return;
end

[plx_path,plx_base_name,plx_ext]=fileparts(data_filename);
if ~strcmpi(plx_ext, '.plx')
   fprintf('WARNING. Data file name does not have the .PLX extention!\n');
end
external_filename=fullfile(plx_path,[plx_base_name '.mat']); % if there is an external file, this would be the name

if isempty(mapping_filename)
   fprintf('No mapping file specified.\n');
   success=0;
   return;
end

if isempty(cortex_filename)
   fprintf('No output file base name specified.\n');
   success=0;
   return;
end

gui_support=0;
if ~isempty(options)
  if strcmpi(options{1},'GUI Handles')   % GUI support
     gui_support=1;
     file_number_handle=options{2};
     trial_number_handle=options{3};
     cortex_file_path_handle=options{4};
     include_analog_checkbox_handle=options{5};
%     decimate_value_handle=options{6};   % decimate now comes from mapping file only
     starting_file_number=str2double(get(file_number_handle,'String'));
     if get(include_analog_checkbox_handle,'Value')==0
       include_analog=0;
     else
       include_analog=1;
     end
  else
     include_analog=1;
     if strcmpi(options{1},'NOANALOG')  % command line support
        include_analog=0;
     end

     if length(options) > 1 && ~isempty(options{2})
        pfid=fopen(options{2},'a');  % append to file
        if pfid== -1
            fprintf(1,'Error opening the file for progress reporting!\n');
            pfid=1;
        end
     end

     if length(options) > 2 && ~isempty(options{3})
        if strcmpi(options{3},'ALL') 
           errorlevel=4;
        elseif strcmpi(options{3},'MOST') 
           errorlevel=3;
        elseif strcmpi(options{3},'WARNINGS') 
           errorlevel=2; 
        elseif strcmpi(options{3},'ERRORS')  
           errorlevel=1;  % report all of these
        else
           errorlevel=3;  % default
        end % option 'ALL' 'MOST' ...
     end % length(options) > 1 &&

     % don't flag fragmentation as an error if using Alpha-Omega style Plexon file 
     if length(options) > 3 && ~isempty(options{4})
        if strcmpi(options{4},'ALPHAOMEGA')  
           allow_fragmented=true;
        end
     end

     if length(options) > 4 && ~isempty(options{5})
        if strcmpi(options{5},'NOOVERFLOW')
           no_eog_overflow=true;  % do not allow EOG overflow
        end
     end

  end % if GUI support
end % if any options

fprintf(pfid,'\n Processing data file: %s\n',data_filename);
if errorlevel > 2
   fprintf(pfid,'   Reading MAP file\n');
end

% The timestamp matrix returned by plx_info() has these columns
template_name=['unsorted'; 'unit A  ';'unit B  ';'unit C  ';'unit D  ';...
  'unit E  ';'unit F  ';'unit G  ';'unit H  ';'unit I  ';'unit J  ';'unit K  ';...
  'unit L  ';'unit M  ';'unit N  ';'unit O  ';'unit P  ';'unit Q  ';'unit R  ';...
  'unit S  ';'unit T  ';'unit U  ';'unit V  ';'unit W  ';'unit X  ';'unit Y  ';'unit Z  ' ];

% read the plx2ctx mapping file
% M  holds start, stop and other scalar information
% S  spike channel information:  electrode number | template number | event code 
% A  analog channel information
% E  EPP analog channel information, which includes external analog channel information
[M, A, S, E]=parse_mapping_file(mapping_filename);

if isempty(M) 
   fprintf(pfid,'Cannot read or understand mapping file\n');
   if pfid > 1
       fclose(pfid);
   end
   success=0;
   return;
end

if dump_mapping_parameters==1 || errorlevel > 4
   if ~isempty(M.ignore_events)
      fprintf(pfid,'Ignore codes:');
      for i=1:length(M.ignore_events)
         fprintf(pfid,'  %d',M.ignore_events(i));
      end
      fprintf(pfid,'\n');
   end
   fprintf(pfid,'Plexon start / stop:  %3d / %-3d \n',M.plexon_start_code,M.plexon_stop_code);
   fprintf(pfid,'Cortex start / stop:  %3d / %-3d \n',M.cortex_start_code,M.cortex_stop_code);
   fprintf(pfid,'Analog start / stop:  %3d / %-3d \n',M.analog_start_code,M.analog_stop_code);
   fprintf(pfid,'Number of analog bits: %d\nTime divisor: %d\n',M.analog_bits,M.time_divisor);
   fprintf(pfid,'Electrode      Template    Event Code\n');
   for i=1:size(S,1)
      fprintf(pfid,'   %2d         %s        %5d\n',S(i,1),template_name(S(i,2)+1,:),S(i,3));
   end
   for i=1:size(A,1)
      fprintf(pfid,'Plexon analog channel %2d  ==> Cortex EOG channel %d  decimated 1:%d\n',A(i,1),A(i,2),A(i,3));
   end
   for i=1:size(E,1)
      fprintf(pfid,'Plexon analog channel %2d  ==> Cortex EPP channel %d  decimated 1:%d\n',E(i,1),E(i,2),E(i,3));
   end
   for i=1:size(X,1)
      fprintf(pfid,'External analog channel %2d  ==> Cortex EPP channel %d  decimated 1:%d\n',X(i,1),X(i,2),X(i,3));
   end
end

if errorlevel > 2
   fprintf(pfid,'   Looking for data file\n');
end

% It is possible to have an incomplete or out-of-order list of electrodes, 
%      e.g.  sig001, sig004, sig009

% PLXinfo(n)=
%      .name         sig001                                        actual channel name
%      .number       1                                             channel number based on XXXnnn (XXX removed)
%      .counts      [ unsorted  unitA  unitB  unitC ... unitZ ]    any zeros are place holders
%
% PIindex   [PLXinfo(1).number  PLXinfo(2).number PLXinfo(3).number ... ];
%     find(PIindex==n)   finds the PLXinfo index for electrode # n   
%     that is, PLXinfo(find(PIindex==n))   gives the data for electrode # n
%
% find, in order, the electrodes in the data file
PIindex=[];

% make sure the file exists
test_fid=fopen(data_filename);
if test_fid==-1
   fprintf(pfid,'-------  Error: Cannot open datafile.\n');
   if pfid > 1
      fclose(pfid);
   end
   success=0;
   return;
else
   fclose(test_fid);
end    

try
   [electrode_count,names] = plx_chan_names(data_filename);
catch
   fprintf(pfid,' Error opening datafile. Quitting.\n');
   if pfid > 1
      fclose(pfid);
   end
   success=0;
   return;
end

if errorlevel > 2
   fprintf(pfid,'   Fetching spike channels\n');
end

[raw_count,rawchans] = plx_chanmap(data_filename);   % each electrode has a raw channel number
% PLXinfo(electrode_count)=struct('name','','number',0,'rawchan',0,'counts',0);
% PIindex=zeros(1,electrode_count);

% Standard Plexon names are sig001, sig002, sig003.  However, the prefix to these names
% can be modified by different programs. They might be eNur001, eNur002, etc. 
% Find at which character the numeric part starts. We assume the channel
% name always ends with a 3 digit numeric part.

for entry_number=1:electrode_count
  PLXinfo(entry_number).name=names(entry_number,:);
  PLXinfo(entry_number).number=str2double(names(entry_number,end-2:end));  % example: 'sig001' ==> 1
  PLXinfo(entry_number).rawchan=rawchans(entry_number);  % example: sig005 might be rawchan 2
  PIindex=[PIindex PLXinfo(entry_number).number];
end

% find out how many time stamps each unit has
[tscounts, wfcounts, number_of_events] = plx_info(data_filename, fullread);
for tscount_column=2:length(tscounts(1,:))
   tsc=tscounts(:,tscount_column)';  % transpose column list of counts to row 
   nonz=find(tsc~=0);     % remove trailing zeros
   if ~isempty(nonz)
      tsc=tsc(1:nonz(end));
   end
   PLXinfo(tscount_column-1).counts=tsc;  % spike count for each unit on this electrode
end

fprintf(pfid,'\nSearching trials...\n');

% organize all event codes into trials 

if debug_file_handles
   fprintf([' parse_trials for data file ' data_filename  '\n']);  % do not print this to pfid
   list_open_files;
end
feature accel off;  % Circumvent a bug in the MATLAB Java accelerator (MATLAB V7.3 and later)
[T]=parse_trials(data_filename,M);
feature accel on;   % Circumvent a bug in the MATLAB Java accelerator (MATLAB V7.3 and later)
if debug_file_handles
   list_open_files;
end
if length(T) < 2 && errorlevel > 1
   fprintf(pfid,' No useable data found in data file\n');
   if pfid > 1
       fclose(pfid);
   end   
   success=0;
   return;
end

% Search each mapping file entry for a defined unit
% and add its spikes (as event codes) to the end of each trial

if errorlevel > 2
   fprintf(pfid,'Converting spikes into event codes\n');
end
for S_entry=1:size(S,1)

   % get next unit (=electrode/template) entry from the mapping file
   electrode=S(S_entry,1);          % electrode number (1 to 512)
   template_number=S(S_entry,2);    % template number (0 = unsorted, 1 = unit A, 2 = unit B, ... 26 = unit Z)
   event_code=S(S_entry,3);         % Cortex event code to assign to these spikes
   first_trial=0;                   % will be first trial that this spike occurs in
   last_trial=0;                    % will be the last trial that this spike occurs in

   if ~isempty(find(PIindex==electrode, 1))  % is this electrode in the data file?
      % get spike count for this unit
      all_templates=PLXinfo(PIindex==electrode).counts;  % array of all spike counts for units on this electrode
      if length(all_templates) >= (template_number+1)         
         spike_count=all_templates(template_number+1);  % it is possible to have zero spikes
      else 
         spike_count=0;  % if not listed, count is zero
      end
   else
      spike_count=0;
   end

   % Process only if the unit is defined and has spikes
   if  (event_code > 0) && (spike_count > 0)
      try
         [n, ts] = plx_ts(data_filename, PLXinfo(PIindex==electrode).rawchan, template_number);  % uses raw channel number
      catch
         fprintf(pfid,'Internal error. plx_info() reports spikes that that plx_ts() cannot find.\n');
         n=0;
         ts=[];
      end
      
      if n ~= spike_count
         fprintf(pfid,'Internal error. plx_info() reports %d spikes. plx_ts() found %d spikes.\n',spike_count,n);
      end
      
      if debug_channel_ordering==1 || errorlevel > 3
         fprintf(pfid,'Electrode %d / Unit %d (%s/%s) should have %d spikes.  %d spikes found\n',electrode,...
            template_number,PLXinfo(PIindex==electrode).name,template_name(template_number+1,:),spike_count,n);
      end
      if n > 0   % any spikes in unit?
         ts=ts';  % convert to row matrix

         % Cut the list of spike times along each trial border and append the appropriate
         % segment to the end of each trial. 
         for trial=1:length(T)-1    % all but last trial (pseudo trial)
            start_time=T(trial).start_time;   % time stamp for start of trial 
            end_time=T(trial).stop_time;      % time stamp for end of trial
            if debug_spike_times==1 || errorlevel > 3
               fprintf(pfid,'start=%1.4f ana_start=%1.4f ana_stop=%1.4f stop=%1.4f\n',...
                   start_time,T(trial).analog_start_time,T(trial).analog_stop_time,end_time);
            end
            % find the time stamps of the spikes that belong in this trial
            trial_ts=ts((ts >= start_time) & (ts <= end_time)); 
            num_spikes=length(trial_ts);
            if num_spikes > 0
               if first_trial==0
                  first_trial=trial;  % first trial with spikes
               end
               last_trial=trial;      % find last trial with spikes
               % assign them all the same event code from the mapping file
               trial_spike_code=ones(1,num_spikes)*event_code; 
               % append these events to the end of the trial. The trials will be time sorted later.
               T(trial).events=[T(trial).events trial_spike_code];  
               T(trial).times= [T(trial).times trial_ts];
            end % num_spikes > 0
         end % for trial=1:length(T)-1   
         if errorlevel > 2
            fprintf(pfid,'Electrode %d / Unit %d (%s/%s) has %d spikes [code %d] from trial %d to trial %d\n',electrode,template_number,...
                PLXinfo(find(PIindex==electrode)).name,template_name(template_number+1,:),spike_count,event_code,first_trial,last_trial);
         end

      elseif debug_spike_times==1 || errorlevel > 3  %  no spikes in this unit
         fprintf(pfid,'     0 spikes found \n');
      end
   end
end % for defined_templates=1:size(S,1)

% Because spike events are simply appended and Cortex analysis tools expect chronological event
% times, time sort all the trials

if errorlevel > 3
   fprintf(pfid,'Resorting trials\n');
end

for trial=1:length(T)-1    % all but last trial (pseudo trial)
   [T(trial).times,sort_index] = sort(T(trial).times);
   T(trial).events=T(trial).events(sort_index);
end

% store all the event data in cortex format, but don't add any analog data yet.
if include_analog==1 && isempty(A)
    fprintf(pfid,'MAP file does not request any analog data.\n');
    include_analog=0;
end
% go through a series of tests before deciding if there will be analog data
if include_analog==1
%   rehash;
%   pack;
   % look for EOG and EPP data 
   if errorlevel > 2
      fprintf(pfid,'Looking for analog data...\n');
   end
   xrow=find(A(:,2)==cortex_x_channel);   % x data is Cortex channel 3, find Plexon channel number (0 is first channel)
   yrow=find(A(:,2)==cortex_y_channel);   % y data is Cortex channel 4
   xdecimate=A(xrow,3); 
   ydecimate=A(yrow,3);
   
   if A(xrow,1)==A(yrow,1)
      xy_same_plexon_channel=1;
      if errorlevel > 1
         fprintf('\nWarning: Both X and Y analog channels are mapped to the same Plexon Channel\n'); % print to user screen
      end
   end
   
   if (length(find(A(:,2)==1))>1) || (length(find(A(:,2)==2))>1)
      if errorlevel > 1
         fprintf(pfid,'MAPPING FILE ERROR:  Cannot map two Plexon channels to the same EOG channel\n');
      end
      dt=1;
      t0=0;
      include_analog=0;
   end

   if isempty(xrow) || isempty(yrow)
      if errorlevel > 1
         fprintf(pfid,'Problem with EOG or no EOG analog data found. No EOG or EPP will be processed.\n');
      end
      dt=1;
      t0=0;
      include_analog=0;
   else
      if xrow==yrow
         if errorlevel > 1
            fprintf(pfid,'X and Y channels are the same channel number. Not allowed! No EOG or EPP will be processed.\n');
         end
         dt=1;
         t0=0;
         include_analog=0;
      end
   end % if ~isempty(xrow) && ~isempty(yrow)
end



if include_analog==1
   % Process EOG. Do not include any EPP if there is a problem with EOG.
   % This section fetches all the EOG data from the file. 
   % fetch EOG analog data and information for X and Y channels
   [xadfreq, xn, xts, xfn, xad] = fractional_plx_ad(data_filename,A(xrow,1)-1);
   if isempty(xn)
       xn=0;
   end

   % if there is more than one fragment, keep only the first one
   if length(xts) > 1 && allow_fragmented==false
      xn=xfn(1);
      xts=xts(1);
      xad=xad(1:xn);
      fprintf(pfid,'Error: A/D X data is fragmented and it should not be. See ALPHAOMEGA option to change this.\n');
      success=0;  % file conversion failure!
   end
   [yadfreq, yn, yts, yfn, yad] = fractional_plx_ad(data_filename,A(yrow,1)-1);
   if isempty(yn)
       yn=0;
   end
   % if there is more than one fragment, keep only the first one
   if length(yts) > 1  && allow_fragmented==false
      yn=yfn(1);
      yts=yts(1);
      yad=yad(1:yn);
      fprintf(pfid,'Error: A/D Y data is fragmented and it should not be. See ALPHAOMEGA option to change this.\n');
      success=0;  % file conversion failure!
   end
   if ~isempty(xad) && ~isempty(yad) 
      if xdecimate ~= ydecimate
         fprintf(pfid,'Warning: Two different decimate values in mapping file for EOG. Using X channel decimate value.\n');
      end
      decimate=xdecimate;  % arbitrary
      if errorlevel > 2
         fprintf(pfid,'EOG X-Y data found on Plexon channels %d and %d\n',A(xrow,1),A(yrow,1));
         fprintf(pfid,'sample rates: X=%9.4f   Y=%9.4f\n',xadfreq,yadfreq);
         fprintf(pfid,'will be decimated 1:%d\n',decimate);
         fprintf(pfid,'Ranges: X=%7.2f to %7.2f  Y=%7.2f to %7.2f\n',min(xad),max(xad),min(yad),max(yad));
      end
   end
   
   if xadfreq ~= yadfreq || xn ~= yn
      fprintf(pfid,'ERROR: X and Y A/D channels are not from a common X-Y data set. They have different sample rates.\n');
      success=0;
   end
   
   if xn==0 && yn>0 
      if errorlevel > 1
         fprintf(pfid,'Warning: Y channel has data, but X channel is empty\n');
         fprintf(pfid,'    **** X channel will be set to all zeros ****\n');
         success=0;
      end
      decimate=ydecimate;
      xadfreq=yadfreq;
      xn=yn;
      xts=yts;
      xfn=yfn;
      xad=zeros(size(yad));
   end
   if yn==0 && xn>0
      if errorlevel > 1
         fprintf(pfid,'Warning: X channel has data, but Y channel is empty\n');
         fprintf(pfid,'    **** Y channel will be set to all zeros ****\n');
         success=0;
      end
      decimate=xdecimate;
      yadfreq=xadfreq;
      yn=xn;
      yts=xts;
      yfn=xfn;
      yad=zeros(size(xad));
   end

   if xn==0 && yn==0 || isempty(xad) && isempty(yad)
      include_analog=0;
      if errorlevel > 1
         fprintf(pfid,' Excluding analog\n');
         success=0;
      end
   end
end

EPP_data=[];
EPP_di=0;
if (include_analog==1) && (size(E,1) > 0)
   % mapped plexon channels are E(:,1)  
   for i=1:size(E,1)
      % fetch EPP data for this Channel
      if E(i,4)==0     % from .PLX file or .MAT file?
         [eadfreq, en, ets, efn, ead] = fractional_plx_ad(data_filename,E(i,1)-1);
      else
         [eadfreq, en, ets, efn, ead] = external_fractional_plx_ad(external_filename,E(i,1)-1);
      end
      % if there is more than one fragment, keep only the first one
      if length(ets) > 1 
         en=efn(1);
         ets=ets(1);
         ead=ead(1:en);
         fprintf(pfid,'EPP data from Plexon Channel %d is fragmented and it should not be. See ALPHAOMEGA option to change this.\n',E(i,1));
         success=0;  % file conversion failure!
      end
      if ~isempty(en)
         % save channel, frequency, time stamps, and data.  decimate if required.
         % analog data comes from Plexon as a floating point value. must make it fit into a 12 bit unsigned
         % integer.]
         if errorlevel > 2
            if E(i,4)==0  
               fprintf(pfid,'EPP data for Plexon channel %d (Cortex channel %d) found. (From PLX file)\n',E(i,1),E(i,2));
            else
               fprintf(pfid,'EPP data for Plexon channel %d (Cortex channel %d) found. (From MAT file)\n',E(i,1),E(i,2));
            end
         end
         EPP_di=EPP_di+1;
         EPP_data(EPP_di).entry= E(i,:);
         EPP_data(EPP_di).eadfreq= eadfreq / E(i,3);
         EPP_data(EPP_di).ets = ets;
         if E(i,3) > 1
            ead=ead(1:E(i,3):end) ;  % decimate
         end
         % does the signed data fit into 12 bits +/- 2047?
         maximum_value=max(abs(ead));  % largest absolute value of data
         if maximum_value > MAX_12BIT_SIGNED_INTEGER  % 2047 = largest 11 bit integer (12th bit is sign bit)
            if errorlevel > 1
               fprintf(pfid,' Maximum absolute value found = %d     Maximum allowed = %d\n', maximum_value,MAX_12BIT_SIGNED_INTEGER);
            end
            % if we are very near the maximum, just truncate the values that run over
            if maximum_value < MAX_12BIT_SIGNED_INTEGER+10
               ead(find(ead > MAX_12BIT_SIGNED_INTEGER)) = MAX_12BIT_SIGNED_INTEGER;
               ead(find(ead < -MAX_12BIT_SIGNED_INTEGER)) = -MAX_12BIT_SIGNED_INTEGER;
               if errorlevel > 1
                  fprintf(pfid,'WARNING: EPP data slightly above 12 bit integer ceiling. Some points will be truncated to fit. \n');
               end
            else
               if errorlevel > 1
                  fprintf(pfid,'WARNING: EPP data does not fit into a 12 bit integer. It must be rescaled. \n');
               end
               ead= ead * MAX_12BIT_SIGNED_INTEGER / maximum_value;  % rescale
            end % if maximum_value < MAX_12BIT
         end % if maximum_value > MAX_12BIT
         % shift above zero to make an unsigned integer. Should now range between 0 and 4096
         EPP_data(EPP_di).ead = fix(ead+MAX_12BIT_SIGNED_INTEGER);
      end  % if ~isempty(en)
   end % for i=1:size(E,1)
end  % if (include_analog==1)

file_number=-1;  % force a new file at the outset

% build and save each trial
if errorlevel > 2
   fprintf(pfid,'\nWriting event data to disk in Cortex format\n');
end
if gui_support==1
   path_string=get(cortex_file_path_handle,'String');
else
   path_string='';
end

byte_estimate=0;
for trial=1:length(T)-1
   % recognize if a NEW FILE code was encountered
   if T(trial).file_number+starting_file_number ~= file_number
      if file_number > 0
         fclose(fid_cortex_temp); % close previous file
      end
      file_number=T(trial).file_number+starting_file_number;     % starting_file_number=1 or comes from GUI
      first_trial_of_file=trial;
      if gui_support==1
         set(file_number_handle,'String',num2str(file_number));  % update GUI
      end

      % make the file a temporary file if we are going to add analog data later
      if include_analog==1
         fn_temp=fullfile(path_string,[cortex_filename '_temp' '.' num2str(file_number)]);
         if errorlevel > 2
            fprintf(pfid,'Creating temporary Cortex file:\n %s\n',fn_temp);
         end
      else
         fn_temp=fullfile(path_string,[cortex_filename '.' num2str(file_number)]); % not temporary
         if errorlevel > 2
            fprintf(pfid,'Creating Cortex file:\n %s\n',fn_temp);
         end
      end
      fid_cortex_temp=fopen(fn_temp,'w');
      if fid_cortex_temp== -1
          fprintf(pfid,'Critical error. Cannot create a temporary file\n');
          if pfid > 1
             fclose(pfid);
          end   
          success=0;
          return;  % dangerous. probably have some files open
      end
   end

%   if gui_support==1
%      set(trial_number_handle,'String',num2str(trial-first_trial_of_file+1));
%   end
        
   % get event times and codes. Sort them by time
   [times,sort_index]=sort(T(trial).times);
   events=T(trial).events(sort_index);
   times=  (times-times(1))*1000;  % trial starts at zero time, and is in 1.0 ms tics
   eog=[];  % not included in temporary file
   epp=[];  % not included in temporary file

   i=[];   % clear i
   i.length=0;
   i.condition=1;
   i.repeat=1;
   i.block=1;
   i.trial=trial-1;
   i.isi_size=4*length(times);
   i.code_size=2*length(events);
   i.eog_size= 2*length(eog); 
   i.epp_size= 2*length(epp);
   i.storage_rate=1;
   i.resolution=1;   % we are saving as 1 ms resolution
   i.expected=1;
   i.response=1;
   i.response_error=0;
  
      if show_headers==1 || errorlevel > 3
      %  report header
         fprintf(pfid,'        Trial %d  \n',i.trial); 
         fprintf(pfid,'                          estimated start %d (%XH)\n',byte_estimate,byte_estimate);
         fprintf(pfid,'length %d  condition %d   repeat %d   block %d\n',i.length,i.condition,i.repeat,i.block);
         fprintf(pfid,'trial number %d   isi_size %d   code size %d\n',i.trial,i.isi_size,i.code_size);
         fprintf(pfid,'EOG size %d  EPP size %d  Eye storage rate %d\n',i.eog_size,i.epp_size,i.storage_rate);
         fprintf(pfid,'Khz resol %d  expected %d   response %d   error %d\n',i.resolution,i.expected,...
                  i.response,i.response_error);
         byte_estimate=byte_estimate+26+i.isi_size+i.code_size+i.epp_size+i.eog_size;
      end % if show_headers==1

   if fid_cortex_temp > 0
      write_cortex_header(i,fid_cortex_temp);
      write_cortex_record(round(times),events,epp,eog,fid_cortex_temp);
   end

end % for trial=1:length(T)-1

if fid_cortex_temp > 0
   fclose(fid_cortex_temp);
end


%%% We are done if there is no analog data %%%
byte_estimate=0;
if include_analog==1
   if errorlevel > 2
      fprintf(pfid,'Including analog data.\n'); 
   end
   eog_overflow_counter=0;
   if decimate ~= 1
      if errorlevel > 2
         fprintf(pfid,'EOG frequency decimated from %9.4f to %9.4f Hz\n',xadfreq,xadfreq/decimate);
      end
      xadfreq = xadfreq / decimate;
   end
   dt=1 / xadfreq;  % time between samples (seconds)
   t0=xts;          % time of 1st sample

   % read temporary cortex file, add analog data, write final Cortex file
   file_number=-1;  % force a new file at the outset
   % build and save each trial
   if errorlevel > 2
      fprintf(pfid,'\nReading temporary files, adding analog data, and writing permanent data files.\n');
   end
   if gui_support==1
      path_string=get(cortex_file_path_handle,'String');
   else
      path_string='';
   end

   for trial=1:length(T)-1
      if debug_decimation ~= 0 ||  errorlevel > 3
        fprintf('Trial %d\n',trial);  % print to user screen
      end
      if T(trial).file_number+starting_file_number ~= file_number
         if file_number > 0
            fclose(fid_cortex_temp);
            fclose(fid_cortex);
         end
         file_number=T(trial).file_number+starting_file_number;
         fn_temp=fullfile(path_string,[cortex_filename '_temp' '.' num2str(file_number)]);
         temp_cortex_index=read_cortex_index(fn_temp);   % read index of temporary Cortex file
         if isempty(temp_cortex_index)
            fprintf(pfid,'Failed Reading temporary Cortex file\n');
            if pfid > 1
                fclose(pfid);
             end    
             success=0;
             return;
         end
         fid_cortex_temp=fopen(fn_temp,'r');    % open file for data reading
         fn=fullfile(path_string,[cortex_filename '.' num2str(file_number)]);
         fid_cortex=fopen(fn,'w');
         first_trial_of_file=trial;
         if gui_support==1
            set(file_number_handle,'String',num2str(file_number));
         end
         if errorlevel > 2
            fprintf(pfid,'Reading temporary Cortex file: %s\nCreating Cortex file:\n%s\n',fn_temp,fn);
         end
      end

      if gui_support==1
         set(trial_number_handle,'String',num2str(trial-first_trial_of_file+1));
      end
           
      % get event times and codes from temporary Cortex file
      temp_cortex_record = read_cortex_record(fid_cortex_temp,temp_cortex_index(trial),0);
      times=temp_cortex_record.event_time;
      events=temp_cortex_record.event_code;
      
      % Add EOG data. Requires 2 bytes per data value, one XY pair is 4 bytes.
      % The EOG pointer is an unsigned 16 bit interger, so the maximum number of
      % XY sample pairs is MAX_EOG_POINTER_SIZE/4. It is also the maximum number of X values, or Y values.
      % Find the time stamps of the EOG data that belong in this trial
      if T(trial).analog_start_time >= 0
         if T(trial).analog_stop_time >= 0
            analog_stop_time = T(trial).analog_stop_time;  % use the analog stop time if available
         else
            analog_stop_time = T(trial).stop_time;         % otherwise, use the end of trial
         end
         start_index_to_analog=ceil( ((T(trial).analog_start_time-t0)/dt)+1 );
         end_index_to_analog=floor( ((analog_stop_time-t0)/dt)+1 );
         if end_index_to_analog > 0  % we might be throwing away last trial of analog data
            index_to_analog=start_index_to_analog:decimate:end_index_to_analog;
            number_of_sample_pairs=length(index_to_analog);   
            if debug_decimation ~= 0 || errorlevel > 3
               fprintf(pfid,'eog array size = %d bytes   decimated 1:%d\n',(number_of_sample_pairs*4),decimate);
               fprintf(pfid,'trial duration = %f \n', analog_stop_time - T(trial).analog_start_time);  
            end
            if (number_of_sample_pairs*4) > MAX_EOG_POINTER_SIZE 
               fprintf(pfid,'EOG array is too big (%d) in trial %d. Truncating to %d.\n',(number_of_sample_pairs*4),trial,MAX_EOG_POINTER_SIZE);
               number_of_sample_pairs=floor(MAX_EOG_POINTER_SIZE/4);  % truncate and force index to integer
               eog_overflow_counter=eog_overflow_counter+1;
            end
            
            if end_index_to_analog > length(xad) || end_index_to_analog > length(yad)
                eog=[];  % Someone used the "PAUSE RECORDING" option on the Plexon. Bad idea!
                fprintf(pfid,'Not enough EOG data to fill the Analog_start to Analog_stop interval in trial %d\n',trial);
                skip_this_trial=true;  % don't try to do any EPP data in this tril
            else
               skip_this_trial=false;
               eog=zeros(1,number_of_sample_pairs*2);   % make an array for both X and Y values
               eog(1:2:end)=xad(index_to_analog(1:number_of_sample_pairs));  % place the x values before the y values
               eog(2:2:end)=yad(index_to_analog(1:number_of_sample_pairs));
            end
         else
            eog=[];
         end
      else
         eog=[];   % RULE: we do not save analog on trials without a start code
      end

      % Add EPP data if we have any. EPP values are left shifted by 4 binary bits,
      % then the channel number is inserted in those 4 vacant positions.
      % Raw A/D must be 12 bit unsigned or smaller integer
      epp=[];
      if EPP_di > 0 && ~skip_this_trial
         % find the time stamps of the EPP data that belong in this trial
         % For now, use the same analog start and stop times as EOG.
         if T(trial).analog_start_time >= 0   
            if T(trial).analog_stop_time >= 0
               analog_stop_time = T(trial).analog_stop_time;  % use the analog stop time if available
            else
               analog_stop_time = T(trial).stop_time;         % otherwise, use the end of trial
            end % if T(trial).analog.stop_time >= 0
            % find the segment of data for the current trial, for each EPP channel
            for i=1:EPP_di
               edt= 1/EPP_data(i).eadfreq;  % time between samples (decimation has already taken place)
               et0=EPP_data(i).ets;         % time of 1st sample
               start_index_to_analog=ceil( ((T(trial).analog_start_time-et0)/edt)+1 );
               end_index_to_analog=floor( ((analog_stop_time-et0)/edt)+1 );
               if end_index_to_analog > 0  % we might be throwing away last trial of analog data
                  index_to_analog=start_index_to_analog:end_index_to_analog;
                  size_of_next_epp=length(index_to_analog);    
                  if debug_decimation ~= 0 || errorlevel > 3
                     fprintf(pfid,'epp array size = %d\n',2*size_of_next_epp);
                  end                  
                  if (length(epp)+size_of_next_epp) > (MAX_EPP_SIZE/2)
                     fprintf(pfid,'EPP array is too big (%d bytes) in trial %d. Truncating. ',2*size_of_next_epp,trial);  
                     size_of_next_epp= (MAX_EPP_SIZE/2)-length(epp);  % truncate
                     fprintf(pfid,'Keeping %d bytes of epp data.\n',2*size_of_next_epp);
                  end
                  new_epp=EPP_data(i).ead(index_to_analog(1:size_of_next_epp));
                  cortex_channel_number=EPP_data(i).entry(2);
                  epp=[epp ; (bitshift(new_epp,4)+cortex_channel_number) ];  % encode with channel number
               end % end_index_to_analog > 0  
            end % for i=1:EPP_di
         end % if T(trial).analog.start_time >= 0
      end % if EPP_di > 0

      % make a new index by combining the cortex trial devoid of analog with the new analog data 
      i=temp_cortex_index(trial);
      i.eog_size= 2*length(eog); 
      i.epp_size= 2*length(epp);
      i.storage_rate=1;   % meaningless


      if show_headers==1
      %  report header
         fprintf(pfid,'        Trial %d  \n',i.trial); 
         fprintf(pfid,'estimated start %d (%XH)     start of header %d (%X)\n',byte_estimate,byte_estimate,...
                  i.start_of_header,i.start_of_header);
         fprintf(pfid,'length %d  condition %d   repeat %d   block %d\n',i.length,i.condition,i.repeat,i.block);
         fprintf(pfid,'trial number %d   isi_size %d   code size %d\n',i.trial,i.isi_size,i.code_size);
         fprintf(pfid,'EOG size %d  EPP size %d  Eye storage rate %d\n',i.eog_size,i.epp_size,i.storage_rate);
         fprintf(pfid,'Khz resol %d  expected %d   response %d   error %d\n',i.resolution,i.expected,...
                  i.response,i.response_error);
         byte_estimate=byte_estimate+26+i.isi_size+i.code_size+i.epp_size+i.eog_size;
      end % if show_headers==1

      % write to final Cortex file
      if fid_cortex > 0
         write_cortex_header(i,fid_cortex);
         write_cortex_record(round(times),events,epp,eog,fid_cortex);
      end
     
   end % for trial=1:length(T)-1

   if fid_cortex > 0
      if errorlevel > 2
         fprintf(pfid,'Closing Cortex file and deleting temporary file.\n');
      end
      fclose(fid_cortex_temp);
      fclose(fid_cortex);
      delete(fn_temp);
   end

   if eog_overflow_counter > 0
      fprintf(pfid,'EOG overflow occurred on %d trials.\n',eog_overflow_counter);
      if  no_eog_overflow==true 
         fprintf(pfid,'Overflows not allowed. File error.\n');
         success=0;   % failure
      end
   end

end  % if include_analog==1

fprintf(pfid,' --- Done ---\n');
if pfid > 1
   fclose(pfid);
end

%
% ----------- write_cortex_header ------------------ 
%
function write_cortex_header(index,fid_cortex) 
   cortex_header_size=26;  % number of bytes in a Cortex header
   a=fwrite(fid_cortex,index.length,        'uint16');  % length       2 bytes
   b=fwrite(fid_cortex,index.condition,     'int16');   % condition    2 bytes
   c=fwrite(fid_cortex,index.repeat,        'uint16');  % repeat       2 bytes
   d=fwrite(fid_cortex,index.block,         'uint16');  % block        2 bytes
   e=fwrite(fid_cortex,index.trial,         'uint16');  % trial        2 bytes
   f=fwrite(fid_cortex,index.isi_size,      'uint16');  % isi_size     2 bytes
   g=fwrite(fid_cortex,index.code_size,     'uint16');  % code_size    2 bytes
   h=fwrite(fid_cortex,index.eog_size,      'uint16');  % eog_size     2 bytes
   i=fwrite(fid_cortex,index.epp_size,      'uint16');  % epp_size     2 bytes
   j=fwrite(fid_cortex,index.storage_rate,  'uint8');   % storage_rate 1 byte
   k=fwrite(fid_cortex,index.resolution,    'uint8');   % resolution   1 byte
   l=fwrite(fid_cortex,index.expected,      'int16');   % expected     2 bytes
   m=fwrite(fid_cortex,index.response,      'int16');   % response     2 bytes
   n=fwrite(fid_cortex,index.response_error,'int16');   % response_error  2 bytes

   bytes_written=2*(a+b+c+d+e+f+g+h+i+l+m+n)+ 1*(j+k);

   if bytes_written ~= cortex_header_size
      fprintf(pfid,'Error writing cortex header.  %d bytes written\n',bytes_written);
      if pfid > 1
         fclose(pfid);
      end     
   end

%
% ------------ write_cortex_record ----------------------
%
function write_cortex_record(times,events,epp,eog,fid_cortex)
   a=fwrite(fid_cortex,times,  'uint32');      % 4 byte event times as 1.0 ms ticks
   b=fwrite(fid_cortex,events, 'uint16');      % 2 byte event codes 
   c=fwrite(fid_cortex,epp,    'uint16');      % 2 byte epp data stored as unsigned integer
   d=fwrite(fid_cortex,eog,    'int16');       % 2 byte eog values stored as signed integer
   bytes_written= 4*a + 2*(b+c+d);

% save for debugging
%   fprintf('%d (%XH) data bytes written + header = %d (%XH)\n',bytes_written,bytes_written,...
%          bytes_written+26,bytes_written+26);

%
% ------------ read_cortex_index -------------------------
%
function [index]=read_cortex_index(file_name)
%
%  Read all cortex indexes from a cortex data file.
% Inputs
%   file_name      name of Cortex data file
% Outputs
%   index
%       index(n).start_of_header   offset from start of file
%       index(n).length
%       index(n).condition
%       index(n).repeat
%       index(n).block
%       index(n).trial
%       index(n).isi_size
%       index(n).code_size
%       index(n).eog_size
%       index(n).epp_size
%       index(n).resolution
%       index(n).storage_rate
%       index(n).expected
%       index(n).response
%       index(n).response_error
% Globals modified
%    cortex_header_size
% 

cortex_header_size=26;  % number of bytes in a Cortex header

if isempty(file_name)
      fprintf('----- Error  No file name given.\n');
   index=[];
   return;
end
ci_fid=fopen(file_name);
if ci_fid < 1
      fprintf('----- Warning. Cortex file  %s  not found.\n',file_name);
   index=[];
   return;
end

i=1;
offset=ftell(ci_fid);
while 1 
   if fseek(ci_fid,offset,'bof');  % find start of next index entry
      break;
   end
   index_entry.start_of_header=ftell(ci_fid);  % mark the location of this entry
   [index_entry.length,n]=fread(ci_fid,1,'uint16'); % 2 bytes
   if n==0  % eof
      if (i==1) 
            fprintf('----- Warning  Cortex file ended with no headers.\n');
         if ci_fid > 0
            fclose(ci_fid);
            ci_fid=-1;
         end
         index=[];
         return;
      end
      break;
   end
   [index_entry.condition,n]=  fread(ci_fid,1,'int16'); % 2 bytes
   index_entry.condition=index_entry.condition+1;  % stored as condx-1
   [index_entry.repeat,n]=     fread(ci_fid,1,'uint16'); % 2 bytes
   [index_entry.block,n]=      fread(ci_fid,1,'uint16'); % 2 bytes
   index_entry.block=index_entry.block+1;  % stored as block-1
   [index_entry.trial,n]=      fread(ci_fid,1,'uint16'); % 2 bytes
   [index_entry.isi_size,n]=   fread(ci_fid,1,'uint16'); % 2 bytes
   [index_entry.code_size,n]=  fread(ci_fid,1,'uint16'); % 2 bytes
   [index_entry.eog_size,n]=   fread(ci_fid,1,'uint16'); % 2 bytes
   [index_entry.epp_size,n]=   fread(ci_fid,1,'uint16'); % 2 bytes
   [index_entry.storage_rate,n]=fread(ci_fid,1,'uint8'); % 1 byte
   [index_entry.resolution,n]= fread(ci_fid,1,'uint8'); % 1 byte
   [index_entry.expected,n]=   fread(ci_fid,1,'int16'); % 2 bytes
   [index_entry.response,n]=   fread(ci_fid,1,'int16'); % 2 bytes
   [index_entry.response_error,n]=fread(ci_fid,1,'int16'); % 2 bytes
   if n==0  % eof
         fprintf('----- Warning [makdat ce_read_cortex_index]. Unexpected end of Cortex file.\n');
      break;
   end
   % calculate offset of next index entry
   offset=offset + cortex_header_size + index_entry.isi_size + index_entry.code_size ...
        + index_entry.eog_size + index_entry.epp_size;  
   index(i)=index_entry;
   i=i+1;
end
if ci_fid > 0
   fclose(ci_fid);
   ci_fid=-1;
end


%
%  --------- read cortex record ---------
%
function [cortex_record]=read_cortex_record(input_fid,cortex_index,exclude_analog)
%
%  Read one record from a Cortex data file.  
%  
%  Inputs
%    input_fid          fid of input file
%    cortex_index       one Cortex index entry (see ce_read_cortex_index()) for structure
%    exclude_analog     skip analog data, return empty analog arrays
%  Outputs
%    cortex_record
%        cortex_record.event_time[]       time stamps for event codes
%        cortex_record.event_code[]       event codes
%        cortex_record.eog[:,2]           primary (X) and secondary (Y) channel data
%        cortex_record.epp[:,2]           epp channel data converted to x and y
%  
% This program assumes all files with EPP data have exactly 2 EPP channels
%
%
%
cortex_header_size=26;  % number of bytes in a Cortex header
if isempty(cortex_index)
   fprintf('----- Warning. Completely empty Cortex index entry encountered.\n');
   cortex_record=[];
   return;
end
if input_fid < 0
   fprintf('----- Error. Cortex data file is not open.\n');
   cortex_record=[];
   return;
end

data_size= cortex_index.isi_size + cortex_index.code_size + cortex_index.eog_size ...
          + cortex_index.epp_size; 

if data_size==0     % handle empty record
   cortex_record.event_time=[];
   cortex_record.event_code=[];
   cortex_record.eog=[];
   cortex_record.epp=[];
   return;
end

offset=cortex_index.start_of_header + cortex_header_size;

if fseek(input_fid,offset,'bof');  % find start of data
   cortex_record=[];
   fprintf( ...
      'Error . Could not find start of cortex data at offset: %d in file %s.\n', ...
      offset, fopen(input_fid));
   return;
end

num_of_codes=cortex_index.code_size / 2;
[cortex_record.event_time,n]=fread(input_fid,num_of_codes,'uint32'); % 4 bytes for each event time
[cortex_record.event_code,n]=fread(input_fid,num_of_codes,'uint16'); % 2 bytes for each event code
% epp array comes next, even though it is later in the header than the eog


if exclude_analog
   cortex_record.epp=[];
   cortex_record.eog=[];
else
   samples=cortex_index.epp_size / 4;
   epp_samples=fread(input_fid,[2 samples],'uint16'); % 2 bytes x 2 channels x n samples epp
   epp_samples=bitshift(epp_samples,-4);  % remove channel number tag from samples
   cortex_record.epp = epp_samples';  % transpose and save
   % eog always comes as two channels.  There is no channel information on these.
   samples=cortex_index.eog_size / 4;
   [eog_samples,n]=fread(input_fid,[2 samples],'int16');
   cortex_record.eog=eog_samples';  % 2 bytes x 2 channels x n samples eog
end






