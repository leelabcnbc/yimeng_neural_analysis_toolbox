function [F] = read_external_ad(filename, ch)
%
% [F] = read_external_ad(filename, ch)
%
%  A. Mitz  7 April 2009
%
% INPUT:
%   filename with .mat extension
%   channel - 0-based channel number or [] for all channels. 
%   0-based means these channel number are 1 less than the actual Plexon channel numbers
% 
% OUTPUT:
%   Structure of length n    n = length(ch)
%   F(i).ch        channel number of entry i
%   F(i).adfreq    digitization frequency 
%   F(i).n         total number of A/D data points 
%   F(i).ts        array of fragment timestamps (one timestamp per fragment, in seconds)
%   F(i).fn        number of data points in each fragment
%   F(i).ad        a/d values

i=0;
load (filename);   

if ~isempty(ch)
   for entry=1:length(E)
      z=find(ch==E(entry).ch);   % see if this is a desired channel number
      if  ~isempty(z)
         i=i+1;
         F(i).ch     =  E(entry).ch;
         F(i).adfreq =  E(entry).adfreq;
         F(i).n      =  E(entry).n;
         F(i).ts     =  E(entry).ts;
         F(i).fn     =  E(entry).fn;
         F(i).ad     =  E(entry).ad;
       end
   end
else F=E;
end