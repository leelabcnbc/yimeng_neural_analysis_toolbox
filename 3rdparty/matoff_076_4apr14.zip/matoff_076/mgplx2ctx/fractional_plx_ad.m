function [freq,n,ts,fn,ad]=fractional_plx_ad(data_filename,chan)
%  
% Plexon data files can only store integer sample rates. However, non-integer
% rates can be stored as multiple A/D fragments. This subroutine is a wrapper 
% around plx_ad() to handle cases of fractional sampling rates. 
% It checks the results of plx_ad(). If analog data are
% fragmented, it will see if the fragmentation is a result of a fractional
% sample rate. If so, it defragments the data and return the a/d frequency
% as a floating point number (fractional sample rate). Otherwise, it returns
% the fragments in their original form. This program assumes the stored 
% sample rate (freq) is adjacent (nearest integer) to the true fractional sample rate.
%
% a. mitz  13 sept 2007
% a. mitz  25 mar  2008   add an alternative way to calculate fractional sample rate
% a. mitz   1 oct  2009   correct rare occurance where alternative was causes a crash
%
try
   [freq,n,ts,fn,ad] = plx_ad(data_filename,chan);
catch
   freq=1;
   n=[];
   ts=0;
   fn=[];
   ad=[];
end;

if length(ts) < 2   % fragmented?
   return;            % no, just return
end

% estimate the fractional sample rate = 
%     number of samples before the start of the last fragment / duration of all but last fragment
fractional_sample_rate=sum(fn(1:end-1))/(ts(end)-ts(1));

% is fractional sample rate adjacent to the integer sample rate reported by the plx_ad function?
if (fractional_sample_rate >= freq & fractional_sample_rate < (freq+1)) | ...
   (fractional_sample_rate > (freq-1) & fractional_sample_rate <= freq) 
   freq=fractional_sample_rate;    % yes, defragment and change sample rate to fractional value
   fn=n;
   ts=ts(1);
   return;
end

% is fraction sample rate an integer value?
difference = fractional_sample_rate-round(fractional_sample_rate);
if abs(difference) < 1E-10
   freq=round(fractional_sample_rate);   % yes, defragment and change sample rate to fractional value
   fn=n;
   ts=ts(1);
   return;
end

% is there a better way to calculate fractional sample rate?
a=diff(ts);
if length(fn) > 1 && length(a) > 1
   fractional_sample_rate= fn(2)/a(2);
end

% adjacent to the integer sample rate reported by the plx_ad function?
if (fractional_sample_rate >= freq & fractional_sample_rate < (freq+1)) | ...
   (fractional_sample_rate > (freq-1) & fractional_sample_rate <= freq) 
   freq=fractional_sample_rate;    % yes, defragment and change sample rate to fractional value
   fn=n;
   ts=ts(1);
   return;
end

% an integer value?
difference = fractional_sample_rate-round(fractional_sample_rate);
if abs(difference) < 1E-10
   freq=round(fractional_sample_rate);   % yes, defragment and change sample rate to fractional value
   fn=n;
   ts=ts(1);
   return;
end



return;
