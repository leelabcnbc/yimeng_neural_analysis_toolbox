function plot_external_ad(filename)
%
% plot_external_ad(filename)    Plots and dumps parameters for an external analog file
%
%  A. Mitz   7 April 2009
%
% INPUT:
%   filename with .mat extension
% 
%   Structure of length n    n = length(ch)
%   E(i).ch        channel number of entry i (stored as Plexon channel - 1).
%   E(i).adfreq    digitization frequency 
%   E(i).n         total number of A/D data points 
%   E(i).ts        array of fragment timestamps (one timestamp per fragment, in seconds)
%   E(i).fn        number of data points in each fragment
%   E(i).ad        a/d values

i=0;
load (filename);   

nentry=length(E);
figure;
for e=1:nentry
   fprintf('Plotting: index=%d, chan=%d, freq=%d, size=%d, frags=%d\n',e, E(e).ch+1,E(e).adfreq,E(e).n,length(E(e).ts));
   subplot(nentry,1,e);
   plot(E(e).ad);
   title(['Index ' num2str(e) '  Chan ' num2str(E(e).ch+1)]);
end
