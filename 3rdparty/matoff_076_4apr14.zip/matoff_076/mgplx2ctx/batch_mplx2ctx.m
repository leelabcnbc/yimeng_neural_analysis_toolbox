function batch_mplx2ctx(command_file_name,batch_log_file_name)
%
%  Convert a whole series of Plexon files to Cortex using mplx2ctx.m
%
% Parameters
%  command_file_name    name of command file. see format below
%  batch_log_file_name  name of log file that will report the outcome of each command.
%                       The batch log is very concise, listing each plexon file 
%                       and marking those that failed to process correctly
%
%  Command file.  This is a comma-delimited text file. Each line is a conversion command:
%  <plexon file name>,<mapping file name>,<cortex file root name>,ANALOG,<report file name>
%
%  plexon file name       name of plexon file including path information and .plx extension
%  mapping file name      name of mapping file for the conversion. see documentation. 
%                         Must be listed in every line.
%  cortex file root name  root name (no extension) of cortex files that will be created. 
%                         Extensions (.1, .2, etc.) will be added as necessary during the conversion
%  ANALOG                 ANALOG to include analog data.  NOANALOG to exclude analog data.
%  report file name       detailed information about each conversion will go to this file. 
%                         The file name can be listed only once and all subsequent conversions 
%                         will continue to append to this file.
%
%  Example command file
%  mo047f11.plx,plx2ctx.map,mo047,ANALOG,report.txt
%  mo059j11.plx,plx2ctx.map,mo059,NOANALOG
%  mo062j11.plx,plx2ctx.map,mo062,ANALOG
%
%  Example use of batch_mplx2ctx:
%  batch_mplx2ctx('moPlx2Ctx.txt','batch.log');
%
%
%
debug=0;

if isempty(command_file_name)
   return;
end
if isempty(batch_log_file_name)
   batch_log_file_name='batch_mplx2ctx.log';
end
if debug
   list_open_files;
end

log_fid=fopen(batch_log_file_name,'a');
list_fid=fopen(command_file_name,'r');
report_file='';

while 1
   list_line=fgetl(list_fid);
   if ~ischar(list_line)
      if debug
         disp('End of batch command file');
      end
      break;  % exit when result is numeric
   end
   if isempty(list_line)
      if debug
         disp('skipping blank line in batch command file');
      end    
      continue;  % skip blank lines
   end

   % fetch plexon file name
   [plexon_file,r]=strtok(list_line,',');
   if isempty(plexon_file)
      if debug
         disp('skipping mostly blank line in batch command file');
      end          
      continue;  % skip blank lines
   end

   if debug
      disp(['plexon file: ' plexon_file]);
   end
   
   pfn=strrep(plexon_file,'\','\\');

   % fetch map file name
   if length(r) > 1
      r=r(2:end);
      [map_file,r]=strtok(r,',');
   else 
      fprintf(1,['Insufficient information to process file: ' pfn '\n']);
      fprintf(log_fid,[pfn ' ---      failed\n']);
      continue;
   end

   % fetch root name for cortex files
   if length(r) > 1
      r=r(2:end);
      [cortex_root_file,r]=strtok(r,',');
   else 
      fprintf(1,['Insufficient information to process file ' pfn '\n']);
      fprintf(log_fid,[pfn ' ---      failed\n']);
      continue;
   end

   % look for the ANALOG or NOANALOG option
   if length(r) > 1
      r=r(2:end);
      [analog_option,r]=strtok(r,',');
   else 
      analog_option='ANALOG';
      report_file='';
   end
 
   % look for the report file options. Default is console
   if length(r) > 1
      r=r(2:end);
      [report_file,r]=strtok(r,',');
   else 
      % report_file='';  % keep using 
   end

   if debug
      disp('Executing mplx2ctx');
      list_open_files; 
   end
   % build and execute the command
   options{1}=analog_option;
   options{2}=report_file;
   [success]=mplx2ctx(plexon_file,map_file,cortex_root_file,options);
   if success==1
      fprintf(log_fid,[pfn '\n']);
   else
      fprintf(log_fid,[pfn ' ---      failed\n']);
   end
   
   if debug
      disp('mplx2ctx executed');
      list_open_files; 
   end
   
end
fclose(list_fid);
fclose(log_fid);


fprintf(1,'\n\n  ---------------- BATCH FILE DONE ----------------   \n');
fprintf(1,['results stored in log file: ' batch_log_file_name '\n\n']);
