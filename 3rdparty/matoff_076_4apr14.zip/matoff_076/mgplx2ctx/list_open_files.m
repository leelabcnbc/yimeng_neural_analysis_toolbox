function list_open_files
%
%  Debugging tool. Lists fid, file name, and mode for each open file
%

fid_list=fopen('all');
if isempty(fid_list)
    disp('no files open');
end
for open_fid=fid_list
    [open_file_name,open_file_mode,dummy]=fopen(open_fid);
    disp([num2str(open_fid) '  ' open_file_name '  ' open_file_mode]);
end

