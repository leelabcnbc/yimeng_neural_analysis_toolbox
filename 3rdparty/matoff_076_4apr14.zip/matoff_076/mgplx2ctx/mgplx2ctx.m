function varargout = mgplx2ctx(varargin)
% MGPLX2CTX M-file for mgplx2ctx.fig
%      MGPLX2CTX, by itself, creates a new MGPLX2CTX or raises the existing
%      singleton*.
%
%      H = MGPLX2CTX returns the handle to a new MGPLX2CTX or the handle to
%      the existing singleton*.
%
%      MGPLX2CTX('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MGPLX2CTX.M with the given input arguments.
%
%      MGPLX2CTX('Property','Value',...) creates a new MGPLX2CTX or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before mgplx2ctx_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to mgplx2ctx_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help mgplx2ctx

% Last Modified by GUIDE v2.5 15-Mar-2006 14:28:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @mgplx2ctx_OpeningFcn, ...
                   'gui_OutputFcn',  @mgplx2ctx_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before mgplx2ctx is made visible.
function mgplx2ctx_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to mgplx2ctx (see VARARGIN)

% Choose default command line output for mgplx2ctx
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes mgplx2ctx wait for user response (see UIRESUME)
% uiwait(handles.h_mgplx2ctx);


% --- Outputs from this function are returned to the command line.
function varargout = mgplx2ctx_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function h_input_file_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_input_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function h_input_file_Callback(hObject, eventdata, handles)
% hObject    handle to h_input_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_input_file as text
%        str2double(get(hObject,'String')) returns contents of h_input_file as a double
set(handles.h_trial_number,'String','0');

% --- Executes on button press in h_input_file_select.
function h_input_file_select_Callback(hObject, eventdata, handles)
% hObject    handle to h_input_file_select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.target=handles.h_input_file;
handles.default_extension='.plx';
mg_lbox('UserData',handles);

% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over h_input_file_select.
function h_input_file_select_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to h_input_file_select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.target=handles.h_input_file;
handles.default_extension='.plx';
mg_lbox('UserData',handles);

% --- Executes during object creation, after setting all properties.
function h_output_file_root_name_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_output_file_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function h_output_file_path_Callback(hObject, eventdata, handles)
% hObject    handle to h_output_file_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_output_file_path as text
%        str2double(get(hObject,'String')) returns contents of h_output_file_path as a double

% --- Executes during object creation, after setting all properties.
function h_mapping_file_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_mapping_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function h_mapping_file_Callback(hObject, eventdata, handles)
% hObject    handle to h_mapping_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_mapping_file as text
%        str2double(get(hObject,'String')) returns contents of h_mapping_file as a double
set(handles.h_trial_number,'String','0');

% --- Executes on button press in h_mapping_file_select.
function h_mapping_file_select_Callback(hObject, eventdata, handles)
% hObject    handle to h_mapping_file_select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.target=handles.h_mapping_file_name;
handles.default_extension='.map';
mg_lbox('UserData',handles);

% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over h_mapping_file_select.
function h_mapping_file_select_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to h_mapping_file_select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.target=handles.h_mapping_file_name;
handles.default_extension='.map';
mg_lbox('UserData',handles);

% --- Executes during object creation, after setting all properties.
function h_mapping_file_name_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_mapping_file_name (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function h_mapping_file_name_Callback(hObject, eventdata, handles)
% hObject    handle to h_mapping_file_name (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_mapping_file_name as text
%        str2double(get(hObject,'String')) returns contents of h_mapping_file_name as a double
set(handles.h_trial_number,'String','0');

% --- Executes on button press in h_start_button.
function h_start_button_Callback(hObject, eventdata, handles)
% hObject    handle to h_start_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
input_file=get(handles.h_input_file,'String');
mapping_filename=get(handles.h_mapping_file_name,'String');
cortex_filename=get(handles.h_output_file_root_name,'String');
options{1}='GUI Handles';
options{2}=handles.h_file_number;
options{3}=handles.h_trial_number;
options{4}=handles.h_output_file_path;
options{5}=handles.h_include_analog;
options{6}=0;
options{7}=0;
set(handles.h_trial_number,'String','0');
mplx2ctx(input_file,mapping_filename,cortex_filename,options);

% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over h_start_button.
function h_start_button_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to h_start_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
input_file=get(handles.h_input_file,'String');
mapping_filename=get(handles.h_mapping_file_name,'String');
cortex_filename=get(handles.h_output_file_root_name,'String');
options{1}='GUI Handles';
options{2}=handles.h_file_number;
options{3}=handles.h_trial_number;
options{4}=handles.h_output_file_path;
options{5}=handles.h_include_analog;
options{6}=0;
options{7}=0;
set(handles.h_trial_number,'String','0');
mplx2ctx(input_file,mapping_filename,cortex_filename,options);

% --- Executes during object creation, after setting all properties.
function h_output_file_path_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_output_file_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on button press in h_output_file_path_select.
function h_output_file_path_select_Callback(hObject, eventdata, handles)
% hObject    handle to h_output_file_path_select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.target=handles.h_output_file_path;
handles.default_extension='PATH';
mg_lbox('UserData',handles);

% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over h_output_file_path_select.
function h_output_file_path_select_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to h_output_file_path_select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.target=handles.h_output_file_path;
handles.default_extension='PATH';
mg_lbox('UserData',handles);

% --- Executes on button press in h_evaluate_button.
function h_evaluate_button_Callback(hObject, eventdata, handles)
% hObject    handle to h_evaluate_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
input_file=get(handles.h_input_file,'String');
mapping_filename=get(handles.h_mapping_file_name,'String');
cortex_filename=get(handles.h_output_file_root_name,'String');
options{1}='GUI Handles';
options{2}=handles.h_file_number;
options{3}=handles.h_trial_number;
options{4}=handles.h_output_file_path;
options{5}=handles.h_include_analog;
options{6}=0;
options{7}=0;
set(handles.h_trial_number,'String','0');
evaluate(input_file,mapping_filename,cortex_filename,options);

% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over h_evaluate_button.
function h_evaluate_button_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to h_evaluate_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
input_file=get(handles.h_input_file,'String');
mapping_filename=get(handles.h_mapping_file_name,'String');
cortex_filename=get(handles.h_output_file_root_name,'String');
options{1}='GUI Handles';
options{2}=handles.h_file_number;
options{3}=handles.h_trial_number;
options{4}=handles.h_output_file_path;
options{5}=handles.h_include_analog;
options{6}=0;
options{7}=0;
set(handles.h_trial_number,'String','0');
evaluate(input_file,mapping_filename,cortex_filename,options);

% --- Executes on button press in h_include_analog.
function h_include_analog_Callback(hObject, eventdata, handles)
% hObject    handle to h_include_analog (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of h_include_analog


% --- Executes during object creation, after setting all properties.
% function h_decimate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_decimate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
% if ispc
%    set(hObject,'BackgroundColor','white');
%else
%    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
%end

% function h_decimate_Callback(hObject, eventdata, handles)
% hObject    handle to h_decimate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_decimate as text
%        str2double(get(hObject,'String')) returns contents of h_decimate as a double




% --- Executes during object creation, after setting all properties.
function h_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_input_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function h_input_Callback(hObject, eventdata, handles)
% hObject    handle to h_input_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_input_file as text
%        str2double(get(hObject,'String')) returns contents of h_input_file as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_output_file_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_output_file_root_name (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes during object creation, after setting all properties.
function h_file_number_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_file_number (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_mapping_file_name (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on button press in h_output_file_path_select.
function h_output_path_Callback(hObject, eventdata, handles)
% hObject    handle to h_output_file_path_select (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


function h_output_file_root_name_Callback(hObject, eventdata, handles)
% hObject    handle to h_output_file_root_name (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_output_file_root_name as text
%        str2double(get(hObject,'String')) returns contents of h_output_file_root_name as a double


function h_file_number_Callback(hObject, eventdata, handles)
% hObject    handle to h_file_number (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_file_number as text
%        str2double(get(hObject,'String')) returns contents of h_file_number as a double


