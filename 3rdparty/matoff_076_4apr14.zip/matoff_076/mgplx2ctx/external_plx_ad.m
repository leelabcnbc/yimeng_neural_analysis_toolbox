function [adfreq, n, ts, fn, ad] = external_plx_ad(filename, ch)
% external_plx_ad(filename, channel): Read a/d data from a .mat external analog file
%
% [adfreq, n, ts, fn, ad] = external_plx_ad(filename, ch)
%
% INPUT:
%   filename with .mat extension
%   channel - 0-based channel number. ch must be one less than the real Plexon channel number
%
%           a/d data come in fragments. Each fragment has a timestamp
%           and a number of a/d data points. The timestamp corresponds to
%           the time of recording of the first a/d value in this fragment.
%           All the data values stored in the vector ad.
% 
% OUTPUT:
%   adfreq - digitization frequency for this channel
%   n - total number of data points 
%   ts - array of fragment timestamps (one timestamp per fragment, in seconds)
%   fn - number of data points in each fragment
%   ad - array of raw a/d values
%
%
%  Structure is always saved as "E"

adfreq=0;
n=0;
ts=0;
fn=0;
ad=[];

load (filename);
for chan_n=1:length(E)
   if E(chan_n).ch == ch
      adfreq = E(chan_n).adfreq;
      n =  E(chan_n).n;
      ts = E(chan_n).ts;
      fn = E(chan_n).fn;
      ad = E(chan_n).ad;
      break
    end
end
