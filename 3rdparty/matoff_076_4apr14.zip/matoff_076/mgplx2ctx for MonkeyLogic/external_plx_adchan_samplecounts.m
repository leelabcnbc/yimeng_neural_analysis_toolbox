function [n,samplecounts] = external_plx_adchan_samplecounts(filename)
% external_plx_adchan_samplecounts(filename): 
%       Read the per-channel sample counts for external analog channels from a .MAT file
%
% [n,samplecounts] = external_plx_adchan_samplecounts(filename)
%
% INPUT:
%   filename 

% OUTPUT:
%   n - number of channels
%   samplecounts - array of sample counts

try
   load (filename);
catch
   fprintf(' External analog file %s was not found\n', filename);
   n=0;
   samplecounts=0;
   return
end
entries=length(E);

n=0;  % find highest channel number
for i=1:entries
   n=max(n,E(i).ch)+1;  % from zero-based numbering to one-based numbering
end

samplecounts=zeros(n,1); % initialize sample count for each channel

for i=1:entries
   samplecounts(E(i).ch+1)=E(i).n;
end
