function  [n,dspchans] = mlx_chanmap(filename)

n=1;
dspchans=1;