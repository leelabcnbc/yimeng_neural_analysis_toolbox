function [M, A, S, E]=parse_mapping_file(mapping_filename)
%
% Read and parse the plx2ctx mapping file
% M  structure to hold start, stop and other scalar information from mapping file
%   .plexon_start_code
%   .plexon_stop_code
%   .cortex_start_code
%   .cortex_stop_code
%   .analog_start_code
%   .analog_stop_code
%   .analog_bits
%   .time_divisor
% S  array to hold spike channel information from mapping file
%       one row per entry in spike channel table
%       columns:  electrode number   template number   event code
%       electrode numbers 1-512 (sig001 to sig512) for a 512 electrode system
%       template numbers  0-26 (unsorted, unit A, unit B, ... unit Z)
%       event code        1 - 65565 
% A  array to hold analog channel information from mapping file
%        3 columns:  Plexon analog channel number 1 to n    EOG channel     assignment (1 to n: 1=x, 2=y)  Decimation rate
% E  array to hold both EPP and External (X) analog channel information from mapping file
%        4 columns:  Plexon analog channel number 1 to n    EPP channel assignment (1 to n)   Decimation rate   Source (0=PLX, 1=MAT)
%
%
%  v0.11  2 Mar 2006  improved documentation
%  v0.12 22 Mar 2006  detects bad file name
%  v0.13 12 May 2006  template number reported by S now matches the mapping file
%  v0.14 12 May 2006  some error testing and reporting
%  v0.15  3 June 2008  support for EPP
%  v0.16 26 June 2008  Plexon analog channels (EOG and EPP) now numbered to 1 to n (was 0 to n)
%  v0.17 30 Mar  2009  Introduce External analog channels. Extend the E array.
%  v0.18  6 Apr  2009  Documentation on external analog channel data
%  v0.19 21 Apr  2009  support to decimate EOG data using mapping file
%  v0.20  8 Dec  2009  permit leading spaces before the mapping file command
%  
%
% debug option
echo_mappingfile=1;

MAX_ANALOG_CHANNELS=32;

mapping_fid=fopen(mapping_filename,'rt');

M=[];
S=[]; 
A=[];
E=[];

if mapping_fid < 0
   return;
end

% Initialize M
clear M;
M.ignore_events=[];       % no ignore events
M.plexon_start_code=-1;   % no start code
M.plexon_stop_code=-1;    % no stop code
M.cortex_start_code=-1;   % no cortex start code
M.cortex_stop_code=-1;    % no cortex stop code
M.analog_start_code=-1;   % no analog start code
M.analog_stop_code=-1;    % no analog stop code
M.time_divisor=-1;        % no time divisor


% parse map file
while ~feof(mapping_fid)
   % fetch command, remove leading and trailing white spaces
   map_line = fgetl(mapping_fid);
   if map_line == -1  % end of file?
       break
   end
   cmd=strtrim(map_line);  
   if echo_mappingfile==1
      fprintf(cmd);
      fprintf('\n');
   end

   if isempty(cmd) || strncmp(cmd,';',1)

   elseif  strncmp(cmd,'IGNOREEVENTS',12)
      M.ignore_events=[];
      [~,parm]=strtok(cmd,':');
      while ~isempty(parm)
         [icode,parm]=strtok(parm);
         M.ignore_events=[M.ignore_events str2double(icode)];
      end 

   elseif  strncmp(cmd,'PLEXONSTART',11) 
      [~,parm]=strtok(cmd,':'); 
      a=str2double(parm(2:end)); 
      if ~isempty(a) && a > 0
         M.plexon_start_code=a;
      end
      
   elseif  strncmp(cmd,'PLEXONSTOP',10) 
      [~,parm]=strtok(cmd,':'); 
      a=str2double(parm(2:end)); 
      if ~isempty(a) && a > 0
         M.plexon_stop_code=a; 
      end
  
   elseif  strncmp(cmd,'CORTEXSTART',11) 
      [~,parm]=strtok(cmd,':'); 
      a=str2double(parm(2:end)); 
      if ~isempty(a) && a > 0
         M.cortex_start_code=a; 
      end
      
   elseif  strncmp(cmd,'CORTEXSTOP',10) 
      [~,parm]=strtok(cmd,':'); 
      a=str2double(parm(2:end)); 
      if ~isempty(a) && a > 0
         M.cortex_stop_code=a; 
      end
  
   elseif  strncmp(cmd,'ANALOGSTART',11) 
      [~,parm]=strtok(cmd,':'); 
      a=str2double(parm(2:end)); 
      if ~isempty(a) && a > 0 
         M.analog_start_code=a; 
      end

   elseif  strncmp(cmd,'ANALOGSTOP',10) 
      [~,parm]=strtok(cmd,':'); 
      a=str2double(parm(2:end)); 
      if ~isempty(a) && a > 0
         M.analog_stop_code=a; 
      end

   elseif  strncmp(cmd,'ANALOGBITS',10) 
      [~,parm]=strtok(cmd,':'); 
      a=str2double(parm(2:end));
      if ~isempty(a) && a > 0
         M.analog_bits=a; 
      end

   elseif  strncmp(cmd,'TIMEDIVISOR',11) 
      [~,parm]=strtok(cmd,':'); 
      a=str2double(parm(2:end));
      if ~isempty(a) && a > 0
         M.time_divisor=a; 
      end

   elseif strncmp(cmd,'S ',2)
      [ch,remainder]=strtok(cmd(2:end),',');  
      electrode=str2double(ch);
      [u,remainder]=strtok(remainder(2:end),':');
      template=str2double(u);
      unit_event_code=str2double(remainder(2:end));
      if (electrode < 1) || (electrode > 512) || (template < 0) || (template > 26) || ...
         (unit_event_code < 0) || (unit_event_code > 65565) 
         fprintf('Illegal spike definition command in mapping file:\n');
         fprintf('%s\n',cmd);
      else
         S=[S ; electrode template unit_event_code];
      end

   elseif strncmp(cmd,'A ',2)
      [ch,u]=strtok(cmd(2:end),':');  
      plexon_analog_channel=str2double(ch);    % is 1-base channel numbering
      [ch,decim]=strtok(u(2:end),':');         % look for decimation value
      EOG_channel=str2double(ch);              % is 1-base channel numbering
      if isempty(deblank(decim))
         decim='1';
      else 
         decim=decim(2:end);
      end
      EOG_decimate=str2double(decim);
      if isempty(plexon_analog_channel)
          plexon_analog_channel=0;
      end     
      if isempty(EOG_channel)
          EOG_channel=0;
      end  
      % 3 columns:  Plexon analog channel number    EOG channel assignment (1=x, 2=y)  Decimation
      if (plexon_analog_channel < 1) || (plexon_analog_channel > 128) || ...
         (EOG_channel < 0) || (EOG_channel > MAX_ANALOG_CHANNELS)   % EOG channel 0 means "do not map"
         fprintf('Illegal analog definition command in mapping file:\n');
         fprintf('%s\n',cmd);  
      else
         A=[A ; plexon_analog_channel EOG_channel  EOG_decimate];
      end

   elseif strncmp(cmd,'E ',2)
      [ch,u]=strtok(cmd(2:end),':');  
      plexon_analog_channel=str2double(ch);   % is 1-base channel numbering
      [ch,decim]=strtok(u(2:end),':');        % look for decimation value
      EPP_channel=str2double(ch);             % is 1-base channel numbering
      if isempty(deblank(decim))
         decim='1';
      else 
         decim=decim(2:end);
      end
      EPP_decimate=str2double(decim);
      if isempty(plexon_analog_channel)
          plexon_analog_channel=0;
      end     
      if isempty(EPP_channel)
          EPP_channel=0;
      end  
      % 4 columns:  Plexon channel    EPP channel     Decimation   Source
      if (plexon_analog_channel < 1) || (plexon_analog_channel > 128) || ...
         (EPP_channel < 0) || (EPP_channel > MAX_ANALOG_CHANNELS)   % EPP channel 0 means "do not map"
         fprintf('Illegal EPP analog definition command in mapping file:\n');
         fprintf('%s\n',cmd);  
      else
         E=[E ; plexon_analog_channel EPP_channel EPP_decimate  0];
      end

   elseif strncmp(cmd,'X ',2)      % External analog channels are saved as EPP channels, but with Source = 1
      [ch,u]=strtok(cmd(2:end),':');  
      plexon_analog_channel=str2double(ch);   % is 1-base channel numbering
      [ch,decim]=strtok(u(2:end),':');     % look for decimation value
      EPP_channel=str2double(ch);             % is 1-base channel numbering
      if isempty(deblank(decim))
         decim='1';
      else 
         decim=decim(2:end);
      end
      EPP_decimate=str2double(decim);
      if isempty(plexon_analog_channel)
          plexon_analog_channel=0;
      end     
      if isempty(EPP_channel)
          EPP_channel=0;
      end  
      % 4 columns:  Plexon channel    EPP channel     Decimation   Source
      if (plexon_analog_channel < 1) || (plexon_analog_channel > 128) || ...
         (EPP_channel < 0) || (EPP_channel > MAX_ANALOG_CHANNELS)   % EPP channel 0 means "do not map"
         fprintf('Illegal External (X) analog definition command in mapping file:\n');
         fprintf('%s\n',cmd);  
      else
         E=[E ; plexon_analog_channel EPP_channel EPP_decimate  1];
      end


   end % if

end % while ~feof(mapping_fid)
fclose(mapping_fid);
