function [n, ts] = mlx_ts(filename, channel, unit)
% plx_ts(filename, channel, unit): Read spike timestamps from a .mlx file
%
% [n, ts] = mlx_ts(filename, channel, unit)
%
% INPUT:
%   filename -
%   channel - 1-based channel number
%   unit  - unit number (0- unsorted, 1-4 units a-d)
% OUTPUT:
%   n - number of timestamps
%   ts - array of timestamps (in seconds)


n=0;
ts=[];

