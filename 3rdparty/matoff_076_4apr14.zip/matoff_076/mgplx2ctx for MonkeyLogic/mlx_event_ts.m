function [n, ts, sv] = mlx_event_ts(filename, ch)
% mlx_event_ts(filename, channel) Read event timestamps from a MonkeyLogic file
%
% [n, ts, sv] = mlx_event_ts(filename, channel)
%
% INPUT:
%   filename - if empty string, will use File Open dialog
%   channel - 1-based external channel number
%             strobed channel has channel number 257  
% OUTPUT:
%   n - number of timestamps
%   ts - array of timestamps (in seconds)
%   sv - array of strobed event values (filled only if channel is 257)

n=0;
ts=[];
sv=[];

if ch ~= 257
   fprintf(' MonkeyLogic only supports strobed events\n');
   return
end

try
   bhv=bhv_read(filename);
catch
   fprintf('mlx_event_ts: Could not open MonkeyLogic file %s\n',filename);
   return
end

list_of_codes = bhv.CodeNumbersUsed;
number_of_trials =  bhv.TrialNumber(end)-bhv.TrialNumber(1)+1;

% Create an array of trial start times (in milliseconds from the start of trial 1)
trial_start_time = [ 0 ];  % first trial starts at absolute time zero
start_date_vector = bhv.AbsoluteTrialStartTime(1,:);
for T=2:number_of_trials
   trial_start_time = [trial_start_time (1000*etime(bhv.AbsoluteTrialStartTime(T,:),start_date_vector))];
end

t = 0;
for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
   codes=bhv.CodeNumbers{TN}';
   times=bhv.CodeTimes{TN}';
   % if trial starts with 9 9 9, reduce that to a single 9
   a=codes==9; 
   if sum(a(1:3)) == 3 
      codes = codes(3:end);
      times = times(3:end);
   end
   % if trial ends with 18 18 18, reduce that to a single 18
   a=codes==18; 
   if sum(a(end-2:end))==3
      codes = codes(1:end-2);
      times = times(3:end-2);
   end

   sv = [sv   codes] ;    % get list of codes in this trial
   t = t+1;                             % index into trial_start_time array
   ts = [ts  (times + trial_start_time(t))];  % add trial start time to the event times 
end


n = length(ts);


