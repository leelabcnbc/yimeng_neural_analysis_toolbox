function [T]=parse_trials(filename,MAP)
%
% open data file and grab all the event codes and event times
% return with a structure spilit into trial-by-trial data
%
% filename  string for file with any path information
% 
% MAP  structure that holds mapping file information
%   .plexon_start_code
%   .plexon_stop_code
%   .cortex_start_code
%   .cortex_stop_code
%   .analog_start_code
%   .analog_stop_code
%   .analog_bits
%   .time_divisor
%
% T(trial).    trial data for trial number n
%      T(trial).start_time   time (seconds) that trial n began
%      T(trial).stop_time    time that the trial ended
%      T(trial).events       event codes for all events in that trial
%      T(trial).times        timestamps for the event codes
%      T(trial).file_number  file number for this trial starting from 0
%      T(trial).analog_start_time  
%      T(trial).analog_stop_time
%
%
% v 0.11  2 Mar 2006  improved internal documentation
% v 0.12  7 Mar 2006  tolerate files with no event codes that match the Cortex start event
% v 0.13 13 Mar 2006  ++++++++ display
% v 0.14 18 Sep 2009  Reduced + marks to one + per 10 trials
% v 0.15 19 Apr 2011  recognize monkeylogic files
%
%
%
% debug   Send event code data to a file.  Probably better off using
%         debug_trial_events in mplx2ctx for debugging.
debug=0;
debug_file_handles=0;
debug_event_search=false;
monkeylogic=false;

if debug_event_search==true
   fprintf('Searching events ');
end
if debug_file_handles
   list_open_files;
end
if debug==1
   fid_debug=fopen('debug.txt','wt');
end

[plx_path,plx_base_name,plx_ext]=fileparts(filename);
if strcmpi(plx_ext, '.bhv')
   monkeylogic=true;
end

% fetch all the stobbed events and times.  On a Plexon, each event code
% is 15 bits, but other systems can provide 16 bits.
try
   if monkeylogic
      [num_events,times,events] = mlx_event_ts(filename, 257);  % event codes
   else
      [num_events,times,events] = plx_event_ts(filename, 257);  % event codes
   end
catch
   num_events=0;
   times=[];
   events=[];
end
if num_events==0
   T=[];
   fprintf(' Warning: No strobed events found in file: %s\n',filename);
   return;
end

% fprintf('%d events in the Plexon file\n',num_events);

% force events to be in chronological order
old_times=times;
[times,sort_index] = sort(times);
events=events(sort_index);
if isequal(old_times,times) && (debug==1)
   fprintf(fid_debug, 'Note: event timestamps were not in chronological order.... fixed.\n');
end

plus_counter=0;
% Go through each trial. 
% Find the start and end of each new Plexon file (to become new Cortex files: .1, .2, etc.)
% Find the start and end of each trial
% Divide up event codes into trials 
% Find analog start and stop events in each trial
file_number=0;
trial=0;
e=1;
while e <= num_events
   % skip ignored event codes
   if isempty(MAP.ignore_events) || isempty(find(events(e)==MAP.ignore_events, 1))
      % search for the next start-of-trial event code
      % this could be much more efficient using a find().
      while events(e) ~= MAP.cortex_start_code
         % if we run into a start-of-file event, increment the file number
         if events(e) == MAP.plexon_start_code
            file_number=file_number+1;
            if debug==1
               fprintf(fid_debug, ' Plexon Start Code found. Start file number %d\n',file_number);
            end
            fprintf('\n Opening file number %d\n',file_number);
            fprintf(' Adding trials +');
            plus_counter=0;
         end % if events(e) == MAP.plexon_start_code
         e=e+1;
         if e > num_events   % see if file is done
            break;           % yes, exit.
         end
         if debug==1
             fprintf(fid_debug, 'Event code %d at time %f\n',events(e),times(e));
         end
      end % while events(e) ~= MAP.cortex_start_code

      if (e >= num_events) && (trial==0)
         fprintf(' Plexon Start Code (%d) not found in the file.  Exiting. \n',MAP.cortex_start_code);
         T=[];
         return;
      end

      % We have a new start-of-trial. Gather events until we run into the next trial or end-of-file
      if e <= num_events
         trial=trial+1;
         if rem(trial,10)==0   % one + mark for every 10 trials
            if debug_event_search
               fprintf('+');
            end
            plus_counter=plus_counter+1;
         end

         if plus_counter > 61
            if debug_event_search
               fprintf('\n');
            end
            plus_counter=0;
         end
         if debug==1
            fprintf(fid_debug, 'Start of trial %d at time %9.4f  in file %d\n',trial,times(e),file_number);
         end
         T(trial).start_time=times(e);
         T(trial).file_number=file_number;
         T(trial).events=[];
         T(trial).times=[];
         if events(e) == MAP.cortex_start_code   % record the start-of-trial event code in this new trial
            T(trial).events=[T(trial).events events(e)];
            T(trial).times= [T(trial).times times(e)];
            e=e+1;
         end
      end  % if e <= num_events

      % add events to trial until we hit the end of the trial or file
      while (e < num_events) && (events(e) ~= MAP.cortex_start_code) && (events(e) ~= MAP.cortex_stop_code)...
           && (events(e) ~= MAP.plexon_start_code) && (events(e) ~= MAP.plexon_stop_code) 
         if debug==1
             fprintf(fid_debug, 'Event code %d at time %1.4f\n',events(e),times(e));
         end
         T(trial).events=[T(trial).events events(e)];
         T(trial).times= [T(trial).times times(e)];
         e=e+1;
      end

      % if the terminating event was a stop code, record this in the trial
      % record trial end time  
      if (e <= num_events) && (events(e) == MAP.cortex_stop_code)
         T(trial).events=[T(trial).events events(e)];
         T(trial).times= [T(trial).times times(e)];
         T(trial).stop_time=times(e);
         e=e+1;   % for next trial
      else
         if e >= num_events
            T(trial).stop_time= times(end);  % use whatever caused us to stop
         else
            T(trial).stop_time= times(e);  
         end
      end

      % record analog start and stop times
      as=find(T(trial).events==MAP.analog_start_code);
      if ~isempty(as)
         T(trial).analog_start_time=T(trial).times(as(1)); 
      else
         T(trial).analog_start_time=-1;  % rule: start code must be in trial
    %     T(trial).analog_start_time=0;  % start at beginning of trial  [ *** alternative rule
      end
      as=find(T(trial).events==MAP.analog_stop_code);
      if ~isempty(as)
         T(trial).analog_stop_time=T(trial).times(as(1)); 
      else
         T(trial).analog_stop_time=-1;       
      end
   else
      e=e+1;
   end %if isempty(find(events(e)==MAP.ignore_events))
end % while e <= num_events

n=length(T);
fprintf('%d trials found\n',n);
T(n+1).start_time=T(n).times(end);   % very last timestamp becomes pseudo start time for trial number n+1 

if debug==1
   fclose(fid_debug);
end