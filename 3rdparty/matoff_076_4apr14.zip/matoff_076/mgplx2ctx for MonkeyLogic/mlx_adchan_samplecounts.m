function [n,samplecounts] = mlx_adchan_samplecounts(filename)
% mlx_adchan_samplecounts(filename): 
%    Read the per-channel sample counts for analog channels from a bhv file
%
% [n,samplecounts] = mlx_adchan_samplecounts(filename)
%
% INPUT:
%   filename 
%
% OUTPUT:
%   n - number of channels
%   samplecounts - array of sample counts
%
%
% Channel translation
%
%   0   EyeSignal  X
%   1   EyeSignal  Y
%   2   Joystick   X
%   3   Joystick   Y
%   4   General.Gen1
%   5   General.Gen2
%   6   General.Gen3
%   7   General.Gen4
%   8   General.Gen5
%   9   General.Gen6
%   10  General.Gen7
%   11  General.Gen8
%   12  General.Gen9
%

n=13;
samplecounts= zeros(1,13);

try
   bhv=bhv_read(filename);
catch
   fprintf(' mlx_adchan_samplecounts: Could not open MonkeyLogic file %s\n',filename);
   return
end


number_of_trials =  bhv.TrialNumber(end)-bhv.TrialNumber(1)+1;

if ~isempty(bhv.AnalogData{1}.EyeSignal)
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      samplecounts(1) = samplecounts(1) + length(bhv.AnalogData{TN}.EyeSignal(:,1));
      samplecounts(2) = samplecounts(1);
   end
end

if ~isempty(bhv.AnalogData{1}.EyeSignal)
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      samplecounts(3) = samplecounts(3) + length(bhv.AnalogData{TN}.Joystick(:,1));
      samplecounts(4) = samplecounts(3);
   end
end

if ~isempty(bhv.AnalogData{1}.General.Gen1)
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      samplecounts(5) = samplecounts(5) + length(bhv.AnalogData{TN}.General.Gen1);
   end
end

if ~isempty(bhv.AnalogData{1}.General.Gen2)
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      samplecounts(6) = samplecounts(6) + length(bhv.AnalogData{TN}.General.Gen2);
   end
end

if ~isempty(bhv.AnalogData{1}.General.Gen3)
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      samplecounts(7) = samplecounts(7) + length(bhv.AnalogData{TN}.General.Gen3);
   end
end

if ~isempty(bhv.AnalogData{1}.General.Gen4)
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      samplecounts(8) = samplecounts(8) + length(bhv.AnalogData{TN}.General.Gen4);
   end
end

if ~isempty(bhv.AnalogData{1}.General.Gen5)
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      samplecounts(9) = samplecounts(9) + length(bhv.AnalogData{TN}.General.Gen5);
   end
end

if ~isempty(bhv.AnalogData{1}.General.Gen6)
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      samplecounts(10) = samplecounts(10) + length(bhv.AnalogData{TN}.General.Gen6);
   end
end

if ~isempty(bhv.AnalogData{1}.General.Gen7)
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      samplecounts(11) = samplecounts(11) + length(bhv.AnalogData{TN}.General.Gen7);
   end
end

if ~isempty(bhv.AnalogData{1}.General.Gen8)
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      samplecounts(12) = samplecounts(12) + length(bhv.AnalogData{TN}.General.Gen8);
   end
end

if ~isempty(bhv.AnalogData{1}.General.Gen9)
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      samplecounts(13) = samplecounts(13) + length(bhv.AnalogData{TN}.General.Gen9);
   end
end


