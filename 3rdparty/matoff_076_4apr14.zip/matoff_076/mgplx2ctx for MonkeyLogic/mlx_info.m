function  [tscounts, wfcounts, evcounts] = mlx_info(filename, fullread)


tscounts=[0; 0];
wfcountes=[0; 0];
evcounts = [0; 0];
