function [ new_chan_n ]= make_external_plx_ad(filename, ch, offset)
% make_external_plx_ad(filename, channel list): Read a/d data from a .plx file
% and save it as an external analog file with new channel numbering
%
% number_of_channels = make_external_plx_ad(filename, ch)
%
% INPUT:
%   filename without extension.  reads .plx creates .mat with a variable named E
%   ch   array of 0-based channel numbers. These are Plexon channel - 1.
%  offset  this value is added to each channel number to create new channel numbers
%
% OUTPUT:
%   new channel numbers of channels saved (0 based).  Only saves channels with data. 
%   Saved as a MATLAB .MAT file

new_chan_n=[];
chan_n=0;
for c=1:length(ch) 
   fprintf (['   Reading  '  filename '.plx, Plexon channel %d  '],ch(c)+1);
   try
      [adfreq, n, ts, fn, ad] = plx_ad([filename '.plx'],ch(c));
   catch MKEXT_NOCHAN
       fprintf ('   Problem reading Plexon channel %d ( = CDK channel %d)\n', ch(c)+1, ch(c));
       n=0;  
   end
   if n > 0
      new_chan_n=[new_chan_n  ch(c)+offset]; % not pre-alocated because length is used to measure success
      fprintf ([' ==> Creating ' filename '.mat, Plexon channel %d\n'],ch(c)+offset+1);
      % create structure from Plexon values
      chan_n=chan_n+1;
      E(chan_n).ch=ch(c)+offset;
      E(chan_n).adfreq=adfreq;
      E(chan_n).n=n;
      E(chan_n).ts=ts;
      E(chan_n).fn=fn;
      E(chan_n).ad=ad;
   end % if
   
end % for

if chan_n > 0
   save(filename, 'E');
else
   fprintf(['   None of the requested analog channels found in file ' filename '.plx. No external analog file saved.\n']);
end


