function [adfreq, n, ts, fn, ad] = mlx_ad(filename, ch)
% mlx_ad(filename, channel): Read a/d data from a .plx file
%
% [adfreq, n, ts, fn, ad] = plx_ad(filename, ch)
%
% INPUT:
%   filename - if empty string, will use File Open dialog
%   channel - 0-based channel number
%
%           a/d data come in fragments. Each fragment has a timestamp
%           and a number of a/d data points. The timestamp corresponds to
%           the time of recording of the first a/d value in this fragment.
%           All the data values stored in the vector ad.
% 
% OUTPUT:
%   adfreq - digitization frequency for this channel
%   n - total number of data points 
%   ts - array of fragment timestamps (one timestamp per fragment, in seconds)
%   fn - number of data points in each fragment
%   ad - array of raw a/d values (column array)
%
%
% Channel translation
%
%   0   EyeSignal  X
%   1   EyeSignal  Y
%   2   Joystick   X
%   3   Joystick   Y
%   4   General.Gen1
%   5   General.Gen2
%   6   General.Gen3
%   7   General.Gen4
%   8   General.Gen5
%   9   General.Gen6
%   10  General.Gen7
%   11  General.Gen8
%   12  General.Gen9

% we should have one fragment per trial

bhv=[];
adfreq=1;
n=0;
ts=[];
fn=[];
ad=[];

try
   bhv=bhv_read(filename);
catch
   fprintf('mlx_ad: Could not open MonkeyLogic file %s\n',filename);
   return
end

adfreq = bhv.AnalogInputFrequency;
number_of_trials =  bhv.TrialNumber(end)-bhv.TrialNumber(1)+1;

if ch < 0 || ch > 12
   fprintf ('mxl_ax: A/D Channel number out of range\n');

if ch == 0
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      fn = [fn   size(bhv.AnalogData{TN}.EyeSignal(:,1),1)];
      ad = [ad bhv.AnalogData{TN}.EyeSignal(:,1)];
   end
elseif ch==1
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      fn = [fn   size(bhv.AnalogData{TN}.EyeSignal(:,2),1)];
      ad = [ad bhv.AnalogData{TN}.EyeSignal(:,2)];
   end
elseif ch==2
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      fn = [fn   size(bhv.AnalogData{TN}.Joystick(:,1),1)];
      ad = [ad bhv.AnalogData{TN}.Joystick(:,1)];
   end
elseif ch==3
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      fn = [fn   size(bhv.AnalogData{TN}.Joystick(:,2),1)];
      ad = [ad bhv.AnalogData{TN}.Joystick(:,2)];
   end
elseif ch==4
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      fn = [fn   size(bhv.AnalogData{TN}.General.Gen1,1)];
      ad = [ad bhv.AnalogData{TN}.General.Gen1];
   end
elseif ch==5
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      fn = [fn   size(bhv.AnalogData{TN}.General.Gen2,1)];
      ad = [ad bhv.AnalogData{TN}.General.Gen2];
   end
elseif ch==6
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      fn = [fn   size(bhv.AnalogData{TN}.General.Gen3,1)];
      ad = [ad bhv.AnalogData{TN}.General.Gen3];
   end
elseif ch==7
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      fn = [fn   size(bhv.AnalogData{TN}.General.Gen4,1)];
      ad = [ad bhv.AnalogData{TN}.General.Gen4];
   end
elseif ch==8
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      fn = [fn   size(bhv.AnalogData{TN}.General.Gen5,1)];
      ad = [ad bhv.AnalogData{TN}.General.Gen5];
   end
elseif ch==9
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      fn = [fn   size(bhv.AnalogData{TN}.General.Gen6,1)];
      ad = [ad bhv.AnalogData{TN}.General.Gen6];
   end
elseif ch==10
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      fn = [fn   size(bhv.AnalogData{TN}.General.Gen7,1)];
      ad = [ad bhv.AnalogData{TN}.General.Gen7];
   end
elseif ch==11
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      fn = [fn   size(bhv.AnalogData{TN}.General.Gen8,1)];
      ad = [ad bhv.AnalogData{TN}.General.Gen8];
   end
elseif ch==12
   for TN=bhv.TrialNumber(1):bhv.TrialNumber(end)
      fn = [fn   size(bhv.AnalogData{TN}.General.Gen9,1)];
      ad = [ad bhv.AnalogData{TN}.General.Gen9];
   end
end


n = size(ad,2);

ts = [ 0 ];
for T=2:length(fn)-2
   ts = [ts etime(bhv.AbsoluteTrialStartTime(T,:),bhv.AbsoluteTrialStartTime(1,:))];
end

