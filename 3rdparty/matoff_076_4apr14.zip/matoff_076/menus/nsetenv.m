function [response]=nsetenv(ercmd)
%
%  Decode a set environment command. Was originally called setenv, but that
%  conflicts with a built-in MATLAB command.
%
%  Inputs
%    rcmd     command
%  Outputs
%    response
%          0   unrecognized variable
%          1   normal return
%          2   recognized, but no longer used
%  Globals modified
%    environment
%
%  Should probably do more error checking here
%
%  The Environment Menu was built as an afterthought.
%  Thus, the menu is not the primary storage for the
%  environmental variables.  Care must be taken to keep
%  the environment variable in sync with the Environment Menu.
%

global environment
global error_fid warning_fid debug_fid
global errors warnings debugs

ercmd=strrep(ercmd,'=',' ');
% setenv ENV_VAR newvalue
[dummy,rem]=strtok(ercmd);
[dummy,rem]=strtok(ercmd);
[rcmd,v]=strtok(rem);
if length(v) < 1
   response=0;  % no value
   return;
end;
newvalue=strtrim(v(2:end));
rcmd=upper(rcmd);  % force to upper case

response=1;

cmd_len=length(rcmd);   % Length of command string

if ~isempty(findstr(rcmd,'ANALOGSTART')) && cmd_len >= 11
   environment.analogstart=newvalue;
   set(findobj('tag','env_analogstart'),'string',environment.analogstart);
elseif  ~isempty(findstr(rcmd,'ANALOGSTOP')) && cmd_len >= 10
   environment.analogstop=newvalue;
   set(findobj('tag','env_analogstop'),'string',environment.analogstop);
elseif  ~isempty(findstr(rcmd,'DATAPATH')) && cmd_len >= 8
   environment.datapath=cleanpath(newvalue);
   set(findobj('tag','env_datapath'),'string',environment.datapath);
elseif  ~isempty(findstr(rcmd,'DEFAULTPATH')) && cmd_len >= 11
   environment.defaultpath=cleanpath(newvalue);
   set(findobj('tag','env_defaultpath'),'string',environment.defaultpath);   
elseif  ~isempty(findstr(rcmd,'DUMPTEXT')) && cmd_len >= 8
   environment.dumptext=newvalue;
   set(findobj('tag','env_dumptext'),'string',environment.dumptext);
elseif  ~isempty(findstr(rcmd,'DUMPLABEL')) && cmd_len >= 9
   environment.dumplabel=newvalue;  
elseif  ~isempty(findstr(rcmd,'DUMPMODE')) && cmd_len >= 8
   environment.dumpmode=newvalue;  
elseif  ~isempty(findstr(rcmd,'DUMPPATH')) && cmd_len >= 8
   environment.dumppath=cleanpath(newvalue);
   set(findobj('tag','env_dumppath'),'string',environment.dumppath);
elseif  ~isempty(findstr(rcmd,'EDITOR')) && cmd_len >= 6
   environment.editor=newvalue; 
   set(findobj('tag','env_editor'),'string',environment.editor);  
elseif  ~isempty(findstr(rcmd,'EOGSAMPLERATE')) && cmd_len >= 13
   environment.eogsamplerate=newvalue; 
   set(findobj('tag','env_eogsamplerate'),'string',environment.eogsamplerate);   
elseif  ~isempty(findstr(rcmd,'EVENTCODEFILE')) && cmd_len >= 13
   environment.eventcodefile=newvalue;  
   set(findobj('tag','env_eventcodefile'),'string',environment.eventcodefile);
elseif  ~isempty(findstr(rcmd,'FORMATPATH')) && cmd_len >= 10
   environment.formatpath=cleanpath(newvalue);
   set(findobj('tag','env_formatpath'),'string',environment.formatpath);
elseif  ~isempty(findstr(rcmd,'GRAPHICSFORMAT')) && cmd_len >= 14
   environment.graphicsformat=newvalue; 
   set(findobj('tag','env_graphicsformat'),'string',environment.graphicsformat);
elseif  ~isempty(findstr(rcmd,'HISTORYPATH')) && cmd_len >= 10
   environment.historypath=cleanpath(newvalue);  
   set(findobj('tag','env_historypath'),'string',environment.historypath);
elseif  ~isempty(findstr(rcmd,'LAYOUTPATH')) && cmd_len >= 10
   environment.layoutpath=cleanpath(newvalue);  
   set(findobj('tag','env_layoutpath'),'string',environment.layoutpath);
elseif  ~isempty(findstr(rcmd,'MAKDAT')) && cmd_len >= 6
   environment.makdat=newvalue;
   set(findobj('tag','env_makdat'),'string',environment.makdat);
elseif  ~isempty(findstr(rcmd,'MAKDUMP')) && cmd_len >= 7
   if isempty(newvalue)
      environment.makdump='';
   else
      environment.makdump=newvalue;
   end;
   set(findobj('tag','env_makdump'),'string',environment.makdump);  
elseif  ~isempty(findstr(rcmd,'MAXINPUTTRIALS')) && cmd_len >= 14
   environment.maxinputtrials=newvalue;
   set(findobj('tag','env_maxinputtrials'),'string',environment.maxinputtrials);
elseif  ~isempty(findstr(rcmd,'MAXTRIALSFOUND')) && cmd_len >= 14
   newvalue=strrep(newvalue,'"','');  % remove double quote marks
   newvalue=strrep(newvalue,'''',''); % remove single quote marks
   environment.maxtrialsfound=newvalue; 
   set(findobj('tag','env_maxtrialsfound'),'string',environment.maxtrialsfound);  

elseif  ~isempty(findstr(rcmd,'SPIKETIMEOFFSET')) && cmd_len >= 15
   newvalue=strrep(newvalue,'"','');  % remove double quote marks
   newvalue=strrep(newvalue,'''',''); % remove single quote marks
   environment.spiketimeoffset=newvalue; 
   set(findobj('tag','env_spiketimeoffset'),'string',environment.spiketimeoffset);  

elseif  ~isempty(findstr(rcmd,'METACHAR1')) && cmd_len >= 9
   environment.metachar1=newvalue;
   set(findobj('tag','env_metachar1'),'string',environment.metachar1);
elseif  ~isempty(findstr(rcmd,'METACHAR2')) && cmd_len >= 9
   environment.metachar2=newvalue;
   set(findobj('tag','env_metachar2'),'string',environment.metachar2);
elseif  ~isempty(findstr(rcmd,'METAPATH')) && cmd_len >= 8
   environment.metapath=cleanpath(newvalue);
   set(findobj('tag','env_metapath'),'string',environment.metapath);
elseif  ~isempty(findstr(rcmd,'PLOTPATH')) && cmd_len >= 8
   environment.plotpath=cleanpath(newvalue);
   set(findobj('tag','env_plotpath'),'string',environment.plotpath);
elseif  ~isempty(findstr(rcmd,'PROTOCOLPATH')) && cmd_len >= 12
   environment.protocolpath=cleanpath(newvalue);
   set(findobj('tag','env_protocolpath'),'string',environment.protocolpath);
elseif  ~isempty(findstr(rcmd,'REMAPFILE'))  && cmd_len >= 9
   environment.remapfile=newvalue; 
   set(findobj('tag','env_remapfile'),'string',environment.remapfile);
elseif  ~isempty(findstr(rcmd,'STATPATH')) && cmd_len >= 8
   environment.statpath=cleanpath(newvalue);
   set(findobj('tag','env_statpath'),'string',environment.statpath);

elseif  ~isempty(findstr(rcmd,'ANALOGMIN')) && cmd_len >= 8
   environment.analog_min=newvalue;
elseif  ~isempty(findstr(rcmd,'ANALOGMAX')) && cmd_len >= 8
   environment.analog_max=newvalue;
else
   response=0;  % unrecognized
end;


function [path]=cleanpath (rpath)
%
% cleanpath  assure proper formatting of a path environmental variable
%            by removing any trailing "\" 
if isempty(rpath)
   path=rpath;  % empty string
   return;
end;
if strcmp(rpath(end),'\') && (length(rpath) > 1)
   path=rpath(1:end-1);
else
   path=rpath;
end;

   