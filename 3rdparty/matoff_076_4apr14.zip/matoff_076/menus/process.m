function [response]=process
% 
%  Execute data processing steps based on current value of "taint".
%  Update taint.
%
% Output
%    response   1  ready to plot (mapping completed)
%               0  not ready to plot
% Globals modified
%    taint   10  need to open a file
%            20  need to scan
%            30  need to accumulate
%            40  need to map
%            50  ready to plot
%    spike_counts
%

global taint spike_counts
global error_fid warning_fid debug_fid
global errors warnings debugs
global time_zero
global fid fn environment

response=0;
if debugs
   fprintf(debug_fid,'Debug [process]. Taint=%d .\n',taint);
end
% Check for a valid open file.  Exit if no file found.
if taint <= 10
   if warnings
      fprintf(warning_fid,'Warning [process]. No file open.\n');
   end
end

% Scan for trials.  Exit if no trials found, otherwise update GUI.
if (taint > 10) & (taint <= 20)
   [trials_found,spike_counts]=scan;
   if isempty(trials_found)  % bail out if nothing found
      if warnings
         fprintf(warning_fid,'Warning [process]. No trials found.\n');
      end
   else
      taint=30;
      if sum(spike_counts)> 0
         fprintf(1,'Number of spikes found in each channel:\n');
      end
      for i=1:length(spike_counts)
         if spike_counts(i) > 0
            fprintf(1,'  Chan: %d has %d spikes\n',i-1,spike_counts(i));
            if environment.logging==1
               fprintf(fid.log,'spike chan: %d has %d spikes\n',i-1,spike_counts(i));
            end
         end
      end
      % update GUI
      if debugs
         fprintf(debug_fid,'Debug [process]. Updating GUI with trial count and spike count.\n');
      end
      set(findobj('Tag','trialsfound'),'String',num2str(trials_found));
      pulse_channel=get(findobj('Tag','spikechannelmenu'),'Value')-1;
      if (pulse_channel >= 0) & get(findobj('Tag','spikechannelmenu'),'UserData')
         if length(spike_counts) >= (pulse_channel+1)
            spikecount=spike_counts(pulse_channel+1);
         else
            spikecount=0;
         end
         set(findobj('Tag','pulsesfound'),'String',num2str(spikecount));
      else
         set(findobj('Tag','pulsesfound'),'String','off');
      end
      
   end
end

% Accumulate does nothing
if (taint > 20) & (taint <= 30)
   taint=40;
end

% Map trials for plotting, force remap if no trials mapped
if (taint > 30) & (taint <= 40)
   trials_found=map;
   fprintf(1,'%d trials mapped.\n',trials_found);
   if environment.logging==1
      fprintf(fid.log,'%d trials mapped.\n',trials_found);
   end
   response=trials_found;
   if isempty(time_zero)
      if warnings
         fprintf(warning_fid,'Warning [process]. Cannot plot data without proper CENTER time.\n');
      end
      taint=20;
      response=0;
   end
   if response > 0
      taint=50;
   end
end
if taint>=50
   response=1;
end

if response==0
   fprintf(1,'Cannot create plot\n');
   if environment.logging==1
      fprintf(fid.log,'Cannot create plot\n');
   end
end