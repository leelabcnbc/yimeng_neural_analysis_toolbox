function[response]=old_plot(pnumber,overplot)
% Update plot based on layout parameters. Use an existing plot number.
% Will cycle through entire layout list
%
% Inputs
%    pnumber    plot number (figure number) of existing plot
%    overplot     if overplot=1, do not create a new figure or change the handles
% Outputs 
%    response   from make_plot
% Globals changed
%    current_layout
% 

global layouts current_layout plot_number
global error_fid warning_fid debug_fid
global environment fid
global errors warnings debugs

layout_count=0;
layout_list=expand_range_list(get(findobj('Tag','displays'),'String'));
if strcmp(layout_list,'@')
   if errors
      fprintf(error_fid,'Error [old_plot]. Invalid layout list');
   end;
   return;
end;
for layout_number=layout_list
   % set up the next display
   fprintf(1,'layout %d\n',layout_number);
   if environment.logging==1
      fprintf(fid.log,'layout %d\n',layout_number);
   end;
   if ((layout_number > 0) & (layout_number <= 10)& (layout_number ~= current_layout))
     set_layout(layouts(layout_number));
     set(findobj('Tag','layout_number'),'String',num2str(layout_number));
     current_layout=layout_number;
   else
      if layout_number ~= current_layout
         if errors
            fprintf(error_fid,'Error [old_plot]. Invalid layout number.\n');
         end; 
      end;
   end;
   
   if overplot==1       % overplot uses current figure and axis
      figure(pnumber);
      do_not_move=2;
   else
      figure(pnumber+layout_count);
      if str2num(get(findobj('Tag','subplot_total'),'String')) == 1
         clf;
      end;
      set(pnumber+layout_count,'Units','Normalized');
      plot_number=pnumber; 
      do_not_move=1;
   end;

   if get(findobj('Tag','xy_on_off'),'Value') | get(findobj('Tag','avexy_on_off'),'Value')
      handles=xy_figure(do_not_move);
   else
      handles=raster_figure(do_not_move);
   end;

   response=make_plot(handles,0);
   if overplot==0
      layout_count=layout_count+1;
   end;
end;
