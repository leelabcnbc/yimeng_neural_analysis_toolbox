function [selected_event_data]=read_event_record(event_record_fid,trial_list)
%
%  Collect event codes and their times from a range of trials 
%  in the data file.
%  
%  Inputs
%     event_record_fid                 handle of event file
%     trial_list          list of file trials to fetch from disk
%  Outputs
%    selected_event_data  columns: events(trial1) times(trial1) events(trial2) times(trial2) ...
%  Globals modified
%    cach_trials.event    vector with 2 entries: [lowest highest] file trial numbers in cache
%    event_data_cache     row 1: event codes, row 2: event times
%
global cache_trials work_index work_udf
global event_data_cache
global error_fid warning_fid debug_fid
global errors warnings debugs

selected_event_data=[];

if isempty(trial_list)
   if debugs
      fprintf(debug_fid,'Debug [read_event_record]. Empty trial list requested.\n');
   end;
   return;
end;

if debugs
   fprintf(debug_fid,'Debug [read_event_record]. %d trials of event data requested.\n',length(trial_list));
end;

low_trial=min(trial_list);
high_trial=max(trial_list);

if high_trial > length(work_index)
   fprintf(error_fid, 'Error [read_event_record]. Requested trial exceeds index size.\n');
   return;
end;

% are the requested file trials in the cache?

if (low_trial >= cache_trials.event(1)) & (high_trial <= cache_trials.event(2))
   if debugs
      fprintf(debug_fid,'Debug [read_event_record]. Requested event data trials were found in cache.\n');
   end;
   [selected_event_data]=collate_trials(event_data_cache,cache_trials.event,trial_list);
   return;
end;

% File trials are not in cache, go get them from data file
starting_file_position=work_index(low_trial).event_start_position;
number_of_records=0;

for t=low_trial:high_trial
   number_of_records=number_of_records+work_index(t).event_records;  % size of datablock to pull from file
end;

if debugs
   fprintf(debug_fid,'Debug [read_event_record]. Requested event data trials not in cache, reading from file.\n');
   fprintf(debug_fid,'Debug [read_event_record]. Starting file position: %d   Number of records: %d \n', ...
      starting_file_position, number_of_records);
end;

try
   fseek(event_record_fid,starting_file_position,'bof');
catch
   if errors
      fprintf(error_fid,'Error [read_event_record]. Tried to read past end of the event file.\n');
   end;
   selected_event_data=[];
   return;
end;

try
   event_data_cache=fread(event_record_fid,[2 number_of_records],'int32');   % read from file
   cache_trials.event=[low_trial high_trial];
catch
   if errors
      fprintf(error_fid,'Error [read_event_record].  Error reading event data.\n');
      fprintf(error_fid,'Starting offset: %-5d , number of records: %-5d \n', ...
             starting_file_position,number_of_records);
   end;
   cache_trials.event=[0 0];   % values no longer valid    
   selected_event_data=[];
   return;
end;

% pluck out data for requested file trials
[selected_event_data]=collate_trials(event_data_cache,cache_trials.event,trial_list);

return;

