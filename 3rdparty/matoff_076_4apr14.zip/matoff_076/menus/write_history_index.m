function [success]=write_history_index(file_name,hindex)
%
%  Writes the entire history index file.
% Inputs
%   file_name    name of data file with no extension, includes all path information
%   hindex(entry_number).unitname          unit name ascii string (1 to 12 characters)
%                       .history_start     pointer to start of this trial history in the history file
%                       .history_length    number of bytes in history record
%
%
%  success < 0 if an error occurs
%
global error_fid warning_fid debug_fid
global errors warnings debugs
global MAX_UNIT_NAME

max_unit_name=num2str(eval('MAX_UNIT_NAME'));   % get values and convert to string
success=0;

if isempty(file_name)
   if errors
      fprintf(error_fid,'Error [write_history_index]. History index file name is empty. Cannot write history index.\n');
   end;
   success=-1;   % -1  empty file name
   return;
end;

hindex_file_name=[file_name '.hindex'];
if debugs
   fprintf(debug_fid,'Debug [write_history_index]. Opening file to write %s\n',hindex_file_name);
end;
hindex_fid=fopen(hindex_file_name,'wb+');   % overwrite any existing file
if hindex_fid < 1
   if warnings
      fprintf(error_fid,'Warning [write_history_index]. Error trying to create history index file for: %s.\n',hindex_file_name);
   end;
   success=-2;  % -2  file open error
   return;
end;
if debugs
   fprintf(debug_fid,'Debug [write_history_index]. history index fid= %d\n',hindex_fid);
end;

for unit=1:length(hindex)
   if debugs
      fprintf(debug_fid,'Debug [write_history_index]. Writing history index for unit = %s\n',hindex(unit).unitname);
   end;
   try   
      unit_name=[hindex(unit).unitname zeros(1,MAX_UNIT_NAME-length(hindex(unit).unitname))];      % force unit name to full size of field
      fwrite(hindex_fid,unit_name,[max_unit_name '*char']);                                        % 12 byte unit name
      fwrite(hindex_fid,hindex(unit).history_start,'uint32');      % location of first history record for this trial in history file
      fwrite(hindex_fid,hindex(unit).history_length,'uint32');     % size of history record for this trial
   catch
      if errors
         fprintf(error_fid, 'Error [write_history_index]. Error writing history index file.\n');
      end;
      fclose(hindex_fid); 
      hindex_fid= -1;
      success = -3;  
      return;
   end; % try
end;  % for


try   
   unit_name=['END_OF_FILE' zeros(1,MAX_UNIT_NAME-length('END_OF_FILE'))];      % force EOF string to full size of field
   fwrite(hindex_fid,unit_name,[max_unit_name '*char']);    
   fwrite(hindex_fid,0,'uint32');     % location of first history record for this trial in history file
   fwrite(hindex_fid,0,'uint32');     % size of history record for this trial
catch
   if errors
      fprintf(error_fid, 'Error [write_history_index]. Error writing EOF record into index file.\n');
   end;
   fclose(hindex_fid);
   hindex_fid=-1;
      success=-4;
   return;
end;  % try/catch

if debugs
   fprintf(debug_fid,'Debug [write_history_index]. Successful write.  Closing index file\n');
end;
fclose(hindex_fid);
hindex_fid=-1;
success=1;            % successful write
% END