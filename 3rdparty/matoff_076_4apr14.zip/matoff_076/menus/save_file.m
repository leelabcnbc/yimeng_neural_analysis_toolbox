function save_file(file_name,options)
%
%  Create a protocol file.  Saves all the file, sequence, and layout parameters.
%
%  Inputs
%     file_name    file name for the save. Is prepended by PROTOCOLPATH parameter
%     options
%                  layout   include the layout parameters
%                  only     save only the layout parameters
%
global environment

state={'NOSHOW';'SHOW'};  % useful constants
off_on={'OFF';'ON';'OFF'}; % use values 1,2 for off/on and 2,3 for on/off
histogram_raw={'RAWCOUNTS';'NORMALCOUNTS'};

% use .pro suffix if none given
[path,name,ext]=fileparts(file_name);
if isempty(ext)
   ext='.pro';
end;
file_name=fullfile(path,[name ext]);

% prepend the path for this protocol file
file_name=filepath(file_name,environment.protocolpath); 

save_fid=fopen(file_name,'wt');  % open a DOS file for text writing

option_list=deblank(strjust(options,'left'));

% start writing to file
fprintf(save_fid,'BEGIN\n');

if isempty(findstr(option_list,'only'))
   % basic variables
   fprintf(save_fid,'FILE %s\n',get(findobj('Tag','filename'),'String'));
   entry_number=get(findobj('Tag','unit'),'Value');
   unit_string=get(findobj('Tag','unit'),'String');
   unit=deblank(strjust(unit_string(entry_number,:),'left'));
   fprintf(save_fid,'UNIT %s\n',unit);
   glo=get(findobj('Tag','globalignore'),'String');
   if isempty(glo) 
      glo='[]';   % without brackets, parse_command thinks you want a response
   end;
   fprintf(save_fid,'GLOBALIGNORE %s\n',glo);
   fprintf(save_fid,'SEQUENCE %s\n',get(findobj('Tag','sequence'),'String'));
   fprintf(save_fid,'CENTER %s\n',get(findobj('Tag','center'),'String'));
   fprintf(save_fid,'MARK %s\n',get(findobj('Tag','mark'),'String'));
   fprintf(save_fid,'SPOT %s\n',get(findobj('Tag','spot'),'String'));
   fprintf(save_fid,'SOURCE %s\n',get(findobj('Tag','source'),'String'));
   fprintf(save_fid,'SPAN %s\n',get(findobj('Tag','span'),'String'));
   fprintf(save_fid,'TRIALS %s\n',get(findobj('Tag','trials'),'String'));
   if get(findobj('Tag','spikechannelmenu'),'UserData');
      fprintf(save_fid,'PULSECHANNEL %d\n',get(findobj('Tag','spikechannelmenu'),'Value')-1);
   else
      fprintf(save_fid,'PULSECHANNEL OFF\n');
   end;
   fprintf(save_fid,'FREQUENCY %s\n',get(findobj('Tag','frequency'),'String'));
   fprintf(save_fid,'WINDOW %s\n',get(findobj('Tag','window'),'String'));
   fprintf(save_fid,'SHIFT %s\n',get(findobj('Tag','shift'),'String'));
   chan1=get(findobj('Tag','xchannelmenu'),'Value')-1;
   if chan1==0
      fprintf(save_fid,'ANALOG OFF\n');
   else
      fprintf(save_fid,'ANALOGCHANNEL %d\n',chan1);
   end;

   chan2=get(findobj('Tag','ychannelmenu'),'Value')-1;
   if chan2==0
      fprintf(save_fid,'ANA2 OFF\n');
   else
      fprintf(save_fid,'ANA2 %d\n',chan2);
   end;

   % sort
   sort_option_list=get(findobj('Tag','trialsort'),'String');
   sort_option=get(findobj('Tag','trialsort'),'value');
   sort_option=deblank(sort_option_list(sort_option,:));
   if strcmp(sort_option,'pulse') 
      sort_option=[sort_option ' ' get(findobj('Tag','pulsesortrange1'),'String') ...
            ' ' get(findobj('Tag','pulsesortrange2'),'String')   ]; 
   end;
   cmd=['SORT ' sort_option];
   fprintf(save_fid,'%s\n',cmd);
   
   % units and segments
   cmd=['SEGMENT ' char(state(1+get(findobj('Tag','segments_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['SEGMENT A '  get(findobj('Tag','segmenta1'),'String') ' ' get(findobj('Tag','segmenta2'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['SEGMENT B '  get(findobj('Tag','segmentb1'),'String') ' ' get(findobj('Tag','segmentb2'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   

end;

if ~isempty(findstr(option_list,'only')) | ...
      ~isempty(findstr(option_list,'layout'))
   
   
      
   % ================== Layout ======================

   % raster
   cmd=['RASTER ' char(state(1+get(findobj('Tag','raster_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['RASTER SIZE ' get(findobj('Tag','raster_tic_size'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['RASTER LABEL ' get(findobj('Tag','raster_label_size'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['RASTER YPOS ' get(findobj('Tag','raster_y_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['RASTER SEPARATION ' get(findobj('Tag','raster_separation'),'String')];
   fprintf(save_fid,'%s\n',cmd);


   % 1st analog
   cmd=['ANALOG ' char(state(1+get(findobj('Tag','analog_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['ANALOG SIZE ' get(findobj('Tag','analog_trace_size'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['ANALOG YPOS ' get(findobj('Tag','analog_y_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['ANALOG LINE ' num2str(get(findobj('Tag','analog_style'),'Value'))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['ANALOG SEPARATION ' get(findobj('Tag','analog_separation'),'String')];
   fprintf(save_fid,'%s\n',cmd);


   % AvAnalog (average of 1st analog)
   cmd=['AvANALOG ' char(state(1+get(findobj('Tag','average_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['AvANALOG SIZE ' get(findobj('Tag','average_trace_size'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['AvANALOG YPOS ' get(findobj('Tag','average_y_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['AvANALOG LINE ' num2str(get(findobj('Tag','average_style'),'Value'))];
   fprintf(save_fid,'%s\n',cmd);


   % 2nd analog
   cmd=['ANA2 ' char(state(1+get(findobj('Tag','analog2_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['ANA2 SIZE ' get(findobj('Tag','analog2_trace_size'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['ANA2 YPOS ' get(findobj('Tag','analog2_y_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['ANA2 LINE ' num2str(get(findobj('Tag','analog2_style'),'Value'))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['ANA2 SEPARATION ' get(findobj('Tag','analog2_separation'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   
   % first dx/dt
   cmd=['FirstDx ' char(state(1+get(findobj('Tag','dxdt_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['FirstDx SIZE ' get(findobj('Tag','dxdt_trace_size'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['FirstDx YPOS ' get(findobj('Tag','dxdt_y_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['FirstDx LINE ' num2str(get(findobj('Tag','dxdt_style'),'Value'))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['FirstDx SEPARATION ' get(findobj('Tag','dxdt_separation'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   
   % first dx/dt for analog 2
   cmd=['Fir2Dx ' char(state(1+get(findobj('Tag','dxdt2_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['Fir2Dx SIZE ' get(findobj('Tag','dxdt2_trace_size'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['Fir2Dx YPOS ' get(findobj('Tag','dxdt2_y_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['Fir2Dx LINE ' num2str(get(findobj('Tag','dxdt2_style'),'Value'))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['Fir2Dx SEPARATION ' get(findobj('Tag','dxdt2_separation'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   
   % Av2Analog (average of 2nd analog)
   cmd=['Av2ANALOG ' char(state(1+get(findobj('Tag','average2_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['Av2ANALOG SIZE ' get(findobj('Tag','average2_trace_size'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['Av2ANALOG YPOS ' get(findobj('Tag','average2_y_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['Av2ANALOG LINE ' num2str(get(findobj('Tag','average2_style'),'Value'))];
   fprintf(save_fid,'%s\n',cmd);


   % X-Y analog
   cmd=['XY OVERLAP ' char(off_on(1+get(findobj('Tag','xy_overlap_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['XY ' char(state(1+get(findobj('Tag','xy_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['XY SIZE ' get(findobj('Tag','xy_trace_size'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['XY XPOS ' get(findobj('Tag','xy_x_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['XY YPOS ' get(findobj('Tag','xy_y_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['XY LINE ' num2str(get(findobj('Tag','xy_style'),'Value'))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['XY SEPARATION ' get(findobj('Tag','xy_separation'),'String')];
   fprintf(save_fid,'%s\n',cmd);


   % X-Y time range
   time_range_index=get(findobj('Tag','xy_time_criteria'),'value');
   time_range_start=get(findobj('Tag','xy_time_start'),'string');
   time_range_stop=get(findobj('Tag','xy_time_stop'),'string');
   if time_range_index==1  
      cmd=['XY TIME ALL'];
   elseif time_range_index==2
      cmd=['XY TIME TIME ' time_range_start ' ' time_range_stop];
   elseif time_range_index==3
      cmd=['XY TIME EVENTS ' time_range_start ' ' time_range_stop];
   elseif time_range_index==4
      cmd=['XY TIME CLASSES ' time_range_start ' ' time_range_stop];
   end;
   fprintf(save_fid,'%s\n',cmd);

   % History spot
   cmd=['HISTORY SPOT ' char(state(1+get(findobj('Tag','history_spot_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['HISTORY SPOT FIRSTCLASS ' get(findobj('Tag','history_spot_first_class'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['HISTORY SPOT LASTCLASS ' get(findobj('Tag','history_spot_last_class'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   color_list=get(findobj('Tag','history_spot_color'),'string');
   color_item_number=get(findobj('Tag','history_spot_color'),'value'); 
   cmd=['HISTORY SPOT COLOR ' color_list(color_item_number,:)];
   fprintf(save_fid,'%s\n',cmd);

   % Validate spikes
   cmd=['VALIDATESPIKES ' char(off_on(1+get(findobj('Tag','validate_spikes_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['VALIDATESPIKES STARTCLASS ' get(findobj('Tag','valid_spikes_start_class'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['VALIDATESPIKES ENDCLASS ' get(findobj('Tag','valid_spikes_end_class'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   color_list=get(findobj('Tag','invalid_spike_color'),'string');
   color_item_number=get(findobj('Tag','invalid_spike_color'),'value'); 
   cmd=['VALIDATESPIKES COLOR ' color_list(color_item_number,:)];
   fprintf(save_fid,'%s\n',cmd);


   % Average X-Y    - not implemented in make_plot yet
   cmd=['AvXY ' char(state(1+get(findobj('Tag','avxy_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['AvXY SIZE ' get(findobj('Tag','avxy_trace_size'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['AvXY XPOS ' get(findobj('Tag','avxy_x_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['AvXY YPOS ' get(findobj('Tag','avxy_y_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['AvXY LINE ' num2str(get(findobj('Tag','avxy_style'),'Value'))];
   fprintf(save_fid,'%s\n',cmd);


   % histogram
   cmd=['HISTOGRAM ' char(state(1+get(findobj('Tag','histogram_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['HISTOGRAM SIZE ' get(findobj('Tag','histogram_size'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['HISTOGRAM YPOS ' get(findobj('Tag','histogram_y_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['HISTOGRAM LINE ' num2str(get(findobj('Tag','histogram_style'),'Value'))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['BINWIDTH ' get(findobj('Tag','histogram_binwidth'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['SCALE ' get(findobj('Tag','histogram_scale'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['HISTOGRAM SCALE ' char(state(1+get(findobj('Tag','histogram_scale_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['HISTOGRAM ' char(histogram_raw(1+get(findobj('Tag','histogram_raw_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['HISTOGRAM REFERENCE' char(off_on(1+get(findobj('Tag','histogram_ref_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['HISTOGRAM REFERENCE ' get(findobj('Tag','histogram_ref_limits'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   color_list=get(findobj('Tag','histogram_ref_color'),'string');
   color_item_number=get(findobj('Tag','histogram_ref_color'),'value'); 
   cmd=['HISTOGRAM REFERENCE COLOR ' color_list(color_item_number,:)];
   fprintf(save_fid,'%s\n',cmd);

   % RIP
   cmd=['RIP ' char(state(1+get(findobj('Tag','RIP_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['RIP SIZE ' get(findobj('Tag','RIP_size'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['RIP YPOS ' get(findobj('Tag','RIP_y_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['RIP LINE ' num2str(get(findobj('Tag','RIP_style'),'Value'))];
   fprintf(save_fid,'%s\n',cmd);

   % center line
   cmd=['CENTERLINE ' char(state(1+get(findobj('Tag','centerline_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['CENTERLINE SIZE ' get(findobj('Tag','centerline_size'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['CENTERLINE YPOS ' get(findobj('Tag','centerline_y_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['CENTERLINE LINE ' num2str(get(findobj('Tag','centerline_style'),'Value'))];
   fprintf(save_fid,'%s\n',cmd);
   
   % axis
   cmd=['AXIS XATZERO ' char(off_on(1+get(findobj('Tag','xatzero'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['AXIS '  char(off_on(2+get(findobj('Tag','hidexaxis'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);

   
   % autoupdate
   manual_auto={'MANUALUPDATE';'AUTOUPDATE'};	
   cmd= char(manual_auto(1 + get(findobj('Tag','autoupdate'),'Value')));
   fprintf(save_fid,'%s\n',cmd);

   % HIDE PLOT  not saved
   

   % ================== Heading and text ======================
   
   cmd=['HEADING ' char(state(1+get(findobj('Tag','heading_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['HEADING XPOS ' get(findobj('Tag','heading_x_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['HEADING YPOS ' get(findobj('Tag','heading_y_pos'),'String')];
   fprintf(save_fid,'%s\n',cmd);
   cmd=['HEADING SIZE ' get(findobj('Tag','heading_size'),'String')]; % font size in points
   fprintf(save_fid,'%s\n',cmd); 
   
   
   cmd=['TEXT ' char(state(1+get(findobj('Tag','text_on_off'),'Value')))];
   fprintf(save_fid,'%s\n',cmd);
   
   for line_number=1:9
      stnum=num2str(line_number);
      cmd=['TEXT LINE ' stnum];  % must be first of this group
      fprintf(save_fid,'%s\n',cmd);       
      cmd=['TEXT ' char(off_on(1+get(findobj('Tag',['text' stnum '_on_off']),'Value')))];
      fprintf(save_fid,'%s\n',cmd);
      cmd=['TEXT XPOS ' get(findobj('Tag',['text' stnum '_x_pos']),'String')];
      fprintf(save_fid,'%s\n',cmd);
      cmd=['TEXT YPOS ' get(findobj('Tag',['text' stnum '_y_pos']),'String')];
      fprintf(save_fid,'%s\n',cmd);  
      cmd=['TEXT SIZE ' get(findobj('Tag',['text' stnum '_size']),'String')];
      fprintf(save_fid,'%s\n',cmd);      
      angle_list=get(findobj('Tag',['text' stnum '_angle']),'string');
      angle_item_number=get(findobj('Tag',['text' stnum '_angle']),'value');
      cmd=['TEXT ANGLE ' angle_list(angle_item_number,:)];
      fprintf(save_fid,'%s\n',cmd);      
      color_list=get(findobj('Tag',['text' stnum '_color']),'string');
      color_item_number=get(findobj('Tag',['text' stnum '_color']),'value'); 
      cmd=['TEXT COLOR ' color_list(color_item_number,:)];
      fprintf(save_fid,'%s\n',cmd);
      cmd=['TEXT FRAME ' char(off_on(1+get(findobj('Tag',['text' stnum '_frame']),'Value')))];
      fprintf(save_fid,'%s\n',cmd);
      cmd=['TEXT STRING ' get(findobj('Tag',['text' stnum '_string']),'String')];
      fprintf(save_fid,'%s\n',cmd);     
   end;
   

   

end;



% Finish

fprintf(save_fid,'END\n');
fclose(save_fid);
save_fid=-1;


