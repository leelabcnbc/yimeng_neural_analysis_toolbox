function drawhist(time_start,time_span,hist_values,y_max,shift_from_top,y_size,fill_color,ref_y,ref_color)
% 
% draw a histogram
% Inputs
%   time_start      starting time, for example -1000 (ms)
%   time_span       time span of the histogram, for example 2000 (ms)
%   hist_values     histogram itself, for example in firing rate units (spikes/s)
%   y_max           histogram maximum, for example 100 spikes/s
%   shift_from_top  shift of histogram base from top (0 - minimum, 1 - maximum)
%   y_size          y dimension of the plot (from 0 to 1); for example 0.2 (20%)
%   fill_color      histogram color ('k' - black, etc.) Specify as 'i' for no fill.
%   ref_y           array of horizontal reference lines, use [0] if not needed
%   ref_color       a color for horizontal reference lines, use 0 if not needed
%

number_of_bins = length(hist_values);
bin_size=time_span-time_span/number_of_bins;
% create an array of bin times
x = ((1:number_of_bins)-1)/(number_of_bins-1)*bin_size + time_start;
% create an array of bin values, scaled and shifted on the page
y = hist_values/y_max*y_size+1-shift_from_top;

%  create array xx such that every element of x is repeated except for the first.  Add a new last value.
%  e.g.  x = [1 2 3 4 5]   xx = [1 2 2 3 3 4 4 5 5 6 ]    (1 is not repeated, 6 is addded)
xx = [x x];  
xx(1:2:length(xx)) = x; 
xx(2:2:length(xx)) = x +(x(2)-x(1));
firstx=xx(1);
lastx=xx(end);
%  finish up.  The example will now look like this:  xx = [1 2 2 3 3 4 4 5 5 6 6 1 1]
xx = [xx xx(length(xx)) xx(1) xx(1)];

% very similar with y     e.g.  y = [10 20 30 40 50]   yy = [10 10 20 20 30 30 40 40 50 50 ]   
yy = [y y];
yy(1:2:length(yy)) = y;
yy(2:2:length(yy)) = y;
% finish up.  yy=[ 10 10 20 20 30 30 40 40 50 50 1-shift 1-shift 10]
yy = [yy (1-shift_from_top) (1-shift_from_top) yy(1)];

% now we have all the X-Y pairs:
%          bin 1          bin2          bin3          bin4          bin5       y axis    x axis    close the figure
%   xx = [1      2      2      3      3      4      4      5      5      6       6        1                1         ]
%   yy = [10     10     20     20     30     30     40     40     50     50     1-shift   1-shift          10        ]
%

% create reference lines
%  create repeated array [first_x NaN last_x    first_x NaN last_x  ...]
rx=[ref_y ref_y NaN*ones(1,length(ref_y))];  % establish size of array
rx(1:3:length(rx))=firstx;
rx(2:3:length(rx))=lastx;
rx(3:3:length(rx))=NaN;

ref=ref_y/y_max*y_size+1-shift_from_top;   % scale and position y value
% duplicate every entry in reference list, using NaN between ref values
ry=[ref_y ref_y NaN*ones(1,length(ref_y))];  % establish size of array
ry(1:3:length(ry))=ref;
ry(2:3:length(ry))=ref;
ry(3:3:length(ry))=NaN;

if findstr(fill_color,'i')
   fill_color=strrep(fill_color,'i','');  % remove no-fill marker
   if isempty(fill_color)
      fill_color='k';
   end;
   plot(xx,yy,fill_color);
   plot(rx,ry,ref_color);
else
   patch(xx,yy,fill_color,'edgecolor',fill_color);
   patch(rx,ry,ref_color,'edgecolor',fill_color);
end;



