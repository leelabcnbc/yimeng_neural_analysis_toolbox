function [response]=work_file(close)
%
%  Open or close MatOFF files (originally called "WorkOFF" files)
% 
% Inputs
%   close      1 = close all MatOFF files
%              0 = open MatOFF files
% Outputs
%   response          results of open attempt
% Globals modified
%   work_filename     used only by work_file
%   work_fid
%   work_index        using read_index
%   work_udf          using read_index
%   taint
%
global work_filename work_fid work_index work_udef
global analog_data_cache pulse_data_cache event_data_cache
global environment taint cache_trials
global error_fid warning_fid debug_fid
global errors warnings debugs


% reset cache regardless if we are doing open or close
cache_trials.event=[0 0];   % trial number that have been cached
cache_trials.pulse=[0 0];
cache_trials.analog=[0 0];
event_data_cache =[];    % actual cache
pulse_data_cache=[];
analog_data_cache=[];

if close  % close
   close_work_files;
else      % open
   basefilename=get(findobj('Tag','filename'),'String');  % see what file user wants open
   if ~isempty(basefilename)
      basefilename=filepath(basefilename,environment.datapath);  % is this file already open?
      if strcmp(work_filename,basefilename)    % is this file already open?
         response='File already open';
         return;
      elseif ~isempty(work_filename)    % is an old file open?
         close_work_files;              %   yes, close it
      end;
      work_filename=basefilename;  % save name of new file
      [work_index,work_udef]=read_index([basefilename '.index']);  % fetch index
      if isempty(work_index)
         response='Empty index';
         return;
      end;
      work_fid.event=fopen([basefilename '.event']);   % Open files, event
      work_fid.pulse=fopen([basefilename '.pulse']);   %             pulse
      work_fid.analog=fopen([basefilename '.analog']); %             analog
      if debugs
         fprintf(debug_fid,'Debug [work_file]. file ids  event=%d  pulse=%d  analog=%d\n',...
            work_fid.event,work_fid.pulse,work_fid.analog);
      end;
      trials_list=work_udef(1).trials;
      number_of_trials=length(trials_list);
      response=[num2str(number_of_trials) ' Trials in data file']; 
      unit_list=[];
      for u=1:length(work_udef)
         unit_list=strvcat(unit_list,work_udef(u).name);
      end;
      set(findobj('Tag','unit'),'Value',1);
      set(findobj('Tag','unit'),'String',unit_list);
      environment.unitfound=1;
      trials_list=work_udef(1).trials;
      number_of_spikes=0;
      if max(trials_list) > size(work_index,2)
         if errors
            fprintf(error_fid,'Error [work_file]. Trials list does not match size of work_index.\n');
            fprintf(error_fid,'Error [work_file]. This probably indicates a corrupt index for the data file.\n');
            fprintf(error_fid,'Error [work_file]. The file will not be opened.\n');
         end;
         close_work_files;              %   yes, close it
         response='File error';
         return;
      end;
      for t=trials_list
         number_of_spikes=number_of_spikes + work_index(t).pulse_records;
      end;
      set(findobj('Tag','spikechannelmenu'),'Value',work_udef(1).channel+1);
      set(findobj('Tag','pulsesfound'),'String',num2str(number_of_spikes));

   else  % empty file name
      response='No file specified';
      
   end; % if ~empty basefilename
    
end; % if close





function close_work_files

% Globals modified
%   work_filename     used only by work_file
%   work_fid
%   work_index        using read_index
%   work_udf          using read_index
%
global work_filename work_fid work_index work_udef
global error_fid warning_fid debug_fid
global errors warnings debugs

   filename=fopen(work_fid.event);
   if ~isempty(filename)
      fclose(work_fid.event);
      if debugs
         fprintf(debug_fid,'Debug [work_file]. Closing event file id=%d\n',work_fid.event);
      end;
   end;
   work_fid.event=-1;
   filename=fopen(work_fid.pulse);
   if ~isempty(filename)
      fclose(work_fid.pulse);
      if debugs
         fprintf(debug_fid,'Debug [work_file]. Closing pulse file id=%d\n',work_fid.pulse);
      end;
   end;
   work_fid.pulse=-1;
   filename=fopen(work_fid.analog);
   if ~isempty(filename)
      fclose(work_fid.analog);
      if debugs
         fprintf(debug_fid,'Debug [work_file]. Closing analog file id=%d\n',work_fid.analog);
      end;   
   end;
   work_fid.analog=-1;
   work_index=[];
   work_udf=[];
   work_filename='';

