function[trials_found]=map
% 
% Align spike trials on centering codes 
% Modify a number of global variables.
%
% Outputs
%   trials_found   list a count of the number of trials that match search criteria
% Globals modified
%   event_codes     from work_scan, one row per trial -- row of event codes that match sequence
%   event_times     from work_scan, one row per trial -- row of event times to match event_codes
%   spiketrials     2 column array of [trial_number  time_mark] based on spikemap, 
%                   but times are centered on centering codes
%   time_zero       time of centering code for each trial (row vector)
%

global spikemap event_codes event_times 
global spiketrials time_zero
global error_fid warning_fid debug_fid
global errors warnings debugs
global work_trial_list
global selected_unit_trials unit_trials
global center_is_class




% ====== get spikes for specified channel ========

if ~isempty(spikemap) && get(findobj('Tag','spikechannelmenu'),'UserData')  % bail out if nothing found
   % parse out the spike times for the selected unit
   % spiketrials: 2 column array of [trial number, time mark] for every spike in a given spike channel
   if debugs
      fprintf(debug_fid,'Debug [map]. Extracting spikes for requested channel.\n');
   end;
   channel=get(findobj('Tag','spikechannelmenu'),'Value')-1;  % spike channels start with 0
   this_chan=find(spikemap(:,2)==channel);  % find row numbers that match requested channel
   spiketrials=spikemap(this_chan,[1 3]);  % save columns 1 and 3 from those rows  
else
   spiketrials=[];
end;

% ===== get event times for all trials ========

% event_codes: n column array: each row is a trial, each column is the next event code
% event_times: n column array: each row is a trial, each column is a time mark for the matching code
if debugs
   fprintf(debug_fid,'Debug [map]. Fetching event codes\n');
end;

trials_found=size(event_codes,1);

% ==== find the zero time for each trial =======
time_zero=[];
% Each trial has a centering code.  The time of that code becomes "time zero" for that trial.
center_group=str2double(get(findobj('Tag','center'),'String'));
if trials_found > 0
   % find time zero for each unsorted trial
   if debugs
      fprintf(debug_fid,'Debug [map]. Aligning to the centering codes.\n');
   end;     
   if center_group <= size(event_codes,2)
      % CENTER is a group number (that points to an event code)
      time_zero=event_times(:,center_group)';  % row vector of event times
      
   elseif center_group < center_is_class
      if errors
          fprintf(error_fid,'Error [map]. CENTER value is greater than the number of groups in the search sequence.\n');
      end
      return;
            
   else
      % CENTER is a history class number, class has the absolute centering time for each trial
      if debugs
         fprintf(debug_fid,'Debug [map]. Centering code is a history class:  %d.\n',center_group);
      end;
      tcv=list_class(center_group);  % fetch all trials and class values for this class
      if isempty(tcv)
         if errors
            fprintf(error_fid,'Error [map]. CENTER value points to an empty history class.\n');
         end
         return;
      end    
      trials_in_class=tcv(1,:);      % get file trial numbers
      times_in_class=tcv(2,:);       % get time stored for each file trial (ms)
      time_zero=zeros(1,trials_found);  % initialize to 0, since it is possible that some trials have no class value
      for trial=1:trials_found
          file_trial=selected_unit_trials(trial);  % convert this unsorted trial number (trial) to a file trial number 
          i=find(trials_in_class==file_trial);  % see if this trial has a class value
          if ~isempty(i)
              time_zero(trial)=times_in_class(i)*10;  % this is the trial offset value. convert from ms to .1ms
          end
      end     
   end %if center_group <= trials_found   
         
   % ==== Offset all the spike times, and code times to these new zero times ===
   if ~isempty(spiketrials)
      spiketrials(:,2)=spiketrials(:,2)-time_zero(1,spiketrials(:,1))';  % time_zero converted to column vector
   end
   % events 
   for trial=1:trials_found
      event_times(trial,:)=event_times(trial,:)-time_zero(trial);  
   end 

else
   time_zero=[];
end % if trialsfound > 0



