function [v_layout]=get_layout
%   Extract layout values from the 4 layout menus and 
%   return them in a structure. This is used to synchronize 
%   the GUI layout values with the "layout" array of layouts.
%
% Output
%     v_layout   structure with all critical layout information. created by layout_handles.m
%
global h_layout  % handles to critical layout objects
global error_fid warning_fid debug_fid
global errors warnings debugs
%
%
% From layout_menu.m:
% These are excluded from the layout variable:
%   autoupdate
%   layout_number
v_layout.raster_on_off=get(h_layout.raster_on_off,'Value');
v_layout.raster_tic_size=get(h_layout.raster_tic_size,'String');
v_layout.raster_label_size=get(h_layout.raster_label_size,'String');
v_layout.raster_separation=get(h_layout.raster_separation,'String');
v_layout.raster_y_pos=get(h_layout.raster_y_pos,'String');

v_layout.hide_plot=get(h_layout.hide_plot,'Value');
v_layout.hide_xaxis=get(h_layout.hide_xaxis,'Value');
v_layout.xatzero=get(h_layout.xatzero,'Value');

v_layout.centerline_y_pos=get(h_layout.centerline_y_pos,'String');
v_layout.centerline_on_off=get(h_layout.centerline_on_off,'Value');
v_layout.centerline_size=get(h_layout.centerline_size,'String');
v_layout.centerline_style=get(h_layout.centerline_style,'Value');

v_layout.histogram_on_off=get(h_layout.histogram_on_off,'Value');
v_layout.histogram_y_pos=get(h_layout.histogram_y_pos,'String');
v_layout.histogram_size=get(h_layout.histogram_size,'String');
v_layout.histogram_style=get(h_layout.histogram_style,'Value');
v_layout.histogram_binwidth=get(h_layout.histogram_binwidth,'String');
v_layout.histogram_scale_on_off=get(h_layout.histogram_scale_on_off,'Value');
v_layout.histogram_scale=get(h_layout.histogram_scale,'String');
v_layout.histogram_raw_on_off=get(h_layout.histogram_raw_on_off,'Value');
v_layout.histogram_ref_on_off=get(h_layout.histogram_ref_on_off,'Value');
v_layout.histogram_ref_limits=get(h_layout.histogram_ref_limits,'String');
v_layout.histogram_ref_color=get(h_layout.histogram_ref_color,'Value');

v_layout.analog_on_off=get(h_layout.analog_on_off,'Value');
v_layout.analog_y_pos=get(h_layout.analog_y_pos,'String');
v_layout.analog_trace_size=get(h_layout.analog_trace_size,'String');
v_layout.analog_style=get(h_layout.analog_style,'Value');
v_layout.analog_separation=get(h_layout.analog_separation,'String');

v_layout.analog2_on_off=get(h_layout.analog2_on_off,'Value');
v_layout.analog2_y_pos=get(h_layout.analog2_y_pos,'String');
v_layout.analog2_style=get(h_layout.analog2_style,'Value');
v_layout.analog2_trace_size=get(h_layout.analog2_trace_size,'String');
v_layout.analog2_separation=get(h_layout.analog2_separation,'String');


% from menu2
v_layout.average_on_off=get(h_layout.average_on_off,'Value');
v_layout.average_trace_size=get(h_layout.average_trace_size,'String');
v_layout.average_y_pos=get(h_layout.average_y_pos,'String');
v_layout.average_style=get(h_layout.average_style,'Value');
v_layout.average2_style=get(h_layout.average2_style,'Value');
v_layout.average2_y_pos=get(h_layout.average2_y_pos,'String');
v_layout.average2_trace_size=get(h_layout.average2_trace_size,'String');
v_layout.average2_on_off=get(h_layout.average2_on_off,'Value');

v_layout.dxdt2_on_off=get(h_layout.dxdt2_on_off,'Value');
v_layout.dxdt2_trace_size=get(h_layout.dxdt2_trace_size,'String');
v_layout.dxdt2_separation=get(h_layout.dxdt2_separation,'String');
v_layout.dxdt2_y_pos=get(h_layout.dxdt2_y_pos,'String');
v_layout.dxdt2_style=get(h_layout.dxdt2_style,'Value');
v_layout.dxdt_style=get(h_layout.dxdt_style,'Value');
v_layout.dxdt_y_pos=get(h_layout.dxdt_y_pos,'String');
v_layout.dxdt_separation=get(h_layout.dxdt_separation,'String');
v_layout.dxdt_trace_size=get(h_layout.dxdt_trace_size,'String');
v_layout.dxdt_on_off=get(h_layout.dxdt_on_off,'Value');

v_layout.heading_on_off=get(h_layout.heading_on_off,'Value');
v_layout.heading_x_pos=get(h_layout.heading_x_pos,'String');
v_layout.heading_y_pos=get(h_layout.heading_y_pos,'String');
v_layout.heading_size=get(h_layout.heading_size,'String');

v_layout.RIP_on_off=get(h_layout.RIP_on_off,'Value');
v_layout.RIP_y_pos=get(h_layout.RIP_y_pos,'String');
v_layout.RIP_size=get(h_layout.RIP_size,'String');
v_layout.RIP_style=get(h_layout.RIP_style,'Value');

% from menu3
v_layout.xy_overlap_on_off=get(h_layout.xy_overlap_on_off,'Value');
v_layout.xy_on_off=get(h_layout.xy_on_off,'Value');
v_layout.xy_trace_size=get(h_layout.xy_trace_size,'String');
v_layout.xy_separation=get(h_layout.xy_separation,'String');
v_layout.xy_y_pos=get(h_layout.xy_y_pos,'String');
v_layout.xy_x_pos=get(h_layout.xy_x_pos,'String');
v_layout.xy_style=get(h_layout.xy_style,'Value');

v_layout.avxy_style=get(h_layout.avxy_style,'Value');
v_layout.avxy_y_pos=get(h_layout.avxy_y_pos,'String');
v_layout.avxy_trace_size=get(h_layout.avxy_trace_size,'String');
v_layout.avxy_on_off=get(h_layout.avxy_on_off,'Value');
v_layout.avxy_x_pos=get(h_layout.avxy_x_pos,'String');

v_layout.xy_x_pos=get(h_layout.xy_x_pos,'String');
v_layout.xy_time_criteria=get(h_layout.xy_time_criteria,'Value');
v_layout.xy_time_start=get(h_layout.xy_time_start,'String');
v_layout.xy_time_stop=get(h_layout.xy_time_stop,'String');

v_layout.history_spot_on_off=get(h_layout.history_spot_on_off,'String');
v_layout.history_spot_first_class=get(h_layout.history_spot_first_class,'String');
v_layout.history_spot_last_class=get(h_layout.history_spot_last_class,'String');
v_layout.history_spot_color=get(h_layout.history_spot_color,'Value');


v_layout.validate_spikes_on_off=get(h_layout.validate_spikes_on_off,'String');
v_layout.valid_spikes_start_class=get(h_layout.valid_spikes_start_class,'String');
v_layout.valid_spikes_end_class=get(h_layout.valid_spikes_end_class,'String');
v_layout.invalid_spike_color=get(h_layout.invalid_spike_color,'Value');


% from sequence menu
v_layout.segments_on_off=get(h_layout.segments_on_off,'Value');
v_layout.sortrangeshow=get(h_layout.sortrangeshow,'Value');

% from text menu


v_layout.text_on_off=get(h_layout.text_on_off,'Value');

error_exit= 'fprintf(error_fid,''Error [set_layout]. Cannot set text menu values\n''); return; ';
for i=1:9
   stnum=num2str(i);
   tag=['text' stnum '_on_off'];
   eval(['v_layout.' tag '=get(h_layout.' tag ',''Value'');'],error_exit );
   tag=['text' stnum '_x_pos'];
   eval(['v_layout.' tag '=get(h_layout.' tag ',''String'');'],error_exit );
   tag=['text' stnum '_y_pos'];
   eval(['v_layout.' tag '=get(h_layout.' tag ',''String'');'],error_exit ); 
   tag=['text' stnum '_size'];
   eval(['v_layout.' tag '=get(h_layout.' tag ',''String'');'],error_exit ); 
   tag=['text' stnum '_angle'];
   eval(['v_layout.' tag '=get(h_layout.' tag ',''Value'');'],error_exit ); 
   tag=['text' stnum '_color'];
   eval(['v_layout.' tag '=get(h_layout.' tag ',''Value'');'],error_exit );   
   tag=['text' stnum '_string'];
   eval(['v_layout.' tag '=get(h_layout.' tag ',''String'');'],error_exit );
   tag=['text' stnum '_frame'];
   eval(['v_layout.' tag '=get(h_layout.' tag ',''String'');'],error_exit );


end;
if debugs
   fprintf(debug_fid,'Debug [get_layout]. layout information.\n');
   v_layout
end; 

