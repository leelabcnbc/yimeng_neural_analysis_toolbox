function [newlist]=expand_range_list(oldlist)
% expand a matoff list (range notation uses dash "-")
% into a sorted matlab list.  Strip off any brackets "[ ]".
%
% Inputs
%   oldlist    MatOFF list to expand (ascii characters)
% Outputs
%   newlist    numeric or newlist='@' if an error occurred.
%
%    To test for the error, use something like this:
%       newlist=expand_range_list(oldlist);
%       if isstr(trial_list)
%          fprintf('Error.  Illegal list.\n');
%       end;
%
newlist=[];
if isempty(oldlist)
   return;
end;
newlist=strrep(oldlist,'[','');  % remove brackets
newlist=strrep(newlist,']','');
newlist=strrep(newlist,'-',':'); % convert dash notation to matlab notation
if isempty(newlist)
   return;
end;
newlist=deblank(strjust(newlist,'left'));
if isempty(str2num(newlist(1)))   % first character must be numeric
   newlist='@';
   return;
end;
eval(['newlist=[' newlist '];'],'newlist=''@'';');  % expand the list
newlist=sort(newlist);    % sort
