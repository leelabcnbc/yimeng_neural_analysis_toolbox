function [success]=rewrite_history(new_history,rewrite_option)
%
%    Merge history information in memory for current unit with data previously
%    stored in the .history file
%
% Inputs
%   new_history(cindex).class       = class 
%                      .trial_list  = [] array of trial numbers that belong in this class
%                      .values      = [] array of matching class values for each trial
%                  (cindex indexes a class, range 1 to n, n = number of classes for this unit)
%   rewrite_option    "all"      if rewrite_option = 1, copy history to all units in this data file that have the same udef index information
%                     "delete"   if rewrite_option = 2, delete history of this unit from file
%                      Note: cannot "delete all"
%
% Outputs
%   success          = 1  successful storage of merged histories, negative value indicates error
%
% Globals modified
%

global error_fid warning_fid debug_fid
global errors warnings debugs
global environment
global work_udef
global MAX_UNIT_NAME

temp_basefilename = 'temp';  % base file name for temporary file
success=0;
temp_history_fid=-3;

if debugs
   fprintf(debug_fid,'Debug [rewrite_history]. Updating history file for current unit.\n');
end

% Make sure a data file is open
basefilename=get(findobj('Tag','filename'),'String');  % see what file is specified in the GUI
if isempty(basefilename)
   if warnings
      fprintf(warning_fid,'Warning [rewrite_history]. No file open.\n');
   end
   return;
end

% Make sure there is a unit selected
entry_number=get(findobj('Tag','unit'),'Value');
unit_string=get(findobj('Tag','unit'),'String');
unitname=deblank(strjust(unit_string(entry_number,:),'left'));
if isempty(unitname)
   if warnings
      fprintf(warning_fid,'Warning [rewrite_history]. Empty unit name.\n');
   end
   return;
end

% Make sure there is new history data to add
if isempty(new_history) 
   if rewrite_option==2
      if warnings
         fprintf(warning_fid,'Warning [rewrite_history]. History data deleted for this unit.\n');
      end
   else
      if warnings
         fprintf(warning_fid,'Warning [rewrite_history]. No new history information. History data not saved.\n');
      end
      return;
   end
end

% prepare for the "all" option
udef_index=0;

if rewrite_option==1
   if debugs
      fprintf(debug_fid,'Debug [rewrite_history]. ALL option selected, searching for units to update\n');
   end
   % find unit name in unit definition file
   for n=1:length(work_udef)
      if strcmp(work_udef(n).name,unitname)
         udef_index=n;
         break;
      end
   end 
   % sanity check
   if udef_index==0 
       if errors
          fprintf(error_fid,'Error [rewrite_history]. Could not find unit name in work_udef file!.\n');
       end 
       return;
   end
   % create list of unit names that have the same metrics
   ui=0;
   for n=1:length(work_udef)
      if length(work_udef(n).trials)==length(work_udef(udef_index).trials)  % exact same file trials?
        if work_udef(n).trials==work_udef(udef_index).trials           
            ui=ui+1;
            unit_list(ui).name=work_udef(n).name;   % save to list
            fprintf(debug_fid,'Updating %s\n',work_udef(n).name);
         end  % if work_udef(n).trials==
      end  % if length(work_udef(n).trials)==
   end  % for n=1:length(
else
   unit_list(1).name=unitname;   % Without "all" option, only one name in the list
   fprintf(debug_fid,'Updating %s\n',unitname);
end
      

% open temporary file for merged histories.  this will eventually become new history file

temp_basefilename=filepath(temp_basefilename,environment.datapath);  % add the full path to the temporary file name
temp_history_file_name=[temp_basefilename '.history'];
temp_history_index_name=[temp_basefilename '.hindex'];   % used at the end of this program
temp_history_fid=fopen(temp_history_file_name,'wb+');  % write binary, overwrite existing file
if temp_history_fid < 1
   if errors
      fprintf(error_fid,'Error [rewrite_history]. Cannot create temporary history file. Cannot write new history information.\n');
   end
   return;  % return without a success
end
if debugs
   fprintf(debug_fid,'Debug [rewrite_history]. Opening temporary history file for new history data (history fid= %d)\n',temp_history_fid);
end

% get an index for the existing history file
basefilename=filepath(basefilename,environment.datapath);  % add the full path to the base file name
old_hindex=read_history_index(basefilename);               % this will be empty if no file exists
if debugs
   if isempty(old_hindex)
      fprintf(debug_fid,'Debug [rewrite_history]. No prior history data found for this file.\n');
   else
      fprintf(debug_fid,'Debug [rewrite_history]. Copying old history data.\n');
   end
end

% Copy all old histories that are not in the list of units to be changed to a new file
% Copy process includes building a new index file.
new_hindex_unit=0;    % counts units in the new index
byte_count=0;         % count bytes in new history, used for new history index
for i=1:length(old_hindex)  
   % does the next old index entry match any of the unit names in the list?
   match=0;
   for n=1:length(unit_list)
      if strcmp(old_hindex(i).unitname,unit_list(n).name)  
         match=1;  % we will not copy this unit
         if debugs
           fprintf(debug_fid,'Debug [rewrite_history].  Not copying %s, since it will be changed now\n',old_hindex(i).unitname);
         end
         break;   
      end
   end
   if ~match
       % copy old history unit entry to new history file and build the history index (hindex)
       if debugs
         fprintf(debug_fid,'Debug [rewrite_history].  Copying %s\n',old_hindex(i).unitname);
       end
       new_hindex_unit=new_hindex_unit+1;  % add to new history
       new_hindex(new_hindex_unit).unitname=old_hindex(i).unitname;  % copy unit name
       new_hindex(new_hindex_unit).history_start=byte_count;         % current byte count is starting byte
       old_history=read_history(old_hindex,old_hindex(i).unitname);  % fetch history  
       if isempty(old_history)
           success=-5;
           record_size=0;
           if errors
              fprintf(error_fid,'Error [rewrite_history]. History index found, but history file is missing. Error codes= %d  %d\n',record_size,success);
           end 
           if temp_history_fid > 0
              fclose(temp_history_fid);
              delete(temp_history_file_name);
           end
           return; 
       end
       record_size=write_history(temp_history_fid,old_history,old_hindex(i).unitname);  % copy history for that unit
       if record_size < 1
           success=-1;
           if errors
              fprintf(error_fid,'Error [rewrite_history]. Write failure copying old unit entry. Error codes= %d  %d\n',record_size,success);
           end 
           if temp_history_fid > 0
              fclose(temp_history_fid);
              delete(temp_history_file_name);
           end
           return;
       end
       new_hindex(new_hindex_unit).history_length=record_size;   % record the size of the record
       byte_count = byte_count + record_size;       % track the end of the history file
   end
end % for i=1:length(old_hindex)  

if debugs
   fprintf(debug_fid,'Debug [rewrite_history]. Writing new history data.\n');
end

% Copy the same history to all the units in the unit_list
for n=1:length(unit_list)
   unitname=unit_list(n).name;

   new_hindex_unit=new_hindex_unit+1;
   new_hindex(new_hindex_unit).unitname=unitname;
   new_hindex(new_hindex_unit).history_start=byte_count;

   if debugs
      fprintf(debug_fid,'Debug [rewrite_history].  Writing history data for %s (entry=%d).\n',unitname,new_hindex_unit);
   end

   record_size=write_history(temp_history_fid, new_history, unitname);  % write new history
   if debugs
      fprintf(debug_fid,'Debug [rewrite_history].   %s  starts in history file at %d, length=%d\n',unitname,byte_count,record_size);
   end

   if record_size < 1
       success=-2;
       if errors
          fprintf(error_fid,'Error [rewrite_history]. Write failure writing new history information. Error codes= %d  %d\n',record_size,success);
       end 
       if temp_history_fid > 0
          fclose(temp_history_fid);
          delete(temp_history_file_name);
       end
       return;
   end
   new_hindex(new_hindex_unit).history_length=record_size;   % record the size of the record
   byte_count = byte_count + record_size;       % track the end of the history file
end

% write End-Of-File mark in history file
eof_history.class=0;
eof_history.trial_list=[];
eof_history.values=[];
record_size=write_history(temp_history_fid,eof_history,'END_OF_FILE');
if record_size < 1
   success=-3;
   if errors
      fprintf(error_fid,'Error [rewrite_history]. Write failure writing EOF marker. Error codes= %d  %d\n',record_size,success);
   end 
   if temp_history_fid > 0
      fclose(temp_history_fid);
      delete(temp_history_file_name);
   end
   return;
end
byte_count=record_size;

if debugs
   fprintf(debug_fid,'Debug [rewrite_history]. Closing temporary history file.\n');
end
fclose(temp_history_fid);

if debugs
   fprintf(debug_fid,'Debug [rewrite_history]. Saving index to: %s.\n',[temp_basefilename '.hindex']);
end
success=write_history_index(temp_basefilename,new_hindex);

if debugs
   fprintf(debug_fid,'Debug [rewrite_history]. Replacing old history files with new ones.\n');
end
% delete old history files
basefilename=get(findobj('Tag','filename'),'String');  % find current file name
basefilename=filepath(basefilename,environment.datapath);  % find path
old_history_file_name=[basefilename '.history'];
old_history_index_name=[basefilename '.hindex'];
fid=fopen(old_history_file_name);
if fid > 0
   fclose(fid);
   delete(old_history_file_name);
end
fid= fopen(old_history_index_name);
if fid > 0
   fclose(fid);
   delete(old_history_index_name);
end

% copy temporary files to replace old history files
copyfile(temp_history_file_name,old_history_file_name);
copyfile(temp_history_index_name,old_history_index_name);
delete(temp_history_file_name);
delete(temp_history_index_name);