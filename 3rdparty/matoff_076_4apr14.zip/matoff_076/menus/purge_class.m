function [status]=purge_class(class)
%  Remove a class and all class values (for all trials).  Class need not exist.
%  (Special user function)
% 
%  Inputs
%    class        class to remove
%  Outputs
%    status              1 = successful run,  negative value is an error code
%   
%
%    history.class            class 
%           .trial_list       = [] string array of trial numbers that belong in this class, sorted 
%           .values           = [] array of matching class values for each trial
%
global history
global uh_current_trial uh_last_trial    % to support special user functions
global error_fid warning_fid debug_fid
global errors warnings debugs

if debugs
   fprintf(debug_fid,'Debug [purge_class]. Removing all values for class %d\n',class);
end

if isempty(history) 
   status=1;
   return;
end
new_history=[];
% find the class in the history.
hl=length(history);
cindex=0;
for c=1:hl
  if history(c).class~=class
     cindex=cindex+1;
     new_history=[new_history history(c)];   % retain this class
  end
end

history=new_history;
status=1;