function [status]=assign_class_value(trial,class,class_value)
%  Assign a class and class value to the current history
%  (Special user function)
%  
%  Inputs
%    trial        trial for history change
%    class        class to add or amend
%    class_value  value for the class
%
%    history.class            class 
%           .trial_list       = [] string array of trial numbers that belong in this class, sorted 
%           .values           = [] array of matching class values for each trial
%  Outputs
%    status              1 = successful run,  negative value is an error code
%
global history
global error_fid warning_fid debug_fid
global errors warnings debugs

if debugs
   fprintf(debug_fid,'Debug [assign_class_value]. Assigning trial %d to class %d, value=%d\n',trial,class,class_value);
end;

% Make no assignment if value is NaN or empty 
if isnan(class_value) | isempty(class_value)
   status=1;   % this is fine
   if warnings
      fprintf(warning_fid,'Warnings [assign_class_value].  Class value for trial %d, class %d is NaN or empty. No assignment made.\n',trial,class);
   end;
   return;
end;


try 
    % find the class in the history.
    hl=length(history);
    cindex=hl+1;   % will become next class if not already in history
    for c=1:hl
      if history(c).class==class
         cindex=c;
         break;
      end;
    end;

    if cindex > hl     % create a new class entry?
       if debugs
          fprintf(debug_fid,'Debug [assign_class_value]. This is a new class\n');
       end;
       history(cindex).class=class;
       history(cindex).trial_list= ['' num2str(trial) ''];   % convert trial into a string
       history(cindex).values=class_value;      
    else
       t_list=expand_range_list(history(cindex).trial_list);  % convert string into list
       if length(t_list) ~= length(history(cindex).values)  % opportunity to do history consistency check
            fprintf(error_fid,...
            'Error [assign_class_value]. Trial list length (%d) does not match number of values (%d) for class %d. Class is corrupt.\n'...
	        ,length(t_list),length(history(cindex).values),class);
       end;
       tpos=find(t_list==trial);                      % look for this trial in the list
       if debugs
          fprintf(debug_fid,'Debug [assign_class_value]: Updating history:\n');
       end;
       if ~isempty(tpos)               % does this trial already have a class value?
          history(cindex).values(tpos)=class_value;   % yes, simply assign a new value
       else
          lower=find(t_list < trial);
          upper=find(t_list > trial);
          newt_list=[t_list(lower) trial t_list(upper)];
          history(cindex).trial_list=string_list(newt_list);    % convert to a string list
          history(cindex).values=[history(cindex).values(lower)   class_value   history(cindex).values(upper)];
       end;
    end;
catch
    if errors
       fprintf(error_fid,'Error [assign_class_value]. Matlab error assigning trial %d to class %d, value=%d\n',trial,class,class_value);
       fprintf(error_fid,'%s \n',lasterr);
    end;   
    status=-1;
    return;
end;
status=1;
