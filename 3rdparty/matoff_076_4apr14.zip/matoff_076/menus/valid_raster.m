function valid_raster(trial_list,trial,timestamp,shift_from_top,spacing,barheight,style,starts,ends,invalid_color)
%
%  Draw a raster on the current plot with validated spikes colored differently from the others
%
% Inputs
%  trial_list   There will be one raster line for each number in the
%               trial_list.  Whenever a number in the trial_list is found 
%               in trial, the corresponding timestamp is used to draw a tic.
%               The order of trial_list determines the order of the rasters.           
%               
%  trial timestamp   each spike has an associated trial number and timestamp.
%  
%  shift_from_top    Floating point value. 0 = top, 1 = bottom.
%  spacing           Floating point value. 0 = all raster on one line, 1 = one
%                                          entire page per raster.
%  barheight         Floating point value. 0 = no tic mark, 1 = tic is full height
%                                          of the page.
%  style         Line type (usually '-k')


X = [];
Y = [];

y0 = 1-shift_from_top;
for i_trial = 1:length(trial_list),
   tndx = find(trial == trial_list(i_trial));
   if ~isempty(tndx),
      x = zeros(length(tndx)*3,1)*NaN; 
      y = x;
      n = length(x);
      x(1:3:n) = timestamp(tndx);
      x(2:3:n) = timestamp(tndx);
      y(1:3:n) = y0;
      y(2:3:n) = y0-barheight;
       
      X = [X;x];
      Y = [Y;y];  
   end
   y0 = y0 - spacing;
end

plot(X,Y,style);




