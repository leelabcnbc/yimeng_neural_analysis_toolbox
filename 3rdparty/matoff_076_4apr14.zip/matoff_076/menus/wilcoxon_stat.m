function [decision,m,n,Wx,z]=wilcoxon_stat(x,y)
%
%  Calculate the Wilcoxon_Mann_Whitney statistic for two groups of samples
% 
% Inputs
%  x            array of samples from first group
%  y            array of samples from second group
% Outputs
%  decision     0 not significant for whatever reason
%               1 significant based on z score or Wx value (2-tailed, p < .05)
%  Wx           Wilcoxon statistic if relevant and no z score was reported
%  m            size of smaller group
%  n            size of larger group
%  z            z score if relevant, otherwise NaN

global environment 
global error_fid warning_fid debug_fid
global errors warnings debugs

Wx=NaN;
z=NaN;
decision=0;

[mx,nx] = size(x);   %transpose if input is a column
if mx > nx,
  x = x';
end;

[my,ny] = size(y);   %transpose if input is a column
if my > ny,
  y = y';
end;

lx = length(x);
ly = length(y);

if lx < ly,
  m = lx;
  n = ly;
  I = 0;               %identity of X (smaller sample)
else
  m = ly;
  n = lx;
  I = 1;               %identity of X (smaller sample)
end;

if (lx == 0) | (ly == 0)  % skip analysis if one group is empty
   return;
end;

xy = [x y];           % put x and y together
identity = [zeros(size(x)) ones(size(y))];  % identity markers: x -> 0, y -> 1
[s,k] = sort(xy);        % sort in decreasing order
k = k(end:-1:1);         % transfer to increasing order
ranks = 1:length(k);
ranks_identity = identity(k);
value = xy(k);
N = length(ranks);

t = [];                % handle ties
j = 1;                 % starting point
while j < N
  tie = value(j);      %try this tie value
  tie_indices = find(value == tie);
  tie_count = length(tie_indices);
  if tie_count > 1,    %if indeed there are ties
    t = [t tie_count]; %this will be used for tie-correction
    ranks(tie_indices) = ones(size(ranks(tie_indices)))*mean(ranks(tie_indices));
                       %assign tie observations the average of tied ranks
    j = tie_indices(end)+1; %next j
  else
    j = j+1;           %next j
  end;
end;

Wx = sum(ranks(find(ranks_identity == I)));
Wy = sum(ranks(find(ranks_identity ~= I)));

if (m==3 & n>12) | (m==4 & n>12) | (m>=5 & n>10),   % large samples
  z = Wx + 0.5*sign(Wy - Wx) - m*(N+1)/2;  % estimate z score
  dvdr = sqrt( m*n / (N*(N-1)) * ( (N^3 - N)/12 - sum(t.^3 - t)/12 ) );
  if dvdr ~= 0,
    z = z /dvdr;
  else
    z = 0;
  end;
  Wx=NaN;  % reset this because z score will be reported.
  z = abs(z);
  if z > 1.960,          % p<0.05; two-tailed
    decision = 1;
  else
    decision = 0;
  end;
    
  % small sample, cannot calculate a z score.  Look at Wx.
  elseif (m==3 & n>=4 & n<=12) | (m==4 & n>=4 & n<=12) | (m>=5 & n>=m & n<=10)
     
    % Build Wx table
    Cl(3,4)   =  6; Cu(3,4)   = 18;
    Cl(3,5)   =  6; Cu(3,5)   = 20;
    Cl(3,6)   =  7; Cu(3,6)   = 23;
    Cl(3,7)   =  7; Cu(3,7)   = 25;
    Cl(3,8)   =  8; Cu(3,8)   = 28;
    Cl(3,9)   =  8; Cu(3,9)   = 30;
    Cl(3,10)  =  9; Cu(3,10)  = 33;
    Cl(3,11)  =  9; Cu(3,11)  = 35;
    Cl(3,12)  = 10; Cu(3,12)  = 38;

    Cl(4,4)   = 10; Cu(4,4)   = 25;
    Cl(4,5)   = 11; Cu(4,5)   = 28;
    Cl(4,6)   = 12; Cu(4,6)   = 31;
    Cl(4,7)   = 13; Cu(4,7)   = 35;
    Cl(4,8)   = 14; Cu(4,8)   = 38;
    Cl(4,9)   = 15; Cu(4,9)   = 41;
    Cl(4,10)  = 15; Cu(4,10)  = 44;
    Cl(4,11)  = 16; Cu(4,11)  = 47;
    Cl(4,12)  = 17; Cu(4,12)  = 50;

    Cl(5,5)   = 17; Cu(5,5)   = 37;
    Cl(5,6)   = 18; Cu(5,6)   = 41;
    Cl(5,7)   = 20; Cu(5,7)   = 45;
    Cl(5,8)   = 21; Cu(5,8)   = 48;
    Cl(5,9)   = 22; Cu(5,9)   = 52;
    Cl(5,10)  = 23; Cu(5,10)  = 56;    

    Cl(6,6)   = 26; Cu(6,6)   = 51;
    Cl(6,7)   = 28; Cu(6,7)   = 56;
    Cl(6,8)   = 29; Cu(6,8)   = 60;
    Cl(6,9)   = 31; Cu(6,9)   = 65;
    Cl(6,10)  = 32; Cu(6,10)  = 69;

    Cl(7,7)   = 37; Cu(7,7)   = 68;
    Cl(7,8)   = 39; Cu(7,8)   = 73;
    Cl(7,9)   = 41; Cu(7,9)   = 78;
    Cl(7,10)  = 43; Cu(7,10)  = 83;

    Cl(8,8)   = 49; Cu(8,8)   = 87;
    Cl(8,9)   = 51; Cu(8,9)   = 92;
    Cl(8,10)  = 54; Cu(8,10)  = 98;

    Cl(9,9)   = 63; Cu(9,9)   = 108;
    Cl(9,10)  = 66; Cu(9,10)  = 114;     

    Cl(10,10) = 79; Cu(10,10) = 131; 

  if (Wx >= Cu(m,n)) | (Wx <= Cl(m,n))    % p<0.05; two-tailed
    decision = 1;
  end;
end; % if large sample or small sample





