function [xy_data]=list_analog(trial_requested)
%
%  Returns XY analog data for requested trial
%  (Special user function)
%
% Inputs
%    trial_requested   Trial number (based on all trials in unit)
% Outputs
%    xy_data          row 1   x1  x2  x3  x4  ... xn   x analog values -0.5 to +0.5
%                     row 2   y1  y2  y3  y4  ... yn   y analog values -0.5 to +0.5
%                     row 3   t1  t2  t3  t4  ... tn  (time in millisec)
%  If there is no analog data, returns [ 0
%                                        0
%                                        0  ]
%
%  If one channel is empty, returns 0 for every analog value 
%
global work_fid work_index work_udef environment
global error_fid warning_fid debug_fid
global errors warnings debugs

millisecond_scale=10000;   % 

% look in environment for analog start code.  default is 100
analogstart=100;
if ~isempty(environment.analogstart)
    [dummy,value,valid]=check_string_value(environment.analogstart,1,10000);   % limit to event code 10,000
    if valid
       analogstart=value;
    else
       if warnings
          fprintf(warning_fid,'Warning [list_analog]. Invalid analogstart environmental variable. Using default of 100.\n');
       end;
    end;
end;

% look in environment for analog stop code.  default is 101
analogstop=101;
if ~isempty(environment.analogstop)
    [dummy,value,valid]=check_string_value(environment.analogstop,1,10000);   % limit to event code 10,000
    if valid
       analogstop=value;
    else
       if warnings
          fprintf(warning_fid,'Warning [list_analog]. Invalid analogstop environmental variable. Using default of 101.\n');
       end;
    end;
end;

xy_data=[0;0;0];   % empty data

% Check for a valid list of source trials
sourcetrials_string=get(findobj('Tag','source'),'String');
source_trials=expand_range_list(number_range_list(sourcetrials_string));

% GUI unit number matches work_udef subscript
unit_number=get(findobj('Tag','unit'),'Value');  
% reduce trial list to just the source trials, don't exceed trial list length
highest_trial=length(work_udef(unit_number).trials);  % trial list length
search_trials=source_trials(find(source_trials <= highest_trial)); % limit list length
all_file_trials=work_udef(unit_number).trials(search_trials);  
% number of behavioral trials in this unit
unit_trials=length(all_file_trials); 

if (trial_requested < 1) | (trial_requested > unit_trials)
   if warnings
      fprintf(warning_fid,'Warning [list_analog]. Invalid trial number requested: %d.  Trials available are: 1 to %d\n',trial_requested,unit_trials);
   end;  
end;

file_trial=all_file_trials(trial_requested);            % File trial number for desired trial
% get the channel numbers for X and Y channel
xchan= (get(findobj('Tag','xchannelmenu'),'Value')-1);  % channel is defined if > 0
ychan= (get(findobj('Tag','ychannelmenu'),'Value')-1);

% fetch analog data (list of amplitude values)
if debugs
   fprintf(debug_fid,'Debug [list_analog]. Fetching analog using fid=%d\n',work_fid.analog);
end;

if xchan >= 0
   xanalog_value=read_analog_record(work_fid.analog,file_trial,xchan);
else
    if debugs
       fprintf(debug_fid,'Debug [list_analog]. No X channel selected');
    end;
    xanalog_value=[];
end;

if ychan >= 0
   yanalog_value=read_analog_record(work_fid.analog,file_trial,ychan);
else
    if debugs
       fprintf(debug_fid,'Debug [list_analog]. No Y channel selected');
    end;
    yanalog_value=[];
end;

if isempty(xanalog_value)
   if warnings
      fprintf(warning_fid,'Warning [list_analog]. No analog data for X channel.\n');
   end;
end;

if isempty(yanalog_value)
   if warnings
      fprintf(warning_fid,'Warning [list_analog]. No analog data for Y channel.\n');
   end;
end;

if isempty(yanalog_value) & isempty(xanalog_value)
   return;   % finished
end;

freq=str2num(get(findobj('Tag','frequency'),'String')); 
if freq==0
   if warnings
      fprintf(warning_fid,'Warning [list_analog]. Invalid A/D frequency.  Using default of 250.\n');
   end;  
   freq=250;
end;   

% Every analog value requires a timestamp.  Generate timestamps based analog start event code (code 100)
[events]=list_events(trial_requested);
codes=events(1,:);
times=events(2,:);
event100time=find(codes==analogstart);   
event101time=find(codes==analogstop);
if isempty(event100time)
   if warnings
      fprintf(warning_fid,'Warning [list_analog]. Cannot find analog start  code (%d) in trial %d\n',analogstart,trial_requested);
      fprintf(warning_fid,' Cannot calculate analog times for that trial.\n');
   end;  
   return;
end;
% Reject analog request if the Analog Start event code occurs more than once
if length(event100time) > 1
    if warnings
        fprintf(warning_fid,'Warning [list_analog].  Analog start  code (%d) occurs more than once in trial %d\n',analogstart,trial_requested);
        fprintf(warning_fid,' Analog burst mode not supported. Cannot calculate analog times for that trial.\n');
    end;
    return;
end;    

if isempty(event101time)
   if warnings
      fprintf(warning_fid,'Warning [list_analog]. Cannot find analog stop  code (%d) in trial %d\n',analogstop,trial_requested);
      fprintf(warning_fid,' Cannot calculate analog times for that trial.\n');
   end;  
   return;
end;
% Reject analog request if the Analog Stop event code occurs more than once
if length(event101time) > 1
    if warnings
        fprintf(warning_fid,'Warning [list_analog].  Analog stop  code (%d) occurs more than once in trial %d\n',analogstop,trial_requested);
        fprintf(warning_fid,' Analog burst mode not supported. Cannot calculate analog times for that trial.\n');
    end;
    return;
end;    


timezero=times(event100time);  % time that analogstart code occurred (milliseconds from trial start)
timelast=times(event101time);  % time that analogstop code  occurred (milliseconds from trial start)

time_step=1000/freq;  % milliseconds

% fill empty channel with zeros
if isempty(xanalog_value)
   xanalog_value=zeros(size(yanalog_value));
end;
if isempty(yanalog_value)
   yanalog_value=zeros(size(xanalog_value));
end;

xanalog_time=zeros(size(xanalog_value));  % initialize time matrix
yanalog_time=xanalog_time;

samples=size(xanalog_value,2);  % number of timestamps for trial is number of columns
%estimate and intentionally overshoot the range of timestamps
ending_time= (samples*time_step) + timezero + 10  ;
timestamps=timezero:time_step:ending_time;
% now use exactly the correct number of time stamps
analog_time=timestamps(1:samples);   
% see if last timestamp is anywhere near event code 101
if debugs
   fprintf(debug_fid,'Debug [list_analog]. Event 101 at time: %d, Last analog value at time: %d.\n',timelast,analog_time(end));
end;

xy_data=[xanalog_value ; yanalog_value ; analog_time];
