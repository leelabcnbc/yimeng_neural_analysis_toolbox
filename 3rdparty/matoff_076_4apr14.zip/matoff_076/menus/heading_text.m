function heading_text(x,y,fontsize)
%
%  Display a heading text block on the current figure
% Inputs
%   x           x position of upper left corner of text block in percent   0 = left
%   y           y position of upper left corner of text block in percent   0 = bottom
% fontsize      points
%

file=get(findobj('Tag','filename'),'String');
entry_number=get(findobj('Tag','unit'),'Value');
unit_string=get(findobj('Tag','unit'),'String');
unit=deblank(strjust(unit_string(entry_number,:),'left'));
if get(findobj('Tag','spikechannelmenu'),'UserData')
   pulsech=num2str(get(findobj('Tag','spikechannelmenu'),'Value')-1);
else
   pulsech='off';
end;
analog1=get(findobj('Tag','xchannelmenu'),'Value')-1;
if analog1==0
   analogch1='off';
else
   analogch1=num2str(analog1);
end;   
analog2=get(findobj('Tag','ychannelmenu'),'Value')-1;
   if analog2==0
   analogch2='off';
else
   analogch2=num2str(analog2);
end;

span=get(findobj('Tag','span'),'String');
globalignore=get(findobj('Tag','globalignore'),'String');
sequence=get(findobj('Tag','sequence'),'String');
source=get(findobj('Tag','source'),'String');
trials=get(findobj('Tag','trials'),'String');
frequency=get(findobj('Tag','frequency'),'String');
sort_option_list=get(findobj('Tag','trialsort'),'String');
sort_option=get(findobj('Tag','trialsort'),'value');
sort=deblank(sort_option_list(sort_option,:));
window=get(findobj('Tag','window'),'String');
binwidth=get(findobj('Tag','histogram_binwidth'),'String');
center=get(findobj('Tag','center'),'String');
mark=get(findobj('Tag','mark'),'String');
spot=get(findobj('Tag','spot'),'String');
segments=['(' get(findobj('Tag','segmenta1'),'String') ...
      ',' get(findobj('Tag','segmenta2'),'String') ...
      ',' get(findobj('Tag','segmentb1'),'String') ...
      ',' get(findobj('Tag','segmentb2'),'String') ')'];

header_string=sprintf( ...
   ['File=%-12s Unit=%-12s ' ...
    'PulseCh=%-3s AnaCh1=%-3s AnaCh2=%-3s   Freq=%-4s\n' ...
    'Span=%-5s GloIgnore=%-20s ' ...
    'Sequence=%-33s\n' ...
    'Source=%-9s Trials=%-9s Bin=%-4s ' ...
    'Sort=%-5s Window=%-5s Segs=%-12s\n' ...
    'Center=%-2s  Mark=%-2s  Spot=%-13s']  ...
    ,file,unit,pulsech,analogch1,analogch2,frequency,span,globalignore, ...
    sequence,source,trials,binwidth,sort,window,segments,center,mark,spot);
 

text(x,y,header_string,'FontName','Comic Sans MS','FontUnits','points','FontSize',fontsize,...
     'HorizontalAlignment','left','VerticalAlignment','top');
