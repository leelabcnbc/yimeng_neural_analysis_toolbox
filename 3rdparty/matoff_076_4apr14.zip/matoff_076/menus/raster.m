function raster(sorted_trial_list,spiketrials,timestamp,shift_from_top,spacing,barheight,style)
%
%  Draw a raster on the current plot
%
% Inputs
%  sorted_trial_list[]   There will be one raster line for each number in the
%                      sorted_trial_list.  Whenever a number in the sorted_trial_list is found 
%                      in spiketrials, the corresponding timestamp is used to draw a tic.
%                      The order of sorted_trial_list determines the order of the rasters.           
%               
%  spiketrials[]  timestamp[]     each spike has an associated trial number and timestamp.
%  
%  shift_from_top    Floating point value. 0 = top, 1 = bottom.
%  spacing           Floating point value. 0 = all raster on one line, 1 = one
%                                          entire page per raster.
%  barheight         Floating point value. 0 = no tic mark, 1 = tic is full height
%                                          of the page.
%  style         Line type (usually '-k')

if isempty(spiketrials)
   return;
end

X = [];
Y = [];

y0 = 1-shift_from_top;
for i_trial = 1:length(sorted_trial_list),
   tndx = find(spiketrials == sorted_trial_list(i_trial));
   if ~isempty(tndx),
      x = zeros(length(tndx)*3,1)*NaN; 
      y = x;
      n = length(x);
      x(1:3:n) = timestamp(tndx);
      x(2:3:n) = timestamp(tndx);
      y(1:3:n) = y0;
      y(2:3:n) = y0-barheight;
       
      X = [X;x];
      Y = [Y;y];  
   end
   y0 = y0 - spacing;
end

plot(X,Y,style);




