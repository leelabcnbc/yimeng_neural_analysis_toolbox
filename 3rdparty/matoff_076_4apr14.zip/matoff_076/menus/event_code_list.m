function [code_list]=event_code_list
%
% Create a list of every event sequence that matched the search criteria
% 
%
% Inputs
%    none
% Outputs
%    code_list for each matching sequence, lists the number of matches, then the sequence
% Globals changed
%    none
%
global event_codes 
global error_fid warning_fid debug_fid
global errors warnings debugs

code_list=[];
if isempty(event_codes)
   return;
end;

% look at each matching event sequence from last scan
for row=1:size(event_codes,1)
   code_list=[code_list ; row  event_codes(row,:)];   % row number plus sequence                
end;
