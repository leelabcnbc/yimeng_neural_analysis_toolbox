function [keep_index]=yank_elements(delete_list,array_size)
% 
%  Returns a list of array index values.  Uses the delete_list to 
%  determine which array elements to omit from the index list.  
%
% Inputs
%   delete_list    list of elements to remove from index
%   array_size     size of array
% Outputs
%   keep_list      list of elements to keep
%
% Example use:
%    remove elements 1,2,3,7,9 from array a
%    a=a(yank_elements([1 2 3 7 9],length(a)));
%
%
if (array_size < 1)
   keep_index=[];
   return;
end;
if isempty(delete_list)
   keep_index=1:array_size;
   return;
end;
dz=zeros(1,array_size);
d1=ones(1,array_size);
dz(delete_list)=d1(1,delete_list);
keep_index=find(~dz);

