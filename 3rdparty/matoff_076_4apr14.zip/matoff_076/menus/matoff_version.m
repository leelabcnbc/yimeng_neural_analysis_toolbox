function [version]=matoff_version
% format: version='0.62   24-April-2006';
version='0.76    14-September-2012';