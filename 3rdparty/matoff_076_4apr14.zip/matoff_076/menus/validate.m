function [finished]=validate(in,out)
%
%  validate the if/for/while/switch/end structure by printing out
%  lines of code that include these instructions
%
% in = input file name
% out= output file name

% instructions that we want to track.
instrs={'if' 'for' 'while' 'switch' 'case' 'else' 'end' 'break'};
   
in_fid=fopen(in,'rt');
out_fid=fopen(out,'wt');
while ~feof(in_fid)
   l=fgetl(in_fid);
   if ~isempty(l)
      if ~strcmp(l(1),'%')
         [c,dummy]=strtok(l,'%');  % strip off comments
         c=lower(strjust(c,'left'));
         for i=1:length(instrs)
            inst=char(instrs(i));
            if ~isempty(findstr(c,inst))
               fprintf(out_fid,'%s\n',l);  % print out whole line
               fprintf('%s\n',l); % echo
               break;
            end;
         end;
      end;
   end;
end;
fclose(in_fid);
fclose(out_fid);
finished='done';
  