function[response]=new_plot()
% new_plot    create a new plot based on layout parameters.
%
% Outputs
%   response      string returned by "make_plot"
%
% Globals changed
%   plot_number      incremented
%   current_layout   updated
%

global spiketrials plot_number
global environment fid
global layouts
global current_layout
global error_fid warning_fid debug_fid
global errors warnings debugs

layout_list=expand_range_list(get(findobj('Tag','displays'),'String'));
if strcmp(layout_list,'@')
   if errors
      fprintf(error_fid,'Error [new_plot]. Invalid layout list');
   end;
   return;
end;
for layout_number=layout_list
   % set up the next display
   fprintf(1,'layout %d\n',layout_number);
   if environment.logging==1
      fprintf(fid.log,'layout %d\n',layout_number);
   end;
   if (layout_number > 0) & (layout_number <= 10)& (layout_number ~= current_layout)
      set_layout(layouts(layout_number));
      set(findobj('Tag','layout_number'),'String',num2str(layout_number));
      current_layout=layout_number;
   else
      if layout_number ~= current_layout
         if errors
            fprintf(error_fid,'Error [new_plot]. Invalid layout number.\n');
         end; 
      end;
   end;
   handles=[];
   plot_number=plot_number+1;
   figure(plot_number);
   set(gcf,'Units','Normalized');
   do_not_move=0;
   if get(findobj('Tag','xy_on_off'),'Value') | get(findobj('Tag','avexy_on_off'),'Value')
      handles=xy_figure(do_not_move);
   else
      handles=raster_figure(do_not_move);
   end;
   % returns with the number of plots on the page
   response=make_plot(handles,0);
end;
