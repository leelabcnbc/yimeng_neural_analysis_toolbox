function [spike_times]=list_spikes(trial_number)
%
% Returns a list of spike times for the specified trial number
% Support function for history scripting
%
% Inputs
%    trial number
% Outputs
%    spike_times        (row) all spike times for this trial. Times in milliseconds
%
global work_fid work_udef environment
global error_fid warning_fid debug_fid
global errors warnings debugs
global history

spike_times=[];

sourcetrials_string=get(findobj('Tag','source'),'String');
source_trials=expand_range_list(number_range_list(sourcetrials_string));
if debugs
   fprintf(debug_fid,'Debug [list_spikes]. source trial list:\n');
   fprintf(debug_fid,' %d',source_trials);
   fprintf(debug_fid,'\n');
end;

% GUI unit number matches work_udef subscript
unit_number=get(findobj('Tag','unit'),'Value') ;  
% reduce trial list to just the source trials, don't exceed trial list length
highest_trial=length(work_udef(unit_number).trials);  % trial list length
search_trials=source_trials(find(source_trials <= highest_trial)); % limit list length
file_trials=work_udef(unit_number).trials(search_trials);  
% fetch block of spike data from file
selected_pulse_data=read_pulse_record(work_fid.pulse,file_trials);

% number of behavioral trials in this data set (save this for user_history_function)
unit_trials=length(file_trials); 

if isempty(selected_pulse_data)
   fprintf(warning_fid,'Warning [list_spikes]. No pulse data found for this unit.');
   return;
end;

if (trial_number < 1) | (trial_number > unit_trials) 
   fprintf(error_fid,'Error [list_spikes]. Requested trial number (%d) outside the range of this data set.',trial_number);
   return;
end;

header_marker=selected_pulse_data(1,(2*trial_number)-1);           % first entry is the trial header
header_file_trial_number=selected_pulse_data(1,(2*trial_number));
if debugs
   fprintf(debug_fid,'Debug [list_spikes]. Trial marker: %d    File trial number: %d\n',header_marker,header_file_trial_number);
end;

all_chans=selected_pulse_data(2:end,(2*trial_number)-1)' ;   % the remaining entries are the pulse channels and times
all_chans=all_chans(find(~isnan(all_chans)));                    % NaNs used as padding, remove them
all_times=selected_pulse_data(2:end,(2*trial_number))' ;
all_times=all_times(find(~isnan(all_times)));                        
all_times=all_times/10;  % convert to milliseconds

desired_channel=get(findobj('Tag','spikechannelmenu'),'Value')-1;  % spike channels start with 0
desired=find(all_chans==desired_channel);      % locate pulses of interest
spike_times=all_times(desired);                  % extract the times for these pulses

