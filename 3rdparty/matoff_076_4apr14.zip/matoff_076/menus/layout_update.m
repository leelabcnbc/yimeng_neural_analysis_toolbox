function layout_update()
%   respond to a change in the layout menu if 
%   autoupdate is set.
%
global auto_update

if auto_update
   if process
      parse_command('old plot');  % plot if trials found
   end;
end; 

% END

