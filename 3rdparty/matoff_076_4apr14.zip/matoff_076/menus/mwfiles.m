function response=mwfiles(afilename,bfilename)
%
%  MWfiles command
% 
% Inputs
%  afilename         file created with SET MWU KEEP command
%  bfilename         file created with SET MWU KEEP command
% Output 
%  Response     string:
%               Significant=   0  not significant for whatever reason, or
%                              1  significant based on z score or Wx value (2-tailed, p < .05)
%                m=            size of smaller group
%                n=            size of larger group
%                Wx= or z=     Wilcoxon statistic if relevant and no z score was reported, or
%                              z score if relevant
%                              Neither Wx or z is given if the sample is too small
%
%   Example output:   
%   Significant= 0   m= 10     n= 21    z= 1.315
%


global environment 
global error_fid warning_fid debug_fid
global errors warnings debugs

Wx=NaN;
z=NaN;
decision=0;
m=0;
n=0;

% test for useable parameters
if isempty(afilename) | isempty(bfilename)
   response='Missing file name';   % check for any file name
   return;
end;

% Open and read first file
afile_name=filepath(afilename,environment.statpath);
a_fid=fopen(afile_name,'rt');  
if a_fid < 0 
    response=['Cannot open file ' afile_name];
    return;
else
    a=fscanf(a_fid,'%u',inf);
    fclose(a_fid);  
end;

bfile_name=filepath(bfilename,environment.statpath);
b_fid=fopen(bfile_name,'rt');  
if b_fid < 0 
    response=['Cannot open file ' bfile_name];
    return;
else
    b=fscanf(b_fid,'%u',inf);
    fclose(b_fid);
end;

[decision,m,n,Wx,z]=wilcoxon_stat(a,b);

response= sprintf('Significant= %-1d   m= %-4d   n= %-4d  ',decision,m,n) ;

if ~isnan(Wx)
   response=[response sprintf('Wx= %-6.1d   ',Wx)];
end;

if ~isnan(z)
   response=[response sprintf('z= %-6.3f',z)];
end;



