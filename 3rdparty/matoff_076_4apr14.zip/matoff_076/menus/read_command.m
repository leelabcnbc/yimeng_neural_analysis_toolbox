function read_command(params,output_file)
%
%  execute pcoff "read" command to list the contents of a data file
%
%  read command and its parameters:
%    read [events codes pulses spikes analog which all relevant out=<filename> or append=<filename>]
%
% all parameters are optional.  Only the first 3 characters of an option are necessary.
% events:   include event codes
% codes:    same as events
% pulses:   include pulses
% spikes:   same as pulses
% analog:   include analog
% all:      same as events + pulses + analog
% which:    make summary listing of all channels and codes
% page:     pause at end of each page
% relevant: list events without event times, omit events listed in globalignore
%
% out=<filename>     will send the results to a new file (overwriting any existing file of the same name)
% append=<filename>  will append the results to an existing file (or create a file)
%
% input_file is a required base file name (no extensions)
%
% Inputs
%   params       parameters for the read command
%   output_file  name of optional output file
%
global work_index work_udef 
global environment taint
global error_fid warning_fid debug_fid
global errors warnings debugs
 
event_fid=-3; 
out_fid=-3;
pulse_fid=-3;
analog_fid=-3;

max_noise=50;
basefilename=get(findobj('Tag','filename'),'String');
basefilename=filepath(basefilename,environment.datapath); 
page_count=0;
page_length=30;

output_time(1)=0;
output(1).string='event';
outind=2; % index for output
relevant=0;  %flag
abort=0;


if ~isempty(findstr(params,'all'))
   params=['events pulses analog ' params];
end;

if ~isempty(findstr(params,'which'))
   which_only=1;
   params=['events pulses analog ' params];
else
   which_only=0;
end;

if ~isempty(output_file)  % check for an output file name
   if ~isempty(findstr(params,'out'))  % is this an append or overwrite?
      out_fid=fopen(output_file,'wt');
      fprintf(1,'creating file: %s\n',output_file);
      if environment.logging==1
         fprintf(fid.log,'creating file: %s\n',output_file);
      end;
      max_noise=1;   % used to limit the number of error messages
   elseif  ~isempty(findstr(params,'append')) 
      out_fid=fopen(output_file,'at');
      fprintf(1,'appending to file: %s\n',output_file);
      if environment.logging==1
         fprintf(fid.log,'appending to file: %s\n',output_file);
      end;
      max_noise=1;   % used to limit the number of error messages
   else
     if errors
        fprintf(error_fid,'Error [read_command]. Output file specified, but command not recognized.\n');
     end;  
     out_fid=-1;
   end;
end;

if ~isempty(findstr(params,'rel'))  % relevant
   which_only=0;
   params=['rel'];   % override other parameters!
   relevant=1;
   glo_list=expand_range_list(get(findobj('Tag','globalignore'),'String'));  % fetch globalignore list
end;

unit_number=get(findobj('Tag','unit'),'Value');  % GUI unit number matches work_udef subscript

if ~isempty(findstr(params,'eve')) | ~isempty(findstr(params,'cod')) | relevant
   event_fid=fopen([basefilename '.event']);
   selected_event_data=read_event_record(event_fid,work_udef(unit_number).trials);
end;

if (~isempty(findstr(params,'pul')) | ~isempty(findstr(params,'spi')))
   pulse_fid=fopen([basefilename '.pulse']);
   selected_pulse_data=read_pulse_record(pulse_fid,work_udef(unit_number).trials);
end;


if ~isempty(findstr(params,'ana'))
   analog_fid=fopen([basefilename '.analog']);
   frequency=str2num(get(findobj('Tag','frequency'),'String'));
   if (frequency > 0)
      frequency_step= (10000/frequency);
   else
      frequency_step=40;  % default 250 Hz
   end;
   analog_start_time=0;
end;

% look in environment for analog start code.  default is 100
analogstart=100;
if ~isempty(environment.analogstart)
    [dummy,value,valid]=check_string_value(environment.analogstart,1,10000);   % limit to event code 10,000
    if valid
       analogstart=value;
    else
       if warnings
          fprintf(warning_fid,'Warning [list_analog]. Invalid analogstart environmental variable. Using default of 100.\n');
       end;
    end;
end;

  
source_trial=0;

% Cycle through all the trials in the data file that are listed for this unit
for trial=work_udef(unit_number).trials
   source_trial=source_trial+1;   % this would be the trial number specified by sourcetrial
   clear output_time;   % cumulative string array of all event,analog,spike times
   clear output;        % cumulative string array of all event,analog,spikes
   if which_only | relevant
      outind=1;      % output will start at first byte
   else 
      output_time(1)=0;  
      output(1).string='event/pulse/analog';  % initialize output string
      outind=2;                               % output will start at second byte
   end;   
   
   % == events (codes)
   if ~isempty(findstr(params,'eve')) | ~isempty(findstr(params,'cod')) | relevant
      trial_marker=selected_event_data(1,(2*source_trial)-1);  % find the trial in the cached data file 
      trial_number=selected_event_data(1,(2*source_trial));
      codes=selected_event_data(2:end,(2*source_trial)-1);     % get all the codes and matching times
      codes=codes(find(~isnan(codes)));   % remove nans
      times=selected_event_data(2:end,(2*source_trial));
      times=times(find(~isnan(times)));   % remove nans

      if relevant   % remove global ignore codes, algorithm borrowed from work_scan.m
         % make a list of pointers to codes we should ignore
         ignore_elements=find_any(codes,glo_list);
   
         % use the list of pointers to remove the elements from both codes and times
         codes=codes(yank_elements(ignore_elements,length(codes)));
         times=times(yank_elements(ignore_elements,length(times)));
      end;

      if trial_number ~= trial
         if max_noise > 0
            if errors
               fprintf(error_fid,'Error [read_command]. Trial number mismatch in event file. \n');
            end;
            max_noise=max_noise-1;
         end;
         if ~isempty(fopen(event_fid))
           fclose(event_fid);
           event_fid=-1;
         end;
         if ~isempty(fopen(out_fid))
           fclose(out_fid);
           out_fid=-1;
         end;
         if ~isempty(fopen(pulse_fid))
           fclose(pulse_fid);
           pulse_fid=-1;
         end;
         if ~isempty(fopen(analog_fid))
           fclose(analog_fid);
           analog_fid=-1;
         end; 
         return;
      end;
      if ~isempty(codes)  % any codes?
         length_codes=length(codes); 
         if which_only==1  % summary report?
             output(outind).string= ['number of events          ' num2str(length_codes)];
             output_time(outind)=0;
             outind=outind+1;     
         else 
             for i=1:length(codes)
                if relevant
                   output(outind).string=num2str(codes(i));
                else
                   output(outind).string= ['<event>     ' num2str(codes(i))];
                end;
                output_time(outind)=times(i);
                outind=outind+1;
             end;       
             ast=times(find(codes==analogstart));  % find out when analog starts.
             if length(ast) > 1
                 analog_start_time=ast(1);  % several occurrances of analogstart code (usually 100)
             elseif (isempty(ast))
                analog_start_time=0;      % no occurrance of analogstart code
             else
                analog_start_time=ast;   % exactly one occurrance
             end;
         end;  % summary report  
      else
         analog_start_time=0;
      end; % any codes
   end; % if event (code)
   
   
   % === pulses (spikes)
   if ~isempty(findstr(params,'pul'))  | ~isempty(findstr(params,'spi'))
      trial_marker=selected_pulse_data(1,(2*source_trial)-1);
      trial_number=selected_pulse_data(1,(2*source_trial));
      chans=selected_pulse_data(2:end,(2*source_trial)-1); 
      channel_number=chans(find(~isnan(chans)));   % remove nans
      times=selected_pulse_data(2:end,(2*source_trial));
      timestamp=times(find(~isnan(times)));   % remove nans

      if trial_number ~= trial
         if max_noise > 0
            if errors
               fprintf(error_fid,'Error [read_command]. Trial number mismatch in pulse file. \n');
            end;
         end;
         if ~isempty(fopen(event_fid))
           fclose(event_fid);
           event_fid=-1;
         end;
         if ~isempty(fopen(out_fid))
           fclose(out_fid);
           out_fid=-1;
         end;
         if ~isempty(fopen(pulse_fid))
           fclose(pulse_fid);
           pulse_fid=-1;
         end;
         if ~isempty(fopen(analog_fid))
           fclose(analog_fid);
           analog_fid=-1;
         end; 
         return;  % abort
      end;
  
      length_spikes=length(timestamp); 
      if which_only==1  % summary report?   
         output(outind).string= ['number of spikes          ' num2str(length_spikes) ];
         output_time(outind)=0;
         outind=outind+1;      
      else
         for i=1:length(timestamp)
            output(outind).string= ['<spike>            ' num2str(channel_number(i)) ];
            output_time(outind)=timestamp(i);
            outind=outind+1;
         end;
      end;  
   end; % if pulse
   
   
   % === analog 
   if ~isempty(findstr(params,'ana')) 
      chans=get(findobj('Tag','xchannelmenu'),'Value') - 1;  % for the moment we support only the X analog channel
      if (chans < 1) | (chans > 7)
         if warnings
            fprintf(warning_fid,'Warning [read_command]. Must select valid X analog channel to read analog.\n');
            return;
         end;
      end;
      [analog]=read_analog_record(analog_fid,trial,chans);  % !!! is this the correct "trial" to use? !!!
      if isempty(analog) 
         if max_noise > 0
            if warnings
               fprintf(warning_fid,'Error [read_command]. No analog data \n');
            end;
            max_noise=max_noise-1;
         end;
      end;
      
      %    analog      row is one "sorted trial" with n columns of data followed 
      %                by some number of NaNs. 
      analog_time=analog_start_time;
      
      length_analog=length(analog); 
      if which_only==1  % summary report?   
         output(outind).string= ['number of analog samples  ' num2str(length_analog) ];
         output_time(outind)=0;
         outind=outind+1;      
      else    
         for sample_number=1:length(analog)          % collate all the samples
            output(outind).string= ['<analog X sample ' num2str(sample_number) '  on chan ' num2str(chans) ...
                                    '>             '  num2str(analog(sample_number))];
            output_time(outind)=analog_time;
            analog_time=analog_time+frequency_step;  % advance time for next sample
            outind=outind+1;                         % advance index for next sample
         end;     
      end;
   end; % if analog
   
   % sort by time (shuffle different data types)
   [dummy,sort_index]=sort(output_time);
   if relevant    % relevant option has its own output format:
                  % master trial,source trial,event1,event2,event2...

       if out_fid < 0
          fprintf('%d,%d', trial,source_trial);   % master trial,source trial
          page_count=page_count+1;
       else
          fprintf(out_fid,'%d,%d', trial,source_trial);
       end; 
       
       for noi=1:length(sort_index)
          outind=sort_index(noi);
          if length(output_time) < 2
             output_time(2)=0;
          end;
          if out_fid < 0
             fprintf(',%-s',output(outind).string);
          else
             fprintf(out_fid,',%-s',output(outind).string);
          end; %is empty output_file
       end; % for noi=1:length(sort_index)

       if out_fid < 0
          fprintf('\n');   
          page_count=page_count+1;
          if page_count > page_length
            page_count=0;
            r = input('    <cr> to continue, <q> to quit   ','s') ;
            if strncmp(r,'q',1)
               if ~isempty(fopen(event_fid))
                   fclose(event_fid);
                   event_fid=-1;
               end;
               if ~isempty(fopen(out_fid))
                   fclose(out_fid);
                   out_fid=-1;
               end;
               if ~isempty(fopen(pulse_fid))
                   fclose(pulse_fid);
                   pulse_fid=-1;
               end;
               if ~isempty(fopen(analog_fid))
                   fclose(analog_fid);
                   analog_fid=-1;
               end; 
               return;
             end; % quit
          end; % page_count   
       else
          fprintf(out_fid,'\n');
       end; 

   else


       
       if out_fid < 0
          fprintf('\n        Master Trial %d   Source Trial %d\n', trial,source_trial);
          page_count=page_count+1;
       else
          fprintf(out_fid,'\n     Master Trial %d   Source Trial %d    \n', trial,source_trial);
       end; 
       
       for noi=1:length(sort_index)
          outind=sort_index(noi);
          if length(output_time) < 2
             output_time(2)=0;
          end;
          if out_fid < 0
             fprintf('%-6d   %-s\n',output_time(outind),output(outind).string);
             page_count=page_count+1;
             if page_count > page_length
                page_count=0;
                r = input('    <cr> to continue, <q> to quit   ','s') ;
                if strncmp(r,'q',1)
                   if ~isempty(fopen(event_fid))
                       fclose(event_fid);
                       event_fid=-1;
                   end;
                   if ~isempty(fopen(out_fid))
                       fclose(out_fid);
                       out_fid=-1;
                   end;
                   if ~isempty(fopen(pulse_fid))
                       fclose(pulse_fid);
                       pulse_fid=-1;
                   end;
                   if ~isempty(fopen(analog_fid))
                       fclose(analog_fid);
                       analog_fid=-1;
                   end; 
                   return;
                end; % quit
             end; % page_count   
          else
             fprintf(out_fid,'%-6d   %-s\n',output_time(outind),output(outind).string);
          end; %is empty output_file
       end; % for output_list
   end; % if relevant
   
end;  % trial loop

if ~isempty(fopen(event_fid))
   fclose(event_fid);
   event_fid=-1;
end;
if ~isempty(fopen(out_fid))
   fclose(out_fid);
   out_fid=-1;
end;
if ~isempty(fopen(pulse_fid))
   fclose(pulse_fid);
   pulse_fid=-1;
end;
if ~isempty(fopen(analog_fid))
   fclose(analog_fid);
   analog_fid=-1;
end; 