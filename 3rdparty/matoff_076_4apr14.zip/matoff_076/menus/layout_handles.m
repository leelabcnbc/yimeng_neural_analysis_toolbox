function layout_handles
%
% Initialize h_layout   h_layout is a collection of handles to
% the current layout parameters displayed in the menus. There are
% 10 groups of layouts stored in global "layout". Only one group
% is active, and that is the group in the layout menus.
% 
%
%  Globals changed
%     h_layout
%
global h_layout
global error_fid warning_fid debug_fid trace_fid
global errors warnings debugs

% from main layout menu
h_layout.raster_on_off=findobj('Tag','raster_on_off');
h_layout.raster_tic_size=findobj('Tag','raster_tic_size');
h_layout.raster_label_size=findobj('Tag','raster_label_size');
h_layout.raster_separation=findobj('Tag','raster_separation');
h_layout.raster_y_pos=findobj('Tag','raster_y_pos');

h_layout.hide_plot=findobj('Tag','hide_plot');
h_layout.hide_xaxis=findobj('Tag','hide_xaxis');
h_layout.xatzero=findobj('Tag','xatzero');
h_layout.autoupdate=findobj('Tag','autoupdate');

h_layout.centerline_on_off=findobj('Tag','centerline_on_off');
h_layout.centerline_y_pos=findobj('Tag','centerline_y_pos');
h_layout.centerline_style=findobj('Tag','centerline_style');
h_layout.centerline_size=findobj('Tag','centerline_size');

h_layout.histogram_on_off=findobj('Tag','histogram_on_off');
h_layout.histogram_y_pos=findobj('Tag','histogram_y_pos');
h_layout.histogram_size=findobj('Tag','histogram_size');
h_layout.histogram_style=findobj('Tag','histogram_style');
h_layout.histogram_binwidth=findobj('Tag','histogram_binwidth');
h_layout.histogram_scale=findobj('Tag','histogram_scale');
h_layout.histogram_scale_on_off=findobj('Tag','histogram_scale_on_off');
h_layout.histogram_raw_on_off=findobj('Tag','histogram_raw_on_off');
h_layout.histogram_ref_on_off=findobj('Tag','histogram_ref_on_off');
h_layout.histogram_ref_limits=findobj('Tag','histogram_ref_limits');
h_layout.histogram_ref_color=findobj('Tag','histogram_ref_color');

h_layout.analog_on_off=findobj('Tag','analog_on_off');
h_layout.analog_y_pos=findobj('Tag','analog_y_pos');
h_layout.analog_trace_size=findobj('Tag','analog_trace_size');
h_layout.analog_style=findobj('Tag','analog_style');
h_layout.analog_separation=findobj('Tag','analog_separation');

h_layout.analog2_on_off=findobj('Tag','analog2_on_off');
h_layout.analog2_y_pos=findobj('Tag','analog2_y_pos');
h_layout.analog2_style=findobj('Tag','analog2_style');
h_layout.analog2_trace_size=findobj('Tag','analog2_trace_size');
h_layout.analog2_separation=findobj('Tag','analog2_separation');

% from layout menu2
h_layout.average_on_off=findobj('Tag','average_on_off');
h_layout.average_trace_size=findobj('Tag','average_trace_size');
h_layout.average_y_pos=findobj('Tag','average_y_pos');
h_layout.average_style=findobj('Tag','average_style');
h_layout.average2_style=findobj('Tag','average2_style');
h_layout.average2_y_pos=findobj('Tag','average2_y_pos');
h_layout.average2_trace_size=findobj('Tag','average2_trace_size');
h_layout.average2_on_off=findobj('Tag','average2_on_off');

h_layout.dxdt_style=findobj('Tag','dxdt_style');
h_layout.dxdt_y_pos=findobj('Tag','dxdt_y_pos');
h_layout.dxdt_separation=findobj('Tag','dxdt_separation');
h_layout.dxdt_trace_size=findobj('Tag','dxdt_trace_size');
h_layout.dxdt_on_off=findobj('Tag','dxdt_on_off');
h_layout.dxdt2_on_off=findobj('Tag','dxdt2_on_off');
h_layout.dxdt2_trace_size=findobj('Tag','dxdt2_trace_size');
h_layout.dxdt2_separation=findobj('Tag','dxdt2_separation');
h_layout.dxdt2_y_pos=findobj('Tag','dxdt2_y_pos');
h_layout.dxdt2_style=findobj('Tag','dxdt2_style');

h_layout.RIP_on_off=findobj('Tag','RIP_on_off');
h_layout.RIP_y_pos=findobj('Tag','RIP_y_pos');
h_layout.RIP_size=findobj('Tag','RIP_size');
h_layout.RIP_style=findobj('Tag','RIP_style');

h_layout.heading_on_off=findobj('Tag','heading_on_off');
h_layout.heading_x_pos=findobj('Tag','heading_x_pos');
h_layout.heading_y_pos=findobj('Tag','heading_y_pos');
h_layout.heading_size=findobj('Tag','heading_size');

% from layout menu3
h_layout.xy_overlap_on_off=findobj('Tag','xy_overlap_on_off');
h_layout.xy_on_off=findobj('Tag','xy_on_off');
h_layout.xy_trace_size=findobj('Tag','xy_trace_size');
h_layout.xy_separation=findobj('Tag','xy_separation');
h_layout.xy_y_pos=findobj('Tag','xy_y_pos');
h_layout.xy_x_pos=findobj('Tag','xy_x_pos');
h_layout.xy_style=findobj('Tag','xy_style');

h_layout.avxy_on_off=findobj('Tag','avxy_on_off');
h_layout.avxy_x_pos=findobj('Tag','avxy_x_pos');
h_layout.avxy_y_pos=findobj('Tag','avxy_y_pos');
h_layout.avxy_style=findobj('Tag','avxy_style');
h_layout.avxy_trace_size=findobj('Tag','avxy_trace_size');

h_layout.xy_time_criteria=findobj('Tag','xy_time_criteria');
h_layout.xy_time_start=findobj('Tag','xy_time_start');
h_layout.xy_time_stop=findobj('Tag','xy_time_stop');

h_layout.history_spot_on_off=findobj('Tag','history_spot_on_off');
h_layout.history_spot_first_class=findobj('Tag','history_spot_first_class');
h_layout.history_spot_last_class=findobj('Tag','history_spot_last_class');
h_layout.history_spot_color=findobj('Tag','history_spot_color');

h_layout.validate_spikes_on_off=findobj('Tag','validate_spikes_on_off');
h_layout.valid_spikes_start_class=findobj('Tag','valid_spikes_start_class');
h_layout.valid_spikes_end_class=findobj('Tag','valid_spikes_end_class');
h_layout.invalid_spike_color=findobj('Tag','invalid_spike_color');


% from sequence menu
h_layout.segments_on_off=findobj('Tag','segments_on_off');
h_layout.sortrangeshow=findobj('Tag','sortrangeshow');

% from text layout menu
h_layout.text_on_off=findobj('Tag','text_on_off');
error_exit=[ 'fprintf(error_fid,''Error [layout_handles]. Cannot create text menu handles\n''); return; '];
for i=1:9
   stnum=num2str(i);
   tag=['text' stnum '_on_off'];
   eval(['h_layout.' tag '=findobj(''Tag'',''' tag ''');' ],error_exit );
   tag=['text' stnum '_x_pos'];
   eval(['h_layout.' tag '=findobj(''Tag'',''' tag ''');' ],error_exit );
   tag=['text' stnum '_y_pos'];
   eval(['h_layout.' tag '=findobj(''Tag'',''' tag ''');' ],error_exit ); 
   tag=['text' stnum '_size'];
   eval(['h_layout.' tag '=findobj(''Tag'',''' tag ''');' ],error_exit ); 
   tag=['text' stnum '_angle'];
   eval(['h_layout.' tag '=findobj(''Tag'',''' tag ''');' ],error_exit ); 
   tag=['text' stnum '_color'];
   eval(['h_layout.' tag '=findobj(''Tag'',''' tag ''');' ],error_exit );    
   tag=['text' stnum '_string'];
   eval(['h_layout.' tag '=findobj(''Tag'',''' tag ''');' ],error_exit );
   tag=['text' stnum '_frame'];
   eval(['h_layout.' tag '=findobj(''Tag'',''' tag ''');' ],error_exit );
end;
   
   