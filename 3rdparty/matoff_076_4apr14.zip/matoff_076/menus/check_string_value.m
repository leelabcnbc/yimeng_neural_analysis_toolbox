function [clean_string,value,valid]=check_string_value(input_string,lower_limit,upper_limit)
%
%  Check the validity of a numeric value delivered in a string
%
%  Inputs:
%   input_string    string to check
%   lower_limit     lowest valid value
%   upper_limit     highest valid value
%
%  Returns:
%    clean_string   spaces are stripped off
%    value          converted value
%    valid          1 if string reduces to valid numeric within limits
%
%
valid=0;
clean_string='';
value=0;
if isempty(input_string)
   return;
end
clean_string=strtrim(input_string);
if ischar(clean_string)
   value=str2num(clean_string);
else
   return;
end
if isempty(value) 
   return; 
end
if (value < lower_limit) || (value > upper_limit) 
   return; 
end
valid=1;
