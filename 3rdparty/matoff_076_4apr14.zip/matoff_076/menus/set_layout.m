function success=set_layout(v_layout)
% Update the GUI to match the current layout. 
% Global h_layout is a structure that holds the layout values
%
% Inputs
%   v_layout    complete set of layout command values
% Outputs
%   success     1 is normal exit, 0 is a failure
% Globals modified
%   h_layout    handles to layout elements
%
% Most of this program was automatically generated with 
% figscan.pl  perl script.
% 
global h_layout   % handles to the layout objects
global error_fid warning_fid debug_fid trace_fid
global errors warnings debugs
%
%
success=1;

try
   % from layout_menu.m
   set(h_layout.raster_on_off,'Value', v_layout.raster_on_off);
   set(h_layout.raster_tic_size,'String', v_layout.raster_tic_size);
   set(h_layout.raster_label_size,'String', v_layout.raster_label_size);
   set(h_layout.raster_separation,'String', v_layout.raster_separation);
   set(h_layout.raster_y_pos,'String', v_layout.raster_y_pos);

   set(h_layout.hide_plot,'Value',v_layout.hide_plot);
   set(h_layout.hide_xaxis,'Value',v_layout.hide_xaxis);
   set(h_layout.xatzero,'Value', v_layout.xatzero);

   set(h_layout.centerline_on_off,'Value', v_layout.centerline_on_off);
   set(h_layout.centerline_y_pos,'String', v_layout.centerline_y_pos);
   set(h_layout.centerline_style,'Value', v_layout.centerline_style);
   set(h_layout.centerline_size,'String', v_layout.centerline_size);


   set(h_layout.histogram_on_off,'Value', v_layout.histogram_on_off);
   set(h_layout.histogram_y_pos,'String', v_layout.histogram_y_pos);
   set(h_layout.histogram_size,'String', v_layout.histogram_size);
   set(h_layout.histogram_style,'Value', v_layout.histogram_style);
   set(h_layout.histogram_binwidth,'String', v_layout.histogram_binwidth);
   set(h_layout.histogram_scale,'String', v_layout.histogram_scale);
   set(h_layout.histogram_scale_on_off,'Value',v_layout.histogram_scale_on_off);
   set(h_layout.histogram_raw_on_off,'Value', v_layout.histogram_raw_on_off);
   set(h_layout.histogram_ref_on_off,'Value', v_layout.histogram_ref_on_off);
   set(h_layout.histogram_ref_limits,'String', v_layout.histogram_ref_limits);
   set(h_layout.histogram_ref_color,'Value', v_layout.histogram_ref_color);

   set(h_layout.analog_on_off,'Value', v_layout.analog_on_off);
   set(h_layout.analog_y_pos,'String', v_layout.analog_y_pos);
   set(h_layout.analog_trace_size,'String', v_layout.analog_trace_size);
   set(h_layout.analog_style,'Value', v_layout.analog_style);
   set(h_layout.analog_separation,'String', v_layout.analog_separation);

   set(h_layout.analog2_on_off,'Value', v_layout.analog2_on_off);
   set(h_layout.analog2_y_pos,'String', v_layout.analog2_y_pos);
   set(h_layout.analog2_style,'Value', v_layout.analog2_style);
   set(h_layout.analog2_trace_size,'String', v_layout.analog2_trace_size);
   set(h_layout.analog2_separation,'String', v_layout.analog2_separation);

   % from layout_menu2.m
   set(h_layout.average_on_off,'Value', v_layout.average_on_off);
   set(h_layout.average_trace_size,'String', v_layout.average_trace_size);
   set(h_layout.average_y_pos,'String', v_layout.average_y_pos);
   set(h_layout.average_style,'Value', v_layout.average_style);
   set(h_layout.average2_style,'Value', v_layout.average2_style);
   set(h_layout.average2_y_pos,'String', v_layout.average2_y_pos);
   set(h_layout.average2_trace_size,'String', v_layout.average2_trace_size);
   set(h_layout.average2_on_off,'Value', v_layout.average2_on_off);

   set(h_layout.dxdt2_on_off,'Value', v_layout.dxdt2_on_off);
   set(h_layout.dxdt2_trace_size,'String', v_layout.dxdt2_trace_size);
   set(h_layout.dxdt2_separation,'String', v_layout.dxdt2_separation);
   set(h_layout.dxdt2_y_pos,'String', v_layout.dxdt2_y_pos);
   set(h_layout.dxdt2_style,'Value', v_layout.dxdt2_style);
   set(h_layout.dxdt_style,'Value', v_layout.dxdt_style);
   set(h_layout.dxdt_y_pos,'String', v_layout.dxdt_y_pos);
   set(h_layout.dxdt_separation,'String', v_layout.dxdt_separation);
   set(h_layout.dxdt_trace_size,'String', v_layout.dxdt_trace_size);
   set(h_layout.dxdt_on_off,'Value', v_layout.dxdt_on_off);

   set(h_layout.heading_on_off,'Value',v_layout.heading_on_off);
   set(h_layout.heading_x_pos,'String',v_layout.heading_x_pos);
   set(h_layout.heading_y_pos,'String',v_layout.heading_y_pos);
   set(h_layout.heading_size,'String',v_layout.heading_size);

   set(h_layout.RIP_on_off,'Value', v_layout.RIP_on_off);
   set(h_layout.RIP_y_pos,'String', v_layout.RIP_y_pos);
   set(h_layout.RIP_size,'String', v_layout.RIP_size);
   set(h_layout.RIP_style,'Value', v_layout.RIP_style);

   % from layout_menu3.m
   set(h_layout.xy_overlap_on_off,'Value',v_layout.xy_overlap_on_off);
   set(h_layout.xy_on_off,'Value', v_layout.xy_on_off);
   set(h_layout.xy_trace_size,'String', v_layout.xy_trace_size);
   set(h_layout.xy_separation,'String', v_layout.xy_separation);
   set(h_layout.xy_x_pos,'String', v_layout.xy_x_pos);
   set(h_layout.xy_y_pos,'String', v_layout.xy_y_pos);
   set(h_layout.xy_style,'Value', v_layout.xy_style);

   set(h_layout.avxy_style,'Value', v_layout.avxy_style);
   set(h_layout.avxy_y_pos,'String', v_layout.avxy_y_pos);
   set(h_layout.avxy_trace_size,'String', v_layout.avxy_trace_size);
   set(h_layout.avxy_on_off,'Value', v_layout.avxy_on_off);
   set(h_layout.avxy_x_pos,'String', v_layout.avxy_x_pos);

   set(h_layout.xy_x_pos,'String', v_layout.xy_x_pos);
   set(h_layout.xy_time_criteria,'Value',v_layout.xy_time_criteria);
   set(h_layout.xy_time_start,'String',v_layout.xy_time_start);
   set(h_layout.xy_time_stop,'String',v_layout.xy_time_stop);

   set(h_layout.history_spot_on_off,'String',v_layout.history_spot_on_off);
   set(h_layout.history_spot_first_class,'String',v_layout.history_spot_first_class);
   set(h_layout.history_spot_last_class,'String',v_layout.history_spot_last_class);
   set(h_layout.history_spot_color,'Value', v_layout.history_spot_color);

   set(h_layout.validate_spikes_on_off,'String',v_layout.validate_spikes_on_off);
   set(h_layout.valid_spikes_start_class,'String',v_layout.valid_spikes_start_class);
   set(h_layout.valid_spikes_end_class,'String',v_layout.valid_spikes_end_class);
   set(h_layout.invalid_spike_color,'Value', v_layout.invalid_spike_color);


   % sequence menu
   set(h_layout.segments_on_off,'Value', v_layout.segments_on_off);
   set(h_layout.sortrangeshow,'Value',v_layout.sortrangeshow);

   % from layout_menu_text.m

   error_exit= 'fprintf(error_fid,''Error [set_layout]. Cannot set text menu values\n''); return; ';
   for i=1:9
      stnum=num2str(i);
      tag=['text' stnum '_on_off'];
      eval(['set(h_layout.' tag ',''Value'',v_layout.' tag ');' ],error_exit );
      tag=['text' stnum '_x_pos'];
      eval(['set(h_layout.' tag ',''String'',v_layout.' tag ');' ],error_exit );
      tag=['text' stnum '_y_pos'];
      eval(['set(h_layout.' tag ',''String'',v_layout.' tag ');' ],error_exit ); 
      tag=['text' stnum '_size'];
      eval(['set(h_layout.' tag ',''String'',v_layout.' tag ');' ],error_exit ); 
      tag=['text' stnum '_angle'];
      eval(['set(h_layout.' tag ',''Value'',v_layout.' tag ');' ],error_exit ); 
      tag=['text' stnum '_color'];
      eval(['set(h_layout.' tag ',''Value'',v_layout.' tag ');' ],error_exit );    
      tag=['text' stnum '_string'];
      eval(['set(h_layout.' tag ',''String'',v_layout.' tag ');' ],error_exit );
      tag=['text' stnum '_frame'];
      eval(['set(h_layout.' tag ',''String'',v_layout.' tag ');' ],error_exit );
   end;


catch
   success=0;   
   if errors
      fprintf(error_fid,'Error [set_layout]. Unable to completely copy layout parameters into the GUI.\n');
      fprintf(error_fid,'%s\n',lasterr);
   end; 
end;