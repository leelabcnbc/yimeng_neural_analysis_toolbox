function marks(trial_list,mark,mark_timestamp,shift_from_top,spacing,markerheight,style)
%
%  Draw markers under rasters on the current plot (raster-oriented)
%
%  Note: all vectors must be column vectors.
%  Inputs
%    trial_list   There will be one raster line for each number in the
%                 trial_list.  Whenever a number in the trial_list is found 
%                 in trial, the corresponding timestamp is used to draw the mark.
%                 The order of trial_list determines the order of the rasters.           
%               
%    mark mark_timestamp   each marker has an associated trial number and timestamp.
%  
%    shift_from_top    Floating point value. 0 = top, 1 = bottom.
%    spacing           Floating point value. 0 = all raster on one line, 1 = one
%                                          entire page per raster.
%    markerheight      Floating point value. 0 = no mark, 5 = large mark
%
global error_fid warning_fid debug_fid
global errors warnings debugs

[a b]=size(trial_list);
if b > a 
   if errors
      fprintf(error_fid,'Internal Error [marks]. trial_list is row vector.\n');
   end
   trial_list=trial_list';
end
[a b]=size(mark);
if b > a 
   if errors
      fprintf(error_fid,'Internal Error [marks]. mark is row vector.\n');
   end
   return;
end
if size(mark,1) ~= size(mark_timestamp,1)
   if errors
      fprintf(error_fid,'Internal Error [marks]. mark and mark_timestamp arrays do not match.\n');
   end
   return;
end

X = [];
Y = [];

y0 = 1-shift_from_top;
for i_trial = 1:length(trial_list)
      tndx = find(mark == trial_list(i_trial));
      if ~isempty(tndx)
         x = mark_timestamp(tndx);
         y = zeros(size(x))+y0;       
         X = [X;x];
         Y = [Y;y];  
      end % if empty tndx
   y0 = y0 - spacing;
end

current_units = get(gca,'units');
set(gca,'units','normalized');
plot(X,Y,style,'markersize',markerheight*2.5*100);
set(gca,'units',current_units);

