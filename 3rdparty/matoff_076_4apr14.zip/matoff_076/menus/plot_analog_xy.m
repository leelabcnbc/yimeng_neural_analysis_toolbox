function plot_analog_xy(xzero,sorted_trial_list,handles)
%
% Draw a XY plot 
%
% Inputs
%    xzero                Location of 0 on the x axis (calculated in make_plot)
%    sorted_trial_list    Sorted list of trial numbers that match search criteria
%                         Map these back to file trials with: work_trial_list(sorted_trial_list)
%                         All times in absolute units (not PCOFF units)
%    
% Outputs
%    none
%
global spikemap event_codes event_times 
global RESCALE_TIME ANALOG_RANGE
global work_trial_list work_analog_start_stop
global time_zero plot_number
global work_fid environment
global error_fid warning_fid debug_fid
global errors warnings debugs
global selected_unit_trials


main_handle=handles(1);
left_handle=handles(2);
right_handle=handles(3);
bottom_handle=handles(4);

% sorted_trial_list is the ordered list of trials to analyze based on the TRIALS command
if isempty(work_trial_list)
   if debugs
      fprintf(debug_fid,'Debug [plot_analog_xy]. No analog trials to plot.\n');
   end;
   return;
end;
shift=str2num(get(findobj('Tag','shift'),'String'));
% Calculate the start and end of the display window
window=str2num(get(findobj('Tag','window'),'String'));   
start_time = 10 * (-(window/2)+shift) / RESCALE_TIME;     % convert to seconds
end_time   = 10 * ( (window/2)+shift) / RESCALE_TIME;     % convert to seconds

% fetch analog data

chan1=get(findobj('Tag','xchannelmenu'),'Value')-1;   % first analog
chan2=get(findobj('Tag','ychannelmenu'),'Value')-1;   % second analog

if (chan1 < 1) | (chan2 < 1)
   if warnings
      fprintf(warning_fid,'Warning [plot_analog_xy].  Cannot plot XY data without two channels defined.\n');
   end;
   return;
end;


lower_time_limit= -60000 ; % one minute is plenty
upper_time_limit= 60000;

% time_range_criteria     Basis for limiting the time range of the XY data
%                         1= all data, 2=time range, 3=time between event codes
time_range_criteria=get(findobj('Tag','xy_time_criteria'),'Value');
if debugs
   fprintf(debug_fid,'Debug [plot_analog_xy]. Time range criteria = %d.\n',time_range_criteria);
end;
%-------------------------------------------------------------------------------------
if time_range_criteria == 1  % just use all A/D data
    % column 1 has all the same start times, column 2 has all the same stop times
    start_stop=[ (ones(length(sorted_trial_list),1)*lower_time_limit) ... 
          (ones(length(sorted_trial_list),1)*upper_time_limit) ] ;   
    if debugs
      fprintf(debug_fid,'Debug [plot_analog_xy]. Use all analog data.  Setting all analog XY durations to +/- 60 sec.\n');
    end;

% -------------------------------------------------------------------------------------
elseif time_range_criteria == 2  % use A/D data between two time values (relative to centering code)
   [dummy,time_range_start,valid]= ...
       check_string_value(get(findobj('Tag','xy_time_start'),'String'),lower_time_limit,upper_time_limit);
    if ~valid
       if warnings
          fprintf(warning_fid,'Warning [plot_analog_xy]. Invalid XY start time. Aborting plot.\n');
       end;
       return;
   end;   
   [dummy,time_range_stop,valid]= ...
      check_string_value(get(findobj('Tag','xy_time_stop'),'String'),lower_time_limit,upper_time_limit);
   if ~valid
       if warnings
          fprintf(warning_fid,'Warning [plot_analog_xy]. Invalid XY stop time. Aborting plot.\n');
       end;
       return;
    end;
    % column 1 has all the same start times, column 2 has all the same stop times
    start_stop=[ (ones(length(sorted_trial_list),1)*time_range_start) ... 
          (ones(length(sorted_trial_list),1)*time_range_stop) ] ;  
    if debugs
       fprintf(debug_fid,'Debug [plot_analog_xy]. Setting all analog XY durations to: %d to %d msec.\n',...
             time_range_start,time_range_stop);
    end;
    start_stop=start_stop/1000;   % convert start_stop to seconds
 
% -----------------------------------------------------------------------------------------   
 elseif time_range_criteria==3     % display A/D data between two event codes
    [number_of_trials,number_of_codes]=size(event_codes); 
    [dummy,code_start,valid]= ...
       check_string_value(get(findobj('Tag','xy_time_start'),'String'),1,number_of_codes);
    if ~valid
       if warnings
          fprintf(warning_fid,'Warning [plot_analog_xy]. Invalid XY start event number. Remember to use\n');
          fprintf(warning_fid,'event numbers (like CENTER and MARK), not event codes.   Aborting XY plot.\n');
       end;
       return;
   end;   
   [dummy,code_stop,valid]= ...
      check_string_value(get(findobj('Tag','xy_time_stop'),'String'),code_start,number_of_codes);
   if ~valid
       if warnings
          fprintf(warning_fid,'Warning [plot_analog_xy]. Invalid XY stop event number. Remember to use\n');
          fprintf(warning_fid,'event numbers (like CENTER and MARK), not event codes.   Aborting XY plot.\n');
       end;
       return;
   end;
   start_stop=[event_times(sorted_trial_list,code_start)  event_times(sorted_trial_list,code_stop)];
   start_stop=(start_stop/RESCALE_TIME)-xzero;
   
   if debugs
       fprintf(debug_fid,'Debug [plot_analog_xy]. Setting analog XY durations individually based on events.\n',...
             time_range_start,time_range_stop);
   end;
  
% ------------------------------------------------------------------------------------
elseif time_range_criteria==4   % display A/D data between two history class values
   [clean_string,value1,valid1]=check_string_value(get(findobj('Tag','xy_time_start'),'String'),1,10000);
   [clean_string,value2,valid2]=check_string_value(get(findobj('Tag','xy_time_stop'),'String'),1,10000);
   if debugs
      fprintf(debug_fid,'Debug [plot_analog_xy]. XY time range control using history classes %d and %d.\n',value1,value2);
   end;
   if valid1 & valid2
      startclass=value1;
      stopclass=value2;
      if debugs
         fprintf(debug_fid,'Debug [plot_analog_xy]. Using history classes %d and %d for analog start/stop\n',startclass,stopclass);
      end;
      all_start_trials=[];
      all_stop_trials=[];
      all_start_times=[]; 
      all_stop_times =[];
      [number_of_trials,number_of_codes]=size(event_codes); 
      for trial=1:number_of_trials        % for trials that match the sequence
         selected_trial=selected_unit_trials(trial);   % find which trial this match came from  
         list=list_trial(selected_trial);  % list_trial array was made before sequence matching
         if ~isempty(list)
            classes=list(1,:);
            values=list(2,:);
            start_index=find(classes == startclass);
            stop_index =find(classes == stopclass);
            if (length(start_index) ~= length(stop_index))
               if warnings
                  fprintf(warning_fid,'Warning [plot_analog_xy]. Number of start and stop classes do not match.\n');
               end;  
            end;
            new_start_trials=ones(length(start_index),1)*trial; 
            new_stop_trials =ones(length(stop_index),1)*trial; 
            start_time_shift=ones(1,length(start_index))*time_zero(trial)/RESCALE_TIME;   % time_zero array was created after sequence matching
            stop_time_shift=ones(1,length(stop_index))*time_zero(trial)/RESCALE_TIME;   % time_zero array was created after sequence matching
            new_start_times=(values(start_index)/1000) - start_time_shift;   % convert to seconds and align with centering code
            new_stop_times =(values(stop_index)/1000) - stop_time_shift;   % convert to seconds and align with centering code
            all_start_trials=[all_start_trials ; new_start_trials];    
            all_stop_trials=[all_stop_trials ; new_stop_trials];   
            all_start_times= [all_start_times  ; new_start_times' ];    
            all_stop_times =[all_stop_times  ; new_stop_times' ];    
         end;
      end; %for trial
      if debugs
         fprintf(debug_fid,'Debug [plot_analog_xy]. %d start times and %d stop times found\n',length(all_start_times),...
              length(all_stop_times));
      end;
      all_start_times=all_start_times - xzero;   % rescale for plot  align to time_zero
      start_stop=[all_start_times   all_stop_times];
   else
      if warnings
          fprintf(warning_fid,'Warning [make_plot]. History spot classes are not valid.  History spots disabled.\n');
      end;  
      set(findobj('Tag','history_spot_on_off'),'Value',0);   % turn off history spots
   end;



% --------------------------------------------------------------------------------------- 
else
    if errors
       fprintf(error_fid,'Internal error [plot_analog_xy]. Unknown XY time range criteria requested.\n');
    end;
    return;
 end;

if debugs

   fprintf(debug_fid,'Debug [plot_analog_xy]. Plotting XY.\n');
end;
handle=left_handle;
% handle=main_handle;
set(handle,'Visible','on');
set(plot_number,'CurrentAxes',handle);
axis([0 1 0 1]);
   
% aspect ratio depends on both the figure and the axis
position=get(handle,'Position');
width=position(3);
height=position(4);
axis_aspect_ratio=height/width;
position=get(plot_number,'Position');
width=position(3);
height=position(4);
aspect_ratio=(height/width)*axis_aspect_ratio;
   
axis manual;
hold on;
style_list=get(findobj('Tag','xy_style'),'String');   % get list of options
style_choice=get(findobj('Tag','xy_style'),'Value');  % pointer to chosen option
style_name=deblank(style_list(style_choice,:));
style='-k';  % default
if strcmp(style_name,'solid')
   style='-k';
elseif strcmp(style_name,'dot')
   style=':k';
elseif strcmp(style_name,'dash')
   style='--k';
 elseif(strcmp(style_name,'red'))
     style='-r';
 elseif(strcmp(style_name,'blue'))
     style='-b';
 elseif(strcmp(style_name,'green'))
     style='-g';
 elseif(strcmp(style_name,'cyan'))
     style='-c';
end; 
sep=str2num(get(findobj('Tag','xy_separation'),'String'))/ 100; 
xpos=str2num(get(findobj('Tag','xy_x_pos'),'String'))/ 100;
ypos=str2num(get(findobj('Tag','xy_y_pos'),'String'))/ 100;
xy_size=str2num(get(findobj('Tag','xy_trace_size'),'String'))/ 100;


% Rescale all analog data to the range -1 to +1

% OLD method, before environmental variables
% rescale_analog= ANALOG_RANGE / 1;  % analog range / full scale of Y axis (full scale = 1.0)
% analog_zero= ANALOG_RANGE / 2;   % center of Y axis

rescale_analog = (abs(environment.analogmin)+abs(environment.analogmax)) / 2 ;  % range of analog values
analog_zero = rescale_analog / 2; 

% fetch analog data (amplitude values)in the exact order that it should be displayed
analog1_value= ...
   (read_analog_record(work_fid.analog,work_trial_list(sorted_trial_list),chan1)-analog_zero)/rescale_analog;

if isempty(analog1_value)
   if warnings
      fprintf(warning_fid,'Warning [plot_analog]. No analog data on this channel (%d).\n',chan1);
   end;
   return;
end;

analog2_value= ...
   (read_analog_record(work_fid.analog,work_trial_list(sorted_trial_list),chan2)-analog_zero)/rescale_analog;

if isempty(analog2_value)
   if warnings
      fprintf(warning_fid,'Warning [plot_analog]. No analog data on this channel (%d).\n',chan2);
   end;
   return;
end;

freq=str2num(get(findobj('Tag','frequency'),'String')); 
time_step=1/freq;  % seconds
centered_starting_time=((work_analog_start_stop(:,1)'-time_zero)/RESCALE_TIME)-xzero; % seconds
analog_time=ones(size(analog1_value))*NaN;  % initialize time matrix
samples=size(analog1_value,2);  % number of timestamps for each trial
nans=ones(1,samples)* NaN;  % a row of NaNs that match one row of analog data
for trial=1:length(sorted_trial_list)
   %estimate and intentionally overshoot the range of timestamps
   ending_time= (samples*time_step) + centered_starting_time(sorted_trial_list(trial)) + 10 ;
   timestamps=centered_starting_time(sorted_trial_list(trial)):time_step:ending_time;
   % Use time stamps to determine which analog data values to keep
   keepers=find( (timestamps(1:samples) >= start_stop(trial,1)) &  ...
      (timestamps(1:samples) <= start_stop(trial,2)) );
   junkers=yank_elements(keepers,samples);  % elements to discard
   analog1_value(trial,junkers)=nans(junkers);  % replace unwanted data with NaNs
   analog2_value(trial,junkers)=nans(junkers);  
end;

analogxy(analog1_value,analog2_value,xpos,ypos,sep,xy_size,style,aspect_ratio);
%  analogxy(analog1_value,analog2_value,.050,0,0,.1,style);

set(plot_number,'CurrentAxes',main_handle);  % return to the main window


