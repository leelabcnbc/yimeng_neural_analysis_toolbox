function [seq]=format_sequence(sequence)
%
%  parse a sequence string and reformat it.
%
% Inputs
%   sequence    sequence string
% Outputs
%   seq         sequence string or "@" to indicate an error 
%
global error_fid warning_fid debug_fid
global errors warnings debugs

seq=[];
sequence=strrep(sequence,'[','');   % loose left brackets in existing string
while length(sequence)
   [group,sequence]=strtok(sequence,']');  % right bracket defines a group
   group=number_range_list(group);     % set up ranges properly
   if strcmp(group,'@')
      if warnings
         fprintf(warning_fid,'Warning [format_sequence].  Cannot reformat sequence string: %s\n',sequence);
      end;
      return;
   end;
   if ~isempty(group)
      seq=[seq '[' group ']' ];    
   end;
end;

 
