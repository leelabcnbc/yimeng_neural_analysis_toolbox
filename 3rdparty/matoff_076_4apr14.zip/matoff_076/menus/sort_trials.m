function [ordered_trial_list]=sort_trials
%
% Organize list of trial numbers based on sort criteria.
% This involves two steps, sorting and selecting.
% event_codes, event_times, and analog data are indexed chronologically
% for only trials that meet the search criteria.  
% Sorting involves reordering their index based on the data or some 
% other criteria.
% Selecting is the processes of including or excluding the
% the nth element of the sorted list.
% NOT ALL OPTIONS ARE IMPLEMENTED, SEE BELOW
%
% Inputs
%    none
% Outputs
%   ordered_trial_list     Row array.  Reordered list of (matching) trials based on sort criteria
% Globals modified
%   sort_values            Col 1 = unsorted trial number,
%                          Col 2 = value of criteria used to determine sort
%
global event_codes event_times spiketrials
global work_trial_list selected_unit_trials
global environment  fid
global error_fid warning_fid debug_fid
global errors warnings debugs
global sort_values history

CENTER_IS_CLASS = 99; 

sort_values=[];
criteria_list=[];
trial_list=get(findobj('Tag','trials'),'String');
ordered_trial_list=[];

if isempty(work_trial_list) 
   if debugs
      fprintf(debug_fid,'Debug [sort_trials]. Empty trial list.\n');
   end;
   return;
end;

sort_option_list=get(findobj('Tag','trialsort'),'String');
sort_option=get(findobj('Tag','trialsort'),'value');
sort_option=deblank(sort_option_list(sort_option,:));
center=str2double(get(findobj('Tag','center'),'String'));
mark=str2double(get(findobj('Tag','mark'),'String'));

if debugs
   fprintf(debug_fid,'Debug [sort_trials]. Sort option >> %s <<.\n',sort_option);
end;

switch sort_option  % sort, then select
   case {'off'}
      criteria_list=ones(length(work_trial_list),1);  % criteria is just ones
      [~,sorted_trial_list]=sort(criteria_list);   % no sorting takes place here
      ordered_trial_list=select(sorted_trial_list');  % just select
   case {'center'}
      % CENTER sort groups trials according to the centering code encountered.
      trials_found=size(event_codes,1);
      if (center > CENTER_IS_CLASS) && (center > trials_found)
         if warnings
            fprintf(warning_fid,'Warning [sort_trials]. SORT CENTER has no effect when using a history class for centering.\n');
         end;   
         % treat this as SORT OFF
         criteria_list=ones(size(event_codes(:,1)));  % criteria is just ones
         [~,sorted_trial_list]=sort(criteria_list);   % no sorting takes place here
         ordered_trial_list=select(sorted_trial_list');  % just select
         criteria_list=criteria_list(ordered_trial_list);   
      else
         % fetch and sort center codes
         criteria_list=event_codes(:,center);
         [~,sorted_trial_list]=sort(criteria_list);  % keep just the index of the sorting process
         ordered_trial_list=select(sorted_trial_list');  % select trials to display
         criteria_list=criteria_list(ordered_trial_list);   % save the sort criteria
      end;
   case {'time'}
      % TIME sort groups trials according to the time between the center and mark events
      % absolute time difference between center (always at time 0) and mark for each trial
      criteria_list=abs(event_times(:,mark)); % epoch_times
      % sort this list
      [~,sorted_trial_list]=sort(criteria_list);
      ordered_trial_list=select(sorted_trial_list');  % select trials to display
      criteria_list=criteria_list(ordered_trial_list);   % save the sort criteria
      
   % count the number of pulses between the low and high pulse sort values  
   case {'pulse'}
      psr_low=get(findobj('Tag','pulsesortrange1'),'String');
      psr_high=get(findobj('Tag','pulsesortrange2'),'String');

      if isempty(psr_low) || isempty(psr_high)    % bad string?
         low=-1;
         high=-1;  % force failure below
      else
         low=str2double(psr_low);                   % good string, convert to numbers
         high=str2double(psr_high);
      end;
      window=str2double(get(findobj('Tag','window'),'String'));   % get dimensions of plot
      shift=str2double(get(findobj('Tag','shift'),'String')); 
      spike_counts=[];      
      
      % time range for sort expressed in absolute time (PCOFF units no longer supported>
      bottom=shift-(window/2);
      top=(window/2)+shift;
      if (low < bottom) || (low > top) || (high < bottom) || (high > top) || (low > high)
         if errors
            fprintf(error_fid,'Error [sort_trials]. Improper range for sort pulse.\n');
         end;
         % bail out
         criteria_list=ones(length(work_trial_list),1);  % criteria is just ones
         [~,sorted_trial_list]=sort(criteria_list);   % no sorting takes place here
         ordered_trial_list=select(sorted_trial_list');  % just select
      else
         abs_low= low*10;    % convert to .1 ms tics
         abs_high= high *10; 
      end;

      
      % low and high limits for the sort are now in absolute time
      % count spikes in this range 
      for trial_number=min(spiketrials(:,1)):max(spiketrials(:,1))   
         % make list of all spike times in this trial 
         s=spiketrials(find(spiketrials(:,1)==trial_number),2);
         % count the number of these spikes that are within the markers
         cnt=length(find(abs_low <= s & s <= abs_high));
         spike_counts(trial_number)= cnt;
      end;
      % sort this list
      criteria_list=spike_counts';
      [~,sorted_trial_list]=sort(spike_counts');
      ordered_trial_list=select(sorted_trial_list');  % select trials to display
      criteria_list=criteria_list(ordered_trial_list);   % save the sorted criteria
      

   case {'epoch'}

      % EPOCH sort groups trials according to the number of spikes between the center and mark events
      % get times of center (always time 0) and mark codes for each trial
      epoch_times=[zeros(size(event_times(:,1),1),1), event_times(:,mark)];
      % make sure earlier time comes first in each trial
      epoch_times=[min(epoch_times(:,1),epoch_times(:,2)) max(epoch_times(:,1),epoch_times(:,2))];

      % count the spikes in the center--mark epoch of each trial
      spike_counts=[];
      for trial_number=min(spiketrials(:,1)):max(spiketrials(:,1))   
          % make list of all spike times in this trial 
          s=spiketrials(find(spiketrials(:,1)==trial_number),2);
          % count the number of these spikes that are within center--mark epoch
          cnt=length(find(epoch_times(trial_number,1) <= s & s <= epoch_times(trial_number,2)));
          spike_counts(trial_number)= cnt;
      end;
      % sort this list
      criteria_list=spike_counts';
      [~,sorted_trial_list]=sort(spike_counts');
      criteria_list=criteria_list(sorted_trial_list);   % save the sorted criteria
      ordered_trial_list=select(sorted_trial_list');  % select trials to display
      
   case {'peak'} 
      
      % Sort based on the time to maximum analog value found within the specified time window.
      
      % Fetch analog data
      [analog_data,analog_time]=fetch_analog;  % fetch and scale all analog trials that match search criteria
                                               % analog data is in absolute time.
                                               
      [low,high]=time_window('peak');  % fetch the time window for this sort, check for validity    
     
      if (low==0 && high==0)  ||  isempty(analog_data)    % failure        
         if warnings
            fprintf(warning_fid,'Warning [sort_trials]. Cannot SORT PEAK. No analog data or PEAK parameters set wrong.\n');
         end;            
         % bail out
         criteria_list=ones(length(work_trial_list),1);  % criteria is just ones
         [~,sorted_trial_list]=sort(criteria_list);   % no sorting takes place here
         ordered_trial_list=select(sorted_trial_list');  % just select
         sort_values=[ordered_trial_list'  criteria_list(1:length(ordered_trial_list))];                                         
         return;  % abort
      end;
            
      % initialize two arrays.
      peak_value=ones(length(work_trial_list),1);
      elapse_time=peak_value;
      % find time of maximum analog value withing time range for each trial
      for trial=1:length(work_trial_list)
         % locate elements of the analog data within the time range of interest
         segment=find((analog_time(trial,:) > low) & (analog_time(trial,:) <= high));
         % locate the maximum value in this range
         peak_index=find(analog_data(trial,segment)==max(analog_data(trial,segment))); 
         peak_value_index=segment(peak_index);
         peak_value(trial)=analog_data(trial,peak_value_index(1));  % be careful to take first peak
         % measure elapse time to peak
         elapse_time(trial)=analog_time(trial,peak_value_index(1))-low;
      end;
      
      criteria_list=elapse_time;
      [~,sorted_trial_list]=sort(criteria_list);
      criteria_list=criteria_list(sorted_trial_list);   % save the sorted criteria
      ordered_trial_list=select(sorted_trial_list');  % select trials to display  
         
      
  case {'pit'} 
      
      % Sort based on the time to minimum analog value found within the specified time window.
      
      % Fetch analog data
      [analog_data,analog_time]=fetch_analog;  % fetch and scale all analog trials that match search criteria
                                               % analog data is in absolute time.
                                               
      [low,high]=time_window('pit');  % fetch the time window for this sort, check for validity                                     
      if ((low==0) && (high==0)) ||  isempty(analog_data)    % signals a failure   
         % bail out
         if warnings
            fprintf(warning_fid,'Warning [sort_trials]. Cannot SORT PIT. No analog data or PIT parameters set wrong.\n');
         end;  
         criteria_list=ones(length(work_trial_list),1);  % criteria is just ones
         [~,sorted_trial_list]=sort(criteria_list);   % no sorting takes place here
         ordered_trial_list=select(sorted_trial_list');  % just select
         sort_values=[ordered_trial_list'  criteria_list(1:length(ordered_trial_list))];                                         
         return;  % abort
      end;
            
      % initialize two arrays.
      pit_value=ones(length(work_trial_list),1);
      elapse_time=pit_value;
      % find time of minimum analog value withing time range for each trial
      for trial=1:length(work_trial_list)
         % locate elements of the analog data within the time range of interest
         segment=find((analog_time(trial,:) > low) & (analog_time(trial,:) <= high));
         if ~isempty(segment)
            % locate the minimum value in this range
            pit_index=find(analog_data(trial,segment)==min(analog_data(trial,segment))); 
            pit_value_index=segment(pit_index);
            pit_value(trial)=analog_data(trial,pit_value_index(1));  % be careful to take first pit
            % measure elapse time to pit
            elapse_time(trial)=analog_time(trial,pit_value_index(1))-low;
         else  % no analog data in this range
            pit_value(trial)=0;   % I am not sure if these are good fall-back values, but we have
            elapse_time(trial)=1; % to put something here.
         end;
      end;
      
      criteria_list=elapse_time;
      [~,sorted_trial_list]=sort(criteria_list);
      criteria_list=criteria_list(sorted_trial_list);   % save the sorted criteria
      ordered_trial_list=select(sorted_trial_list');  % select trials to display  
         
      
  case {'min'} 
      
      % Sort based on the minimum analog value found within the specified time window.
      
      % Fetch analog data
      [analog_data,analog_time]=fetch_analog;  % fetch and scale all analog trials that match search criteria
                                               % analog data is in absolute time.
                                               
      [low,high]=time_window('min');  % fetch the time window for this sort, check for validity                                     
      if ((low==0) && (high==0)) ||  isempty(analog_data)   % signals a failure 
         if warnings
            fprintf(warning_fid,'Warning [sort_trials]. Cannot SORT MIN. No analog data or MIN parameters set wrong.\n');
         end; 
         % bail out
         criteria_list=ones(length(work_trial_list),1);  % criteria is just ones
         [~,sorted_trial_list]=sort(criteria_list);   % no sorting takes place here
         ordered_trial_list=select(sorted_trial_list');  % just select
         sort_values=[ordered_trial_list'  criteria_list(1:length(ordered_trial_list))];                                         
         return;  % abort
      end;
            
      % initialize two arrays.
      min_value=ones(length(work_trial_list),1);
      elapse_time=min_value;
      % find minimum analog value withing time range for each trial
      for trial=1:length(work_trial_list)
         % locate elements of the analog data within the time range of interest
         segment=find((analog_time(trial,:) > low) & (analog_time(trial,:) <= high));
         % locate the minimum value in this range
         min_index=find(analog_data(trial,segment)==min(analog_data(trial,segment))); 
         min_value_index=segment(min_index);
         min_value(trial)=analog_data(trial,min_value_index(1));  % be careful to take first min
      end;
      
      criteria_list=min_value;
      [~,sorted_trial_list]=sort(criteria_list);
      criteria_list=criteria_list(sorted_trial_list);   % save the sorted criteria
      ordered_trial_list=select(sorted_trial_list');  % select trials to display  
         
        
      
     case {'max'} 
      
      % Sort based on the maximum analog value found within the specified time window.
      
      % Fetch analog data
      [analog_data,analog_time]=fetch_analog;  % fetch and scale all analog trials that match search criteria
                                               % analog data is in absolute time.
                                               
      [low,high]=time_window('max');  % fetch the time window for this sort, check for validity                                     
      if ((low==0) && (high==0)) ||  isempty(analog_data)   % signals a failure 
         if warnings
            fprintf(warning_fid,'Warning [sort_trials]. Cannot SORT MAX. No analog data or MAX parameters set wrong.\n');
         end; 
         % bail out
         criteria_list=ones(length(work_trial_list),1);  % criteria is just ones
         [~,sorted_trial_list]=sort(criteria_list);   % no sorting takes place here
         ordered_trial_list=select(sorted_trial_list');  % just select
         sort_values=[ordered_trial_list'  criteria_list(1:length(ordered_trial_list))];                                         
         return;  % abort
      end;
            
      % initialize two arrays.
      max_value=ones(length(work_trial_list),1);
      elapse_time=max_value;
      % find maximum analog value withing time range for each trial
      for trial=1:length(work_trial_list)
         % locate elements of the analog data within the time range of interest
         segment=find((analog_time(trial,:) > low) & (analog_time(trial,:) <= high));
         % locate the maximum value in this range
         max_index=find(analog_data(trial,segment)==max(analog_data(trial,segment))); 
         max_value_index=segment(max_index);
         max_value(trial)=analog_data(trial,max_value_index(1));  % be careful to take first max
      end;
      
      criteria_list=max_value;
      [~,sorted_trial_list]=sort(criteria_list);
      criteria_list=criteria_list(sorted_trial_list);   % save the sorted criteria
      ordered_trial_list=select(sorted_trial_list');  % select trials to display  


   case {'history'}
      % History sort uses a single history class to determine the order of the trials
      % sort this list
      
      sc=get(findobj('Tag','historysortrange1'),'String');
      [~,sort_class,valid]=check_string_value(sc,1,20000);  
      if valid           % check value
          % find the class in the history.
          list=[];
          for c=1:length(history)
            if history(c).class==sort_class
               list=[expand_range_list(history(c).trial_list) ; history(c).values];
               break;
            end;
          end;
 
          if ~isempty(list)

              not_in_class=[];    % keep track of trials with no class values
              criteria_list=zeros(1,length(selected_unit_trials));  % start with a criteria of zero
       
              for selected_trial_index=1:length(selected_unit_trials)
                 unit_trial_index=find(list(1,:)==selected_unit_trials(selected_trial_index)); % look for this trial
                 if length(unit_trial_index)==1
                    criteria_list(selected_trial_index)=list(2,unit_trial_index);  % get criteria value for this trial
                 elseif length(unit_trial_index) > 1   % should never get here, history class list has duplicate trials
                    if errors
                       fprintf(error_fid,'Error [sort_trials]. Serious error with sort history.\n');
                    end;
                 else
                    not_in_class=[not_in_class selected_trial_index];  % track trials not in the history class
                 end;
               end;  % for unit_trial
               min_criteria=min(criteria_list);  % find the lowest criteria value of data set
               % the following statement will fail if user is using full range of the class value variable
               criteria_list(not_in_class)=min_criteria - 1; % set unlisted trials just below this minimum
              [~,sorted_trial_list]=sort(criteria_list);
              ordered_trial_list=select(sorted_trial_list);  % select trials to display
              criteria_list=criteria_list(ordered_trial_list);   % save the sort criteria  
              criteria_list=criteria_list';
          else
              if warnings
                  fprintf(warning_fid,'Warning [sort_trials]. History sort list is empty.\n -- Data will remain UNSORTED --\n');
              end
               % treat this as SORT OFF
               criteria_list=ones(size(event_codes(:,1)));  % criteria is just ones
               [~,sorted_trial_list]=sort(criteria_list);   % no sorting takes place here
               ordered_trial_list=select(sorted_trial_list');  % just select
               criteria_list=criteria_list(ordered_trial_list);
          end             
      else
        if errors
           fprintf(error_fid,'Error [sort_trials]. Invalid history class. Cannot sort by history.\n');
        end
      end

      
   case {'delta','zero','int'}  %  FUNCTIONS THAT ARE NOT IMPLEMENTED
      if warnings
         fprintf(debug_fid,'Warning [sort_trials]. Sort option %s not implemented yet.\n',sort_option);
      end;
      % treat this as SORT OFF
      criteria_list=ones(size(event_codes(:,1)));  % criteria is just ones
      [~,sorted_trial_list]=sort(criteria_list);   % no sorting takes place here
      ordered_trial_list=select(sorted_trial_list');  % just select
      criteria_list=criteria_list(ordered_trial_list);
end; % switch
   
if isempty(ordered_trial_list)
   return;  % return with empty sort_values();
end;
sort_values=[ordered_trial_list'  criteria_list(1:length(ordered_trial_list))];




% End of main


% =========================================================================== %
%                       select
% =========================================================================== %

function selected_trials=select(sorted_trial_list)
%
% After the trial list has been sorted, choose which trials
% are retained for display.
%
% Inputs
%   sorted_trial_list    row vector of non-sequential trial numbers
%   keep_these           row vector of sequential elements of sorted_trial_list to keep
% Outputs
%   selected_trials      row vector of trial numbers to use
%

global error_fid warning_fid debug_fid
global errors warnings debugs

trial_list=get(findobj('Tag','trials'),'String');

% Prepare for "selecting"
% Get list of trials from "trials" command. This list is ordinal,
% e.g.  1,3,5-9,45,55   The list can also be a "trials function"
% The keep_these list will describe which trials are to be
% included in the final display AFTER we do the sorting below.
if ~isempty(findstr(trial_list,'x'))       % parse a value like 3x+5
   step=str2double(strtok(trial_list,'x'));     % grab the 3 before the 'x'
   [~,start]=strtok(trial_list,'+');   % grab the 5 after the '+'
   start=str2double(start);
   % decode a trials function
   keep_these=start:step:str2double(get(findobj('Tag','trialsfound'),'String'));
   if debugs
      fprintf(debug_fid,'Debug [sort_trials (Select)]. Decoding trials function for sort options: %s\n',sort_option);
   end;
else   
   % more typical trial list
   keep_these=expand_range_list(trial_list);
   if isempty(keep_these) || isstr(keep_these)
      if debugs
         fprintf(debug_fid,'Debug [sort_trials (select)]. Empty trial list.\n');
      end;
      selected_trials=[];
      return;
   end;
end;

% prune keep_these to not exceed the maximum elements in the sorted list
keep_these=keep_these(find(keep_these <= size(sorted_trial_list,2)));
% now keep_these can be used to index the trials to keep
selected_trials=sorted_trial_list(keep_these);
   
   
   

% =========================================================================== %
%                fetch analog
% =========================================================================== %   
   
   
function [analog_value,analog_time]=fetch_analog
%   
%  fetch analog data for sorts based on analog criteria
%     
%  We only sort on Channel 1  (X)
%
% Inputs
%   first_trial        lowest unsorted trial number
%   last_trial         highest unsorted trial number
% Outputs
%   analog_value(trial,sample number)   analog values
%   analog_time(trial,sample number)    time stamps
%                                       trial range is first_trial to last_trial
%

global RESCALE_TIME ANALOG_RANGE
global work_trial_list work_analog_start_stop
global time_zero
global work_fid 
global error_fid warning_fid debug_fid
global errors warnings debugs

analog_value=[];
analog_time=[];

x_at_zero=get(findobj('Tag','xatzero'),'Value');  % forces time scale to have zero on left
shift=str2double(get(findobj('Tag','shift'),'String'));
window=str2double(get(findobj('Tag','window'),'String'));
start_time=10 * (-(window/2)+shift) / RESCALE_TIME;   % convert to seconds
end_time= 10 * ((window/2)+shift) / RESCALE_TIME;     % convert to seconds
if x_at_zero
   xzero=start_time;  % seconds
   end_time=end_time-start_time;
   start_time=0;
else
   xzero=0;
end;

chan=get(findobj('Tag','xchannelmenu'),'Value')-1;
if chan==0
   if warnings
      fprintf(warning_fid,'Warning [sort_trials (fetch_analog)]. Cannot sort: no primary (X) analog channel selected.\n');
   end;
   return;
end;

% fetch analog data (amplitude values)in the exact order that it should be displayed
if debugs
   fprintf(debug_fid,'Debug [sort_trials]. Fetching analog using fid=%d\n',work_fid.analog);
end;


% Rescale all analog data to the range -1 to +1

% OLD method, before environmental variables
% rescale_analog= ANALOG_RANGE / 1;  % analog range / full scale of Y axis (full scale = 1.0)
% analog_zero= ANALOG_RANGE / 2;   % center of Y axis

rescale_analog = (abs(environment.analogmin)+abs(environment.analogmax)) / 2 ;  % range of analog values
analog_zero = rescale_analog / 2; 


analog_value= ...
   (read_analog_record(work_fid.analog,work_trial_list,chan)-analog_zero)/rescale_analog;

if isempty(analog_value)
   if warnings
      fprintf(warning_fid,'Warning [sort_trials (fetch_analog)]. Cannot Sort, no analog data on X channel (%d).\n',chan);
   end;
   return;
end;


% estimate sample rate
if debugs
   fprintf(debug_fid,'Debug [sort_trials (fetch_analog)]. Estimated sample rate:\n'); 
end;

rates=[];

for t=1:length(work_trial_list)
   number_of_samples = length(find(~isnan(analog_value(t,:))));  % find the number of non-NaN data points
   trial_duration=(work_analog_start_stop(t,2)' - work_analog_start_stop(t,1)' ) / 10 ;  % duration of this trial in ms.
   rates=[rates (number_of_samples/trial_duration)];
   if debugs
      fprintf(debug_fid,'%d samples / %d msec = %d samp/s from unsorted trial %d (sorted trial %d)\n',...
         number_of_samples,trial_duration,round(1000*(number_of_samples/trial_duration)),t,t );
   end;
end;  % for t=1:length(work_trial_list)

freq=str2double(get(findobj('Tag','frequency'),'String')); 
freq_error=abs(round(1000 * rates)-freq);

if warnings & find(freq_error > 2)
   fprintf(1,'Warning [sort_trials (fetch_analog)]. Calculated A/D sample rate (%d samp/sec) \n',abs(round(1000 * rates)));
   fprintf(1,'does not agree with sample rate of some trials.\n');
   if environment.logging==1
      fprintf(fid.log,'Warning [sort_trials (fetch_analog)]. Calculated A/D sample rate (%d samp/sec) \n',abs(round(1000 * rates)));
      fprintf(fid.log,'does not agree with sample rate of some trials.\n');
   end;
end;

% Every analog value requires a timestamp.  Generate timestamps based on
% the time between the centering code and analogstart code (usually 100).
time_step=1/freq;  % seconds
centered_starting_time=((work_analog_start_stop(:,1)'-time_zero)/RESCALE_TIME)-xzero; % seconds
analog_time=zeros(size(analog_value));  % initialize time matrix
samples=size(analog_value,2);  % number of timestamps for each trial
% for trial=1:size(analog_value,1)  % over all trials
for trial=1:length(work_trial_list)
   %estimate and intentionally overshoot the range of timestamps
   ending_time= (samples*time_step) + centered_starting_time(trial) + 10 ;
   timestamps=centered_starting_time(trial):time_step:ending_time;
   % now use exactly the correct number of time stamps
   analog_time(trial,:)=timestamps(1:samples);   
end; % for trial=1:length(work_trial_list)



% =========================================================================== %
%                time_window
% =========================================================================== %   
   
   
function [low,high]=time_window(sort_name)

%  determine the time window for a sort option.  Check for valid time range
%
%  Inputs
%     sort_name     % string used to read sort time range from GUI
%  Outputs
%     low,high      % absolute trial time in seconds 
%

global environment 
global error_fid warning_fid debug_fid
global errors warnings debugs

% convert specified time range from old pcoff notation (600 pixels) to real time if necessary
sort_low=get(findobj('Tag',[sort_name 'sortrange1']),'String');
sort_high=get(findobj('Tag',[sort_name 'sortrange2']),'String');
    
lower_limit=-60000;
upper_limit=60000;
seg_scale=1000;

[~,low_value,low_valid]=check_string_value(sort_low,lower_limit,upper_limit);
[~,high_value,high_valid]=check_string_value(sort_high,lower_limit,upper_limit);
    
% check the validity of the time range
if ~high_valid || ~low_valid || (high_value <= low_value)  % abort if invalid range values
   if errors
      fprintf(error_fid,'Error [sort_trials (time_window)]. Improper range for sorting.\nTrials not sorted.\n');
   end;
   low=0;   % signal a failure
   high=0;
   return;
end;   
      
% rescale time range to seconds
low=low_value/seg_scale;
high=high_value/seg_scale;


