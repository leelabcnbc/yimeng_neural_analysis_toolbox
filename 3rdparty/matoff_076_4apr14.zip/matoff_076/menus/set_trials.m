function response=set_trials(trial_string)
%
% Update the Trials entry of the GUI 
%
%
global error_fid warning_fid debug_fid trace_fid
global errors warnings debugs
global environment

if isempty(trial_string)
   response='No trials specified';
   return;
end;

old_string=get(findobj('Tag','trials'),'String');  % preserve original string
if isempty(findstr(trial_string,'x'))  % does this look like a trial function?
   valid=normal_list(trial_string);     % no, treat as a normal list
   if isempty(valid)
      response='Invalid trial list';    % bad list. Try to recover using old string
      if isempty(findstr(old_string,'x'))
         valid=normal_list(old_string);
      else
         valid=trialfunction(old_string);
      end;
      set(findobj('Tag','trials'),'String',valid);
      return;
   end;
else
   valid=trialfunction(trial_string);     % trial function
   if isempty(valid)
      response='Invalid TrialFunction';      % bad function. Try to recover using old string
      if isempty(findstr(old_string,'x'))
         valid=normal_list(old_string);
      else
         valid=trialfunction(old_string);
      end;
      set(findobj('Tag','trials'),'String',valid);
      return;
   end;
end;
response='';  % success
set(findobj('Tag','trials'),'String',valid);
% end set_trials
   
      



function valid_function=trialfunction(test_function)
%
% check a trialfunction
% return carefully checked and formated string, or null if bad.
%
%  allowed formats: ax+b  or  a,b
% 
global environment
global error_fid warning_fid debug_fid trace_fid
global errors warnings debugs 
%
%
valid_function=[];
tfstring=lower(deblank(strjust(test_function)));
if isempty(tfstring)
   return;
end;
tfstring=strrep(tfstring,'[','');       % remove left bracket
if isempty(tfstring)
   return;
end;
tfstring=strrep(tfstring,']','');       % remove right bracket
if isempty(tfstring)
   return;
end;
tfstring=strrep(tfstring,'x','');       % remove 'x'
if isempty(tfstring)
   return;
end;
tfstring=strrep(tfstring,'+',',');      % replace '+' with ','
if isempty(tfstring)
   return;
end;
[a_str,b_str]=strtok(tfstring,',');     % parse using ','
if isempty(a_str) | isempty(b_str)
   return;
end;
b_str=strrep(b_str,',','');             % remove ',' 
if isempty(b_str)
   return;
end;
a=str2num(a_str);
b=str2num(b_str);
if isempty(a) | isempty(b)
   return;
end;
if b==0
   if warnings
      fprintf(warning_fid, 'Warning [set_trials]. Trial numbers must be greater than zero.\n');
   end;
   return;
end;

if ischar(environment.maxtrialsfound)
   mtf=str2num(environment.maxtrialsfound);
else 
   mtf=environment.maxtrialsfound;
end;
if b > mtf
   if warnings
      fprintf(warning_fid, 'Warning [set_trials]. Trial function starts at a non-existing trial number.\n');
   end;
   return;
end;
if (a < 1) | (b < 1)
   return;
end;
a_str=deblank(strjust(a_str,'left'));
b_str=deblank(strjust(b_str,'left'));
valid_function=[a_str 'x+' b_str];




function valid_list_string=normal_list(test_list)
%
% check a normal (not trials function) trials string.
% return carefully checked and formated string of trial numbers, or null if bad.
% 
global environment
global error_fid warning_fid debug_fid trace_fid
global errors warnings debugs 

valid_list=expand_range_list(test_list);  % try to expand test_list
if strcmp(valid_list,'@')
   valid_list_string=[];
   return;
elseif ~isempty(find(valid_list <= 0))  % do not allow zero or negative
   valid_list_string=[];
   return;
else
   % healthy list
end;
num_trials_requested=length(valid_list);  % how many trials does s/he want?
if ischar(environment.maxtrialsfound)
   mtf=str2num(environment.maxtrialsfound);
else 
   mtf=environment.maxtrialsfound;
end;
if num_trials_requested > mtf % see if list length exceeds the allowed limit
   if warnings
      fprintf(warning_fid,'Warning [set_trials]. Trial list exceeds "maxtrialsfound" environmental variable.\n');
      fprintf(warning_fid,'                      Trial list truncated to %d entries.\n',mtf);
   end;
   valid_list=valid_list(1:mtf);
end;
% convert to simplified pcoff range
string_list=[];
for i=1:length(valid_list)
   string_list=[string_list ',' num2str(valid_list(i))];
end;
string_list=string_list(2:end);  % remove first comma
valid_list_string=number_range_list(string_list)   ;   % reformat (order and compact) list





