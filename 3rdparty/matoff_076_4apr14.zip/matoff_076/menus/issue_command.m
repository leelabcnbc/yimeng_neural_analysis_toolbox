function[response]= issue_command(command)
%   Print command on screen and call parse_command
%   Used by GUI callback functions.  If errorlevel==serious, then
%   most input commands are not listed on the output device.
%
%  Input
%    command    command to execute
%  Outputs
%    response     response value returned by parse_command
%    file_error   file error report from parse_command
%
%   
%

global quietly
global environment fid fn

if quietly==0                     % do not echo command unless "quietly" is off
   fprintf(1,'%s\n',command);
   if environment.logging==1
      fprintf(fid.log,'%s\n',command);
   end;
else                             % look for exceptions (file,unit,quit,exit)
   c=deblank(command);
   [cmd,params]=strtok(c);  % separate command name from parameters
   cmd=lower(deblank(strjust(cmd)));  % all commands to lower case
   if strncmp(cmd,'file',3) | strncmp(cmd,'unitname',3) | ((strcmp(cmd,'quit') | strcmp(cmd,'exit')) & length(cmd)==4)
      fprintf(1,'%s\n',command);
      if environment.logging==1
         fprintf(fid.log,'%s\n',command);
      end;
   end;
end;
response=parse_command(command);

r=deblank(strjust(response,'left')); % do not print if only white spaces
if ~isempty(r)
   fprintf(1,'%s\n',response);
   if environment.logging==1
      fprintf(fid.log,'%s\n',response);
   end;
end;
