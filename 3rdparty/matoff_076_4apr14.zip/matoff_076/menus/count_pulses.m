function [counts]=count_pulses
%
%  Search the contents of a data file, count the number of spikes in each channel.
%  Uses currently open file and unit.  This is cobbled together from bits and
%  pieces of read_pulses.m and collate_trials.  It taxes memory much less than
%  if a full data collation is done.
%
% Inputs
%   none
% Outputs
%   counts       array of counts in each channel counts(1) is for chan 0, counts(2) is for chan 1, etc.
%
global work_index work_udef work_fid
global environment taint
global error_fid warning_fid debug_fid
global errors warnings debugs

counts(1)=0;

if taint < 20
   response='No file open';
   return;
end;

unit_number=get(findobj('Tag','unit'),'Value');  % GUI unit number matches work_udef subscript

pulses_fid=work_fid.pulse;
trial_list=work_udef(unit_number).trials;

if isempty(trial_list)
   if debugs
      fprintf(debug_fid,'Debug [count_pulses]. Empty trial list requested.\n');
   end;
   return;
end;

if debugs
   fprintf(debug_fid,'Debug [count_pulses]. %d trials of pulse data requested.\n',length(trial_list));
end;

low_trial=min(trial_list);
high_trial=max(trial_list);

if high_trial > length(work_index)
   fprintf(error_fid, 'Error [count_pulses]. Requested trial exceeds index size.\n');
   return;
end;

% File_trials are never cached in this program, go get them from data file
starting_file_position=work_index(low_trial).pulse_start_position;
number_of_records=0;
for t=low_trial:high_trial
   number_of_records=number_of_records+work_index(t).pulse_records;  % size of data block to pull from file
end;

try
   fseek(pulses_fid,starting_file_position,'bof');
catch
   if errors
      fprintf(error_fid,'Error [count_pulses]. Tried to read past end of the pulse file.\n');
   end;
   return;
end;

try
   file_data=fread(pulses_fid,[2 number_of_records],'int32');   % read from file
   trial_range=[low_trial high_trial];
catch
   if errors
      fprintf(error_fid,'Error [count_pulses].  Error reading pulse data.\n');
      fprintf(error_fid,'Starting offset: %-5d , number of records: %-5d \n', ...
             starting_file_position,number_of_records);
   end;
   trial_range=[0 0];   % values no longer valid    
   return;
end;

% pluck out data for requested file_trials

TRIAL_HEADER_MARKER=-1;
if isempty(file_data)
   return;
end;
% point to the header markers
trial_marker_list=find(file_data(1,:)== TRIAL_HEADER_MARKER);

for t=trial_list   % this list is in units of file trial numbers, just like trial_marker_list
   trial_start_index=trial_marker_list(find(file_data(2,trial_marker_list)==t)); 
   if length(trial_start_index) ~= 1   % did we locate exactly one trial?
      if errors
         fprintf(error_fid,'Error [count_pulses]. Could not find trial marker.\n');
      end;
      return;   
   end;   
   % find the index of the next trial in this dataset, then translate 
   % the start and stop indicies to column numbers of file_data
   if t < trial_range(2)  % is there another trial in this dataset?
      % yes, locate index just before next trial
      trial_end_index=trial_marker_list((t-trial_range(1)) + 2) -1 ;  
   else
      trial_end_index=length(file_data(2,:));  % no, last index of file
   end;
    
   % grab just the channel numbers from this trial to count spikes
   chans= file_data(1,trial_start_index:trial_end_index);
   channel_number=chans(find(~isnan(chans)));   % remove nans
   highest_channel=max(channel_number);
   if (highest_channel+1) > length(counts)
      counts(highest_channel+1)=0;   % expand array as necessary
   end;
   
   % Sort counts by channel number
   for chan=0:highest_channel
      counts(chan+1)= counts(chan+1) + length(find(channel_number==chan));  
   end;
end;

return;
