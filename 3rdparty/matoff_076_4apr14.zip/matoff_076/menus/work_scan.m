function [work_trial_list]=work_scan
%
% Finds which trials match the search criteria (sequence).  Results are
% saved in the global variables: work_trial_list, work_analog_start 
% and work_events_arrays.  Supports unit=* 
%
% Inputs
%    none
% Outputs
%    work_trial_list          List of file trials that match search criteria. (It is also saved as a global variable)
% Globals changed
%    work_trial_list          List of file trials that match the search criteria.
%    event_codes              The sequence of matching event codes for each trial in work_trial_list
%    event_times              The sequence of matching event times for each trial in work_trial_list
%    work_analog_start_stop   Column 1: The time analog starts for every trial in this unit (in "unsorted trials")
%                             Column 2: The time analog ends for every trial in this unit (in "unsorted trials")
%    unit_trials              number of trials in unit
%    selected_unit_trials     trial numbers for trials that matched search criteria (become unsorted trials if accepted by history)
% 
% This version does not support local ignore.
%
global work_fid work_index work_udef environment
% global work_events_array1 work_events_array2
global spikemap event_codes event_times
global work_trial_list work_analog_start_stop
global error_fid warning_fid debug_fid
global errors warnings debugs
global history selected_unit_trials unit_trials
global center_is_class

% initialize
work_analog_start=[];
work_analog_stop=[];
work_trial_list=[];       % list of file trial numbers that match the code sequence
selected_unit_trials=[];  % list of which trials (1..n) that matched the code sequence
event_codes=[];
event_times=[];

% Is a file open?
if isempty(deblank(get(findobj('Tag','filename'),'String')))
   if warnings
      fprintf(warning_fid,'Warning [work_scan]. File not open.\n');
   end;
   % should we re-adjust "taint" here?
   return;
end;

% Check for a valid code sequence
glo_list=expand_range_list(get(findobj('Tag','globalignore'),'String'));
seq_string=get(findobj('Tag','sequence'),'String');
% parse string into groups of codes
seq_string=strrep(seq_string,'[','');   % loose left brackets in existing string
seq_index=0;
while ~isempty(seq_string)
   [group,seq_string]=strtok(seq_string,']');  % right bracket defines a group
   if (isempty(group))
      break;
   end;
   seq_index=seq_index+1;
   sequence(seq_index).codes=expand_range_list(group);   
end;

if seq_index==0        % Empty sequence?
   if warnings
      fprintf(warning_fid,'Warning [work_scan]. Empty sequence. Scan aborted.\n');
   end;
   return;
end;

allcodes=[];

for seq_index=1:length(sequence)     % Sequence with an empty code group?
   if isempty(sequence(seq_index))
      if warnings
         fprintf(warning_fid,'Warning [work_scan]. Cannot process a sequence with an empty code group.\n');
      end;
      return;
   end; 
   allcodes=[allcodes sequence(seq_index).codes];
end;

if ~isempty(glo_list)             % Sequence code also in Global Ignore list?
   for i=1:length(allcodes)
      if find(glo_list==allcodes(i))
         if errors
            fprintf(error_fid,'Error [work_scan]. Global ignore value %d is not allowed in the sequence.\n', allcodes(i));
         end;
         return;
      end;
   end;
end;


[clean_string,value,valid]=check_string_value(get(findobj('Tag','center'),'String'),1,10000);
if ~valid
   fprintf(error_fid,'CENTER value (%s) not valid\n',clean_string);
   return;
end
if (value > length(sequence)) && (value < center_is_class)
   fprintf(error_fid,'CENTER value (%s) cannot be used with this SEQUENCE\n',clean_string);
   return;
end
if value >= center_is_class
   if warnings
      fprintf(warning_fid,'Reminder:Your CENTER value (%d) identifies a history class, not an event group.\n',value);
   end
end

[clean_string,~,valid]=check_string_value(get(findobj('Tag','mark'),'String'),1,length(sequence)); 
if ~valid
   fprintf(error_fid,'MARK value (%s) cannot be used with this SEQUENCE\n',clean_string);
   return;
end

% Check for a valid list of source trials
sourcetrials_string=get(findobj('Tag','source'),'String');
if isempty(sourcetrials_string)
   if errors
      fprintf(error_fid,'Error [work_scan]. Improper SourceTrials entry. Cannot Scan data.\n');
   end;
   return;
end;
if ~isempty(findstr(sourcetrials_string,'=')) % SourceTrials entry might have "="
   sourcetrials_string=strtok(sourcetrials_string,'=');
end;
source_trials=expand_range_list(number_range_list(sourcetrials_string));

if strcmp(source_trials,'@')
   if errors
      fprintf(error_fid,'Error [work_scan]. Improper SourceTrials entry. Cannot Scan data.\n');
   end;
   return;
end;

% Check for a vaid span
span_string=get(findobj('Tag','span'),'String');
if strcmp(span_string,'all') || isempty(span_string)
   span=0;
   if debugs
   fprintf(debug_fid,'Debug [work_scan].  Span is off (all).\n');
   end; 
else 
   span=str2double(span_string)* 10;   % convert to .1 ms
   if span <= 0
      span=0;
      if debugs
         fprintf(debug_fid,'Debug [work_scan].  Span is off (all).\n');
      end;
   end;
end;

if isempty(source_trials)  % Nothing to do
   if warnings
      fprintf(warning_fid,'Warning [work_scan]. No source trials to scan.\n');
   end;
   return;
end;


% look in environment for analog start code.  default is 100
WORK_ANALOG_START_CODE=100;
if ~isempty(environment.analogstart)
    [~,value,valid]=check_string_value(environment.analogstart,1,10000);   % limit to event code 10,000
    if valid
       WORK_ANALOG_START_CODE=value;
    else
       if warnings
          fprintf(warning_fid,'Warning [list_analog]. Invalid analogstart environmental variable. Using default of 100.\n');
       end;
    end;
end;

% look in environment for analog stop code.  default is 101
WORK_ANALOG_STOP_CODE=101;
if ~isempty(environment.analogstop)
    [~,value,valid]=check_string_value(environment.analogstop,1,10000);   % limit to event code 10,000
    if valid
       WORK_ANALOG_STOP_CODE=value;
    else
       if warnings
          fprintf(warning_fid,'Warning [list_analog]. Invalid analogstop environmental variable. Using default of 101.\n');
       end;
    end;
end;

if get(findobj('Tag','historyfile'),'UserData')   % Use a history file?
   user_history_file_name=get(findobj('Tag','historyfile'),'String');
   [~,hfname,hfext]=fileparts(user_history_file_name);   
   if isempty(hfname)
      if debugs
         fprintf(debug_fid,'Debug [work_scan].  Empty history script file name.  History will not be used.\n');
      end;
      use_history=0;
   else
      user_history_file_name=filepath(user_history_file_name,environment.historypath); % add history path
      [hfpath,hfname,hfext]=fileparts(user_history_file_name);  % rebuild file name without the .m extension
      user_history_file_name=fullfile(hfpath,hfname);   
      use_history=1;
      if debugs
         fprintf(debug_fid,'Debug [work_scan]. History script  > %s <  will be used.\n',user_history_file_name);
      end;
   end;
else
   use_history=0;
end;

if debugs
   fprintf(debug_fid,'Debug [work_scan]. Finding trials that match search critera.\n');
   if use_history
      fprintf(debug_fid,'Debug [work_scan]. Applying user history function to matching trials.\n');
   else
      fprintf(debug_fid,'Debug [work_scan]. No user history function in use.\n');
   end;
end;

% GUI unit number matches work_udef subscript
unit_number=get(findobj('Tag','unit'),'Value');  
% reduce trial list to just the source trials, don't exceed trial list length
highest_trial=length(work_udef(unit_number).trials);  % trial list length
search_trials=source_trials(source_trials <= highest_trial); % limit list length
trial_candidates=work_udef(unit_number).trials(search_trials);  
% fetch block of event data from file
selected_event_data=read_event_record(work_fid.event,trial_candidates); 
if isempty(selected_event_data)
   if errors
      fprintf(error_fid,'Error [work_scan]. Problem reading data. Terminating scan.\n');
   end;
   return;
end;
   
% number of behavioral trials in this data set (save this for user_history_function)
unit_trials=length(trial_candidates); 

%%%%%%%%%%%%% OVERALL MATOFF EFFICIENCY RELIES ON THIS CODE %%%%%%%%%%%%%%%%%%%
trial_candidate_number=0;
aborted_by_history=0;
for trial=trial_candidates    % "file trials" (not "unsorted trials")
   if aborted_by_history   % The history script can abort the scan process
      if debugs
         fprintf(debug_fid,'Debug [work_scan]. Scan process aborted by history script.\n');
      end;
      break;
   end;
   trial_candidate_number=trial_candidate_number+1;   % current behavioral trial
   trial_marker=selected_event_data(1,(2*trial_candidate_number)-1);
   trial_number=selected_event_data(1,(2*trial_candidate_number));
   codes=selected_event_data(2:end,(2*trial_candidate_number)-1)' ; 
   codes=codes(~isnan(codes));   % remove nans
   allcodes=codes;  % save this for user_history_function.
   times=selected_event_data(2:end,(2*trial_candidate_number))' ;
   times=times(~isnan(times));   % remove nans
   if trial_number ~= trial
      fprintf(error_fid,'Error [work_scan]. Trial number mismatch while reading events file. Aborting scan');
      break;
   end;
   
   % find trials that match the search criteria
   
      % make a list of pointers to codes we should ignore
      ignore_elements=find_any(codes,glo_list);
   
      % use the list of pointers to remove the elements from both codes and times
      codes=codes(yank_elements(ignore_elements,length(codes)));
      times=times(yank_elements(ignore_elements,length(times)));
   
      % Here is the critical part of the program.  Look for the code sequence.
   
   sequence_candidates=find_any(codes,sequence(1).codes); % where might the sequence start?
   
   % look for two obvious cases: 
   %     no match for first code    |  not enough codes in this trial to make a match
   if ~isempty(sequence_candidates) && (length(codes) >= length(sequence))   
      if length(sequence)==1 % second trivial case, only one code group to match
         if ~use_history    % match success does not depend upon history
            match_success=1;
            match_start=sequence_candidates(1);
            match_end=sequence_candidates(1);
            match_span=0;
         else
            [uhf,uhf_status]=user_history_function(trial_candidate_number,unit_trials,history, ...
                                                         user_history_file_name,allcodes,codes);
            if uhf_status~=1    % history function crashed!
               match_success=0;
               aborted_by_history=1;   % scan aborted by error in history function
               if errors
                  fprintf(error_fid,'\nError [work_scan]. Scan aborted by error in history script. Terminating scan.\n');
               end;
            elseif uhf==0      % history function did not allow match
               match_success=0;
            elseif uhf==1      % history function allowed match
               match_success=1;
               match_start=sequence_candidates(1);
               match_end=sequence_candidates(1);
               match_span=0;
            elseif uhf==-1   % history function requested terminating this scan
               match_success=0;
               aborted_by_history=1;
            end;
         end;
      else     % try every possible sequence that starts with the first code
         trial_rejected=0;
         for starting_point=1:length(sequence_candidates)  % each starting point

            match_success=1;  % assume sequence matches
            % starting point matches, test subsequent codes in sequence
            for seq_index=2:length(sequence) % each code group in the sequence (1st code group was already tested)
               trial_code_index=sequence_candidates(starting_point)+ seq_index-1;
               if trial_code_index > length(codes)
                  trial_rejected=1;  % ran out of codes in this trial, cannot match the sequence in this trial
                  match_success=0; 
                  break;         % begin exiting current trial
               end;
               trial_code=codes(trial_code_index); % successful so far, test next code in trial
               if isempty(find(sequence(seq_index).codes==trial_code, 1)) % in sequence code group?
                  match_success=0;  % no
                  break; % match failed. move on to next starting point.
               end;
            end; % for seq_index=2

            if match_success==1     % success in matching the entire sequence
               match_start=sequence_candidates(starting_point);
               match_end=sequence_candidates(starting_point)+length(sequence)-1;
               match_span=times(match_end) - times(match_start);
               break;
            end;

            if trial_rejected==1    % trial was disqualified
               match_success=0;
               break;  
            end;
          end; % for each starting_point   

         if match_success && use_history  % call user's history function if needed
            [uhf,uhf_status]=user_history_function(trial_candidate_number,unit_trials,history, ...
                                                       user_history_file_name,allcodes,codes);
            if uhf_status == -1
               aborted_by_history=1;   % scan aborted by user history function
               if errors
                  fprintf(error_fid,'\nError [work_scan]. Scan aborted by error in history script. Terminating scan.\n');
               end;
               match_success=0;  % pass to next trial and then it will exit.
            elseif uhf==0
               if debugs
                  fprintf(debug_fid,'Debug [work_scan]. Trial rejected by history script.\n');
               end;
               match_success=0;  % pass to next trial without recording data.
            elseif uhf==-1      % history function requested terminating this scan
               match_success=0;
               aborted_by_history=1;
            end;
         end;

         if  match_success  % see if we still have a successful sequence match after a history script
            if ((match_span <= span) || (span==0))   % is the sequence within the permitted time window (Span)?
               if debugs
                  fprintf(debug_fid,'Debug [work_scan]. -------------- Trial %d accepted.\n',trial);
               end;
               work_trial_list=[work_trial_list trial]; % successful match
               selected_unit_trials=[selected_unit_trials trial_candidate_number]; 
               event_codes=[event_codes ; codes(match_start:match_end)];
               event_times=[event_times ; times(match_start:match_end)];
               % record the time that analog data started in this trial
               as_index=find(codes==WORK_ANALOG_START_CODE);  % analog start code (usually 100) marks start of analog
               if isempty(as_index)
                  work_analog_start=[work_analog_start -1];   % place holder
               elseif length(as_index) > 1
                  fprintf(warning_fid,'Warning [work_scan]. Analog start code (%d) occurs more than once in trial\n',...
                      WORK_ANALOG_START_CODE);
                  work_analog_start=[work_analog_start times(as_index(1))];
               else % the preferred case
                  work_analog_start=[work_analog_start times(as_index)];  % "unsorted trials" 
               end;
               % record the time that analog data ended in this trial
               as_index=find(codes==WORK_ANALOG_STOP_CODE);  % analog stop code (usually 101 )marks end of analog
               if isempty(as_index)
                  work_analog_stop=[work_analog_stop -1];   % place holder
               elseif length(as_index) > 1
                  fprintf(warning_fid,'Warning [work_scan]. Analog stop code (%d) occurs more than once in trial\n',...
                      WORK_ANALOG_STOP_CODE);
                  work_analog_stop=[work_analog_stop times(as_index(1))];
               else % the preferred case
                  work_analog_stop=[work_analog_stop times(as_index)];  % "unsorted trials" 
               end;
            end; % if match_span <= span
         end; % if match_success==1
      end; % only one code to match     
   end; % no match on first code
end; % next trial
work_analog_start_stop=[work_analog_start' work_analog_stop'];  % these better have equal lengths
if debugs
   fprintf(debug_fid,'Debug [work_scan]. Trials found=%d\n',length(work_trial_list)); %#ok<*NODEF>
end;

% end of main


