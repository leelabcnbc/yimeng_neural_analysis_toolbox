function [A,T]=thin_mean_alignment(trial_list,time,amplitude,step)
%
%  Align a group of analog traces for making a thin mean.  
%
%  BUGS:  Probably need to make sure trials that end early have NaNs after they end.
%
%
%  Inputs:
%     trial_list    Ordered list of trials to use in time and amplitude. Order probably
%                   does not matter. Must be a row array.
%     time          matrix of timestamps for datapoints in amplitude
%     amplitude     matrix of analog data. row=trials, columns=samples
%     step          1/frequency of samples
%  Outputs:
%     A             new array of samples. columns have been shifted to align all the timestamps
%                   to nearest time of T
%     T             array of timestamps.
%
%
global error_fid warning_fid debug_fid
global errors warnings debugs

if isempty(trial_list) || isempty(amplitude) || isempty(time)
   if warnings
      fprintf(warning_fid,'Warning [thin_mean_alignment]. Empty trial list or analog data array.\n');
   end;
   A=[];
   T=[];
   return;
end

[a b]=size(trial_list);
if a > b 
   if errors
      fprintf(error_fid,'Internal Error [thin_mean_alignment]. trial_list is column vector.\n');
   end
   trial_list=trial_list';
end


max_x_trial=size(amplitude,1);
trial_list=trial_list(find(trial_list <= max_x_trial));  % make sure trial list does not exceed array size

sparenans=ones(1,10000)*NaN;  % a handy array of NaN's

% create an array of time values that cover the entire range of times
tmin=min(min(time)); tmax=max(max(time));
T=tmin:step:tmax;   % new time scale
LT=length(T);               % number of columns in final array
LA=length(amplitude(1,:));  % number of columns in original array
LR=length(amplitude(:,1));  % number of rows (trials)
A=ones(LR,LT)*NaN;  % initialize new amplitude array
% We are going to align amplitude(trial,:) so that every trial starts at
% tmin and ends at tmax.  Do this by inserting the proper number of NaNs
% before the first valid data value.  
for trial=trial_list
   % bracket the first timestamp of this trial between closest steps of the new timescale
   T_col_low =max(find(T <= time(trial,1)));  % time step just below first trial
   T_col_hi  =min(find(T >= time(trial,1)));  % time step just above first trial
   T_col=T_col_low;   % assume this is closest
   if (isempty(T_col)) % in case we are at the extreme end and came up empty.
      T_col=T_col_hi;
   elseif (isempty(T_col_hi))  
                       % stop here if at other extreme end
   elseif (abs(T(T_col_hi)-time(trial,1)) < abs(T(T_col_low)-time(trial,1)))
      T_col=T_col_hi;   % closer to the next highest index
   end;
   if (isempty(T_col))  % rather unexpected problem. Ended up with empty T_col.
      if (errors)
         fprintf(error_fid,'Error [make_plot: Thin mean alignment]. Cannot make an average.\n');
         A=[];
         break;
      end;
   end;
   
   nans_needed=max(T_col-1, LT-LA-T_col+1);
   if length(sparenans) < nans_needed
      sparenans=ones(1,nans_needed)*NaN;  % a increase array of NaN's 
   end
       
   if (LT <= (T_col-1)+LA)  % enough columns in "amplitude" to satisfy "A" ?
      A(trial,:)=[sparenans(1:T_col-1) amplitude(trial,1:(LT-T_col+1))];  % "sparenans" defined at top
   else   % no, need extra NaNs
      A(trial,:)=[sparenans(1:T_col-1) amplitude(trial,1:end) sparenans(1:LT-LA-T_col+1)];
   end;
end; % trial loop 