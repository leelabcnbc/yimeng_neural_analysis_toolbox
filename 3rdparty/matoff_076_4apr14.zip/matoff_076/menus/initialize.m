function response=initialize
%
%  initialize the layouts
%
%  Outputs
%     response        1= success, 0= failure
%  Globals changed
%     layouts
% 
%
global layouts
global error_fid warning_fid debug_fid
global errors warnings debugs
%
response=1;

try
   layout=get_layout;  % collect a set of layout values from the current GUI settings
   for i=1:10
      temp_layouts(i)=layout;  % assign those layout values to a temp variable
   end;
   layouts=temp_layouts;  % redimension 'layouts' to hold all the layouts
   clear temp_layouts;
catch
   fprintf(error_fid,'[initialize] Initialization failed trying to create layouts. \n');
   fprintf(error_fid,'%s\n',lasterr);
   response=0;
   return;
end;

if set_layout(layouts(1));         % default layout is layout #1
   set(findobj('Tag','layout_number'),'String','1');
   fprintf(warning_fid,'Layouts initialized.\n');
else
   fprintf(error_fid,'Initialization failed trying to establish layout 1. \n');
   response=0;
end;