function dump(params)
%
% Dump various internal variables
%   Parameters accepted:  
%     spikes
%     
%
global event_codes event_times 
global spiketrials time_zero environment fid
global error_fid warning_fid debug_fid
global errors warnings debugs
global work_trial_list taint  
global history

params=deblank(strjust(params,'left'));  % squeeze out spaces from parameters
lparams=lower(params);    % lower case version of parameters 

if isempty(params)
   if warnings
      fprintf(warning_fid,'Warning [dump]. No dump options requested.\n');
   end;
   return;
end; % if isempty(params)

% spike times relative to the centering code
if strncmp(lparams,'spikes',3)
   if debugs
      fprintf(debug_fid,'Debug [dump]. Dump spikes.\n');
   end;
   if process < 1   % use the process command to bring data up to date
      if warnings
         fprintf(warning_fid,'Warning [dump]. Not ready for dump.\n');
      end;
      return;
   end;
   file_name='';
   if findstr(lparams,'out')
      [dummy,rem]=strtok(params); % remove "spikes"
      [dummy,rem]=strtok(rem);    % remove "output"
      [out]=strtok(rem);
      if ~isempty(out)
         file_name=filepath(out,environment.dumppath); 
      end;
   end; % if findstr(lparams,'out')
   
   % make sure trials are sorted
   if ~isempty(work_trial_list)
      % fetch list of trials based on sorting criteria, reorder list starting from 1
      % "sort_trials" uses the GUI TRIALS list to help choose which trials to include
      unsorted_trial_list=work_trial_list-work_trial_list(1)+1;
      % fetch list of trials based on sorting criteria
      sorted_trial_list=sort_trials;  
   else
      if errors
         fprintf(error_fid,'Error [dump]. Cannot sort spikes\n');
      end;
      return;
   end; %  if ~isempty(work_trial_list)

   % collect centered spike times for each trial
   for t=1:length(sorted_trial_list)
      spike_dump(t).sorted=t;  % new trial numbering after sort
      spike_dump(t).unsorted=sorted_trial_list(t);  % unsorted (chronological) trial number
      % extract spikes for the sorted trial and convert to ms
      if ~isempty(spiketrials)
         spike_dump(t).spikes=(spiketrials(find(spiketrials(:,1)==sorted_trial_list(t)),2))/10; 
         spike_dump(t).size=length(spike_dump(t).spikes);  % size of spike list
      else
         spike_dump(t).spikes=[];
         spike_dump(t).size=0;
      end;
   end; %  for t=1:length(sorted_trial_list)
   if isempty(file_name)
      for t=1:length(spike_dump)
         fprintf(1,'\nSorted Trial %4d    Chronological Trial %4d: \n', ...
                        spike_dump(t).sorted,spike_dump(t).unsorted);
         if spike_dump(t).size > 0
            for s=1:spike_dump(t).size
               fprintf(1,'      %6d\n',spike_dump(t).spikes(s));
            end;
         else
            fprintf(1,'\n');
         end; % if spike_dump(t).size > 0
      end; % for t=1:length(spike_dump)
   else
      if strcmp(environment.dumpmode,'APPEND')
         spike_dump_fid=fopen(file_name,'at');
      else
         spike_dump_fid=fopen(file_name,'wt');
      end;
      if spike_dump_fid < 1
         if errors
            fprintf(error_fid,'Error [dump]. Cannot open dump file %s\n',file_name);
         end;
         return;
      end;
      for t=1:length(spike_dump)
         fprintf(spike_dump_fid,'%s %-4d:%-4d:',environment.dumptext,spike_dump(t).sorted,spike_dump(t).unsorted);
         if spike_dump(t).size > 0
            for s=1:spike_dump(t).size
               fprintf(spike_dump_fid,'%d',spike_dump(t).spikes(s));
               if s < spike_dump(t).size
                  fprintf(spike_dump_fid,',');
               end; 
            end; % for s=1:spike_dump(t).size
         end; % if spike_dump(t).size > 0
         fprintf(spike_dump_fid,'\n');
      end; % for t=1:length(spike_dump)
      fclose(spike_dump_fid);
      spike_dump_fid=-1;
   end; % if isempty(file_name)


elseif strncmp(lparams,'history',3)
   if debugs
      fprintf(debug_fid,'Debug [dump]. Dump history.\n');
   end;
   file_name='';
   if findstr(lparams,'out')
      [dummy,rem]=strtok(params); % remove "history"
      [dummy,rem]=strtok(rem);    % remove "output"
      [out]=strtok(rem);
      if ~isempty(out)
         file_name=filepath(out,environment.dumppath); 
      end;
   end; % if findstr

   if ~isempty(history)   
       if isempty(file_name)
          for t=1:length(history)
             fprintf(1,'\nClass = %d\n',history(t).class);
             trial_list=history(t).trial_list;
             htrials=expand_range_list(trial_list);
             lcount=0;
             number_of_pair_per_line=12;
             for s=1:(length(history(t).values)/number_of_pair_per_line)+1
                for n=1:number_of_pair_per_line
                   lcount=lcount+1;
                   if lcount <= length(history(t).values)
                      fprintf(1,'(%d,%d) ',htrials(lcount),history(t).values(lcount));
                   end;
                end;
                fprintf(1,'\n');
             end;           
          end; % for t=1:length(history)
       else  % isempty(file_name)
          if strcmp(environment.dumpmode,'APPEND')
             h_dump_fid=fopen(file_name,'at');
          else
             h_dump_fid=fopen(file_name,'wt');
          end; % strcmp(environment.dumpmode
          if h_dump_fid < 1
             if errors
                fprintf(error_fid,'Error [dump]. Cannot open dump file %s\n',file_name);
             end;
             return;
          end; % if h_dump_fid
          for t=1:length(history)
             fprintf(h_dump_fid,'\nClass = %d\n',history(t).class);
             trial_list=history(t).trial_list;
             htrials=expand_range_list(trial_list);
             for s=1:length(history(t).values)
                fprintf(h_dump_fid,'(%d,%d) ',htrials(s),history(t).values(s));
             end;           
          end; % for t=1:length(history)
          fclose(h_dump_fid);
          h_dump_fid=-1;
       end; % if isempty(file_name)
   end; % if ~isempty(history)

else
   fprintf(1,'Dump command not recognized\n');
   if environment.logging==1
      fprintf(fid.log,'Dump command not recognized\n');
   end;
end;
