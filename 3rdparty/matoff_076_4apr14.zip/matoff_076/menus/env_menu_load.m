function env_menu_load
%
% ===============================================
%   Set Environment Menu GUI to reflect
%   the environmental variable values
% ===============================================

global environment

set(findobj('tag','env_analogstart'),'string',environment.analogstart);
set(findobj('tag','env_analogstop'),'string',environment.analogstop);
set(findobj('tag','env_datapath'),'string',environment.datapath);
set(findobj('tag','env_defaultpath'),'string',environment.defaultpath);   
set(findobj('tag','env_dumptext'),'string',environment.dumptext);
set(findobj('tag','env_dumplabel'),'string',environment.dumplabel);
set(findobj('tag','env_dumpmode'),'string',environment.dumpmode);
set(findobj('tag','env_dumppath'),'string',environment.dumppath);
set(findobj('tag','env_editor'),'string',environment.editor);
set(findobj('tag','env_eogsamplerate'),'string',environment.eogsamplerate);     
set(findobj('tag','env_eventcodefile'),'string',environment.eventcodefile);
set(findobj('tag','env_formatpath'),'string',environment.formatpath);
set(findobj('tag','env_graphicsformat'),'string',environment.graphicsformat);
set(findobj('tag','env_historypath'),'string',environment.historypath);
set(findobj('tag','env_layoutpath'),'string',environment.layoutpath);
set(findobj('tag','env_makdat'),'string',environment.makdat);
set(findobj('tag','env_makdump'),'string',environment.makdump);
set(findobj('tag','env_maxinputtrials'),'string',environment.maxinputtrials);
set(findobj('tag','env_maxtrialsfound'),'string',environment.maxtrialsfound);
set(findobj('tag','env_metachar1'),'string',environment.metachar1);
set(findobj('tag','env_metachar2'),'string',environment.metachar2);
set(findobj('tag','env_metapath'),'string',environment.metapath);   
set(findobj('tag','env_plotpath'),'string',environment.plotpath);
set(findobj('tag','env_protocolpath'),'string',environment.protocolpath);
set(findobj('tag','env_remapfile'),'string',environment.remapfile); 
set(findobj('tag','env_statpath'),'string',environment.statpath);
set(findobj('tag','env_spiketimeoffset'),'string',environment.spiketimeoffset);
