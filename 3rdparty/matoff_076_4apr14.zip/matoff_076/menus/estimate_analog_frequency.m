function freq=estimate_analog_frequency(allowed)
%
% Estimates the sample frequency of analog data
%
% Inputs
%    allowed        List of permitted analog frequencies
%
% Outputs
%    actual frequency
%
global RESCALE_TIME
global work_trial_list work_analog_start_stop
global time_zero
global work_fid environment
global error_fid warning_fid debug_fid
global errors warnings debugs

millisecond_scale=10000;   

freq=0;  % error response
number_of_test_trials=22;

if isempty(work_trial_list)
   if warnings
      fprintf(warning_fid,'Warning [estimate_analog_frequency].  You must scan a valid sequence before A/D frequency can be estimated.\n');
   end;
   return;
end;

chan=get(findobj('Tag','xchannelmenu'),'Value')-1;   % first analog
if isempty(chan)
   if warnings
      fprintf(warning_fid,'Warning [estimate_analog_frequency]. No analog channel selected.\n');
   end;
   return;
end;

% fetch analog data (amplitude values)
if debugs
   fprintf(debug_fid,'Debug [estimate_analog_frequency]. Fetching analog using fid=%d\n',work_fid.analog);
end;


if length(work_trial_list) > number_of_test_trials   % choose up to 22 test trials
   test_trials=1:number_of_test_trials;
else
   test_trials=1:length(work_trial_list);
end;

analog_value=read_analog_record(work_fid.analog,work_trial_list(test_trials),chan);

if isempty(analog_value)
   if warnings
      fprintf(warning_fid,'Warning [estimate_analog_frequency]. No analog data on this channel (%d).\n',chan);
   end;
   return;
end;

% estimate sample rate

rates=[];
sum_rates=0;
num_rates=0;
for t=1:length(test_trials)
   number_of_samples = length(find(~isnan(analog_value(t,:))));  % find the number of non-NaN data points
   trial_duration=abs(work_analog_start_stop(t,2)' - work_analog_start_stop(t,1)' )  ;  % duration of this trial in ms.
   if trial_duration < 0.00001
      if warnings
         fprintf(warning_fid,'Warning [estimate_analog_frequency]. No analog data, or analog start/stop event codes missing from sequence.\n');
      end;  
   else   
      rates=[rates  millisecond_scale*(number_of_samples/trial_duration)];         % samples / second
      sum_rates=sum_rates+ millisecond_scale*(number_of_samples/trial_duration);
      num_rates=num_rates+1;
   end   
   if debugs
      fprintf(debug_fid,'%d samples / %d msec = %d samp/s from unsorted trial %d (sorted trial %d)\n',...
         number_of_samples,trial_duration/10,round(millisecond_scale*(number_of_samples/trial_duration)),work_trial_list(t),t );
   end;
end;

if num_rates < 1
   if warnings
      fprintf(warning_fid,'Warning [estimate_analog_frequency]. Too few valid trials to calculate analog rate.\n');
   end;  
   return;
end;

ave_rate=sum_rates/num_rates;  % do we want to discard outliers first?


if debugs
   fprintf(debug_fid,'Debug [estimate_analog_frequency]. Calculated A/D rate: %8.4f samp/s.\n',ave_rate);
end;

if isempty(allowed)
   freq=round(ave_rate);
else                % Compare average rate to allowed values of any are listed
   error_list=[];
   for r=1:length(allowed)
      a2d_rate=allowed(r);
      err=abs(a2d_rate-ave_rate);
      if debugs
         fprintf(debug_fid,'Debug [estimate_analog_frequency]. Allowed A/D rate: %8.4f samp/s  error= %f.\n',a2d_rate,err);
      end;
      if err < (.05 * a2d_rate)   % 5%
         freq=a2d_rate;
         break;
      end;
   end;
end;

if debugs
   fprintf(debug_fid,'Debug [estimate_analog_frequency]. Setting A/D rate to: %8.4f samp/s\n',freq);
end;
set(findobj('Tag','frequency'),'String',num2str(freq));



