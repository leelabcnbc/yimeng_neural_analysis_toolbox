function [color_number]=color2number(color_name)
%
% Simple translation from a color name to a number that matches the
% drop-down lists in MatOFF, which are always in this order. The number,
% one-letter abbreviation, or full name can be used.
%
% 1 y yellow 
% 2 m magenta 
% 3 c cyan 
% 4 r red 
% 5 g green 
% 6 b blue 
% 7 w white 
% 8 k black
%
[name,color_number,valid]=check_string_value(color_name,1,8);
if valid  % if this is a valid number, return with the color number
   return;
end

name=lower(name);  % assume this is a name
if strcmp(name,'yellow') | strcmp(name,'y')
   color_number=1;
elseif strcmp(name,'magenta') | strcmp(name,'m')
   color_number=2;
elseif strcmp(name,'cyan') | strcmp(name,'c')
   color_number=3;
elseif strcmp(name,'red') | strcmp(name,'r')
   color_number=4;
elseif strcmp(name,'green') | strcmp(name,'g')
   color_number=5;
elseif strcmp(name,'blue') | strcmp(name,'b')
   color_number=6;
elseif strcmp(name,'white') | strcmp(name,'w')
   color_number=7;
elseif strcmp(name,'black') | strcmp(name,'k')
   color_number=8;
else
   color_number=0;
end

