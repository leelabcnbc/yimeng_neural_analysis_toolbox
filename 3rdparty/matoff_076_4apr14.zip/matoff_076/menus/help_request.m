function help_request(pcmd)
%  help command
% 
% Inputs
%    pcmd    command to describe
%
global error_fid warning_fid debug_fid
%

if isempty(pcmd)
   fprintf(1,'Enter   help <topic>    Available topics are:\n\n');
   fprintf(1,'A      Accumulate, Analog, Ana2, Append, Autoupdate, Avanalog, Av2analog, Axis,\n');    
   fprintf(1,'B      Batch, Begin, Bell, Binwidth,\n');                                               
   fprintf(1,'C      Calculator, Center, Close, Cmd, Continue, Copy, \n');                                  
   fprintf(1,'DE     Date, Display, Edit, End, Endif, Erase, Errorlevel, Exit,\n');      
   fprintf(1,'F      File, Fileerror, Found, Frequency,\n');
   fprintf(1,'GHI    Globalignore, Help, Hide, Histogram, History Index, Initialize, Invalid,\n');                     
   fprintf(1,'JKL    Layout, Load, Log, \n');                                                         
   fprintf(1,'M      Makdat, Map, Mark, Matlab, Manualupdate, MenuPosition, MWfiles,\n');                            
   fprintf(1,'NOPQ   New, Nextplot, Old, Open, Plot, Print, Pulsechannel, PWD, Quit,\n');                       
   fprintf(1,'R      Read, RIP,\n');                                                                  
   fprintf(1,'S      Save, Scale, Scan, Segment, Sequence, Set, Setenv,\n');                          
   fprintf(1,'S      Shift, Show, Sort, Sourcetrials, Span, Spot, \n');                               
   fprintf(1,'TUV    Taint, Text, Trialfunction, Trials, Type, Unit, Validatespikes, Version,\n'); 
   fprintf(1,'WXYZ   Walk, Why, Window, Write, XY, Z\n\n');                                                                     
 
elseif strncmp(pcmd,'cmd',5)
   fprintf(1,'cmd   enter the PCOFF command mode. Use MATLAB to return to MatLab command line.\n');
elseif strncmp(pcmd,'matlab',5)
   fprintf(1,'MATLAB   leave the PCOFF mode and return to MatLab command line. Use pcmd to enter PCOFF again.\n');
elseif strncmp(pcmd,'accumulate',3)
   fprintf(1,'ACCumulate is mainly for debugging. The accumulate \n'); 
   fprintf(1,' command will force the next processing set to "map".\n');
elseif strncmp(pcmd,'append',3)
   fprintf(1,'APPend opens an existing ASCII file for use with the WRITE command.'); 
   fprintf(1,' Append will open a new file if no file of the same name exists.\n');
   fprintf(1,' Close the file with the CLOSE ASCII command.\n');
elseif strncmp(pcmd,'axis',2)    % axis command (new command)
   fprintf(1,'   AXis XATzero <ON or OFf>  Force time axis to be zero at the origin.\n');
   fprintf(1,'   AXis ON                   Display the X axis on the plot.\n');
   fprintf(1,'   AXis OFF                  Do not display the X axis on the plot.\n');
   fprintf(1,'   AXis MULTiplot <number of plots per page>    Place up to 8 graphs on the same plot.\n');
   fprintf(1,'   AXis SUBplOt <position of next plot on page> Use with multiplot to select location of next graph.\n');
elseif strncmp(pcmd,'batch',3)
   fprintf(1,'   BATch <filename>   Execute a DOS batch file written for PCOFF\n');   
elseif strncmp(pcmd,'begin',5) | strncmp(pcmd,'end',3)
   fprintf(1,'BEGIN and END used to be required in protocol files. They are now ignored\n');
elseif strncmp(pcmd,'bell',3)
   fprintf(1,'BELl                   will cause the computer to beep (via the sound card speakers)\n');
   fprintf(1,'BELl <frequency> <duration>  will change the tone frequency and duration\n');
elseif strncmp(pcmd,'calculator',3)
   fprintf(1,'CALculator will call up the Windows calculator program\n');
elseif strncmp(pcmd,'center',3)
   fprintf(1,'CENter or CENterline\n');
   fprintf(1,'CENter n          n>0 choose event group for centering the rasters'); 
   fprintf(1,'CENterline SHOw       put a center line on the plot\n');
   fprintf(1,'CENterline NOShow     remove center line from the plot\n');
   fprintf(1,'CENterline SIze       adjust the vertical length of center line\n');
   fprintf(1,'CENterline YPos       adjust horizontal position of center line\n');
   fprintf(1,'CENterline LINe       choose line type of center line (1 to 7)\n');
elseif strncmp(pcmd,'close',3)
   fprintf(1,'CLOse  close currently open ASCII file or data file.\n');  
   fprintf(1,'CLOse ASCii        will close ASCII file (see Append and Open commands.)\n');
   fprintf(1,'CLOse DATafile     will close current data file.\n');
   fprintf(1,'CLOse APPendfile   will close all open SET <process> APPEND files.\n');
   fprintf(1,'  If no parameter is given, Close will try first to close an ASCII file.\n');
   fprintf(1,'  If there is no ASCII file open, it will close the data file.\n');
elseif strncmp(pcmd,'continue',4)   
   fprintf(1,'CONTinue     Resume a protocol file after BREAK command\n');
elseif strncmp(pcmd,'copy',4)   
   fprintf(1,'COPY         Copy layout parameters from one layout to another\n');
   fprintf(1,'COPY <source #> <destination #>           Copy all parameters from source layout number to destination layout number\n');
   fprintf(1,'COPY <source #> <destination #> text      Copy only the text from the source layout to the destination layout \n');
elseif strncmp(pcmd,'date',3)
   fprintf(1,'DATe <list>   Print the current date.\n');       
elseif strncmp(pcmd,'display',3)
   fprintf(1,'DISplay <list>   Select which stored layouts to plot.\n');   
elseif strncmp(pcmd,'dump',3)
   fprintf(1,'dump spikes [OUTPUT] <filename>   list spike times (relative to centering code) for each trial\n');   
   fprintf(1,'dump index [OUTPUT] <filename>    list the index to a file\n');
   fprintf(1,'dump setstats [OUTPUT] <filename> list the settings of all the SET options\n');
   fprintf(1,'dump events [OUTPUT] <filename>   list event codes for every trial found\n');
   fprintf(1,'dump history [OUTPUT] <filename>  list all history classes and their values for every trial\n');
elseif strncmp(pcmd,'edit',3)
   fprintf(1,'EDIt filename  Edit an ASCII file\n');   
   fprintf(1,'   The environmental variable EDITOR must be set first\n');     
elseif strcmp(pcmd,'end')
   fprintf(1,'END     Terminate the current protocol file or metafile\n');      
elseif strncmp(pcmd,'endif',5)
   fprintf(1,'ENDIF <condition>  Terminate a protocol file if condition is met\n');
   fprintf(1,'Conditions:  NOUNIT     Last "unit" command failed to open a unit\n');
   fprintf(1,'             NOANALOG   No data in primary (X) analog channel\n');    
elseif strncmp(pcmd,'erase',3)
   fprintf(1,'ERAse <plot number>  Erase current plot or designated plot number\n');
elseif strncmp(pcmd,'exit',3) | strncmp(pcmd,'quit',3)
   fprintf(1,'EXIT  Close MatOFF and MATLAB.\n');
   fprintf(1,'QUIT  Close MatOFF, but keep MATLAB running.\n');
elseif strncmp(pcmd,'errorlevel',3)   
   fprintf(1,'ERRorlevel <parameter>   Decide how much debugging information MatOFF will provide.\n');
   fprintf(1,'         debug      tons of information\n');
   fprintf(1,'         warning    helpful information\n');
   fprintf(1,'         serious    only report major problems\n');
   fprintf(1,'         fatal      you might get nothing\n');
   fprintf(1,' If the command is given without parameters, the currentl error level is returned.\n');   
elseif strncmp(pcmd,'fileerror',7)  % this test must come before FILE command decoding 
   fprintf(1,'FILEERRor  EXIT or BREAK   Decide which action to take if \n');
   fprintf(1,'an error occurs opening a file during a protocol file.\n'); 
elseif strncmp(pcmd,'file',2)
   fprintf(1,'FIle <filename>    open new data file  \n');   
elseif strncmp(pcmd,'found',2)
   fprintf(1,'FOund       list the sequences that were found and how many of each\n');     
elseif strncmp(pcmd,'frequency',3)
   fprintf(1,'FREquency <value>      set A/D frequency in Hz\n');
   fprintf(1,'FREquency auto         set A/D frequency based on data file\n');
   fprintf(1,'FREquency auto <list>  set A/D frequency based on data file, list of allowed values\n');
elseif strncmp(pcmd,'globalignore',3)
   fprintf(1,'GLObalignore <list>       comma list of event codes to ignore\n');
   fprintf(1,'GLObalignore auto <list>  ignore those codes not in the sequence\n');
   fprintf(1,'If the list is omitted, the current list is printed on the screen\n');
elseif strncmp(pcmd,'help',3)
   fprintf(1,'HELp <command>       Get brief help message for command.\n');
   fprintf(1,'Capital letters are used to show how many letters of the command\n');
   fprintf(1,'must be entered.\n');
elseif strncmp(pcmd,'hide',3)
   fprintf(1,'HIDe PLOt   do not draw plots on the screen \n');
   fprintf(1,'Same as Set plot noshow. Use Set plot show or Show plot to\n');
   fprintf(1,'return to normal plot display.\n');

elseif strncmp(pcmd,'index',3)
   fprintf(1,'INDex   lists the index of current open file\n');
elseif strncmp(pcmd,'initialize',3)
   fprintf(1,'INItialize  Reset the graphics layouts to default settings.\n');  
elseif strncmp(pcmd,'invalid',3)
   fprintf(1,'INVALID SPIKE COLOR <color>  color of spikes that are NOT valid: black,blue,green,red,cyan or k,b,g,r,c.\n');
   fprintf(1,' (see VALIDATE SPIKES for more information)\n');
elseif strncmp(pcmd,'load',3) 
   fprintf(1,'LOAd <filename>   Start running a protocol file\n');
elseif strncmp(pcmd,'log',3)
   fprintf(1,'LOG command will be implemented real soon now...\n');
elseif strncmp(pcmd,'manualupdate',3)     % manual update
   fprintf(1,'   MANualupdate  turn off autoupdate feature.\n');   
elseif strncmp(pcmd,'save',3)
   fprintf(1,'SAVe <filename> <options>    Save settings to a protocol file\n');
   fprintf(1,'Options:   none     save file and sequence information\n');
   fprintf(1,'           layout   save file, sequence and layout information\n');
   fprintf(1,'           only     save only layout information\n');
elseif strncmp(pcmd,'makdat',4) | strncmp(pcmd,'makedat',4)
   fprintf(1,'   MAKDat <listfile> <outputfile> -<options>   Read and convert Cortex data files.\n'); 
   fprintf(1,'   <listfile> must include any extension. <outputfile> must NOT have an extension.\n');
   fprintf(1,'Options:   \n');
   fprintf(1,'   processing: 8   8 spike channels. (Default is 2, use REMAP file to define more channels.)\n');
   fprintf(1,'               N   No output file. Process input, but do not create output files.\n');
   fprintf(1,'               O   Overwrite existing output file. Makdat will not overwrite without permission.\n');
   fprintf(1,'               P   Exclude EPP analog data.\n');
   fprintf(1,'               R   Exclude EOG analog data.\n'); 
   fprintf(1,'               T   Ignore Cortex condition codes. Otherwise, condition codes get mapped to event codes.\n');
   fprintf(1,'               X   Exclude all analog (same as -PR)\n');
   fprintf(1,'   debugging:  A   Show each analog value. (Creates lots of output.)\n');
   fprintf(1,'               C   Input file name are case sensitive. \n');
   fprintf(1,'               D   Show progress of data processing. Used for simple debugging.\n');
   fprintf(1,'               E   Suppress warning messages.\n');
   fprintf(1,'               F   List event codes and times. (Creates moderate amount of output.)\n');
   fprintf(1,'               H   Display the Cortex header for each trial\n');
   fprintf(1,'               S   List spike times and channels (Creates lots of output if lots of spikes.)\n');
   fprintf(1,'               V   Verbose mode. Additional debug information. \n');
   fprintf(1,'Example:\n');
   fprintf(1,'    makdat ch095b.lst ch095 -OTH \n');
elseif strncmp(pcmd,'map',3)
   fprintf(1,'MAP     manually initiate the mapping processs.\n');
elseif strncmp(pcmd,'mark',3)
   fprintf(1,'MARk n     n>0  choose event group to mark each trial'); 
elseif strncmp(pcmd,'menuposition',4)
    fprintf(1,'MENUposition SAVe <filename>     Save current screen layout of the menus\n');
    fprintf(1,'MENUposition LOAd <filename>     Load saved screen layout of the menus\n');    
elseif strncmp(pcmd,'MWfiles',3)
   fprintf(1,'MWFiles <filename 1> <filename 2>     Do a Wilcoxon Mann Whitney test on these two files.\n');
   fprintf(1,'Results are for 2-tailed test at p=0.05.  Files are produced by Set mwu keep command.\n');
elseif strncmp(pcmd,'show',3)
   fprintf(1,'SHOw   with no parameters, starts processing and displaying data\n');
   fprintf(1,'       based on current settings.\n');
   fprintf(1,'SHOw <parameter>    display current value for parameter:\n');
   fprintf(1,' sequence         filename     unitname       spikecounts\n');
   fprintf(1,' globalignore     window       span           center\n');
   fprintf(1,' frequency        mark         spot           source\n');
   fprintf(1,' segments         binwidth     trials         taint\n');
   fprintf(1,' directory        environment              \n');
elseif strncmp(pcmd,'unitname',3)
   fprintf(1,'UNItname <name>    name of unit. See Index command.\n');
   fprintf(1,'The "*" character can be used to indicate all units in the\n');
   fprintf(1,'current file.\n');
elseif strncmp(pcmd,'cd',2)
   fprintf(1,'cd <directory>     change directory.\n');
elseif strncmp(pcmd,'read',3)
   fprintf(1,'REAd <data type> OUT=<filename>   Show listing of data from\n');
   fprintf(1,'                                  current unit.\n');
   fprintf(1,' data types are:  codes (or events), pulses (or spikes), analog\n');
   fprintf(1,' The data type "all" can be used to indicate all three types.\n');
   fprintf(1,' The data type "which" will generate a summary of the data types.\n');
   fprintf(1,' OUT=<filename> routes the results to a file insted of the screen.\n');
elseif strncmp(pcmd,'sequence',3)
   fprintf(1,'SEQence <sequence>   enter the sequence of codes to search for.\n');
   fprintf(1,'If <sequence> is blank, the current sequence is printed.\n');
elseif strncmp(pcmd,'pwd',3)
   fprintf(1,'PWD    print the current working directory.\n');
elseif strncmp(pcmd,'shift',3)
   fprintf(1,'SHIft n     shift current plot left by n milliseconds.\n');
elseif strncmp(pcmd,'scan',4)   % avoid conflict with "scale"
   fprintf(1,'SCAN      scan current data file for trials that match sequence list.\n');   
elseif strncmp(pcmd,'spot',3)  % spot command
   fprintf(1,'SPOt <code list>  place spot marker on plot for each code listed.\n');
elseif strncmp(pcmd,'pulsechannel',3)
   fprintf(1,'PULsechannel n    select spike channel for all plots and stats.\n');
elseif strncmp(pcmd,'text',3)
   fprintf(1,'   TEXt <parameter>    Place one of 7 possible lines of text on the plot.\n');
   fprintf(1,'parameters \n');
   fprintf(1,'   SHOw        enable text on the plot.\n');
   fprintf(1,'   NOShow      disable all text from the plot.\n');
   fprintf(1,'   LINe        make this line number "current" (1 to 7).\n'); 
   fprintf(1,'   ON          enable "current" line.\n');
   fprintf(1,'   OFf         disable "current" line.\n');
   fprintf(1,'   STRing      text string for "current" line.\n');   
   fprintf(1,'   XPOs        set horizontal position of first letter.\n');   
   fprintf(1,'   YPOs        set vertical position of first letter.\n');
   fprintf(1,'   Frame       Frame text inside subplot.\n');
   fprintf(1,'   SIZe        set font size (in points).\n');
   fprintf(1,'   COLor       set font color: black,blue,green,red,cyan or k,b,g,r,c.\n'); 
elseif strncmp(pcmd,'trialfunction',6)  % THIS MUST BE TESTED BEFORE 'TRIAL' COMMAND
   fprintf(1,'TRIALFunction is an automatic sampling function for the list of trials to plot.\n');
   fprintf(1,'   TRIALF 3,1   will plot trials 1,4,7,11,... up to TRIALSFOUND  \n');
   fprintf(1,'   TRIALF 3x+1  is a synonym for the same command\n');
% trials will recognize the trialfunction if 'x' is used, Will also recognize misspelling!
elseif strncmp(pcmd,'trials',3) | strncmp(pcmd,'trails',3)
   fprintf(1,'TRIals <list>   list of trials to keep for plotting purposes.\n');
elseif strncmp(pcmd,'new',3)
   fprintf(1,'NEW PLot    create a new plot figure using current settings.\n');
elseif strncmp(pcmd,'nextplot',3)
   fprintf(1,'NEXtplot <figure number>   set the figure number for the next show/plot, but do not show or plot.\n');
elseif strncmp(pcmd,'old',3)
   fprintf(1,'OLD PLot   plot using current settings onto existing figure.\n');
   fprintf(1,'OLD PLot <figure number>   optional figure number to select one of several figures.\n');
   fprintf(1,'OLD PLot NExt   adds + 1 to currrent figure number before plotting.\n');
elseif strncmp(pcmd,'open',3)
   fprintf(1,'OPEn <filename>  opens an ASCII file for use with the WRITE command.'); 
   fprintf(1,' Open  will delete any existing file with the same name.\n');
   fprintf(1,' Close the file with the CLOSE ASCII command.\n');   
elseif strncmp(pcmd,'plot',3)   
   fprintf(1,'PLOt  saves a figure to the disk as a graphics file\n');
   fprintf(1,'   PLOt <n>    save figure number n to disk. Omit n for current figure.\n');
elseif strncmp(pcmd,'print',3)   
   fprintf(1,'PRInt  print a figure\n');
   fprintf(1,'   PRInt <n>    prints figure number n. Omit n for current figure.\n');
   fprintf(1,'   PRInt ORIentation <orient>   set orientation to portrait or landscape\n');
   fprintf(1,'   PRInt PAPertype <size>   set target paper size to letter, legal, or A4\n');
elseif strncmp(pcmd,'span',3)
   fprintf(1,'SPAn <time>   maximum time (in milliseconds) allowed between first and last elements of the search sequence.\n');
   fprintf(1,'SPAn all      disable SPAN.  Search entire trial for sequence.\n');
elseif strncmp(pcmd,'sourcetrials',3)
   fprintf(1,'SOUrcetrials   which trials in the raw data to search for matching event codes.\n'); 
elseif strncmp(pcmd,'window',3)
   fprintf(1,'WINdow     period of time to plot (in milliseconds).\n'); 
elseif strncmp(pcmd,'layout',3)
   fprintf(1,'LAYout <parameter>   Choose one of 10 stored plot descriptions. Save or recall the set.\n');
   fprintf(1,'parameters \n');
   fprintf(1,'   n                  from 1 to 10   Choose one of 10 stored plot descriptions.\n');
   fprintf(1,'   save <filename>    save all 10 plot descriptions to disk.\n');
   fprintf(1,'   file <filename>    load all 10 plot descriptions to disk.\n');
elseif (strncmp(pcmd,'analog',4) | strncmp(pcmd,'ana2',4))
   fprintf(1,'   ANALog <parameter>    Control of primary ("X") analog channel.\n');
   fprintf(1,'or ANA2   <parameter>    Control of secondary ("Y") analog channel.\n');
   fprintf(1,'parameters \n');
   fprintf(1,'   SHOw        enable display of analog data on plots.\n');
   fprintf(1,'   NOShow      disable display of analog data on plots.\n');
   fprintf(1,'   OFf         set analog channel to 0=off. \n');
   fprintf(1,'   YPOs        set vertical position of analog data on plot.\n');
   fprintf(1,'   SIZe        set gain of analog on plot.\n');
   fprintf(1,'   SEParation  set distance between trials of analog. Negative reverses plot order.\n');
   fprintf(1,'   LINe        set line type for analog traces (value 1 to 7).\n');
   fprintf(1,'   n           0 = off, 1..7 selects an input channel number for primary analog.\n');
elseif strncmp(pcmd,'avanalog',4)  | ...
       strncmp(pcmd,'av2analog',4) | ... 
       strncmp(pcmd,'firstdx',4)   | ...
       strncmp(pcmd,'fir2dx',4)
   fprintf(1,'   AVANalog  <parameter>    Control plot of averaged analog data from primary channel.\n');
   fprintf(1,'or AV2Analog <parameter>    Control plot of averaged analog data from secondary channel.\n');
   fprintf(1,'or FIRStdx   <parameter>    Control plot of first derivative data from primary channel.\n');
   fprintf(1,'or FIR2dx    <parameter>    Control plot of first derivative data from secondary channel.\n');
   fprintf(1,'parameters \n');
   fprintf(1,'   SHOw        enable display of processed analog data on plots.\n');
   fprintf(1,'   NOShow      disable display of processed analog data on plots.\n');
   fprintf(1,'   YPOs        set vertical position of processed analog data on plot.\n');
   fprintf(1,'   SIZe        set gain of processed analog on plot.\n');
   fprintf(1,'   SEParation  set distance between trials of data. Negative reverses plot order.\n');
   fprintf(1,'   LINe        set line type for processed analog traces (value 1 to 7).\n');
elseif strncmp(pcmd,'xy',2) 
   fprintf(1,'   XY  <parameter>    Control X-Y plot of analog data.\n');
   fprintf(1,'parameters \n');
   fprintf(1,'   SHOw        enable display of X-Y analog data on plots.\n');
   fprintf(1,'   NOShow      disable display of X-Y analog data on plots.\n');
   fprintf(1,'   LABels      set marker sizes.\n');
   fprintf(1,'   XPOs        set horizontal position of X-Y plot.\n');
   fprintf(1,'   YPOs        set vertical position of X-Y plot.\n');
   fprintf(1,'   SIZe        set gain of X-Y plot.\n');
   fprintf(1,'   SEParation  set distance between X-Y plots. Negative reverses plot order.\n');
   fprintf(1,'   LINe        set line type for analog traces (value 1 to 7).\n');
   fprintf(1,'   TIMe All    show all the analog points in each trial.\n');
   fprintf(1,'   TIMe Time <t1> <t2>    show only analog points between times t1 and t2.\n');
   fprintf(1,'   TIMe Events <e1> <e2>  show only analog points between events e1 and e2.\n');
   fprintf(1,'   OVEerlap ON/OFF   ON= XY plot fills whole plot page, OFF= XY plot to left of raster.\n');
   
elseif strncmp(pcmd,'histogram',6)
   fprintf(1,'   HIStogram  <parameter>    Control histogram plot.\n');
   fprintf(1,'parameters \n');
   fprintf(1,'   SHOw   (or ON)   enable display on plots.\n');
   fprintf(1,'   NOShow (or OFF)  disable display on plots.\n');
   fprintf(1,'   YPOs             set vertical position of X-Y plot.\n');
   fprintf(1,'   SIZe             set size plot.\n');
   fprintf(1,'   LINe             set line type for RIP or histogram (value 1 to 7).\n');
   fprintf(1,'   SCAle            same as the Scale command.  Type "help scale" to see options.\n');
   fprintf(1,'   RAWcounts        histogram scaled by the number of counts in each bin\n');
   fprintf(1,'   NORmalcounts     histogram scaled in pulses/second\n');
   fprintf(1,'   REFerence SHow   turn on reference lines\n');
   fprintf(1,'   REFerence NOShow turn off reference lines\n');
   fprintf(1,'   REFerence        set number of Standard Deviations from mean\n');
   fprintf(1,'   REFerence COlor  select color of reference lines\n');

elseif strncmp(pcmd,'history',7)
   fprintf(1,'   HISTORY  <parameter>    Modify unit history.\n');
   fprintf(1,'parameters \n');
   fprintf(1,'   CLEar                  remove all history class assignments for this unit.\n');
   fprintf(1,'   DATa                   send a list of values to the history script.\n');
   fprintf(1,'   FIle <filename>        select user script file (must have  .m  extension.\n');
   fprintf(1,'   ON                     use user history script.\n');
   fprintf(1,'   OFF                    ignore user history script.\n');
   fprintf(1,'   REWrite <all>          make changes permanent by adding history data to disk files.\n');
   fprintf(1,'   SPOt SHOw (or ON)      enable display of history spot markers (triangles) on plots.\n');
   fprintf(1,'   SPOt NOShow (or OFF)   disable display of history spot markers on plots.\n');
   fprintf(1,'   SPOt FIRSt <parameter> first history class to use for spot marker times.\n');
   fprintf(1,'   SPOt LASt <parameter>  last history class to use for spot marker times.\n');
   fprintf(1,'   SPOt COLor             set spot color: black,blue,green,red,cyan or k,b,g,r,c.\n'); 

elseif strncmp(pcmd,'rip',3)
   fprintf(1,'   RIP        <parameter>    Control Reciprocal Interval Plot.\n');
   fprintf(1,'   ** The RIP command is not yet implemented ** \n');
   fprintf(1,'parameters \n');
   fprintf(1,'   SHOw   (or ON)  enable display on plots.\n');
   fprintf(1,'   NOShow (or OFF) disable display on plots.\n');
   fprintf(1,'   YPOs            set vertical position of X-Y plot.\n');
   fprintf(1,'   SIZe            set size plot.\n');
   fprintf(1,'   LINe            set line type for RIP or histogram (value 1 to 7).\n');
   fprintf(1,'   SCAle           same as the Scale command.  Type "help scale" to see options.\n');
elseif strncmp(pcmd,'binwidth',3)
   fprintf(1,'   BINwidth <parameter>  Set binwidth for histogram.\n');
elseif strncmp(pcmd,'scale',4)
   fprintf(1,'   SCALe <parameter>  Control histogram scale (same as Histogram scale). \n');
   fprintf(1,'parameters \n');
   fprintf(1,'   SHOw (or ON)     Display the histogram scale.\n');
   fprintf(1,'   NOShow (or OFF)  Do not display the histogram scale.\n');
   fprintf(1,'   AUTO             Automatically scale the histogram.\n');
   fprintf(1,'   <number>         Set the maximum pulses per second value.\n');
elseif strncmp(pcmd,'raster',2)
   fprintf(1,'   RAster <parameter>  Control display of rasters on plot.\n');
   fprintf(1,'parameters \n');
   fprintf(1,'   SHOw        enable display on plots.\n');
   fprintf(1,'   NOShow      disable display on plots.\n');
   fprintf(1,'   LABels      set size of raster markers.\n');
   fprintf(1,'   YPOs        set vertical position of X-Y plot.\n');
   fprintf(1,'   SIZe        set size plot.\n');
   fprintf(1,'   SEParation  set distance between rasters. Negative reverses plot order.\n');
elseif strncmp(pcmd,'autoupdate',3)  % auto update 
   fprintf(1,'   AUToupdate  for replot of data after (almost) every command.\n');
   fprintf(1,'               Stop autoupdate with the MANualupdate command.\n');

elseif strncmp(pcmd,'resort',6)  % pseudo command generated by GUI Sort
   fprintf(1,'   RESORT  used internally to force sort.\n'); 
elseif strncmp(pcmd,'sort',3)
   fprintf(1,'   SORt <parameter>   Change the order of the trials displayed on a plot.\n');
   fprintf(1,'                      Many of these may not be implemented yet.\n');
   fprintf(1,'parameters (determines the basis for the sort)\n');
   fprintf(1,'   OFF                  chronological order\n');
   fprintf(1,'   CENter               in order of the centering code.\n');
   fprintf(1,'   TIMe                 time between the center and mark codes in each trial.\n');
   fprintf(1,'   PULse <low> <high>   number of pulses between two selected times.\n');
   fprintf(1,'   EPOch                number of pulses between center and mark codes.\n');
   fprintf(1,'   DELta <low> <high>   magnitude difference between two "X" analog values.\n');
   fprintf(1,'   MIN <low> <high>     minimum "X" analog value between two selected times.\n');
   fprintf(1,'   MAX <low> <high>     maximum "X" analog value between two selected times.\n');
   fprintf(1,'   PEAk <low> <high>    time between first selected time and the maximum of "X".\n');
   fprintf(1,'   PIT  <low> <high>    time between first selected time and the minimum of "X".\n');
   fprintf(1,'   ZERo <low>           time between selected time and the first zero value of X".\n');
   fprintf(1,'   INT <low> <high>     use area under curve (integral).\n');                  
elseif strncmp(pcmd,'taint',3)
   fprintf(1,'   TAInt <parameter>    Set the level of processing needed before drawing a plot.\n');
   fprintf(1,'   Levels are normally determined by the program.  No parameter asks the program for\n');
   fprintf(1,'   the current value.  Values are: \n');
   fprintf(1,'   10= no file open     20= need to scan     30= need to accumulate\n');
   fprintf(1,'   40= need to map      50= ready to plot \n');
elseif strncmp(pcmd,'segment',3)
   fprintf(1,'   SEGment <parameter>  Enable or set value of time segments. Used for statistics.\n');
   fprintf(1,'parameters \n');
   fprintf(1,'   SHOw            enable display on plots.\n');
   fprintf(1,'   NOShow          disable display on plots.\n');
   fprintf(1,'   a1 <value>      set start of segment a \n');
   fprintf(1,'   a2 <value>      set end of segment a \n');
   fprintf(1,'   b1 <value>      set start of segment b \n');
   fprintf(1,'   b2 <value>      set end of segment b \n');
   fprintf(1,'   seg a <range>   set segment a to time range. range example: 350 400 \n');
   fprintf(1,'   seg b <range>   set segment b to time range.\n');
   fprintf(1,'Range values are either in PCOFF unit (1 to 600) or absolute time (ms).\n');   
   fprintf(1,'Use: AXIS UNITS PCOFF or AXIS UNITS ABSOLUTE to select units.\n');   
   fprintf(1,'The mouse can be used to set segment values a1, a2, b1, or b2.  \n');
   fprintf(1,'For example:   segment a1 mouse   and use the mouse to select a1.  \n');
elseif strncmp(pcmd,'setenv',6)   % process setenv
   fprintf(1,'   SETENV <variable> <value>   set an environmental variable. Example:\n');
   fprintf(1,'   setenv  DATAPATH  c:\data  \n');
   fprintf(1,'   Variables: \n');
   fprintf(1,'ANALOGSTART     event code that marks the start of analog data \n');
   fprintf(1,'ANALOGSTOP      event code that marks the end of analog data \n');
   fprintf(1,'DATAPATH        path for datafiles \n');
   fprintf(1,'DEFAULTPATH     path if no other path is specified \n');
   fprintf(1,'DUMPTEXT        text added to each line of output in the DUMP SPIKES file. \n');
   fprintf(1,'DUMPLABEL       text string added to the header of each Set <process> show/keep \n');
   fprintf(1,'DUMPMODE        set to (NO)APPEND to (not) append lines with the DUMP SPIKES command. \n');
   fprintf(1,'DUMPPATH        path for set <process> keep or for dump command \n');
   fprintf(1,'EDITOR          full path and file name for your text editor \n');
   fprintf(1,'EOGSAMPLERATE   default A/D sample rate \n');
   fprintf(1,'EVENTCODEFILE   file to assign a name to each event code \n');
   fprintf(1,'FORMATPATH      path for .fmt files \n');
   fprintf(1,'GRAPHICSFORMAT  file format save by the Plot command: tiff, tiffn, hpgl, jpeg, eps, ai, or png \n');
   fprintf(1,'HISTORYPATH     path of user history scripts \n');
   fprintf(1,'LAYOUTPATH      path for loading the layout file \n');
   fprintf(1,'MAKDAT          default parameters for MAKDAT command \n');
   fprintf(1,'MAKDUMP         if defined, all Makdat messages will go to this file \n');
   fprintf(1,'MAXINPUTTRIALS  debugging tool. Limits number of trials processed by Makdat. \n');   
   fprintf(1,'MAXTRIALSFOUND  Limits number of trials that a sequence search can find and plot. \n');
   fprintf(1,'METACHAR1       replacement character used after call to metafiles ("$") \n');
   fprintf(1,'METACHAR2       replacement character used after PCOFF command ("%") \n');
   fprintf(1,'METAPATH        default path to find metafiles \n');
   fprintf(1,'PLOTPATH        path to place plots \n');
   fprintf(1,'PROTOCOLPATH    default path to store and find protocol files \n');
   fprintf(1,'REMAPFILE       if defined, file for spike channel mapping \n');
   fprintf(1,'STATPATH        path to store statistical results \n');
elseif strncmp(pcmd,'set',3)
   fprintf(1,'   SET     This command controls a number of processes. \n');
   fprintf(1,' Each process can produce listings on the screen or send results to\n');
   fprintf(1,' a disk file.  \n');   
   fprintf(1,'  Processes: \n');
   fprintf(1,'       epochstats, events, histogram, mwu, plot, segmentstats, sort  \n');   
   fprintf(1,'  Options available for each process: \n');
   fprintf(1,'       show / noshow, keep / nokeep, append / noappend,  \n');   
   fprintf(1,'       name , number\n\n');
   fprintf(1,'  Examples:  \n');
   fprintf(1,'       set epochstats keep     save epoch stats after each Show command\n');
   fprintf(1,'       set epochstats name monk_r242   save next file as "monk_r242.epk"\n');
   fprintf(1,'  Some special set commands:\n');
   fprintf(1,'       set sort   reverse / noreverse  to control the order of trials display.\n');
   fprintf(1,'       set plot   show / noshow        to control display of the plot.\n');
   fprintf(1,'       set print  color / nocolor      to control printing of the plot.\n');
elseif strncmp(pcmd,'type',3)
   fprintf(1,'   TYPe <filename>    Print the contents of a file.\n');
elseif strncmp(pcmd,'thin',3)
   fprintf(1,'   THIn             Old PCOFF command. Recognized, but not used.\n');
elseif strncmp(pcmd,'resolution',3)
   fprintf(1,'   RESolution      Old PCOFF command. Recognized, but not used.\n');
elseif strncmp(pcmd,'validatespikes',4)
   fprintf(1,'   VALIDatespikes   Each trial has a start and stop time. Only spikes in that window (valid spikes)\n');
   fprintf(1,'                    are included in the histogram. Invalid spikes are colored differently in the raster.\n');
   fprintf(1,'parameters \n');
   fprintf(1,'      on            include only valid spikes (in the time window of each trail) on histogram.\n');
   fprintf(1,'      off           do not limit the spike counts.\n');
   fprintf(1,'      start  <class number>    use this class number to get the starting time in each trial.\n');
   fprintf(1,'      end    <class number>    use this class number to get the ending time in each trial.\n');
   fprintf(1,'      color  <color name>      color of spikes that are NOT valid: black,blue,green,red,cyan or k,b,g,r,c.\n');
   fprintf(1,'INVALID SPIKE COLOR <color name>  alternative for VALIDATE SPIKE COLOR.\n');
elseif strncmp(pcmd,'version',3)
   fprintf(1,'   VERsion         display version number of Matoff\n');   
elseif strncmp(pcmd,'walk',4)
   fprintf(1,'   WALK <parameter>   control the rate at which READ command lists lines\n');
   fprintf(1,'of text. Parameter is a positive integer.\n');
elseif strncmp(pcmd,'write',3)
   fprintf(1,'   WRIte <parameter>   send parameter as text to the ASCII file.\n');
   fprintf(1,' See the Open, Append, and Close commands.\n');   
   
else
   fprintf(1,'No help for %s\n',pcmd);
end;
