function [selected_pulse_data]=read_pulse_record(pulse_fid,trial_list)
%
%  Collect pulse channels and their times from 
%  a range of file_trials in the data file
% 
%  Inputs
%     pulse_fid                 handle of pulse file
%     trial_list          list of file_trials to fetch from disk
%  Outputs
%    selected_pulse_data  columns: channels(trial1) times(trial1) channels(trial2) times(trial2) ...
%  Globals modified
%    cache_trials.pulse   vector with 2 entries: [lowest highest] file_trial numbers in cache
%    pulse_data_cache     row 1: pulse chan, row 2: pulse times
%

global cache_trials work_index work_udf
global pulse_data_cache
global error_fid warning_fid debug_fid
global errors warnings debugs

selected_pulse_data=[];

if isempty(trial_list)
   if debugs
      fprintf(debug_fid,'Debug [read_pulse_record]. Empty trial list requested.\n');
   end;
   return;
end;

if debugs
   fprintf(debug_fid,'Debug [read_pulse_record]. %d trials of pulse data requested.\n',length(trial_list));
end;

low_trial=min(trial_list);
high_trial=max(trial_list);

if high_trial > length(work_index)
   fprintf(error_fid, 'Error [read_pulse_record]. Requested trial exceeds index size.\n');
   return;
end;

% are the requested file_trials in the cache?

if (low_trial >= cache_trials.pulse(1)) & (high_trial <= cache_trials.pulse(2))
   if debugs
      fprintf(debug_fid,'Debug [read_pulse_record]. Requested pulse data trials were found in cache.\n');
   end;
   [selected_pulse_data]=collate_trials(pulse_data_cache,cache_trials.pulse,trial_list);
   return;
end;

if debugs
   fprintf(debug_fid,'Debug [read_pulse_record]. Requested pulse data trials not in cache, reading from file.\n');
end;
% File_trials are not in cache, go get them from data file
starting_file_position=work_index(low_trial).pulse_start_position;
number_of_records=0;
for t=low_trial:high_trial
   number_of_records=number_of_records+work_index(t).pulse_records;  % size of data block to pull from file
end;

try
   fseek(pulse_fid,starting_file_position,'bof');
catch
   if errors
      fprintf(error_fid,'Error [read_pulse_record]. Tried to read past end of the pulse file.\n');
   end;
   return;
end;

try
   pulse_data_cache=fread(pulse_fid,[2 number_of_records],'int32');   % read from file
   cache_trials.pulse=[low_trial high_trial];
catch
   if errors
      fprintf(error_fid,'Error [read_pulse_record].  Error reading pulse data.\n');
      fprintf(error_fid,'Starting offset: %-5d , number of records: %-5d \n', ...
             starting_file_position,number_of_records);
   end;
   cache_trials.pulse=[0 0];   % values no longer valid    
   return;
end;

% pluck out data for requested file_trials
[selected_pulse_data]=collate_trials(pulse_data_cache,cache_trials.pulse,trial_list);

return;
 
