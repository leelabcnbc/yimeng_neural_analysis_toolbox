function response=load_layouts(filename)
%
%   Load layout files from disk
% Inputs
%   filename     disk file name of saved layouts
% Outputs
%   response     1= success
%                0= error
%
global layouts
global errors warnings debugs
global error_fid warning_fid debug_fid
%
response=1;
eval(['load ' filename ' layouts -MAT;'],'response=0;');
if warnings & response==0
  fprintf(warning_fid,'Warning [load_layouts]. Cannot read layout file.\n');
end; 
if length(layouts) < 10
   response=0;
   if warnings & response==0
      fprintf(warning_fid,'Warning [load_layouts]. Layout file size wrong.\n');
   end; 
end;

