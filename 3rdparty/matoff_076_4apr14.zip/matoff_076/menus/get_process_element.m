function [response]= get_process_element(process,element_number)
%
% extract a parameter (element) stored by the set <process> command
%
% Inputs
%   process         process string
%   element_number  which element to extract
% Outputs
%   response        null string or requested element

global error_fid warning_fid debug_fid
global errors warnings debugs

response='';
if isempty(process)
   if debugs
      fprintf(debug_fid,'Debug [get_process_element]. Empty process string.\n');
   end;   
   return;
end;
colon_number=element_number-1;
colons=findstr(process,':');
if (colon_number < 1) | (colon_number > length(colons))
   if debugs
      fprintf(debug_fid,'Debug [get_process_element]. Element number %d not in string %s.\n',element_number,process);
   end;   
   return;
end;
   
if colons(colon_number)== length(process)
   response='';
else
   response=process(colons(colon_number)+1:end);
end;

