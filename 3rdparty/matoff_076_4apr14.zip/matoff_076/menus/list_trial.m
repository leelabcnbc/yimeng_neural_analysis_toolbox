function [list]=list_trial(trial)
%  Return a 2 row array of classes and class values for a trial.
%  Uses unit's trial number (behavioral trial number)
%  This is a special user function. However, it is also used by make_plot.m
% 
%  Inputs
%    trial       trial to look up
%  Outputs
%    list        row 1   classes
%                row 2   matching class values    
%   
%    history.class            class 
%           .trial_list       = [] string array of trial numbers that belong in this class, sorted 
%           .values           = [] array of matching class values for each trial
%
global history
global error_fid warning_fid debug_fid
global errors warnings debugs



% search the history.
list=[];
for c=1:length(history)
   tpos=find(expand_range_list(history(c).trial_list)==trial);   % is the trial is assigned to this class?
   if ~isempty(tpos)
      list=[ list [history(c).class ; history(c).values(tpos)]]; % Yes, add the class and class value to the list
   end
end

if debugs
   fprintf(debug_fid,'Debug [list_trial]. %d classes with values found for trial %d\n',length(list),trial);
end