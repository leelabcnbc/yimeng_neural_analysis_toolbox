function [index]=find_any(array1,array2)
%
%  Return the list of indicies for array1 of elements in array1
%  that occur anywhere in array2.  
% Inputs
%    array1   array that might have elements of interest
%    array2   array of interesting items
% Outputs
%    index    list of index values pointing to interesting array1 elements
%
index=[];
if isempty(array1) | isempty(array2)
   return;
end;
for i=1:length(array1)
   if find(array2==array1(i));
      index=[index i];
   end;
end;