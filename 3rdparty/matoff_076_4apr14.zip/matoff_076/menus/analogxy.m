function analogxy(xvalue,yvalue,x_pos,y_pos,sep,size,style,aspect)
%
%  Draw xy analog traces on the current plot
%
% Inputs
%  xvalue(trial,:) yvalue(trial,:)    one trace
%  x_pos            0 = top, 1 = bottom.
%  y_pos            0 = left, 1 = right
%  sep              0 = all raster on one line, 1 = one entire page per raster.
%  size             0 = flat line, 1 = full signal is full height of the page.
%  style            Line type (usually '-k')
%
global error_fid warning_fid debug_fid
global errors warnings debugs

if isempty(xvalue) | isempty(yvalue)
   if warnings
      fprintf(warning_fid,'Warning [analogxy]. No X-Y data to plot.\n');
   end;
   return;
end;
    
trial_list=1:length(xvalue(:,1));
if trial_list(end) ~= length(yvalue(:,1))
   if errors
      fprintf(error_fid,'Error [analogxy]. X array and Y array sizes differ. Cannot plot X-Y.\n');
   end;
   return;
end;

x = [];
y = [];
y0 = 1 - y_pos;
for i_trial = trial_list
   x  = ((xvalue(i_trial,:) * aspect) * size) + x_pos  ;
   y  = (yvalue(i_trial,:) * size)  + y0;
   y0 = y0 - sep;  % set up position of next plot
   plot(x,y,style);
end;






