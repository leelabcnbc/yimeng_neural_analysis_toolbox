function save_menu_positions(file_name)
%
% Find and save the current locations of the standard MatOFF menus
% 
%
menu_names=[];
menu_names(1).n='file_menu';
menu_names(2).n='display_space';
menu_names(3).n='sequence_menu';
menu_names(4).n='layout_menu';
menu_names(5).n='layout_menu2';
menu_names(6).n='layout_menu3';
menu_names(7).n='layout_menu_text';
menu_positions=[];
for n=1:7
   menu_positions= [ menu_positions ; get(findobj('Tag',menu_names(n).n),'Position')];
end;

eval(['save ' file_name ' menu_positions -MAT;'],' disp(''[save_menu_positions]: Error saving menu positions.''); ');
