function save_layouts(file_name)
% Store all layouts to file
%
global layouts 

eval(['save ' file_name ' layouts -MAT;'],' disp(''Error saving layouts.''); ');