%                 MatOff  Initialization

% VERSION NUMBER STORED IN:   matoff_version.m

%==================================================
%                remaining globals
%==================================================


global windows_version
windows_report=evalc('!ver');
if any(findstr(windows_report,' 95 ')) || any(findstr(windows_report,' 98 ')) ...
      || any(findstr(windows_report,' Millennium '))
   windows_version=1;
elseif any(findstr(windows_report,' NT ')) || any(findstr(windows_report,' 2000 '))
   windows_version=2;
elseif any(findstr(windows_report,' XP ')) || any(findstr(windows_report,'Version 5.2.379'))
   windows_version=3;
elseif any(findstr(windows_report,'Version 6.0.60')) || any(findstr(windows_report,'Version 6.1.760'))
   windows_version=4;
elseif any(findstr(windows_report,'Version 6.2.920'))   % Windows 8
   windows_version=4;
else
   windows_version=3;    % just guess!
end
   
% Optional: you can manually set the windows version by uncommenting this line
% windows_version=3;

% Windows Version:
%     1    Windows 95, 98, or ME
%     2    Windows NT or 2000
%     3    Windows XP or XP 64
%     4    Windows Vista, Server 2008, Windows 7


% message devices
global error_fid warning_fid debug_fid trace_fid
global errors warnings debugs quietly
error_fid=1;
warning_fid=1;
debug_fid=1;
errors=1;
warnings=1;
debugs=0;
quietly=0;

global last_command

% Process control
global taint
% 10  file
% 20  scan
% 30  accumulate
% 40  map
% 50  plot
taint=10;   % start out needing to get a valid file open

% Extracted data
global spikemap event_codes event_times spike_counts
spikemap=[];
event_codes=[];
event_times=[];
spike_counts=[];


% Mapped data
global spiketrials time_zero
spiketrials=[];
time_zero=0;

% plots
global plot_number layout
global x_at_zero auto_update 


global center_is_class
% A CENTER value equal to or greater than the number of groups in the 
% sequence AND greater than this number is a interpreted as a class
center_is_class = 99; 


% set command needs persistant variables
% each variable has a colon-delimited string that holds
% the values:  show/noshow,keep/nokeep,append,<filename>
global set_process
set_process.histogram='noshow:nokeep:noappend:'; % note empty file name
set_process.mwu='noshow:nokeep:noappend:'; 
set_process.plot='noshow:nokeep:noappend:';   
set_process.epochstats='noshow:nokeep:noappend:'; 
set_process.segmentstats='noshow:nokeep:noappend:';
set_process.sortvalues='noshow:nokeep:noappend:'; 
set_process.events='noshow:nokeep:noappend:';

% persistant values for file handles and file name numbering
% fid.x is the file handle for process x
% fn.x  is the number of the next file name. if fn.x=32 then the next file name is 32.x
global fid fn

fid.asciifile=-1;        fn.asciifile=0;  % fn.asciifile is not used
fid.epochstats=-1;       fn.epochstats=0;
fid.histogram=-1;        fn.histogram=0;
fid.mwu=-1;              fn.mwu=0;
fid.plot=-1;             fn.plot=0;
fid.segmentstats=-1;     fn.segmentstats=0;
fid.sortvalues=-1;       fn.sortvalues=0;
fid.events=-1;           fn.events=0;
fid.log=-1;              fn.event=0;

% sort values (see sort_trials())
global sort_values
sort_values=[];

% global variables for LOAD, BATCH, CALL
global load_state batch_state call_state
global load_fid batch_fid  call_fid meta_fid
load_state=0;  % no load file open
batch_state=0; % no batch file open
call_state=0;  % no call file open
load_fid=-1;  batch_fid=-1;  call_fid=-1;  meta_fid=-1;

global fileerror break_state
fileerror='break';  
break_state=0;

global environment pcoff_argument

global walk walk_speed walk_count
walk=0;   % don't walk
walk_speed=10;
walk_count=0;

global cortex_header_size % set in makdat

global bell_sound bell_sample_rate start_time
% initialize bell to a 1 second 1Khz tone
bell_sample_rate=10*(1000*2*pi);  
bell_sound=sin((0:.1:(1000*2*pi))*1);
start_time=clock;  % save startup time

global MAX_UNIT_NAME
MAX_UNIT_NAME=12;    % maximum number of characters in the unit name.


global selected_event_data selected_fid selected_file_trials
selected_event_data=[];   % used to cache event data during history scripts
selected_fid=0;
selected_file_trials=[];


%==================================================


%==================================================
%           initializations
%==================================================

last_command='';
carrage_return=sprintf('\n');
plot_number=10;
auto_update=0;
taint=10;

% default environmental variables
environment.datapath='.';
environment.defaultpath='.';
environment.dumppath='.';
if (windows_version==1) || (windows_version==3) ||  (windows_version==4)
   environment.editor='c:\windows\notepad.exe';
else
   environment.editor='c:\winnt\notepad.exe';
end 
environment.eogsamplerate='250';
environment.eventcodefile='default.evc';
environment.formatpath='.';
environment.graphicsformat='jpeg';
environment.layoutpath='.';
environment.makdat='';
environment.makdump='';
environment.metachar1='$';
environment.metachar2='%';
environment.metapath='.';
environment.plotpath='.';
environment.protocolpath='.';
environment.remapfile='default.rmp';
environment.statpath='.';
environment.maxinputtrials='';
environment.dumplabel='';
environment.maxtrialsfound=250;
environment.dumptext='';
environment.dumpmode='NOAPPEND';
environment.historypath='.';
environment.analogstart='100';
environment.analogstop='101';
environment.unitfound=0; 
environment.spiketimeoffset=0; 
environment.logging=0;   % logging off
environment.analogmin=0;
environment.analogmax=2048;

global history_crash_allowed
history_crash_allowed=0;     % do not let user history scripts cause a MATLAB error

global matoff_var

% initialize matoff variables
matoff_var.i=zeros(1,20);
matoff_var.s1='';
matoff_var.s2='';
matoff_var.s3='';
matoff_var.s4='';
matoff_var.s5='';
matoff_var.s6='';
matoff_var.s7='';
matoff_var.s8='';
matoff_var.s9='';
matoff_var.s10='';


% initial pcoff_argument values
pcoff_argument.P0=''; pcoff_argument.P1=''; pcoff_argument.P2='';
pcoff_argument.P3=''; pcoff_argument.P4=''; pcoff_argument.P5='';
pcoff_argument.P6=''; pcoff_argument.P7=''; pcoff_argument.P8='';
pcoff_argument.P9='';
pcoff_argument.P0='';       

if (windows_version == 1) || (windows_version == 3) || (windows_version == 4)
   tempfile='c:\windows\temp\workoff.tmp'; % create env file in Windows 95 or 98
else
   tempfile='c:\winnt\temp\workoff.tmp'; % create env file in Windows NT, 2K, XP
end


env_fid=fopen(tempfile,'wt');  % can this file be opened?
if env_fid > 0 
   fclose(env_fid);   % yes. Close file
else 
   disp('Error [matoff]. Could not create temp file. Change windows_version in Matoff.m');
end


eval(['!set > ' tempfile ';'],'disp(''Error [matoff]. Could not create temp file. Change windows_version in Matoff.m'')');

try
   env_fid=fopen(tempfile,'rt');   % open env file
   if env_fid > 0  
      while ~feof(env_fid)
         rcmd=fgetl(env_fid);  % fetch commands from dump of environment
         nsetenv(rcmd);  % update matoff environment, ignore warnings
      end % while
      fclose(env_fid);
      env_fid=-1;
      eval(['!del ' tempfile],'disp(''Error [matoff]. Could not delete temp file.'')');
   end
catch
   disp('Error [matoff]. Could not create temp file. Change windows_version in Matoff.m');
end


%============ layout initialization ============
x_at_zero=0;
set(findobj('Tag','xatzero'),'Value',x_at_zero);
auto_update=0;
set(findobj('Tag','autoupdate'),'Value',x_at_zero);


%==================================================
%            standard windows
%==================================================
file_menu;
display_space;  % plot & print
sequence_menu;
m1=layout_menu;
m2=layout_menu2;
m3=layout_menu3;
tm=layout_menu_text;

pause(0.5);  % waitfor does not work, so use a simple pause.
set(m2,'Visible','off');
set(m3,'Visible','off');
set(tm,'Visible','off');


%==================================================
% layouts are stored on these structures
% layout(1) is the default (startup).
global layouts
global h_layout          % static handles to the layout menus
global current_layout    % needed to sync menus with structures
global current_text_line % active text line number (1 to 9)

layout_handles;          % set up handles to all layout elements

initialize; 
current_layout=1;
set(findobj('Tag','layout_number'),'String','1');
current_text_line=1;


%==================================================

%
% Initialize MatLab based workoff functions
%
global work_filename work_fid work_udf 
global work_analog_start work_analog_stop
global work_unit_list
global work_trial work_classes

work_unit_list=[];
work_filename='';
work_fid.index=-3;
work_fid.event=-3;
work_fid.pulse=-3;
work_fid.analog=-3;
work_events_array1=[];
work_events_array2=[];
work_analog_start=[];
work_analog_stop=[];
work_trial(1).sourcetrial=0;
work_trial(1).events=[];
work_trial(1).classes=[];
work_trial(1).values=[];
work_classes=[];

%
% event, pulse, and analog files are
% cached in the sense that recently read
% trials will not be re-read from the file
%
global cache_trials 
global event_data_cache pulse_data_cache analog_data_cache
global analog_cache_pointers
cache_trials.event=[0 0];   % trial number that have been cached
cache_trials.pulse=[0 0];
cache_trials.analog=[0 0];
event_data_cache =[];    % actual cache
pulse_data_cache=[];
analog_data_cache=[];
analog_cache_pointers=[];

global history
history=[];

%==================================================
%             program startup
%==================================================

% rational initial GUI values

set(findobj('Tag','trials'),'String','1-250');
set(findobj('Tag','span'),'String','all');
set(findobj('Tag','trialsfound'),'String','0');
set(findobj('Tag','filename'),'String',' ');
set(findobj('Tag','unit'),'String','  ');
set(findobj('Tag','protocol_file'),'String', '');
set(findobj('Tag','pulsesfound'),'String',' ');

% history off
set(findobj('Tag','historyfile'),'BackgroundColor',[.753 .753 .753]);  % dim file name display
set(findobj('Tag','historyfile'),'UserData',0);                        % Disable history

start_fid=fopen('startup.pro');  % can this file be opened?
if start_fid > 0 
   fclose(start_fid);   % yes. Close file and use it for startup.
   start_fid=-1;
   issue_command('load startup.pro');
end

parse_command('setenv DISPLAYUNITS=absolute');
set(findobj('Tag','spikechannelmenu'),'UserData',1);
fprintf(1,'MatOFF version %s\n',matoff_version);

cmd;   % start up the MatOFF command processor

%===========
%   end
%===========
