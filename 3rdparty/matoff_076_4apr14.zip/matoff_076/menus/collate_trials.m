function [selected_data]=collate_trials(file_data,trial_range,trial_list)
%
%   Sort data read from a file block into individual file trials.  Works
%   for pulse, event, or analog data.  All use a header marker = -1.
%   However, for efficiency this subroutine is no longer used for analog data.
%    
%
% Inputs
%   file_data               row 1: codes (or channels), row 2: matching times (or analog data) 
%                           for all trials in trial_range
%   trial_range             [lowest highest] file trial numbers in cache
%   trial_list              list of file trials to place in selected_data 
% Outputs
%   selected_data           two columns for each file trial: [code  time ... ] or [channel data ...]
%
%
global error_fid warning_fid debug_fid
global errors warnings debugs

special_debug=0;  % 1=on

TRIAL_HEADER_MARKER=-1;
selected_data=[];
if isempty(file_data)
   return;
end;

% point to the header markers
trial_marker_list=find(file_data(1,:)== TRIAL_HEADER_MARKER);

if special_debug
   fprintf(debug_fid,'Special Debug [collate_trials]. \n');
end;

for t=trial_list   % this list is in units of file trial numbers, just like trial_marker_list
   trial_start_index=trial_marker_list(find(file_data(2,trial_marker_list)==t)); 
   if length(trial_start_index) ~= 1   % did we locate exactly one trial?
      if errors
         fprintf(error_fid,'Error [collate_trials]. Could not find trial marker.\n');
      end;
   selected_data=[];  % run for cover
   return; 
   end;   
   % find the index of the next trial in this dataset, then translate 
   % the start and stop indicies to column numbers of file_data
   if t < trial_range(2)  % is there another trial in this dataset?
      % yes, locate index just before next trial
      trial_end_index=trial_marker_list((t-trial_range(1)) + 2) -1 ;  
   else
      trial_end_index=length(file_data(2,:));  % no, last index of file
   end;
   
   % add the data for this trial as two new columns in selected_data
   [nans,c]=nans_padding(size(selected_data),trial_end_index-trial_start_index+1);
   switch c
   case -1  % empty file_data array
      selected_data=[ selected_data nans nans];  % use nans as place holders
   case 0   % selected_data is empty
      selected_data=[ file_data(1,trial_start_index:trial_end_index)' ... 
            file_data(2,trial_start_index:trial_end_index)' ];
   case 1   % new data has the same number of rows as selected_data
      selected_data=[selected_data  file_data(1,trial_start_index:trial_end_index)' ...
            file_data(2,trial_start_index:trial_end_index)' ];
   case 2   % new data has longer columns than selected_data
      selected_data=[[selected_data ; nans] file_data(1,trial_start_index:trial_end_index)' ...
             file_data(2,trial_start_index:trial_end_index)' ];
   case 3   % new data must be padded with nans before adding it to selected_data
       selected_data=[selected_data [file_data(1,trial_start_index:trial_end_index)' ; nans] ...
             [file_data(2,trial_start_index:trial_end_index)' ; nans] ];
   end; % switch
   if special_debug
       fprintf(debug_fid,'Size of selected_data: %d  %d  \n',size(selected_data,1),size(selected_data,2));
   end;
end; % t=trial_list

