function analog(trial_list,xvalue,yvalue,shift_from_top,spacing,gain,style)
%
%  analog  Draw analog traces on the current plot
%
%  xvalue(trial,:) yvalue(trial,:)    one trace
%  
%  Inputs
%     trial_list         list of trials to plot, must be row vector
%     shift_from_top     0 = top, 1 = bottom.
%     spacing            0 = all raster on one line, 1 = one entire page per raster.
%     gain               0 = flat line, 1 = full signal is full height of the page.
%     style              Line type (usually '-k')
global error_fid warning_fid debug_fid
global errors warnings debugs

X = [];
Y = [];

if isempty(trial_list) | isempty(xvalue) | isempty(yvalue)
   return;
end;
max_x_trial=size(xvalue,1);
trial_list=trial_list(find(trial_list <= max_x_trial));  % make sure trial list does not exceed array size

[b a]=size(trial_list);
if b > a 
   if errors
      fprintf(error_fid,'Internal Error [analog]. trial_list is column vector. Fixing.\n');
   end;
   trial_list=trial_list';
end;


y0 = 1 - shift_from_top;
for i_trial = trial_list
   x  = xvalue(i_trial,:) ;
   y  = (yvalue(i_trial,:) * gain) + y0;
   y0 = y0 - spacing;  % set up position of next plot
   plot(x,y,style);
end;






