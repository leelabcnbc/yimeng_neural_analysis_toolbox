function[response]= parse_command(command)
% command interpreter
%
%  Inputs
%     command   PCOFF command to interpret
%  Outputs
%     response         Character string to display, or special response, e.g. 'FILEERROR', 'EXITMATOFF'
%  Globals modified
%     taint            used for determining next processing step
%     last_command     only used by parse_command
%     x_at_zero, auto_update   set and cleared here
%     load_state, break_state  modified during error recovery
%     current_layout           set here
%     walk, walk_speed, walk_count  controlled here
%     spike_counts
%     history [file off on rewrite clear]
%

global plot_number last_command taint
global x_at_zero auto_update layouts center_is_class
global spike_counts work_index work_udef
global load_state batch_state call_state fileerror
global break_state
global current_layout environment walk walk_speed walk_count
global set_process
global RESCALE_TIME
global bell_sound bell_sample_rate start_time
global fid fn
global current_text_line 
global error_fid warning_fid debug_fid
global errors warnings debugs quietly
global history 

MAX_CENTER=500;  % highest center or mark group number allowed (god forbid!)


% new commands (not found in original PCOFF):
%    read [events codes pulses analog which all out=<filename>]
%    resort
%    save [setspecs layout only]
%    axis [xatzero [on off ] units [pcoff absolute] show noshow]
%    autoupdate   manualupdate
%    Av2Analog [ show noshow ypos size line]
%    taint 
%    Fir2Dx [show noshow ypos size separation line]
%    batch <dos_batchfile_name>
%    type <file>
%    show (almost everything) new:  spikecounts, taint
%    walk   [speed]   pause after executing each command
%    makdat <listfile> <outputfile> -<options>
%    ls = dir
%    setenv <set a PCOFF environment variable>
%    new   create a new plot
%    close
%    matlab
%    cmd
%    unit = *
%    histogram scale show
%    span all
%    xy time [all events time]
%    bell <frequency> <duration>
%    empty commands act like show: file, globalignore
%    see new environment variables
%    make list of show options
%    set plot show/noshow    hides the plot
%    version
%    set sort reverse/noreverse
%    layout save <filename>
%    sort pulse show/noshow
%    segment a1 <value>  individual a1,a2,b1,b2 options
%    segment xx m        enable mouse setting of segment
%    globalignore auto [list]
%    ;  comment
%    edit
%    env_edit  command used by GUI to enable environment editor
%    mak_edit  command used by GUI to enable makdat GUI
%    print orientation
%    print papertype
%    hide plot and show plot synonyms for set plot show/noshow
%    date
%    found
%    text frame
%    histogram rawcounts,reference 
%    dump events
%    menuposition save <filename>
%    menuposition load <filename>
%    overplot
%    set/keep events
%    dump history
%    history [on/off file clear rewrite spot data delete]
%    sort history
%    errorlevel serious (quietly=1)
%    xy time [... classes]
%    xy overlap on/off
%    endif (ignored)
%    mgplx2ctx
%    cortexexplorer
%    why
%    validatespikes [on/off start stop color]
%    old plot next
%    nextplot <number>


% for auto update

[dummy,opn,valid]=check_string_value(get(findobj('Tag','oldplotnumber'),'String'),1,20000);
if ~valid
   fprintf(1,'Error: old plot number is invalid.  Fixing...\n');
   if environment.logging==1
      fprintf(fid.log,'Error: old plot number is invalid.  Fixing...\n');
   end;
   opn=20;
   set(findobj('Tag','oldplotnumber'),'String','20');
end;

response='';  % be sure some response is given

c=deblank(command);
[cmd,params]=strtok(c);  % separate command name from parameters
cmd=lower(deblank(strjust(cmd)));  % all commands to lower case
params=strtrim(params);  % squeeze out spaces from parameters
lparams=lower(params);    % lower case version of parameters 

if isempty(cmd)
   response='';
   return;
end

if strncmp(cmd,'dir',3) || strncmp(cmd,'ls',2)      % dir  (ls)
   fprintf('Directory\n');
   if isempty(params)
      dir_struct=dir;
   else
      dir_struct=dir(params);
   end
   dir_length=length(dir_struct);
   response='';
   for k=1:dir_length
     if dir_struct(k).isdir
        fprintf(1,'Directory %s\n',dir_struct(k).name);
        if environment.logging==1
           fprintf(fid.log,'Directory %s\n',dir_struct(k).name);
        end   
     end
   end
        
   for k=1:dir_length
      if ~dir_struct(k).isdir
         fprintf(1,'%s    ',dir_struct(k).name);
         dss=dir_struct(k).bytes;
         if dss < 1000
            fprintf(1,'%d bytes    ',dir_struct(k).bytes);
         elseif dss < 1000000
            fprintf(1,'%d Kbytes   ',round(dir_struct(k).bytes/1000));
         else
            fprintf(1,'%d Mbytes   ',round(dir_struct(k).bytes/1E6));
         end
         fprintf(1,'%s\n',dir_struct(k).date);
         if environment.logging==1
           fprintf(fid.log,'%s\n',dir_struct(k).name);
         end
      end   
   end
elseif strncmp(cmd,'accut',5)
   response='accut command is no longer used';
elseif strncmp(cmd,'accumulate',3)
   response='accumulate command is no longer used';
   taint=40;  % map is next 
elseif strncmp(cmd,'begin',5) || strncmp(cmd,'end',3) || strncmp(cmd,'endif',5)
   % do nothing
elseif strncmp(cmd,'bell',3)
   if isempty(params)
      sound(bell_sound,bell_sample_rate);
      response='RING';
   else   
      [bell_frequency,bell_duration]=strtok(params);
      [dummy,bell_frequency,valid]=check_string_value(bell_frequency,100,15000);
      if ~valid
         response= 'bell frequency must be between 100 and 15000 hz.';
      else
         [dummy,bell_duration,valid]=check_string_value(bell_duration,0.1,30);   
         if ~valid
            response= 'bell duration must be between 0.1 and 30 seconds.';
         else
            bell_resolution=.1;
            bell_ncycles=0:bell_resolution:(bell_frequency*2*pi);  
            bell_samples=1/bell_resolution*(bell_frequency*2*pi);
            bell_sample_rate=bell_samples/bell_duration;  
            bell_sound=sin(bell_ncycles*bell_duration);
            sound(bell_sound,bell_sample_rate);
            response='RING';
         end; % if ~valid
      end; %if ~valid
   end; % if isempty(params
         

elseif strncmp(cmd,'calculator',3)
   !calc;
   
elseif strncmp(cmd,'cmd',3)
   response='Already in command mode. Use MAT to exit command mode.';
   
% this can be either the centerline command or the center command
elseif strncmp(cmd,'center',3)
   taint_flag=1;
   if strncmp(lparams,'show',3)
      set(findobj('Tag','centerline_on_off'),'Value',1);  
   elseif strncmp(lparams,'noshow',3)
      set(findobj('Tag','centerline_on_off'),'Value',0);  
   elseif strncmp(lparams,'size',2)
      [dummy,asize]=strtok(params);
      [asize,dummy,valid]=check_string_value(asize,0,101);
      if ~valid
         response= 'size value out of range. Valid values are from 0 to 101.';
         taint_flag=0;
      else
         set(findobj('Tag','centerline_size'),'String',asize);      
      end;
   elseif strncmp(lparams,'ypos',2)
      [dummy,ypos]=strtok(params);
      [ypos,dummy,valid]=check_string_value(ypos,0,101);
      if ~valid
         response='y-position value out of range. Valid values are from 0 to 100.';
         taint_flag=0;
      else
         set(findobj('Tag','centerline_y_pos'),'String',ypos);
      end;
   elseif strncmp(lparams,'line',3)
      [dummy,linetype]=strtok(params);
      [dummy,linetype_value,valid]=check_string_value(linetype,1,7);
      if ~valid
         response='line out of range. Valid values are from 1 to 7.';
         taint_flag=0;
      else 
         set(findobj('Tag','centerline_style'),'Value',linetype_value);
      end;
   else
      [lparams,dummy,valid]=check_string_value(lparams,1,MAX_CENTER);
      if ~valid
         response=['Center value out of range. Valid values are from 1 to ' num2str(MAX_CENTER)];
         taint_flag=0;
      else
         set(findobj('Tag','center'),'String',lparams);
      end;
   end;
   if taint_flag   
      if taint > 20   % need to rescan
         taint=20;
      end;
      if auto_update
         if process ;  
            old_plot(opn,0);  % plot if trials were found
         end;   
      end;
   end;

elseif strncmp(cmd,'frequency',3)
   if strncmp(lparams,'auto',4);
      [dummy,allowed_freqs]=strtok(params);      % parse filename preserving case
      freq=estimate_analog_frequency(str2num(allowed_freqs));    % automatically calculate a/d rate
      if freq <= 0
         fprintf(1,'Cannot calculate A/D frequency. Checking environmental variable EOGSAMPLERATE.\n');
         if environment.logging==1
            fprintf(fid.log,'Cannot calculate A/D frequency. Checking environmental variable EOGSAMPLERATE.\n');
         end;
         freq=str2double(environment.eogsamplerate);
         if isempty(freq) || isnan(freq)
            freq=250;
         end;
      end;
      params=num2str(freq);
   end;

   [params,dummy,valid]=check_string_value(params,10,10000);  % a/d rates from 10hz to 10Khz
   if ~valid
      fprintf('A/D frequency out of range. Valid values are from 10 to 10000.\n');
      if environment.logging==1
         fprintf(fid.log,'A/D frequency out of range. Valid values are from 10 to 10000.\n');
      end;
      params='250';
   end;
   set(findobj('Tag','frequency'),'String',params);
   response=['frequency set to '  params];   

   if (taint > 20)   % need to rescan
      taint=20;
   end;
   if auto_update
      if process ;  
         old_plot(opn,0);  % plot if trials were found
      end;   
   end;
   
elseif strncmp(cmd,'globalignore',3)
   if isempty(params)   % an empty command requests the current globalignore string
      response=get(findobj('Tag','globalignore'),'String');    
   elseif length(find(params==']')) > 1
         response='Improper globalignore list. Do not break up list with brackets.';
   else
      if strncmp(lparams,'auto',3)      % list of global ignores is third parameter
         [dummy,gloparams]=strtok(params);  
      else
         gloparams=params;              % list of global ignores is second parameter
      end;
      glo=number_range_list(gloparams);
      if strcmp(glo,'@')
         response='Improper globalignore list. Example:  10,24-34,36,38,40-45  ';
      else
         if strncmp(lparams,'auto',3)     % auto option
            glo_list=expand_range_list(gloparams);
            %  find out what event codes are used in the sequence
            seq_string=get(findobj('Tag','sequence'),'String');
            % search each group of codes
            seq_string=strrep(seq_string,'[','');   % loose left brackets in existing string
            seq_codes=[];
            while ~isempty(seq_string)
               [group,seq_string]=strtok(seq_string,']');  % right bracket defines a group
               if isempty(group)
                  break;
               end;
               seq_codes=[seq_codes expand_range_list(group)];   
            end;
            if ~isempty(seq_codes)
               for sc=seq_codes
                  a=find(glo_list==sc);
                  if ~isempty(a)
                     glo_list=glo_list(yank_elements(a,length(glo_list))); % remove from glo
                  end;
               end;
            end; % if ~isempty(seq_codes
            glo=[];
            for glo_code=glo_list
               glo=[glo num2str(glo_code) ','];
            end;
            glo=number_range_list(glo(1:end-1));
         end; % if strncmp(lparames,'auto'
         
         set(findobj('Tag','globalignore'),'String',['[' glo ']']); 
         if (taint > 20)   % need to rescan
            taint=20;
         end;
         if auto_update
            if process      
               old_plot(opn,0);  % plot if trials found
            end;
         end; % auto_update
      end; % if strcmp(glo,'@')
   end;  % isempty(params
   
elseif strncmp(cmd,'help',3)
   help_request(lparams);

elseif strncmp(cmd,'index',3)
   filename=get(findobj('Tag','filename'),'String');
   number_of_units=length(work_udef);
   if isempty(deblank(filename)) || (taint < 20)
      response='No file open';
   elseif number_of_units == 0
      response='No units found';
   else  % display index
      fprintf(1,'%-12s  %6s    %12s   %12s  %16s\n\n','Unit','Trials','Spike count','Default unit', 'analog channels');
      if environment.logging==1
         fprintf(fid.log,'%-12s  %6s    %12s   %12s  %16s\n\n','Unit','Trials','Spike count','Default unit', 'analog channels');
      end;
      for unit_number=1:number_of_units
         % spike count is for all channels, not just default channel
         spike_count=0;
         for t=work_udef(unit_number).trials
            spike_count=spike_count + work_index(t).pulse_records - 1;   % -1 to skip header marker in each trial
         end;
         trial_count=length(work_udef(unit_number).trials);
         analog_channel_list=list_analog_channels;
         fprintf(1,'%-12s  %6d  %12d        %4d    ',work_udef(unit_number).name, trial_count, ...
               spike_count,work_udef(unit_number).channel);
         if environment.logging==1
            fprintf(fid.log,'%-12s  %6d  %12d        %4d    ',work_udef(unit_number).name, trial_count, ...
               spike_count,work_udef(unit_number).channel);
         end
         if (size(analog_channel_list,1) > 1) || (trace(analog_channel_list) > -1)
            fprintf(1,'       ');
            if environment.logging==1
               fprintf(fid.log,'       ');
            end;
            for chan=1:length(analog_channel_list)
               fprintf(1,'%s  ',analog_channel_list(chan));
               if environment.logging==1
                  fprintf(fid.log,'%s  ',analog_channel_list(chan));
               end;
            end;
         end;
         fprintf(1,'\n');
         if environment.logging==1
            fprintf(fid.log,'\n');
         end;   
      end;
   end; % empty filename
           

elseif strncmp(cmd,'initialize',3)
   initialize;
   
   
% ================ protocol LOAD or CONTINUE =======================   
elseif strncmp(cmd,'load',3)                     % LOAD
   % we are not allowed to LOAD when in a LOAD state, but "load_file" will catch it. 
   r=load_file(params);
   if r == -2 % file error 
      response='';
      % since the error was called during a command line entry,
      % there is no batch file to break or exit from.  
   elseif r==-3  % exit request.  Don't exit.
      response='Exit command in protocol file has been ignored.';
   elseif r==2  % BREAK
      response='<<BREAK>>  use CONTINUE to resume protocol file.';
   end;   
   
elseif strncmp(cmd,'continue',4)              % CONTINUE  
   % decide where to continue
   if batch_state
      batch('CONTINUE');  % let BATCH try to deal with this
      return;
   end;
   if ~break_state && load_state
      if errors
         fprintf(error_fid,'Error [parse_command]. Load file open, but no evidence of BREAK. Fixing...\n');
      end;
      % assume user is trying to recover from a hard error
      break_state=1;
      load_state=1;
   end;
   if ~break_state
      response='no protocol file open'; 
   else
      r=load_file(params);
      if r == -2 % file error 
         response='';
         % since the error was called during a command line entry,
         % there is no batch file to break or exit from.  
      elseif r==-3  % exit request.  Don't exit.
         response='Exit command in protocol file has been ignored.';
      elseif r==2  % BREAK
         response='<<BREAK>>  use CONTINUE to resume protocol file.';
      end;
   end;
      
   
elseif strncmp(cmd,'save',3) && ~load_state  % cannot SAVE during a LOAD
   if load_state
      response='cannot SAVE while a protocol file is open';
   else
      [file_name,options]=strtok(params);
      save_file(file_name,options);
   end;
   
elseif strncmp(cmd,'fileerror',7)  % this test must come before FILE command decoding 
   if strncmp(lparams,'exit',4)
      fileerror='exit';
   elseif strncmp(lparams,'break',5)
      fileerror='break';
   else
      response='Unrecognized FileError command. Valid options are: exit or break.';
   end;
   
elseif strncmp(cmd,'log',3)
   if strncmp(lparams,'file',2)
      [dummy,log_file_name]=strtok(params);      % parse filename preserving case
      log_file_name=strtrim(log_file_name);  % lop off spaces
      log_file_name=filepath(log_file_name,environment.defaultpath);  % prepend path
      fid.log=fopen(log_file_name,'at');
      response='Log file opened. Use LOG ON to begin logging';  
  elseif strncmp(lparams,'on',2)
      if environment.logging==1
         % do nothing, already logging
      elseif fid.log > 0
         environment.logging=1;  % enable logging
         error_fid=fid.log;
         warning_fid=fid.log;
         debug_fid=fid.log;
         response='Logging started.';
      elseif fid.log <= 0   
           response='You must first open a log file with LOG FILE command';
      end;
   elseif strncmp(lparams,'off',2)
      if environment.logging==0
          response='Logging was not on.';
      else
         environment.logging=0;
         error_fid=1;
         warning_fid=1;
         debug_fid=1;
         response='Logging stopped. Data will not be saved until you close log file with LOG CLOSE command.';
      end;
   elseif strncmp(lparams,'close',3)
      if fid.log > 0
         if environment.logging==1
            environment.logging=0;
            error_fid=1;
            warning_fid=1;
            debug_fid=1;
            fclose(fid.log);
            fid.log=-1;
            response='Logging stopped and log file closed.';
          else
            fclose(fid.log);
            fid.log=-1;
            response='Log file closed';
          end;
      else
          response='No log file open';
      end;
   else
       response='Log command not recognized. These are the log optons: file  on  off  close';
   end;
  
elseif strncmp(cmd,'map',3)
   response=[num2str(map) ' trials mapped'];
   if taint < 50
      taint=50;   % 50=plot
   end;
elseif strncmp(cmd,'mark',3)
   [dummy,dummy,valid]=check_string_value(params,1,MAX_CENTER);
   if ~valid
      response=['mark value out of range. Valid values are from 1 to ' num2str(MAX_CENTER)];
      taint_flag=0;
   else
      set(findobj('Tag','mark'),'String',lparams); 
      if (taint > 20)   % need to rescan
         taint=20;
      end;
      if auto_update
         if process      
            old_plot(opn,0);  % plot if trials found
         end;
      end;    
   end; % if valid


% ============== HIDE =======================

elseif strncmp(cmd,'hide',3)
   if strncmp(params,'plot',3)
      response=set_process_command('plot noshow');   % synonym for set plot noshow
   end;

% ============== SHOW =======================



elseif strncmp(cmd,'show',3)
   if isempty(lparams)
     if process
        old_plot(opn,0);
     end;
   elseif strncmp(params,'plot',3)
     response=set_process_command('plot show');   % synonym for set plot show
   elseif strncmp(params,'sequence',3)
     response=get(findobj('Tag','sequence'),'String');
   elseif strncmp(lparams,'globalignore',2)
     response=get(findobj('Tag','globalignore'),'String');
   elseif strncmp(lparams,'span',3)
     response=get(findobj('Tag','span'),'String');
   elseif strncmp(lparams,'filename',2)
     response=get(findobj('Tag','filename'),'String');
   elseif strncmp(lparams,'unitname',2)
     entry_number=get(findobj('Tag','unit'),'Value');
     unit_string=get(findobj('Tag','unit'),'String');
     response=strtrim(unit_string(entry_number,:));
   elseif strncmp(lparams,'pulsechannel',3)
     if get(findobj('Tag','spikechannelmenu'),'UserData')
        response=['pulse channel = ' get(findobj('Tag','spikechannelmenu'),'Value')];
     else
        response='pulses are off';
     end;
   elseif strncmp(lparams,'window',2)
     response=get(findobj('Tag','window'),'String');
   elseif strncmp(lparams,'center',2)
     response=get(findobj('Tag','center'),'String');
   elseif strncmp(lparams,'mark',2)
     response=get(findobj('Tag','mark'),'String');
   elseif strncmp(lparams,'segment',3)
      response=['sega ' get(findobj('Tag','segmenta'),'String') ...
                '  segb ' get(findobj('Tag','segmentb'),'String')];
   elseif strncmp(lparams,'frequency',3)
     response=get(findobj('Tag','frequency'),'String');
   elseif strncmp(lparams,'source',2)
     response=get(findobj('Tag','source'),'String');
   elseif strncmp(lparams,'binwidth',3)
     response=get(findobj('Tag','histogram_binwidth'),'String');
   elseif strncmp(lparams,'trials',2)
      response=get(findobj('Tag','trials'),'String');
   elseif strncmp(lparams,'taint',3)
      switch taint
         case 10
            taint_string='    no valid file open';
         case 20
            taint_string='    scan required';
         case 30
            taint_string='    accumulate required';
         case 40
            taint_string='    map required';
         case 50
            taint_string='    ready to plot';
      end;
      response=['taint=' num2str(taint) taint_string] ;
   elseif strncmp(lparams,'spot',3)
     response=get(findobj('Tag','spot'),'String');
   elseif strncmp(lparams,'directory',3)
      dir;
   elseif strncmp(lparams,'environment',3)
      environment    % no semicolon here
   elseif strncmp(lparams,'spikecounts',3)
      if taint < 20
         response='No file open';
      else
         spike_counts=count_pulses;
         fprintf(1,'List of spike channels and number of spikes in each channel.\n');
         for i=1:length(spike_counts)
            if spike_counts(i) > 0
               fprintf(1,'  spike chan: %d has %d spikes\n',i-1,spike_counts(i));
               if environment.logging==1
                  fprintf(fid.log,'spike chan: %d has %d spikes\n',i-1,spike_counts(i));
               end;   
            end;
         end;
      end;
   else  % assume parameter is a display list
      list=number_range_list(lparams);
      if strcmp(list,'@')
         response='unrecognized SHOW parameter';
      else
         set(findobj('Tag','displays'),'String',['[' list ']']);
      end;
  end % end show

% ============== end SHOW ===================


% ============== DUMP =======================

%  dump <option> print
%  dump <option> output <file>
elseif strncmp(cmd,'dump',3)
  if isempty(lparams)
     response='Missing parameters. Type "help dump" for more information.\n';
  end;  % isempty
  [option,rem]=strtok(lparams);  % get option in lower case
  [outtype,rem]=strtok(rem); % get output type in lower case
  if strncmp(outtype,'print',3)
     output_device=2;  % printer
  elseif strncmp(outtype,'output',3)   
     [dummy,rem]=strtok(params);      % parse filename preserving case
     [dummy,output_file]=strtok(rem);
     output_file=strtrim(output_file);  % lop off spaces
     if isempty(output_file)
        response='Output file name is missing.';
     else
        output_file=filepath(output_file,environment.dumppath);  % prepend path
        if ~isempty(output_file)
           output_device=3;  % disk
        else
           response='Output file path is invalid.';
           output_device=1;  % screen
        end; %~isempty
     end; % isempty
  else
     output_device=1;    % default to screen device
  end; %if outtype is 'print'
  

  if strncmp(option,'events',3)    % dump event codes for all found trials
     if output_device == 1   % screen
        o_fid=1;
     else
        if isempty(output_file)
           output_file='dump_output.tmp';
        end;
        o_fid=fopen(output_file,'wt');
     end;  % if output_device==1
       
     event_list=event_code_list;
     if isempty(event_list)
         response='No trials found';
     else
        cols=size(event_list,2);
        fprintf(o_fid,'  Trial     Sequence\n');
        for r=1:size(event_list,1)
           % print a row
           fprintf(o_fid,' %3d      ',event_list(r,1));
           for c=2:cols       
              fprintf(o_fid,'%d  ',event_list(r,c));
           end;  % for c=2
           fprintf(o_fid,'\n');
        end; % for r=1
     end; % if isempty(event_list)
     
     switch output_device
     case 1   % screen
       % done
     case 2   % printer
        fclose(o_fid);
        o_fid=-1;
        eval(['!notepad /p ' output_file]); % OUTDATED WAY TO WRITE A FILE
        delete(output_file);
     case 3   % file
        fclose(o_fid);
        o_fid=-1;
     end; %switch
  
  elseif strncmp(option,'setstats',3)  % status of each SET/KEEP process
     if output_device == 1
        o_fid=1;
     else
        if isempty(output_file)
           output_file='dump_output.tmp';
        end;
        o_fid=fopen(output_file,'wt');
     end; %if output_device==1
        
     fprintf(o_fid,'%14s  SHOW,KEEP,APPEND,FILE NAME\n','PROCESS');
     a=strrep(set_process.histogram,':',',');
     fprintf(o_fid,'%14s  %-50s\n','HISTOGRAM:',a);
     a=strrep(set_process.mwu,':',',');
     fprintf(o_fid,'%14s  %-50s\n','MWU:',a);
     a=strrep(set_process.plot,':',',');
     fprintf(o_fid,'%14s  %-50s\n','PLOT:',a);
     a=strrep(set_process.epochstats,':',',');
     fprintf(o_fid,'%14s  %-50s\n','EPOCHSTATS:',a);
     a=strrep(set_process.segmentstats,':',',');
     fprintf(o_fid,'%14s  %-50s\n','SEGMENTSTATS:',a);
     a=strrep(set_process.sortvalues,':',',');
     fprintf(o_fid,'%14s  %-50s\n','SORTVALUES:',a);
     a=strrep(set_process.events,':',',');
     fprintf(o_fid,'%14s  %-50s\n','EVENTS:',a);

     switch output_device
     case 1   % screen
          % done
     case 2   % printer
        fclose(o_fid);
        o_fid=-1;
        eval(['!notepad /p ' output_file]);
        delete(output_file);
     case 3   % file
        fclose(o_fid);
        o_fid=-1;
     end;
     
  elseif strncmp(option,'index',3)   % index of units in this file
     if output_device == 1
        o_fid=1;
     else
        if isempty(output_file)
           output_file='dump_output.tmp';
        end;
        o_fid=fopen(output_file,'wt');
     end; %if output_device==1
     filename=get(findobj('Tag','filename'),'String');
     number_of_units=length(work_udef);
     if isempty(deblank(filename)) || taint < 20
        response='No file open';
     elseif number_of_units == 0
        response='No units found';
     else  
        fprintf(o_fid,'%-12s  %6s  %12s   %12s\n\n','Unit','Trials','Spike count','Default unit');
        for unit_number=1:number_of_units
           % spike count is for all channels, not just default channel
           spike_count=0;
           for t=work_udef(unit_number).trials
              spike_count=spike_count + work_index(t).pulse_records -1;
           end;
           trial_count=length(work_udef(unit_number).trials);
           fprintf(o_fid,'%-12s  %6d  %12d   %3d\n',work_udef(unit_number).name, trial_count, ...
           spike_count,work_udef(unit_number).channel);
        end; % for unit_number
        switch output_device
        case 1   % screen
          % done
        case 2   % printer
           fclose(o_fid);
           o_fid=-1;
           eval(['!notepad /p ' output_file]);
           delete(output_file);
        case 3   % file
           fclose(o_fid);
           o_fid=-1;
        end;   
     end; % empty filename  
     
  elseif strncmp(option,'spikes',3) || strncmp(option,'history',3)  % spikes or history
     dump(params);  % dump function supports "spikes" and "history"
       
       
  end; % each dump type


% ============== end DUMP ===================


% FirstDx must come before FILE command
elseif strncmp(cmd,'firstdx',4)    % 4 chars to distinguish from Fir2Dx
   taint_flag=1;
   if strncmp(lparams,'show',3)
      set(findobj('Tag','dxdt_on_off'),'Value',1);
   elseif strncmp(lparams,'noshow',3)
      set(findobj('Tag','dxdt_on_off'),'Value',0);
   elseif strncmp(lparams,'ypos',1)
      [dummy,ypos]=strtok(params);
      ypos=strtrim(ypos);
      set(findobj('Tag','dxdt_y_pos'),'String',ypos);
   elseif strncmp(lparams,'size',2)
      [dummy,asize]=strtok(params);
      asize=strtrim(asize);
      set(findobj('Tag','dxdt_trace_size'),'String',asize);
   elseif strncmp(lparams,'separation',3)
      [dummy,sep]=strtok(params);
      sep=strtrim(sep);
      set(findobj('Tag','dxdt_separation'),'String',sep);
   elseif strncmp(lparams,'line',3)
      [dummy,linetype]=strtok(params);
      set(findobj('Tag','dxdt_style'),'Value',str2double(linetype));
   else
      response='Unrecognized or missing parameters. Valid parameters: show, noshow, ypos, size, separation, line';
      taint_flag=0;
   end;
   if auto_update && taint_flag
      if process      
         old_plot(opn,0);  % plot if trials found
      end;
   end;   

% Fir2Dx must come before FILE command
elseif strncmp(cmd,'fir2dx',4)    % 4 chars to distinguish from FirstDx 
   taint_flag=1;
   if strncmp(lparams,'show',3)
      set(findobj('Tag','dxdt2_on_off'),'Value',1);
   elseif strncmp(lparams,'noshow',3)
      set(findobj('Tag','dxdt2_on_off'),'Value',0);
   elseif strncmp(lparams,'ypos',1)
      [dummy,ypos]=strtok(params);
      ypos=strtrim(ypos);
      set(findobj('Tag','dxdt2_y_pos'),'String',ypos);
   elseif strncmp(lparams,'size',2)
      [dummy,asize]=strtok(params);
      asize=strtrim(asize);
      set(findobj('Tag','dxdt2_trace_size'),'String',asize);
   elseif strncmp(lparams,'separation',3)
      [dummy,sep]=strtok(params);
      sep=strtrim(sep);
      set(findobj('Tag','dxdt2_separation'),'String',sep);
   elseif strncmp(lparams,'line',3)
      [dummy,linetype]=strtok(params);
      set(findobj('Tag','dxdt2_style'),'Value',str2double(linetype));
   else
      response='Unrecognized or missing parameters. Valid parameters: show, noshow, ypos, size, separation, line';
      taint_flag=0;
   end;
   if auto_update && taint_flag
      if process      
         old_plot(opn,0);  % plot if trials found
      end;
   end;   


% file command must be parsed after firstdx and fir2dx so that a two-letter short cut will work
elseif strncmp(cmd,'file',2)
   if isempty(params)   % empty file name?
      response=['Current file name: ' get(findobj('Tag','filename'),'String')];
   else
      file_name=filepath(params,environment.datapath);
      test_fid=fopen([file_name '.index'],'rt');  % verify at least one of the files can be opened
      if test_fid < 0 
         response='FILEERROR';  % send this message to load_file via issue_command
         disp(['cannot open file ' file_name]);
         test_fid=-1;
         if load_state && ~break_state % are we in the middle of a batch file?
            return;
         end;
      else
         fclose(test_fid);  % close this file immediately
         test_fid=-1;
         set(findobj('Tag','filename'),'String',params); 
         response=work_file(0); % 0=open                  Open files, fetch index
         set(findobj('Tag','trialsfound'),'String','0');  % clear GUI
         taint=20;
         if auto_update
            if process      
               old_plot(opn,0);  % plot if trials found
            end;
         end;
      end; % if test_fid < 0
   end; % if empty file name

elseif strncmp(cmd,'unitname',3)
   unit_list=get(findobj('Tag','unit'),'String');
   if isempty(unit_list)
      response='Empty unit list';
   elseif isempty(params)
      unit_number=get(findobj('Tag','unit'),'Value');
      response=['Current unit: ' unit_list(unit_number,:)];
   else
      unit_number=[];
      for i=1:length(unit_list(:,1))
         unit_name=strtrim(unit_list(i,:));
         if strcmp(unit_name,params);
            unit_number=i;
            break;
         end;
      end;
      if isempty(unit_number)
         response='Cannot find requested unit.';
         environment.unitfound=0;
      else
         environment.unitfound=1;
         set(findobj('Tag','unit'),'Value',unit_number);
         trials_list=work_udef(unit_number).trials;
         number_of_spikes=0;
         if isempty(work_index)
            response='Empty data file. You may have to reload FILE by using the FILE command.';
         else
            first_trial=0;  % calculate these, but not used (yet)
            last_trial=0;
            trial=0;
            for t=trials_list 
               trial=trial+1;
               new_spikes=work_index(t).pulse_records - 1;
               number_of_spikes=number_of_spikes + new_spikes;
               if new_spikes > 0
                  if first_trial==0;
                     first_trial=trial;
                  end;
                  last_trial=trial;
               end;
            end;
            set(findobj('Tag','spikechannelmenu'),'Value',work_udef(unit_number).channel+1);
            set(findobj('Tag','pulsesfound'),'String',num2str(number_of_spikes));
            response=['Default pulse channel is ' num2str(work_udef(unit_number).channel)];
            % see if there is a history for this unit
            file_name=filepath(get(findobj('Tag','filename'),'String'),environment.datapath);
            hindex=read_history_index(file_name);
            history=read_history(hindex,unit_name);
         end;  % length(work_index)==0
      end; % isempty(unit_number)
      if taint > 20   % need to rescan
         taint=20;
      end;
      if auto_update
         if process      
            old_plot(opn,0);  % plot if trials found
         end;
      end;
   end; % if isempty(params)
   
elseif strncmp(cmd,'cd',2)
   eval(c,'disp(''Invalid change directory request.  Current directory is:'')');
   response=pwd;

elseif strncmp(cmd,'read',3)
   if taint < 20
      response='No file open';
   else
      if isempty(lparams)
         lparams='all which';
      end;
      [dummy,output_file]=strtok(params,'=');  % isolate output file from an output command
      output_file=strtok(output_file,'=');   % remove equal sign from output file name
      read_command(lparams,output_file);
      response=' Done';
   end;

elseif strncmp(cmd,'sequence',3)
   if isempty(params)   % an empty command requests the current sequence string
      response=get(findobj('Tag','sequence'),'String');
   else
      seq=format_sequence(params);
      set(findobj('Tag','sequence'),'String',seq);
      if taint > 20
         taint=20;   % must rescan
      end;
      if auto_update
         if process 
            old_plot(opn,0);  % plot if trials found
         end;
      end;
   end;

elseif strncmp(cmd,'pwd',3)
   response=pwd;
elseif strncmp(cmd,'shift',3)
   set(findobj('Tag','shift'),'String',params);
   if auto_update
      if process 
         old_plot(opn,0);  % plot if trials found
      end;      
   end;
elseif strncmp(cmd,'scan',4)   % avoid conflict with "scale"
   [trials_found,spike_counts]=scan;
   taint=30;
   if isempty(trials_found)
      trials_found=0;
   end;
   trials_found=num2str(trials_found);
   if sum(spike_counts)> 0
      fprintf(1,'Number of spikes found in each channel:\n');
   end
   for i=1:length(spike_counts)
      if spike_counts(i) > 0
         fprintf(1,'  Chan: %d has %d spikes\n',i-1,spike_counts(i));
         if environment.logging==1
            fprintf(fid.log,'spike chan: %d has %d spikes\n',i-1,spike_counts(i));
         end;  
      end;
   end;
   
   % update GUI
   if  get(findobj('Tag','spikechannelmenu'),'UserData') 
      set(findobj('Tag','trialsfound'),'String',trials_found);
      pulse_channel=get(findobj('Tag','spikechannelmenu'),'Value')-1;
      if get(findobj('Tag','spikechannelmenu'),'UserData')
         if length(spike_counts) >= (pulse_channel+1)
            spikecount=spike_counts(pulse_channel+1);
         else
            spikecount=0;
         end;
      else
         spikecount=0;
      end;
   set(findobj('Tag','pulsesfound'),'String',num2str(spikecount));
   end;
   
elseif strncmp(cmd,'spot',3)  % spot command
   if strncmp(lparams,'off',3)
      list='';
   else   %reformat spot code list
      list=number_range_list(lparams);
   end;
   if isempty(list)
      spot='[]';
      set(findobj('Tag','spot'),'String',spot);
      if auto_update
         if process      
            old_plot(opn,0);  % plot if trials found
         end;
      end;      
   elseif strcmp(list,'@')
         response='improper spot list';
   else
      spot=['[' number_range_list(lparams) ']'];
      set(findobj('Tag','spot'),'String',spot);
      if auto_update
         if process      
            old_plot(opn,0);  % plot if trials found
         end;
      end;
   end;

elseif strncmp(cmd,'pulsechannel',3)
   [dummy,pulse_channel,valid]=check_string_value(params,0,99);
   if strncmp(lparams,'off',3) || strncmp(lparams,'none',3)
      % interesting problem, must accomodate pure behavioral file!
      set(findobj('Tag','pulsesfound'),'String','off');
      set(findobj('Tag','spikechannelmenu'),'Enable','off');
      set(findobj('Tag','spikechannelmenu'),'UserData',0);  % user data field tells us PULSE OFF
   elseif isempty(pulse_channel)
      if get(findobj('Tag','spikechannelmenu'),'UserData')
         response=['pulse channel = ' get(findobj('Tag','spikechannelmenu'),'Value')];
      else
         response='pulses are off';
      end;
   elseif ~valid
      response='Pulsechannel must be in the range of 1 to 99, or "off" (= 0)';
   else
      if length(spike_counts) >= (pulse_channel+1)
         spikecount=spike_counts(pulse_channel+1);
      else
         spikecount=0;
      end;
      set(findobj('Tag','pulsesfound'),'String',num2str(spikecount));
      set(findobj('Tag','spikechannelmenu'),'Enable','on');
      set(findobj('Tag','spikechannelmenu'),'Value',pulse_channel+1);
      set(findobj('Tag','spikechannelmenu'),'UserData',1);
      if taint > 20   % need to rescan
         taint=20;
      end;
      if auto_update
         if process      
            old_plot(opn,0);  % plot if trials found
         end;
      end;
   end; % isempty(pulse_channel)
   
   
% trialfunction can have two formats:  Ax+B  or  A,B
elseif strncmp(cmd,'trialfunction',6)  % THIS MUST BE TESTED BEFORE 'TRIAL' COMMAND
   if isempty(lparams)
       response='improper trialfunction format';  
    else
       tf=lparams;
       if isempty(findstr(tf,'x'))       % in Ax+B format?
          tf=strrep(tf,',','x+');        % no, try to put it into that format
       end;
       response=set_trials(tf);
   end;
   if isempty(response) && auto_update 
      if process
         old_plot(opn,0);  % plot if trials found
      end;
   end; 
 
% trials will recognize the trialfunction if 'x' is used, Will also recognize misspelling!
elseif strncmp(cmd,'trials',3) || strncmp(cmd,'trails',3)
   response=set_trials(params);
   if isempty(response) && auto_update 
      if process
         old_plot(opn,0);  % plot if trials found
      end;
   end; 

elseif strncmp(cmd,'new',3)
   if strncmp(lparams,'plot',3)
      p_response=process;
      % for debugging  fprintf(1,'%d\n',p_response); % update the processing steps
      plots_on_the_page=new_plot;
      response=['drawing new plot number ' num2str(plot_number)];     
   else
      response='perhaps you mean: new plot';
   end;
   
elseif strncmp(cmd,'overplot',4)
  if process 
     old_plot(opn,1);  % plot using current axes information
  else
     response='no trials to plot';
  end;

elseif strncmp(cmd,'nextplot',3)
   [params,dummy,valid]=check_string_value(params,11,1000);  % plots can be numbered 11 to 1000
   if ~valid
      response='Requested plot number out of range. Number from 11 to 1000 are allowed';
   else
     set(findobj('Tag','oldplotnumber'),'String',params);
   end 
    
   
elseif strncmp(cmd,'old',3)
   if strncmp(lparams,'plot',3)
%    get the figure number of the plot to update
     [dummy,pnumber]=strtok(lparams);
     if strcmp(strtrim(pnumber),'next')  % next means to add +1 to the current plot number
        opn_add=1;
        opn='';
     else
        opn_add=0;
        opn=str2double(pnumber);
     end
     if isempty(opn) || isnan(opn)  % no number entered, see if the menu item has a valid number
        opn=str2double(get(findobj('Tag','oldplotnumber'),'String'));
     end
     if isempty(opn) || isnan(opn)  % if menu did not have a useful number, assign one
        opn=plot_number;
     end
     if (opn >= 0) && (opn < 11)
         fprintf(warning_fid, 'Plot numbers 1 to 10 are reserved. Assigning a different one.\n');  
         opn=plot_number;
     end
     if opn < 0
         fprintf(warning_fid, 'Negative plot numbers are not allowed. Assigning a different one.\n');  
         opn=plot_number;
     end
     opn=opn+opn_add;   % add 1 if the "add" option was given
     if process 
        old_plot(opn,0);
     else
        response='no trials to plot';
     end
     % update menu
     set(findobj('Tag','oldplotnumber'),'String',num2str(opn))
  else
     response='perhaps you mean: old plot <figure number>    figure number is optional';
  end

elseif strncmp(cmd,'span',3)
   if strncmp(lparams,'all',3)
      set(findobj('Tag','span'),'String','all');
      if taint > 20   % need to rescan
         taint=20;
      end;
      if auto_update && process 
         old_plot(opn,0);  % plot if trials found
      end;   
   else
      [params,dummy,valid]=check_string_value(params,1,10000);
      if ~valid
         response='Improper span value. Using default span of "all".';
         params='all';
      end;
      set(findobj('Tag','span'),'String',params);
      if taint > 20   % need to rescan
         taint=20;
      end;
      if auto_update && process  
         old_plot(opn,0);  % plot if trials found
      end; 
   end; % if span='all'
elseif strncmp(cmd,'sourcetrials',3)
   % compensate for unusual format: "source [1-200]=200"
   if ~isempty(findstr(params,'='))
      params=strtok(params,'=');
   end;
   expandedlist=expand_range_list(params);
   if ~isempty(find(expandedlist==0))
      fprintf(1,'Trial #0 is not a valid trial number.\n');  % helpful error message
   end
   list=number_range_list(params);

   if strcmp(list,'@') || (min(expandedlist) < 1)
      response='Improper sourcetrials list. Using default values.';
      set(findobj('Tag','source'),'String','[1-1000]');
   else
      set(findobj('Tag','source'),'String',['[' list ']']);
      if taint > 20   % need to rescan
         taint=20;
      end
      if auto_update
         if process      
            old_plot(opn,0);  % plot if trials found
         end
      end
   end
      
elseif strncmp(cmd,'window',3)
   set(findobj('Tag','window'),'String',params);
   if auto_update
      if process      
         old_plot(opn,0);  % plot if trials found
      end;
   end; 

% ==================== Layout ===========================

% copy layout
elseif strncmp(cmd,'copy',3)  % 3 chars to distinguish from "continue" command
   [slay,remainder]=strtok(lparams);
   [dlay,tlay]=strtok(remainder);
   if isempty(slay) || isempty(dlay)
      response='Missing one or both layout numbers.';
   else
      layouts(current_layout)=get_layout;  % Read GUI to synchronize current layout with the GUI
      [dummy,slay_value,valid1]=check_string_value(slay,1,10); % source layout number
      [dummy,dlay_value,valid2]=check_string_value(dlay,1,10); % destination layout number
      if ~valid1 || ~valid2 
         response='layout numbers must be between 1 and 10';
      elseif slay_value==dlay_value
         response='cannot copy layout to itself';

      elseif strncmp(tlay,'text',4) % copy text does not copy anything else
         layouts(dlay_value).text_on_off=layouts(slay_value).text_on_off; 

         layouts(dlay_value).text1_on_off=layouts(slay_value).text1_on_off; 
         layouts(dlay_value).text1_x_pos=layouts(slay_value).text1_x_pos; 
         layouts(dlay_value).text1_y_pos=layouts(slay_value).text1_y_pos; 
         layouts(dlay_value).text1_size=layouts(slay_value).text1_size; 
         layouts(dlay_value).text1_angle=layouts(slay_value).text1_angle; 
         layouts(dlay_value).text1_color=layouts(slay_value).text1_color; 
         layouts(dlay_value).text1_string=layouts(slay_value).text1_string; 
         layouts(dlay_value).text1_string=layouts(slay_value).text1_frame; 

         layouts(dlay_value).text2_on_off=layouts(slay_value).text2_on_off; 
         layouts(dlay_value).text2_x_pos=layouts(slay_value).text2_x_pos; 
         layouts(dlay_value).text2_y_pos=layouts(slay_value).text2_y_pos; 
         layouts(dlay_value).text2_size=layouts(slay_value).text2_size; 
         layouts(dlay_value).text2_angle=layouts(slay_value).text2_angle; 
         layouts(dlay_value).text2_color=layouts(slay_value).text2_color; 
         layouts(dlay_value).text2_string=layouts(slay_value).text2_string; 
         layouts(dlay_value).text1_string=layouts(slay_value).text2_frame; 

         layouts(dlay_value).text3_on_off=layouts(slay_value).text3_on_off; 
         layouts(dlay_value).text3_x_pos=layouts(slay_value).text3_x_pos; 
         layouts(dlay_value).text3_y_pos=layouts(slay_value).text3_y_pos; 
         layouts(dlay_value).text3_size=layouts(slay_value).text3_size; 
         layouts(dlay_value).text3_angle=layouts(slay_value).text3_angle; 
         layouts(dlay_value).text3_color=layouts(slay_value).text3_color; 
         layouts(dlay_value).text3_string=layouts(slay_value).text3_string; 
         layouts(dlay_value).text1_string=layouts(slay_value).text3_frame; 

         layouts(dlay_value).text4_on_off=layouts(slay_value).text4_on_off; 
         layouts(dlay_value).text4_x_pos=layouts(slay_value).text4_x_pos; 
         layouts(dlay_value).text4_y_pos=layouts(slay_value).text4_y_pos; 
         layouts(dlay_value).text4_size=layouts(slay_value).text4_size; 
         layouts(dlay_value).text4_angle=layouts(slay_value).text4_angle; 
         layouts(dlay_value).text4_color=layouts(slay_value).text4_color; 
         layouts(dlay_value).text4_string=layouts(slay_value).text4_string; 
         layouts(dlay_value).text1_string=layouts(slay_value).text4_frame; 

         layouts(dlay_value).text5_on_off=layouts(slay_value).text5_on_off; 
         layouts(dlay_value).text5_x_pos=layouts(slay_value).text5_x_pos; 
         layouts(dlay_value).text5_y_pos=layouts(slay_value).text5_y_pos; 
         layouts(dlay_value).text5_size=layouts(slay_value).text5_size; 
         layouts(dlay_value).text5_angle=layouts(slay_value).text5_angle; 
         layouts(dlay_value).text5_color=layouts(slay_value).text5_color; 
         layouts(dlay_value).text5_string=layouts(slay_value).text5_string; 
         layouts(dlay_value).text1_string=layouts(slay_value).text5_frame; 

         layouts(dlay_value).text6_on_off=layouts(slay_value).text6_on_off; 
         layouts(dlay_value).text6_x_pos=layouts(slay_value).text6_x_pos; 
         layouts(dlay_value).text6_y_pos=layouts(slay_value).text6_y_pos; 
         layouts(dlay_value).text6_size=layouts(slay_value).text6_size; 
         layouts(dlay_value).text6_angle=layouts(slay_value).text6_angle; 
         layouts(dlay_value).text6_color=layouts(slay_value).text6_color; 
         layouts(dlay_value).text6_string=layouts(slay_value).text6_string; 
         layouts(dlay_value).text1_string=layouts(slay_value).text6_frame; 

         layouts(dlay_value).text7_on_off=layouts(slay_value).text7_on_off; 
         layouts(dlay_value).text7_x_pos=layouts(slay_value).text7_x_pos; 
         layouts(dlay_value).text7_y_pos=layouts(slay_value).text7_y_pos; 
         layouts(dlay_value).text7_size=layouts(slay_value).text7_size; 
         layouts(dlay_value).text7_angle=layouts(slay_value).text7_angle; 
         layouts(dlay_value).text7_color=layouts(slay_value).text7_color; 
         layouts(dlay_value).text7_string=layouts(slay_value).text7_string; 
         layouts(dlay_value).text1_string=layouts(slay_value).text7_frame; 

         layouts(dlay_value).text8_on_off=layouts(slay_value).text8_on_off; 
         layouts(dlay_value).text8_x_pos=layouts(slay_value).text8_x_pos; 
         layouts(dlay_value).text8_y_pos=layouts(slay_value).text8_y_pos; 
         layouts(dlay_value).text8_size=layouts(slay_value).text8_size; 
         layouts(dlay_value).text8_angle=layouts(slay_value).text8_angle; 
         layouts(dlay_value).text8_color=layouts(slay_value).text8_color; 
         layouts(dlay_value).text8_string=layouts(slay_value).text8_string; 
         layouts(dlay_value).text1_string=layouts(slay_value).text8_frame; 

         layouts(dlay_value).text9_on_off=layouts(slay_value).text9_on_off; 
         layouts(dlay_value).text9_x_pos=layouts(slay_value).text9_x_pos; 
         layouts(dlay_value).text9_y_pos=layouts(slay_value).text9_y_pos; 
         layouts(dlay_value).text9_size=layouts(slay_value).text9_size; 
         layouts(dlay_value).text9_angle=layouts(slay_value).text9_angle; 
         layouts(dlay_value).text9_color=layouts(slay_value).text9_color; 
         layouts(dlay_value).text9_string=layouts(slay_value).text9_string; 
         layouts(dlay_value).text1_string=layouts(slay_value).text9_frame; 

         layouts(dlay_value)=layouts(slay_value);   % copy the layout
         if dlay_value==current_layout
            set_layout(layouts(current_layout));    % update GUI if necessary
         end;         

      else
         layouts(dlay_value)=layouts(slay_value);   % copy the layout, not the text
         if dlay_value==current_layout
            set_layout(layouts(current_layout));    % update GUI if necessary
         end;
      end;
   end;
   
% layout command   
elseif strncmp(cmd,'layout',3)
   if strncmp(lparams,'file',2)
     [dummy,layout_file]=strtok(params);      % parse filename preserving case
     layout_file=strtrim(layout_file);  % lop off spaces
     layout_file=filepath(layout_file,environment.layoutpath);  % prepend path
     response=load_layouts(layout_file);   % get layout parameters from disk
     if (current_layout < 1) || (current_layout > 10)    % assure valid layout number
        current_layout=1;
     end;
     set_layout(layouts(current_layout));   % activate one of the parameter sets
  elseif strncmp(lparams,'save',2)
     [dummy,layout_file]=strtok(params);      % parse filename preserving case
     layout_file=strtrim(layout_file);  % lop off spaces
     layout_file=filepath(layout_file,environment.layoutpath);  % prepend path
     try
        layouts(current_layout)=get_layout;      % update menu changes to layout structure
     catch
        response='Cannot change layout. Try using Initialize command. (Current layout will be lost)';
     end;    
     layouts(current_layout)=get_layout;      % read GUI to synchronize current layout with the GUI
     save_layouts(layout_file);               % save layout structure on disk
  else
      layout_number=floor(str2double(lparams));
      if ~isempty(layout_number) && ~isnan(layout_number)
         if (layout_number > 0) && (layout_number <= 10) && (layout_number ~= current_layout)
            % update current layout structure to match any changes to the menu
            try
               layouts(current_layout)=get_layout;      % update menu changes to layout structure
            catch
               response='Cannot change layout. Try using Initialize command. (Current layout will be lost)';
            end;   
            set_layout(layouts(layout_number));
            set(findobj('Tag','layout_number'),'String',num2str(layout_number));
            current_layout=layout_number;
         else
            if layout_number ~= current_layout % look for a legal layout number
               response='layout number must integer from 1 to 10'; % was not legal
            end;
         end;
      else
         error_message=load_layouts(params);
         if ~isempty(error_message)
             % fix layout number 
             set(findobj('Tag','layout_number'),'String',num2str(current_layout));
             response=error_message;
         end;
      end;
  end;
 
% "analog" can signify either the layout command or the AnalogChannel command

elseif strncmp(cmd,'analog',4)
   taint_flag=1;
   if strncmp(lparams,'show',3)
      set(findobj('Tag','analog_on_off'),'Value',1);
   elseif strncmp(lparams,'noshow',3)
      set(findobj('Tag','analog_on_off'),'Value',0);
   elseif strncmp(lparams,'off',2)    % same as analogchannel 0
      set(findobj('Tag','xchannelmenu'),'Value',1);
   elseif strncmp(lparams,'ypos',1)
      [dummy,ypos]=strtok(params);
      ypos=strtrim(ypos);
      set(findobj('Tag','analog_y_pos'),'String',ypos);
   elseif strncmp(lparams,'size',2)
      [dummy,asize]=strtok(params);
      asize=strtrim(asize);
      set(findobj('Tag','analog_trace_size'),'String',asize);
   elseif strncmp(lparams,'separation',3)
      [dummy,sep]=strtok(params);
      sep=strtrim(sep);
      set(findobj('Tag','analog_separation'),'String',sep);
   elseif strncmp(lparams,'line',3)
      [dummy,linetype]=strtok(params);
      set(findobj('Tag','analog_style'),'Value',str2double(linetype));
   elseif ~isnan(str2double(lparams))
      if (str2double(lparams) > 0) && (str2double(lparams) <= 15)
         set(findobj('Tag','xchannelmenu'),'Value',str2double(params)+1);
         if taint > 20
            taint=20;  % force scan
         end
      elseif str2double(lparams)==0
         set(findobj('Tag','xchannelmenu'),'Value',1);
         response='(analog off)';
      else
         response='Unrecognized parameter. Valid parameters: show, noshow, ypos, size, separation, line, 0-15';
         taint_flag=0;       
      end;
   end;
   if auto_update && taint_flag
      if process      
         old_plot(opn,0);  % plot if trials found
      end;
   end;   
   
   
% AvAnalog   
elseif strncmp(cmd,'avanalog',4)
   taint_flag=1;
   if strncmp(lparams,'show',3)
      set(findobj('Tag','average_on_off'),'Value',1);
   elseif strncmp(lparams,'noshow',3)
      set(findobj('Tag','average_on_off'),'Value',0);
   elseif strncmp(lparams,'ypos',1)
      [dummy,ypos]=strtok(params);
      ypos=strtrim(ypos);
      set(findobj('Tag','average_y_pos'),'String',ypos);
   elseif strncmp(lparams,'size',2)
      [dummy,asize]=strtok(params);
      asize=strtrim(asize);
      set(findobj('Tag','average_trace_size'),'String',asize);
   elseif strncmp(lparams,'separation',3)
      [dummy,sep]=strtok(params);
      sep=strtrim(sep);
      set(findobj('Tag','average_separation'),'String',sep);
   elseif strncmp(lparams,'line',3)
      [dummy,linetype]=strtok(params);
      set(findobj('Tag','average_style'),'Value',str2double(linetype));
   else
      response='Unrecognized or missing parameters. Valid parameters: show, noshow, ypos, size, separation, line';
      taint_flag=0;
   end;
   if auto_update && taint_flag
      if process      
         old_plot(opn,0);  % plot if trials found
      end;
   end;   
   

% Ana2

elseif strncmp(cmd,'ana2',4)
   taint_flag=1;
   if strncmp(lparams,'show',3)
      set(findobj('Tag','analog2_on_off'),'Value',1);
   elseif strncmp(lparams,'noshow',3)
      set(findobj('Tag','analog2_on_off'),'Value',0);
   elseif strncmp(lparams,'off',2)    % same as ana2 0
      set(findobj('Tag','ychannelmenu'),'Value',1);
   elseif strncmp(lparams,'ypos',1)
      [dummy,ypos]=strtok(params);
      ypos=strtrim(ypos);
      set(findobj('Tag','analog2_y_pos'),'String',ypos);
   elseif strncmp(lparams,'size',2)
      [dummy,asize]=strtok(params);
      asize=strtrim(asize);
      set(findobj('Tag','analog2_trace_size'),'String',asize);
   elseif strncmp(lparams,'separation',3)
      [dummy,sep]=strtok(params);
      sep=strtrim(sep);
      set(findobj('Tag','analog2_separation'),'String',sep);
   elseif strncmp(lparams,'line',3)
      [dummy,linetype]=strtok(params);
      set(findobj('Tag','analog2_style'),'Value',str2double(linetype));
   elseif ~isnan(str2double(lparams))
      if (str2double(lparams) > 0) && (str2double(lparams) <= 15)
         set(findobj('Tag','ychannelmenu'),'Value',str2double(lparams)+1);
         if taint > 20
            taint=20;  % force scan
         end
      elseif str2double(lparams)==0
         set(findobj('Tag','ychannelmenu'),'Value',1);
         response='(analog off)';
      else
         response='Unrecognized parameter. Valid parameters: show, noshow, ypos, size, separation, line, 0-15';
         taint_flag=0;         
      end;
   end;
   if auto_update && taint_flag
      if process      
         old_plot(opn,0);  % plot if trials found
      end;
   end;   

elseif strncmp(cmd,'av2analog',4)
   taint_flag=1;
   if strncmp(lparams,'show',3)
      set(findobj('Tag','average2_on_off'),'Value',1);
   elseif strncmp(lparams,'noshow',3)
      set(findobj('Tag','average2_on_off'),'Value',0);
   elseif strncmp(lparams,'ypos',1)
      [dummy,ypos]=strtok(params);
      ypos=strtrim(ypos);
      set(findobj('Tag','average2_y_pos'),'String',ypos);
   elseif strncmp(lparams,'size',2)
      [dummy,asize]=strtok(params);
      asize=strtrim(asize);
      set(findobj('Tag','average2_trace_size'),'String',asize);
   elseif strncmp(lparams,'separation',3)
      [dummy,sep]=strtok(params);
      sep=strtrim(sep);
      set(findobj('Tag','average2_separation'),'String',sep);
   elseif strncmp(lparams,'line',3)
      [dummy,linetype]=strtok(params);
      set(findobj('Tag','average2_style'),'Value',str2double(linetype));
   else
      response='Unrecognized or missing parameters. Valid parameters: show, noshow, ypos, size, separation, line';
      taint_flag=0;      
   end;
   if auto_update && taint_flag
      if process      
         old_plot(opn,0);  % plot if trials found
      end;
   end;   


% X-Y Analog

elseif strncmp(cmd,'xy',2)
   taint_flag=1;
   if strncmp(lparams,'show',3)
      set(findobj('Tag','xy_on_off'),'Value',1);
   elseif strncmp(lparams,'noshow',3)
      set(findobj('Tag','xy_on_off'),'Value',0);
%  some day we may implement this: an X marks start of each trace,
%  square marks the end of each trace
%   elseif strncmp(lparams,'labels',3)
%      [dummy,asize]=strtok(params);
%      asize=deblank(strjust(asize,'left'));
%      set(findobj('Tag','xy_mark_size'),'String',asize);
   elseif strncmp(lparams,'xpos',1)
      [dummy,xpos]=strtok(params);
      xpos=deblank(strjust(xpos,'left')); %#ok<TRIM2>
      set(findobj('Tag','xy_x_pos'),'String',xpos);
   elseif strncmp(lparams,'ypos',1)
      [dummy,ypos]=strtok(params);
      ypos=strtrim(ypos);
      set(findobj('Tag','xy_y_pos'),'String',ypos);
   elseif strncmp(lparams,'size',2)
      [dummy,asize]=strtok(params);
      asize=strtrim(asize);
      set(findobj('Tag','xy_trace_size'),'String',asize);
   elseif strncmp(lparams,'separation',3)
      [dummy,sep]=strtok(params);
      sep=strtrim(sep);
      set(findobj('Tag','xy_separation'),'String',sep);
   elseif strncmp(lparams,'line',3)
      [dummy,linetype]=strtok(params);
      set(findobj('Tag','xy_style'),'Value',str2double(linetype));
   elseif strncmp(lparams,'overlap',3)
      [dummy,overlap]=strtok(params);
      overlap=lower(strtrim(overlap));
      if (strcmp(overlap,'on'))
         set(findobj('Tag','xy_overlap_on_off'),'Value',1);
      elseif (strcmp(overlap,'off'))
         set(findobj('Tag','xy_overlap_on_off'),'Value',0);
      else
         response='Unrecognized or missing parameter. Valid parameters: on, off';
      end;
   elseif strncmp(lparams,'time',3)
      [dummy,time_criteria]=strtok(lparams);
      time_criteria=strtrim(time_criteria);
      if strncmp(time_criteria,'all',3)
         set(findobj('Tag','xy_time_start'),'Visible','off');
         set(findobj('Tag','xy_time_start_text'),'Visible','off');
         set(findobj('Tag','xy_time_stop'),'Visible','off');
         set(findobj('Tag','xy_time_stop_text'),'Visible','off');
         set(findobj('Tag','xy_time_criteria'),'Value',1);
      elseif strncmp(time_criteria,'time',3) || strncmp(time_criteria,'events',3) || strncmp(time_criteria,'classes',3)
         set(findobj('Tag','xy_time_start'),'Visible','on');
         set(findobj('Tag','xy_time_start_text'),'Visible','on');
         set(findobj('Tag','xy_time_stop'),'Visible','on');
         set(findobj('Tag','xy_time_stop_text'),'Visible','on');
         if strncmp(time_criteria,'time',3)
           set(findobj('Tag','xy_time_criteria'),'Value',2);
           lower_limit=-60000;   % one minute should be enough
           upper_limit=60000;
         elseif strncmp(time_criteria,'events',3) 
           set(findobj('Tag','xy_time_criteria'),'Value',3);
           lower_limit=1;
           upper_limit=100;  % 100 event codes maximum
         elseif strncmp(time_criteria,'classes',3) 
           set(findobj('Tag','xy_time_criteria'),'Value',4);
           lower_limit=1;
           upper_limit=20000;   % reasonable upper limit for number of classes
         end;
         [dummy,start_stop]=strtok(time_criteria);  % try to get start and stop times/events/classes
         start_stop=strtrim(start_stop);
         [start,stop]=strtok(start_stop);
         if ~isempty(start)
            [clean_string,dummy,valid]=check_string_value(start,lower_limit,upper_limit);
            if ~valid
               fprintf(1,'Invalid start value. Range is %d to %d.\n',lower_limit,upper_limit);
               if environment.logging==1
                  fprintf(fid.log,'Invalid start value. Range is %d to %d.\n',lower_limit,upper_limit);
               end;
            else
               set(findobj('Tag','xy_time_start'),'String',clean_string);
            end;         
         end;
         if ~isempty(stop)
            [clean_string,dummy,valid]=check_string_value(stop,lower_limit,upper_limit);
            if ~valid
               fprintf(1,'Invalid stop value. Range is %d to %d.\n',lower_limit,upper_limit);
               if environment.logging==1
                  fprintf(fid.log,'Invalid stop value. Range is %d to %d.\n',lower_limit,upper_limit);
               end;
            else
               set(findobj('Tag','xy_time_stop'),'String',clean_string);
            end;         
         end;
      else
         response='Unrecognized or missing parameters. Valid parameters: all, events e1 e2, time t1 t2, classes';
         taint_flag=0;
      end; % time criteria
   elseif strncmp(lparams,'start',3)
      [dummy,time_value]=strtok(lparams);
      time_value=strtrim(time_value);
      set(findobj('Tag','xy_time_start'),'String',time_value);
   elseif strncmp(lparams,'stop',3)  
      [dummy,time_value]=strtok(lparams);
      time_value=strtrim(time_value);
      set(findobj('Tag','xy_time_stop'),'String',time_value); 
   else
      response='Unrecognized or missing parameters. Valid parameters: show, noshow, xpos, ypos, size, separation, line';
      taint_flag=0;
   end;
   if auto_update && taint_flag
      if process      
         old_plot(opn,0);  % plot if trials found
      end;
   end;   
   
   
   % average XY  (not implemented in plotting code yet)   
   elseif strncmp(cmd,'avxy',2)
   taint_flag=1;
   if strncmp(lparams,'show',3)
      set(findobj('Tag','avxy_on_off'),'Value',1);
   elseif strncmp(lparams,'noshow',3)
      set(findobj('Tag','avxy_on_off'),'Value',0);
   elseif strncmp(lparams,'xpos',1)
      [dummy,xpos]=strtok(params);
      xpos=strtrim(xpos);
      set(findobj('Tag','avxy_x_pos'),'String',xpos);
   elseif strncmp(lparams,'ypos',1)
      [dummy,ypos]=strtok(params);
      ypos=strtrim(ypos);
      set(findobj('Tag','avxy_y_pos'),'String',ypos);
   elseif strncmp(lparams,'size',2)
      [dummy,asize]=strtok(params);
      asize=strtrim(asize);
      set(findobj('Tag','avxy_trace_size'),'String',asize);
   elseif strncmp(lparams,'line',3)
      [dummy,linetype]=strtok(params);
      set(findobj('Tag','avxy_style'),'Value',str2double(linetype));
   else
      response='Unrecognized or missing parameters. Valid parameters: show, noshow, xpos, ypos, size, line';
      taint_flag=0;
   end;
   if auto_update && taint_flag
      if process      
         old_plot(opn,0);  % plot if trials found
      end;
   end;   

   

% RIP

elseif strncmp(cmd,'rip',3)
   taint_flag=1;
   if strncmp(lparams,'show',3) || strncmp(lparams,'on',2) 
      set(findobj('Tag','RIP_on_off'),'Value',1);
   elseif strncmp(lparams,'noshow',3) || strncmp(lparams,'off',2)
      set(findobj('Tag','RIP_on_off'),'Value',0);
   elseif strncmp(lparams,'filled',3)
      response='not implemented';
   elseif strncmp(lparams,'nofilled',3)
      response='not implemented';
   elseif strncmp(lparams,'ypos',1)
      [dummy,ypos]=strtok(params);
      ypos=strtrim(ypos);
      set(findobj('Tag','RIP_y_pos'),'String',ypos);
   elseif strncmp(lparams,'size',2)
      [dummy,asize]=strtok(params);
      asize=strtrim(asize);
      set(findobj('Tag','RIPscale'),'String',asize);
   elseif strncmp(lparams,'line',2)
      [dummy,linetype]=strtok(params);
      set(findobj('Tag','RIP_style'),'Value',str2double(linetype));
   else
      response='Unrecognized or missing parameters. Valid parameters: show, noshow, ypos, size, fill, nofill, line';
      taint_flag=0;      
   end;
   if auto_update && taint_flag
      if process      
         old_plot(opn,0);  % plot if trials found
      end;
   end;   


elseif strncmp(cmd,'binwidth',3)
   [lparams,dummy,valid]=check_string_value(lparams,1,1000);  % 
   if ~valid
      response='binwidth out of range. Valid values are from 1 to 1000.';
   else
      set(findobj('Tag','histogram_binwidth'),'String',lparams);
         if auto_update
            if process      
               old_plot(opn,0);  % plot if trials found
            end;
         end;   
   end; % if valid
   
elseif strncmp(cmd,'scale',4)
   [lparams,dummy,valid]=check_string_value(lparams,1,1000);  % 
   if strncmp(lparams,'show',3) || strncmp(lparams,'on',2)
         set(findobj('Tag','histogram_scale_on_off'),'Value',1);
   elseif strncmp(lparams,'noshow',3) || strncmp(lparams,'off',2)
         set(findobj('Tag','histogram_scale_on_off'),'Value',0);
   elseif ~valid && ~strcmp(lparams,'auto')   % auto is allowed
      response='histogram scale out of range. Valid values are from 1 to 1000.';
   else
      set(findobj('Tag','histogram_scale'),'String',lparams);
      if auto_update
         if process      
            old_plot(opn,0);  % plot if trials found
         end;
      end;   
   end;

elseif strncmp(cmd,'history',7)  % must match all characters to avoid conflict with 'histogram' command
   if strncmp(lparams,'file',2)
      [dummy,user_history_file_name]=strtok(params);      % parse filename preserving case
      user_history_file_name=strtrim(user_history_file_name);  % lop off spaces
      [dummy,dummy,ext]=fileparts(user_history_file_name);
      if strcmp(ext,'.m')
         set(findobj('Tag','historyfile'),'String',user_history_file_name); % write into the GUI
         if taint > 20   % need to rescan
            taint=20;
         end;
      else
         response='File name error.  Must end with  .m  extension.';
      end;
   elseif strncmp(lparams,'data',3)
      [dummy,hd]=strtok(params); 
      try
         history_data=eval(['[' hd ']']);
         set(findobj('Tag','historyfile'),'UserData',history_data); % save data into GUI
      catch
         response='Error storing history data. Data must be a numeric list or single string.';         
      end;
   elseif strncmp(lparams,'on',2)
      set(findobj('Tag','historyfile'),'BackgroundColor',[1 1 1]); % Light up file name display
      set(findobj('Tag','historyfile'),'UserData',1);              % Enable history
      if taint > 20   % need to rescan
         taint=20;
      end;
   elseif strncmp(lparams,'off',2)
      set(findobj('Tag','historyfile'),'BackgroundColor',[.753 .753 .753]);  % dim file name display
      set(findobj('Tag','historyfile'),'UserData',0);                        % Disable history
      if taint > 20   % need to rescan
         taint=20;
      end;
   elseif strncmp(lparams,'spot',2)
      [dummy,s]=strtok(lparams);
      s=strjust(s,'left');
      [dummy,svalue]=strtok(s);  % value if needed
      svalue=strjust(svalue,'left');
      if strncmp(s,'show',3) || strncmp(s,'on',2)
         set(findobj('Tag','history_spot_on_off'),'Value',1);
      elseif strncmp(s,'noshow',3) || strncmp(s,'off',2)
         set(findobj('Tag','history_spot_on_off'),'Value',0);
      elseif strncmp(s,'firstclass',3)
         [dummy,dummy,valid]=check_string_value(svalue,1,20000);   % can only use classes 1 to 20,000 for spotting
         if ~valid
            response='Improper history class value. Range is 1 to 20,000. Defaulting to 500 as the first class.';
            svalue='500';
         end;
         set(findobj('Tag','history_spot_first_class'),'String',svalue);
      elseif strncmp(s,'lastclass',3)
         [dummy,dummy,valid]=check_string_value(svalue,1,20000);   % can only use classes 1 to 20,000 for spotting
         if ~valid
            response='Improper history class value. Range is 1 to 20,000. Defaulting to 550 as the last class.';
            svalue='550';
         end;
         set(findobj('Tag','history_spot_last_class'),'String',svalue);
      elseif strncmp(s,'color',3)
         [dummy,color_spec]=strtok(s);
         color_number=color2number(color_spec);
         if color_number==0
            response='history spot color is invalid. Try: yellow, magenta, cyan, red, green, blue, white or black';
         else 
            set(findobj('Tag','history_spot_color'),'Value',color_number);
         end;
      end;
   elseif strncmp(lparams,'rewrite',3)
       [dummy,rw_option]=strtok(lparams);      % look for "all" option
       rw_option=strjust(rw_option,'left');
       if isempty(rw_option)
          a=rewrite_history(history,0);
       elseif strncmp(rw_option,'all',3)
          a=rewrite_history(history,1);  % all units from the same set of behavioral trials
       elseif strncmp(rw_option,'delete',3)      
          a=rewrite_history([],2);  % erase the history for this unit from the disk
       else 
          a=rewrite_history(history,0); 
       end;
       if a==1
          response='Rewrite successful';
       else
          response='Problem writing history';
       end;
    elseif strncmp(lparams,'clear',3)
       for i=length(history):-1:1
          history(i)=[];
       end;
       response='All history for this unit has been cleared from memory.  Use History Rewrite to make permanent.';
   else
       response='Unrecognized history command. Valid parameters: file on off rewrite clear';
   end;

elseif strncmp(cmd,'histogram',3)
   taint_flag=1;
   if strncmp(lparams,'show',3) || strncmp(lparams,'on',2)
      set(findobj('Tag','histogram_on_off'),'Value',1);
   elseif strncmp(lparams,'noshow',3) || strncmp(lparams,'off',2)
      set(findobj('Tag','histogram_on_off'),'Value',0);
   elseif strncmp(lparams,'rawcounts',3)
      set(findobj('Tag','histogram_raw_on_off'),'Value',1);
   elseif strncmp(lparams,'normalcounts',3)
      set(findobj('Tag','histogram_raw_on_off'),'Value',0);
   elseif strncmp(lparams,'labels',3)
      response='not implemented';
   elseif strncmp(lparams,'ypos',1)
      [dummy,ypos]=strtok(params);
      ypos=strtrim(ypos);
      set(findobj('Tag','histogram_y_pos'),'String',ypos);
   elseif strncmp(lparams,'size',2)
      [dummy,asize]=strtok(params);
      asize=strtrim(asize);
      set(findobj('Tag','histogram_size'),'String',asize);
   elseif strncmp(lparams,'scale',2)
      [dummy,s]=strtok(lparams);
      [s,dummy,valid]=check_string_value(s,1,1000); 
      if strncmp(s,'show',3) || strncmp(s,'on',2)
         set(findobj('Tag','histogram_scale_on_off'),'Value',1);
      elseif strncmp(s,'noshow',3) || strncmp(s,'off',2)
         set(findobj('Tag','histogram_scale_on_off'),'Value',0);
      elseif ~valid && ~strcmp(s,'auto')   % auto is allowed
         response='histogram scale out of range. Range is 1 to 1000.';
      else
         set(findobj('Tag','histogram_scale'),'String',s);
      end;   
   elseif strncmp(lparams,'line',2)
      [dummy,linetype]=strtok(params);
      [linetype,dummy,valid]=check_string_value(linetype,1,4);
      if ~valid
         response='histogram line type invalid. Range is 1 to 4 ';
      else 
         set(findobj('Tag','histogram_style'),'Value',str2double(linetype));
      end;
   elseif strncmp(lparams,'reference',3)
      [dummy,ref]=strtok(lparams);
      [r,dummy,valid]=check_string_value(ref,0,10);  
      if strncmp(r,'show',3) || strncmp(r,'on',2)
         set(findobj('Tag','histogram_ref_on_off'),'Value',1);
      elseif strncmp(r,'noshow',3) || strncmp(r,'off',2)
         set(findobj('Tag','histogram_ref_on_off'),'Value',0);
      elseif strncmp(r,'color',2)
         [dummy,color_spec]=strtok(ref);
         color_number=color2number(color_spec);
         if color_number==0
            response='histogram reference color is invalid. Try: yellow, magenta, cyan, red, green, blue, white or black';
         else 
            set(findobj('Tag','histogram_ref_color'),'Value',color_number);
         end;
      elseif valid
         ref=strtok(r);
         [dummy,ref_limits,valid]=check_string_value(ref,0,10);  % is 10 standard deviations enough?
         set(findobj('Tag','histogram_ref_limits'),'String',num2str(ref_limits));
      end;
   else
      response='Unrecognized or missing parameters. Valid parameters: show, noshow, ypos, size, labels, line reference';
      taint_flag=0;
 % binwidth and scale are separate commands.
   end;
   if auto_update && taint_flag
      if process      
         old_plot(opn,0);  % plot if trials found
      end;
   end;   


elseif strncmp(cmd,'raster',2)
   taint_flag=1;
   if strncmp(lparams,'show',3) || strncmp(lparams,'on',2)
      set(findobj('Tag','raster_on_off'),'Value',1);
   elseif strncmp(lparams,'noshow',3) || strncmp(lparams,'off',2)
      set(findobj('Tag','raster_on_off'),'Value',0);
   elseif strncmp(lparams,'line',3)
      response='not implemented';
   elseif strncmp(lparams,'labels',3)
      [dummy,asize]=strtok(params);
      [asize,dummy,valid]=check_string_value(asize,0,100);
      if ~valid
         response='Invalid raster label command.  Try:  raster label n    0 < n < 100';
      else
         set(findobj('Tag','raster_label_size'),'String',asize);
      end;
   elseif strncmp(lparams,'ypos',1)
      [dummy,ypos]=strtok(params);
      ypos=strtrim(ypos);
      set(findobj('Tag','raster_y_pos'),'String',ypos);
   elseif strncmp(lparams,'size',2)
      [dummy,asize]=strtok(lparams);
      asize=strtrim(asize);
      set(findobj('Tag','raster_tic_size'),'String',asize);
   elseif strncmp(lparams,'separation',3)
      [dummy,sep]=strtok(params);
      sep=strtrim(sep);
      set(findobj('Tag','raster_separation'),'String',sep);
   else
      response='Unrecognized or missing parameters. Valid parameters: show, noshow, ypos, size, separation';
      taint_flag=0;      
   end;      
   if auto_update && taint_flag
      if process     
         old_plot(opn,0);  % plot if trials found
      end;
   end;   
   
elseif strncmp(cmd,'heading',2)
   taint_flag=1;
   if strncmp(lparams,'show',3) || strncmp(lparams,'on',2)
      set(findobj('Tag','heading_on_off'),'Value',1);
   elseif strncmp(lparams,'noshow',3)  || strncmp(lparams,'off',3)
      set(findobj('Tag','heading_on_off'),'Value',0);
   elseif strncmp(lparams,'xpos',1)
      [dummy,xpos]=strtok(params);
      xpos=strtrim(xpos);
      set(findobj('Tag','heading_x_pos'),'String',xpos);
   elseif strncmp(lparams,'ypos',1)
      [dummy,ypos]=strtok(params);
      ypos=strtrim(ypos);
      set(findobj('Tag','heading_y_pos'),'String',ypos);
   elseif strncmp(lparams,'size',2)
      [dummy,asize]=strtok(params);
      asize=strtrim(asize);
      set(findobj('Tag','heading_size'),'String',asize);  % font size in points
   else
      response='Unrecognized or missing parameters. Valid parameters: show, noshow, xpos, ypos, (font) size';
      taint_flag=0;
   end;
   if auto_update && taint_flag
      if process      
         old_plot(opn,0);  % plot if trials found
      end;
   end;   
   
elseif strncmp(cmd,'autoupdate',3)  % auto update 
   set(findobj('Tag','autoupdate'),'Value',1);
   auto_update=1;
elseif strncmp(cmd,'manualupdate',3)     % manual update
   set(findobj('Tag','autoupdate'),'Value',0);
   auto_update=0;

elseif strncmp(cmd,'axis',2)    % axis command (new command)
   if strncmp(lparams,'multiplot',4)
      [dummy,total_subplots]=strtok(lparams);
      [dummy,dummy,valid]=check_string_value(total_subplots,1,72);
      if ~valid
         response='multiplot value out of range. allowed values are 1 to 72' ;
      else
         set(findobj('Tag','subplot_total'),'String',total_subplots);
      end
      
   elseif strncmp(lparams,'subplot',3)
      [dummy,subplot]=strtok(lparams);
      [dummy,subplot_value,valid]=check_string_value(subplot,1,72);
      if ~valid || (subplot_value > str2double(get(findobj('Tag','subplot_total'),'String')))
         response=['subplot value out of range. allowed values are 1 to ' get(findobj('Tag','subplot_total'),'String')] ;
      else
         set(findobj('Tag','subplot_number'),'String',subplot);
      end      
   elseif strncmp(lparams,'xatzero',3)
      [dummy,on_off]=strtok(lparams);
      on_off=lower(strtrim(on_off));
      if strncmp(on_off,'on',2)
         x_at_zero=1;
         set(findobj('Tag','xatzero'),'Value',x_at_zero);
      elseif strncmp(on_off,'off',2)
         x_at_zero=0;
         set(findobj('Tag','xatzero'),'Value',x_at_zero);
      else
         response='unrecognized axis xatzero command. Valid options are: on, off.';
      end;

   % PCOFF UNITS NO LONGER SUPPORTED
   elseif strncmp(lparams,'units',3)
      [dummy,on_off]=strtok(lparams);
      units_type=lower(strtrim(on_off));
      if strncmp(units_type,'pcoff',2)
         response='PCOFF units no longer supported';
      elseif strncmp(units_type,'absolute',3)
         % nothing to do here
      else
         response='axis units command no longer supported.';
      end;
      
   elseif strncmp(lparams,'show',3) || strncmp(lparams,'on',2)
      set(findobj('Tag','hidexaxis'),'Value',0);  % enable display of x axis on plot
   elseif strncmp(lparams,'noshow',3) || strncmp(lparams,'off',2)
      set(findobj('Tag','hidexaxis'),'Value',1);  % hide x axis on plot    
   else
      response='unrecognized axis command. Valid options are: xatzero, units.';
   end;      
   

% ================== end Layout =======================


elseif strcmp(cmd,'exit') && (length(cmd)==4)
   exit;

elseif strcmp(cmd,'quit') && (length(cmd)==4)
   response='EXITMATOFF';


elseif strncmp(cmd,'resort',6)  % pseudo command generated by GUI Sort
   sort_number=get(findobj('Tag','trialsort'),'Value');
   sort_range_settings(sort_number);
   if auto_update
      old_plot(opn,0);
   end

elseif strncmp(cmd,'sort',3)
   list=0;
   if strncmp(lparams,'range',3)  %  SORT RANGE SHOW/NOSHOW
      list=get(findobj('Tag','trialsort'),'Value');
      if findstr(lparams,'nosh')  % don't show range on plot
         set(findobj('Tag','sortrangeshow'),'Value',0); 
      elseif  findstr(lparams,'sh')  % show range  
         set(findobj('Tag','sortrangeshow'),'Value',1);   
      else
         response='Unrecognized command.  Valid options:  sort range show/noshow';
      end;
   elseif strncmp(lparams,'off',3)
      list=1;
   elseif strncmp(lparams,'center',3)
      list=2;
   elseif strncmp(lparams,'time',3)
      list=3;
   elseif strncmp(lparams,'pulse',3)
      [dummy,pulse_sort_range]=strtok(lparams);
      pulse_sort_range=strrep(pulse_sort_range,',',' ');            
      [psr_low,psr_high]=strtok(pulse_sort_range);
      if isempty(psr_low)|| isempty(psr_high)
         low=-1;
         high=-1;  % force failure below
      else
         low=str2double(psr_low);
         high=str2double(psr_high);
      end

      if (low > high) || isnan(low) || isnan (high)
         response='High value less than low value, using default values.';
         set(findobj('Tag','pulsesortrange1'),'String','300'); % default
         set(findobj('Tag','pulsesortrange2'),'String','400'); % default
      else
         list=4;
         set(findobj('Tag','pulsesortrange1'),'String',num2str(low)); 
         set(findobj('Tag','pulsesortrange2'),'String',num2str(high)); 
      end;
   elseif strncmp(lparams,'epoch',3)
      list=5;
   elseif strncmp(lparams,'delta',3)
      list=6;
   elseif strncmp(lparams,'min',3)
      list=7;
   elseif strncmp(lparams,'max',3)
      list=8;
   elseif strncmp(lparams,'peak',3)
      list=9;
   elseif strncmp(lparams,'pit',3)
      list=10;
   elseif strncmp(lparams,'zero',3)
      list=11;
   elseif strncmp(lparams,'int',3)
      list=12;
   elseif strncmp(lparams,'history',3)
      list=13;
      [dummy,history_sort_range]=strtok(lparams);
      [s,svalue,valid]=check_string_value(history_sort_range,1,20000);   % can only use classes 1 to 20,000 for spotting or sorting
      if ~valid
         response='Improper history class value. Using 100 as the sort class.';
         s='100';
      end;
      set(findobj('Tag','historysortrange1'),'String',s);  % put the clean string into the GUI
   elseif isempty(lparams)
      sort_number=get(findobj('Tag','trialsort'),'Value');
      sort_options=get(findobj('Tag','trialsort'),'String');
      response=sort_options(sort_number,:);
   else
      response=['Invalid sort option. Valid options: off, center, time, pulse, epoch, ' ...
            'delta, min, max, peak, pit, zero, int, history, <range>'];
   end;
   if list > 0
     % sort_gui_update(list);
      sort_range_settings(list);
      if auto_update
         old_plot(opn,0);
      end;
   end; %end if list

elseif strncmp(cmd,'taint',3)
   if isempty(lparams)
      % meaning of each taint value
      taint_list={'no file open','need to scan','need to accumulate','need to map','ready to plot'};
      taint_step=char(taint_list(taint/10));
      response=['taint=' num2str(taint) '  >> ' taint_step];
   elseif ~isempty(str2double(params))
      taint_value=str2double(params);
      if (taint_value >= 10) && (taint_value <= 50)
         taint=str2double(params);
      else
         response='Invalid taint value.  Allowed values are: 10, 20, 30, 40, 50.'; 
      end;
   else
      response='Invalid taint option. Valid options are [empty], 10, 20, 30, 40, 50.';
   end;
   
elseif strncmp(cmd,'segment',3)
   taint_flag=1;  % goes to 0 if command is invalid
   if strncmp(lparams,'show',3)
      set(findobj('Tag','segments_on_off'),'Value',1);  % enable display of segments on plot
   elseif strncmp(lparams,'noshow',3)
      set(findobj('Tag','segments_on_off'),'Value',0);
      if taint>=50    % update plot if valid data are on the plot
         old_plot(opn,0);     
      end;
   elseif findstr(lparams,'m')  % process this variant before the other options
      [segment_ab,segment_value]=strtok(lparams);
      if ~(strcmp(segment_ab,'a1') || strcmp(segment_ab,'a2') || strcmp(segment_ab,'b1') || strcmp(segment_ab,'b2'))
         response='Invalid command.  Example:  segment a1 m ';
         taint_flag=0;
      else
         disp('Locate a position on the plot with the mouse.');
         x_position=mark_x_position;
         x_position=round(x_position * 1000);  % seconds to milliseconds

         segstring=['segment' segment_ab];
         set(findobj('Tag',segstring),'String',x_position);
         response=['segment ' segment_ab ' ' num2str(x_position)];        
      end;

   % the GUI or the user can set a segment lower or upper window independently         
   elseif strncmp(lparams,'a1',2)
      [dummy,segment_value]=strtok(lparams);  
      set(findobj('Tag','segmenta1'),'String',segment_value);
   elseif strncmp(lparams,'a2',2)
      [dummy,segment_value]=strtok(lparams);  
      set(findobj('Tag','segmenta2'),'String',segment_value);         
   elseif strncmp(lparams,'b1',2)
      [dummy,segment_value]=strtok(lparams);  
      set(findobj('Tag','segmentb1'),'String',segment_value);         
   elseif strncmp(lparams,'b2',2)
      [dummy,segment_value]=strtok(lparams);  
      set(findobj('Tag','segmentb2'),'String',segment_value);         

   % looks like both segement windows are being set together
   else   % Using the format for absolute units 
      [segment_ab,segment_window]=strtok(lparams);  % decode (example "seg a -450 -200")
      [low,high]=strtok(segment_window);   % try to extract the two numbers
      if ischar(low) && ischar(high)
         low_value=str2double(low);
         high_value=str2double(high);
      else
         low_value=[];
         high_value=[];
      end;
      % validity check
      if ~isempty(low_value) && ~isempty(high_value) && ~isnan(low_value) && ~isnan(high_value)
         switch segment_ab 
            case 'a'
               set(findobj('Tag','segmenta1'),'String',num2str(low_value));
               set(findobj('Tag','segmenta2'),'String',num2str(high_value));               
            case 'b'
               set(findobj('Tag','segmentb1'),'String',num2str(low_value));
               set(findobj('Tag','segmentb2'),'String',num2str(high_value));               
            otherwise
               response='Invalid segment command. Example of valid command:  seg a 350 450 ';
               taint_flag=0;
         end;
      else
         response='Invalid segment command. Example of valid command:  seg a 350 450 ';
         taint_flag=0;
      end;      
   end;
   
   if taint>=50 && taint_flag && get(findobj('Tag','segments_on_off'),'Value')
      old_plot(opn,0);     
   end;
   
% set command has its own processing
elseif strncmp(cmd,'set',3)
   if strncmp(cmd,'setenv',6)   % process setenv
      if isempty(lparams)
         environment    % no semicolon here
      else
         good=nsetenv(c);  % must use "c"
         if good==0
            response= ' environmental variable not recognized';
         elseif good==2
            response= ' this environmental variable is no longer used';
         end; % if good
      end; %if isempty
   else % if setenv
        response=set_process_command(params);
   end;
   
% interpret a dos batch file
elseif strncmp(cmd,'batch',3)
   status=batch(params);
   
elseif strncmp(cmd,'type',3)
   eval(c,'disp(''File not found or could not be opened'')');
   response='';
   
elseif strncmp(cmd,'thin',3)
   response='thinning no longer necessary';
elseif strncmp(cmd,'resolution',3)
   response='resolution no longer necessary';
   
elseif strncmp(cmd,'display',3)
   disp_list=number_range_list(params);
   if strcmp(disp_list,'@')
      response='improper display list';
   else
      set(findobj('Tag','displays'),'String',['[' disp_list ']']);
   end;
elseif strncmp(cmd,'errorlevel',3)
   if isempty(lparams)
      if debugs==1
         response='error level is debug';
      elseif warnings==1
         response='error level is warning';
      elseif errors==1
         response='error level is serious';
      else
         response='error level is fatal';
      end;  
   elseif strncmp(lparams,'fatal',3)
      errors=0;
      warnings=0;
      debugs=0;
      quietly=0;
   elseif strncmp(lparams,'serious',3)
      errors=1;
      warnings=0;
      debugs=0;
      quietly=1;
   elseif strncmp(lparams,'warning',3)
     errors=1;
     warnings=1;
     debugs=0;
     quietly=0;
   elseif strncmp(lparams,'debug',3)
     errors=1;
     warnings=1;
     debugs=1;
     quietly=0;
   end;
   
elseif strncmp(cmd,'walk',4)
   walk=1;
   speed=str2double(params);
   if ~isempty(speed) && ~isnan(speed)
      if speed > 0
         walk_speed=speed;
      end;
   end;
   
elseif strncmp(cmd,'makdat',4) || strncmp(cmd,'makedat',4)
   if isempty(params)
      response='Command: makdat <listfile> <outputfile> -<options>';
   else   
      [list_file,rem]=strtok(params); % list file is always first
      options_start=findstr(rem,'-'); % look for an option list  
      option_list='';
      output_file='';
      if options_start
         if length(rem) > options_start
            option_list=rem(options_start+1:end);
         end;
         if options_start > 1
            output_file=strtrim(rem(1:options_start-1));
         end;
      else
         output_file=strtrim(rem);
      end;
      makdat(list_file,output_file,option_list);
   end;
elseif strncmp(cmd,'version',3)
   response=['Version ' matoff_version];
elseif strncmp(cmd,'plot',3)
%  get the figure number of the plot 
   opn=str2double(params);
   if isempty(opn);  % no number entered, see if the menu item has a valid number
      opn=str2double(get(findobj('Tag','oldplotnumber'),'String'));
   end;
   if isempty(opn) || isnan(opn)  % if menu did not have a useful number, give up
      response='Nothing to plot';
   else
      response=store_plot(opn);
   end;
   
elseif strncmp(cmd,'print',3)
   [dummy,value,valid]=check_string_value(params,1,20000);
   if isempty(params)
      response=print_plot(opn);
   elseif valid
      response=print_plot(value);
   else  % must be a print property
      [dummy,pproperty]=strtok(lparams);   % get property
      last_param=lower(strtrim(pproperty));  
      if strncmp(lparams,'orientation',3)
         if strncmp(last_param,'landscape',3)
            set(findobj('Tag','print_orientation'),'Value',1);
         elseif strncmp(last_param,'portrait',3)
            set(findobj('Tag','print_orientation'),'Value',2);
         else
            response='Invalid print orientation. Use: landscape or portrait.';
         end;
      elseif strncmp(lparams,'papertype',3)
         if strncmp(last_param,'letter',3)
            set(findobj('Tag','print_paper'),'Value',1);
         elseif strncmp(last_param,'legal',3)
            set(findobj('Tag','print_paper'),'Value',2);
         elseif strncmp(last_param,'a4',2)
            set(findobj('Tag','print_paper'),'Value',3);
         else
            response='Invalid print paper type. Use: legal, letter, or A4.';
         end;
      else
         response='Unrecognized print property. Use: orientation or papertype.';
      end;
   end;

   
elseif strncmp(cmd,'erase',3)
%  clear the current figure or other figure (optional figure number) 
   opn=str2double(params);
   if isempty(opn);  % no number entered, see if the menu item has a valid number
      opn=str2double(get(findobj('Tag','oldplotnumber'),'String'));
   end;
   if isempty(opn) || isnan(opn)   % if menu did not have a useful number, give up
      response='No plot';
   else
      figure(opn);
      clf;
   end;
   
elseif strncmp(cmd,'hair',2)
   disp('Locate a position on the plot with the mouse.');
   x_position=mark_x_position;
   x_position=round(x_position * 1000);  % seconds to milliseconds
   response=[num2str(x_position) ' milliseconds'];
   
elseif strncmp(cmd,'time',2)  
   a=fix(clock);
   time=sprintf('%02d:%02d:%02d',a(4),a(5),a(6));
   now_time=clock;
   elapse_time=etime(now_time,start_time);  % in seconds
   mins=fix(elapse_time/60);
   secs=round(mod(elapse_time,60));
   elapsed=sprintf('%d min, %d sec',mins,secs);
   response=[time '     elapsed time: ' elapsed];

elseif strncmp(cmd,'date',3)
   response=date;


elseif strncmp(cmd,'append',3)
   if isempty(params)
      response='Missing file name.';
   else
      asciifilename=filepath(params,'.');
      if strcmp(asciifilename,'<')
         response='Illegal file name.';
      else  
         filename=fopen(fid.asciifile);  % is there an ascii file already open?
         if ~isempty(deblank(filename))
            response='An ASCII file currently open, close it first.'; 
         else
            response='File opened.';
            fid.asciifile=fopen(asciifilename,'at');  % non-destructive open
            if fid.asciifile < 0
               response='Error opening or creating file.';
               fid.asciifile = -1;
            end;
         end; % if ~isempty(filename
      end; % if strncmp(asciifilename,'
   end; % if isempty (params)
   
elseif strncmp(cmd,'open',3)
   if isempty(params)
      response='Missing file name';
   else
      asciifilename=filepath(params,'.');
      if strcmp(asciifilename,'<')
         response='Illegal file name';
      else  
         filename=fopen(fid.asciifile);  % was there an ascii file already open?
         if ~isempty(deblank(filename))
            fclose(fid.asciifile); % yes, close it
            response='An output file was open.  Closing it and opening a new file.'; 
         else
            response='New output file opened.';
         end;
         fid.asciifile=fopen(asciifilename,'wt');  % destructive open
         if fid.asciifile < 0
            response='Error creating new file.';
            fid.asciifile = -1;
         end;
      end; % if strncmp(asciifilename,'
   end; % if isempty (params)   
   
elseif strncmp(cmd,'write',3)
   filename=fopen(fid.asciifile);  % is there an ascii file open?
   if isempty(deblank(filename))
      response='No output file open. Cannot write.'; 
   else
      fprintf(fid.asciifile,'%s\n',params);
   end;

elseif strncmp(cmd,'close',3)
   if isempty(lparams)
      filename=fopen(fid.asciifile);  % is there an ascii file open?
      if ~isempty(deblank(filename))
         fclose(fid.asciifile);
         fid.asciifile=-1;
         response='Closing ascii file.'; 
      else
         response='Closing (input) data file';
         work_file(1);  % close files
         set(findobj('Tag','filename'),'String','');  % clear file name
         set(findobj('Tag','trialsfound'),'String','0');  % clean up GUI
         unit_list=' ';
         set(findobj('Tag','unit'),'Value',1);
         set(findobj('Tag','unit'),'String',unit_list); 
         taint=10;      
      end;
   elseif strncmp(lparams,'ascii',3)
      filename=fopen(fid.asciifile);  % is there an ascii file open?
      if ~isempty(deblank(filename))
         fclose(fid.asciifile);
         fid.asciifile=-1;
         response='Closing ascii file.';    
      else
         response='No ascii file open.';
         fid.asciifile=-1;
      end;
   elseif strncmp(lparams,'datafile',3)
      response='Closing (input) data file';
      work_file(1);  % close files
      set(findobj('Tag','filename'),'String','');  % clear file name
      set(findobj('Tag','trialsfound'),'String','0');  % clean up GUI
      unit_list=' ';
      set(findobj('Tag','unit'),'Value',1);
      set(findobj('Tag','unit'),'String',unit_list);      
      taint=10;  
   elseif strncmp(lparams,'append',3)   % carefully close all "set process append" files
      try 
        fclose(fid.histogram); 
        fid.histogram=-1;  
      catch  
      end;
      try 
        fclose(fid.mwu); 
        fid.mwu=-1;  
      catch  
      end;
      try 
        fclose(fid.plot); 
        fid.plot=-1;  
      catch  
      end;
      try 
        fclose(fid.epochstats); 
        fid.epochstats=-1;  
      catch  
      end;

      try 
        fclose(fid.segmentstats); 
        fid.segmentstats=-1;  
      catch  
      end;
      try 
        fclose(fid.sortvalues); 
        fid.sortvalues=-1;  
      catch  
      end;
      try 
        fclose(fid.events); 
        fid.events=-1;  
      catch  
      end;
   end;

elseif strncmp(cmd,';',1)    % comment
   response='';
elseif strncmp(cmd,'edit',4)  
   eval(['!' environment.editor ' ' params]);
   
elseif strncmp(cmd,'found',3)  
   event_list=events_found;
   if isempty(event_list)
       response='No trials found';
   else
      cols=size(event_list,2);
      fprintf(1,'  Qty     Sequence\n');
      if environment.logging==1
         fprintf(fid.log,'  Qty     Sequence\n');
      end;
      for r=1:size(event_list,1)
         % print a row
         fprintf(1,' %3d      ',event_list(r,1));
         if environment.logging==1
            fprintf(fid.log,' %3d      ',event_list(r,1));
         end;
         for c=2:cols       
            fprintf(1,'%d  ',event_list(r,c));
            if environment.logging==1
               fprintf(fid.log,'%d  ',event_list(r,c));
            end;
         end;
         fprintf(1,'\n');
         if environment.logging==1
            fprintf(fid.log,'\n');
         end;
      end;
   end;
   
elseif strncmp(cmd,'env_edit',8)
   % always kill the existing occurance of the environment editing menu
   if ~isempty(findobj('Tag','environmentmenu'))
      close(findobj('Tag','environmentmenu'));
   end;
   % now start a new instance
   environment_menu;
   % load current environment variable onto it.
   env_menu_load;
elseif strncmp(cmd,'mak_edit',8)
   % always kill the existing occurance of the Makdat menu
   if ~isempty(findobj('Tag','makdatmenu'))
      close(findobj('Tag','makdatmenu'));
   end;
   % now start a new instance
   makdat_menu;   
   
   
elseif strncmp(cmd,'mwfiles',3)
   if isempty(params)
      response='Missing file name';   % check for any file name
   else
      [afilename,bfilename]=strtok(params);
      bfilename=strtrim(bfilename);
      response=mwfiles(afilename,bfilename);   % handle remaining errors here
   end;  % first missing file name



   
elseif strncmp(cmd,'text',3)
   stnum=num2str(current_text_line);
   taint_flag=1;
   if strncmp(lparams,'line',3)
      [dummy,line_number]=strtok(params);
      [dummy,value,valid]=check_string_value(line_number,1,9);
      if ~valid
         response='Bad text line number. Use a value of 1 to 9';
      else
         current_text_line=value;
      end;
   elseif strncmp(lparams,'show',3) 
      set(findobj('Tag','text_on_off'),'Value',1);
   elseif strncmp(lparams,'noshow',3) 
      set(findobj('Tag','text_on_off'),'Value',0);
   elseif strncmp(lparams,'on',2)
      set(findobj('Tag',['text' stnum '_on_off']),'Value',1);
   elseif  strncmp(lparams,'off',3)
      set(findobj('Tag',['text' stnum '_on_off']),'Value',0);
   elseif strncmp(lparams,'pos',1)  % accept both xpos and ypos
      [dummy,pos]=strtok(params);
      pos=strrep(pos,',',' ');
      [xpos,ypos]=strtok(pos);
      [xpos,dummy,xvalid]=check_string_value(xpos,-120,120);
      [ypos,dummy,yvalid]=check_string_value(ypos,-50,120);
      if xvalid && yvalid
         set(findobj('Tag',['text' stnum '_x_pos']),'String',xpos);
         set(findobj('Tag',['text' stnum '_y_pos']),'String',ypos);
      else
         response='Invalid position values. Use: "text pos x,y"  x and y between -100 and +100';
      end;   
   elseif strncmp(lparams,'xpos',1)
      [dummy,xpos]=strtok(params);
      [xpos,dummy,valid]=check_string_value(xpos,-120,120);
      if valid     
         set(findobj('Tag',['text' stnum '_x_pos']),'String',xpos);
      else
         response='Invalid x position value. Use -120 to 120.';
      end;
   elseif strncmp(lparams,'ypos',1)
      [dummy,ypos]=strtok(params);
      [ypos,dummy,valid]=check_string_value(ypos,-50,120);
      if valid     
         set(findobj('Tag',['text' stnum '_y_pos']),'String',ypos);
      else
         response='Invalid y position value. Use -50 to 120.';
      end;
   elseif strncmp(lparams,'frame',1)
      [dummy,on_off]=strtok(params);
      on_off=lower(strtrim(on_off));
      if strncmp(on_off,'on',2)
         set(findobj('Tag',['text' stnum '_frame']),'Value',1);
      elseif  strncmp(on_off,'off',3)
         set(findobj('Tag',['text' stnum '_frame']),'Value',0);
      else
         response='Text frame must be either On or Off';
      end;
   elseif strncmp(lparams,'angle',2)
      [dummy,ang]=strtok(params);
      [dummy,value,valid]=check_string_value(ang,-90,90);
      switch value
      case 0
         item=1;
      case 45
         item=2;
      case 90
         item=3;
      case -45
         item=4;
      case -90
         item=5;
      otherwise
         item=1;
         response='Invalid font angle. Using 0 degrees.  Options are: -90,-45,0,45,90';
      end;   
      set(findobj('Tag',['text' stnum '_angle']),'value',item); 

   elseif strncmp(lparams,'size',2)
      [dummy,asize]=strtok(params);
      [asize,value,valid]=check_string_value(asize,1,120);
      if valid     
         set(findobj('Tag',['text' stnum '_size']),'String',asize);
      else
         response='Invalid font size. Use 1 to 100 points.';
      end;  
   elseif strncmp(lparams,'color',2) 
      [dummy,tcolor]=strtok(params);
      tcolor=strtrim(tcolor);
      switch tcolor
      case {'black','k'}
         item=1;
      case {'blue','b'}
         item=2;
      case {'green','g'}
         item=3;
      case {'red','r'}
         item=4;
      case {'cyan','c'}
         item=5;
      otherwise
         item=0;
         response='Invalid color. Use: black,blue,green,red,cyan or k,b,g,r,c';  
      end;
      if item > 0
         set(findobj('Tag',['text' stnum '_color']),'value',item);
      end;
   elseif strncmp(lparams,'string',2) 
      [dummy,tstring]=strtok(params);
      set(findobj('Tag',['text' stnum '_string']),'String',tstring);    
   else
      response='Unrecognized parameter. Valid parameters: on,off,string,pos,xpos,ypos,size,angle';
      taint_flag=0;
   end;
   if auto_update && taint_flag
      if process      
         old_plot(opn,0);  % plot if trials found
      end;
   end;      
   
elseif strncmp(cmd,'menuposition',4)
   filename='';
   [option,rem]=strtok(lparams);                    % get 'save' or 'load' in lower case
   [filename,rem]=strtok(rem);                      % get file name in lower case
   if isempty(deblank(filename))
        response='File name missing. Try: menuposition save <file> or menuposition load <file>';
   else
       filename=strtrim(filename);      % lop off spaces
       filename=filepath(filename,environment.defaultpath);  % prepend path
       if strncmp(option,'save',3) 
          save_menu_positions(filename);
       elseif strncmp(option,'load',3)
          if load_menu_positions(filename)==0
               response='Error loading menu position file';
          end;
       else
          response='Unrecognized parameter. Try: menuposition save <file> or menuposition load <file>';

       end;
    end;

elseif strncmp(cmd,'mgplx2ctx',4)
   [vmajor,vminor]=strtok(version,'.');
   vnumber=str2num([vmajor vminor(1:2)]);
   if vnumber >= 6.5
      try
         mgplx2ctx;
      catch
         fprintf(1,'mgplx2ctx program not found; make sure it is in the PATH.');
         if environment.logging==1
            fprintf(fid.log,'mgplx2ctx program not found; make sure it is in the PATH.');
         end;
      end;
   else
      response='mgplx2ctx cannot run; it requires MATLAB R13 (v6.5) or later';
   end;

elseif strncmp(cmd,'cortexexplorer',4)
   [vmajor,vminor]=strtok(version,'.');
   vnumber=str2num([vmajor vminor(1:2)]);
   if vnumber >= 6.5
      try
         CortexExplorer;
      catch
         fprintf(1,'CortexExplorer program not found; make sure it is in the PATH.');
         if environment.logging==1
            fprintf(fid.log,'CortexExplorer program not found; make sure it is in the PATH.');
         end;
      end;
   else
      response='CortexExplorer cannot run. It requires MATLAB R13 (v6.5) or later';
   end;

elseif strncmp(cmd,'why',3)
   response=why(lparams);

elseif strncmp(cmd,'invalid',4)
   if strncmp(lparams,'spike',2) 
      [dummy,tcolor]=strtok(params);
      [dummy,tcolor]=strtok(tcolor);
      tcolor=strtrim(tcolor);
      switch tcolor
         case {'yellow','y'}
            item=1;
         case {'magenta','m'}
            item=2;
         case {'cyan','c'}
            item=3;
         case {'red','r'}
            item=4;
         case {'green','g'}
            item=5;         
         case {'blue','b'}
            item=6;
         case  {'white','w'}
            item=7;
         case {'black','k'}
            item=8;
         otherwise
            item=0;
            response='Invalid color. Use: yellow,magenta,cyan,red,green,blue,white,black or y,m,c,r,g,b,w,k';  
      end; % switch
         if item > 0
            set(findobj('Tag','invalid_spike_color'),'value',item);
         end; % if item
    else
       response='did not recognize invalid spike color command';
    end;

elseif strncmp(cmd,'validatespikes',4)
   if strncmp(lparams,'start',3) 
      [dummy,start_class]=strtok(lparams);   % get starting class number
      [dummy,start_class,valid]=check_string_value(start_class,1,2000);  % allow classes over 2000 ?
      if ~valid
         response='start class number must be between 1 and 2000.' ;
      else
         set(findobj('Tag','valid_spikes_start_class'),'String',num2str(start_class));
      end     
   elseif strncmp(lparams,'end',3) 
      [dummy,end_class]=strtok(lparams);   % get ending class number
      [dummy,end_class,valid]=check_string_value(end_class,1,2000);  % allow classes over 2000 ?
      if ~valid
         response='end class number must be between 1 and 2000.' ;
      else
         set(findobj('Tag','valid_spikes_end_class'),'String',num2str(end_class));
      end     
   elseif strncmp(lparams,'on',2) 
      set(findobj('Tag','validate_spikes_on_off'),'Value',1);
   elseif strncmp(lparams,'off',2)
      set(findobj('Tag','validate_spikes_on_off'),'Value',0);
   elseif strncmp(lparams,'color',2) 
      [dummy,tcolor]=strtok(params);
      tcolor=strtrim(tcolor);
      switch tcolor
         case {'yellow','y'}
            item=1;
         case {'magenta','m'}
            item=2;
         case {'cyan','c'}
            item=3;
         case {'red','r'}
            item=4;
         case {'green','g'}
            item=5;         
         case {'blue','b'}
            item=6;
         case  {'white','w'}
            item=7;
         case {'black','k'}
            item=8;
         otherwise
            item=0;
            response='Invalid color. Use: yellow,magenta,cyan,red,green,blue,white,black or y,m,c,r,g,b,w,k';  
      end; % switch
         if item > 0
            set(findobj('Tag','invalid_spike_color'),'value',item);
         end; % if item
    else
       response='did not recognize option';
    end;







   
%----------------------------------------------   
% default response for unrecognized command
%----------------------------------------------
else
   response=metafile(cmd,params);
end

if walk
   if walk_count < walk_speed
      walk_count=walk_count+1;
   else
      walk_count=0;
      r = input('--- WALK  <cr> for next step, <f> faster, <s> slower, <q> to quit walking   ','s') ;
      switch r
      case 'f'
         walk_speed=walk_speed+5;
      case 's'
         walk_speed=walk_speed-5;
         if walk_speed < 1
            walk_speed=1;
         end;
      case 'q'
         walk=0;
      end; % switch
   end; % if walk_count
end; % if walk


%  END
