function [values]=find_class_value(trials,class)
%  Return a list of class values given a class and a list of trials.
%   NaNs are inserted for trials with no values
%  (Special user function)
% 
%  Inputs
%    trials      list of trials to look up
%    class       class to look up
%  Outputs
%    values      one-to-one match with trials list,
%   
%    history(n).class            class 
%              .trial_list       = [] string array of trial numbers that belong in this class, sorted 
%              .values           = [] array of matching class values for each trial
%
global history
global error_fid warning_fid debug_fid
global errors warnings debugs


values=[];
if debugs
   fprintf(debug_fid,'Debug [find_class_value]. Finding values for class %d.\n',class);
end

if find(trials < 1)
   if warnings
      fprintf(warning_fid,'Warning [find_class_value]. User is requesting trial numbers less than 1\n');
   end
end

if class < 1
   if errors
      fprintf(error_fid,'Error [find_class_value]. User requested illegal class number.\n');
   end
   return;
end

if isempty(history)
   if debugs
      fprintf(debug_fid,'Warning [find_class_value]. History is empty.\n');
   end
   return;
end    

nonans=1;
for c=1:length(history)
   if history(c).class==class
      % extract list of trials in this class
      classtrials=expand_range_list(history(c).trial_list);  
      for i=1:length(trials)
         tpos=find(classtrials==trials(i));
         if isempty(tpos)
            values=[values NaN];
            if debugs && nonans
               nonans=0;
               fprintf(debug_fid,'Debug [find_class_value]. One or more values returned for class %d are NaNs\n',class);
            end
         else
            values=[values  history(c).values(tpos)];
         end
      end
      break;
   end % if history(c)
end % c=1:length(history)
