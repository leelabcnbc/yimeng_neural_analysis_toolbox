function [history_data]=list_history_data
%  Return an array of history data stored by the history data command.
%  (Special user function)
% 
%  Inputs
%    none
%  Outputs
%    list        list of numbers or characters left in memory by the History data command
%                
%
global error_fid warning_fid debug_fid
global errors warnings debugs


history_data=get(findobj('Tag','historyfile'),'UserData'); 

if debugs
   if isempty(history_data)
      fprintf(debug_fid,'Debug [list_history_data]. Data array is empty\n');
%   else
%      fprintf(debug_fid,'Debug [list_history_data]. %d data elements found.\n',length(history_data));
   end;
end;

