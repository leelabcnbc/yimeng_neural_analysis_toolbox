function [success]=logfile_write(logstring)

% write a string to the currently-open log file
% appends a new-line after the string is written
% returns with a 0 if no log file is option, otherwise returns with a 1

global environment fid

if environment.logging==0 
   success=0;
   return;
else
   fprintf(fid.log,'%s\n',logstring);
   success=1;
   return;
end
