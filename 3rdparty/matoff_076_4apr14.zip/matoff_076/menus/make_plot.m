function [response]=make_plot(handles,overplot)
%    Create a plot based on layout parameters.  This is the main plotting
%    program and is responsible for each type of plot.
%    The 'figure' command must be executed before entering this routine.
%    This routine also assumes 'map' has been run.
%
% Inputs
%    handles     array [main_handle,left_handle,right_handle,bottom_handle]
%                these are locations on the page  
%    overplot    0 = new axes created (old data distroyed)
%                1 = plot on top of existing figure
% Outputs
%    response    1 if no problem, otherwise 0
% Globals modified
%
global plot_number taint environment fid
global spiketrials set_process time_zero
global super_handle plot_area_handle main_handle
global error_fid warning_fid debug_fid
global errors warnings debugs 
global work_trial_list work_analog_start
global RESCALE_TIME ANALOG_RANGE
global valid_spikes_times

RESCALE_TIME=10000; % converts time stamps from .1ms to seconds
%  no longer used  ANALOG_RANGE=1023;  % range of A/D values 

response=1;
if taint < 50
    if warnings
        fprintf(warning_fid,'Warning [make_plot]. Must map data before plotting.\n');
    end;
    response=0;
    return;
end;

main_handle=handles(1);
left_handle=handles(2);
right_handle=handles(3);
bottom_handle=handles(4);
super_handle=handles(5);
plot_area_handle=handles(6);

freq=str2double(get(findobj('Tag','frequency'),'String'));

if get(findobj('Tag','hide_plot'),'Value')
    set(gcf,'Visible','off');
else
    set(gcf,'Visible','on');
end;


set(super_handle,'Visible','off');
set(plot_area_handle,'Visible','off');
set(left_handle,'Visible','off');
set(right_handle,'Visible','off');
set(bottom_handle,'Visible','off');
set(main_handle,'Visible','on');
set(gcf,'CurrentAxes',main_handle);


% Calculate x axis min and max. Multiply by 10 to match arrays (.1 ms resolution)
% set up time scale (x axis)
x_at_zero=get(findobj('Tag','xatzero'),'Value');  % forces time scale to have zero on left
shift=str2double(get(findobj('Tag','shift'),'String'));
window=str2double(get(findobj('Tag','window'),'String'));
start_time=10 * (-(window/2)+shift) / RESCALE_TIME;   % convert to seconds
end_time= 10 * ((window/2)+shift) / RESCALE_TIME;     % convert to seconds
if x_at_zero
    xzero=start_time;  % seconds
    end_time=end_time-start_time;
    start_time=0;
else
    xzero=0;
end;
time_span=end_time-start_time;
if overplot==0
   axis([start_time end_time 0 1]);
end;
axis manual;
hold on;

if get(findobj('Tag','hidexaxis'),'Value')==1       % hide x axis on plot?
    current_color=get(gca,'Color');
    set(gca,'XColor',current_color);    % make invisible by making it the background color
else
    set(gca,'XColor','k');   % black is the default
end; 

if debugs
    fprintf(debug_fid,'Debug [make_plot]. Sorting trials.\n');
end;

% sorted_trial_list will be the ordered list of trials to analyze based on the SORT and TRIALS commands
if ~isempty(work_trial_list)
    % fetch list of trials based on sorting criteria, reorder list starting from 1
    % "sort_trials" uses the GUI TRIALS list to help choose which trials to include
    %     unsorted_trial_list=work_trial_list-work_trial_list(1)+1;
    %     sorted_trial_list=sort_trials(unsorted_trial_list);  % fetch list of trials based on sorting criteria
    sorted_trial_list=sort_trials;  % fetch list of trials based on sorting criteria
    if get(findobj('Tag','sort_reverse_on_off'),'Value')  % reverse trial order?
        sorted_trial_list=sorted_trial_list(end:-1:1);
    end;
    low_trial=1;
    high_trial=max(sorted_trial_list);  % highest sorted trial number
    % rescaled time stamps
    if ~isempty(spiketrials)
        raster_timestamps=(spiketrials(:,2)/RESCALE_TIME)-xzero;
    else
        raster_timestamps=[0 0];
    end;
else
    sorted_trial_list=[];
    low_trial=1;  high_trial=1;
    raster_timestamps=[0 0];
    if warnings
        fprintf(warning_fid,'Warning [make_plot]. No trials to plot.\n');
    end;
    return;
end;


if debugs
    fprintf(debug_fid,'Debug [make_plot]. trial_list length after sorting = %d\n',length(sorted_trial_list));
end;

% This basic raster information is required for Raster, EpochStats

% segments
sega_low=str2double(get(findobj('Tag','segmenta1'),'String'));
sega_high=str2double(get(findobj('Tag','segmenta2'),'String'));
segb_low=str2double(get(findobj('Tag','segmentb1'),'String'));
segb_high=str2double(get(findobj('Tag','segmentb2'),'String'));


seg_scale=1000;

if debugs
    fprintf(debug_fid,'Debug [make_plot]. Segment values: A:%d  %d  B:%d   %d\n' ... 
        ,sega_low,sega_high,segb_low,segb_high);
end;

if debugs
    fprintf(debug_fid,'Debug [make_plot]. Start drawing each graphics element.\n');
    if isempty(spiketrials)
        fprintf(debug_fid,'Debug [make_plot]. spiketrials is empty!\n');
    end;
end;

% ======== Rasters ===============

if get(findobj('Tag','raster_on_off'),'Value')   % plot rasters: spikes, marks, spots
    if ~plot_raster(raster_timestamps,sorted_trial_list,xzero)
        if warnings
            fprintf(warning_fid,'Warning [make_plot]. Error during plot, aborting.\n');
        end;
        response=0;
        return;   % abort if a problem occurs during raster plot
    end;
end; 


% ===== Centerline ============

if get(findobj('Tag','centerline_on_off'),'Value')
    style_list=get(findobj('Tag','centerline_style'),'String');   % get list of options
    style_choice=get(findobj('Tag','centerline_style'),'value');  % pointer to chosen option
    style_name=deblank(style_list(style_choice,:));
    style='-k';  % default
    if (strcmp(style_name,'solid'))
        style='-k';
    elseif(strcmp(style_name,'dot'))
        style=':k';
    elseif(strcmp(style_name,'dash'))
        style='--k';
    elseif(strcmp(style_name,'red'))
        style='-r';
    elseif(strcmp(style_name,'blue'))
        style='-b';
    elseif(strcmp(style_name,'green'))
        style='-g';
    elseif(strcmp(style_name,'cyan'))
        style='-c';
    end;
    
    ypos=str2double(get(findobj('Tag','centerline_y_pos'),'String'))/ 100;
    centerline_size=str2double(get(findobj('Tag','centerline_size'),'String'))/ 100;
    raster(1,1,-xzero,ypos,1,centerline_size,style);
end;

% ======== Segment markers ===============


if get(findobj('Tag','segments_on_off'),'Value')
    if debugs
        fprintf(debug_fid,'Debug [make_plot]. Drawing segment markers\n');
    end;
    raster(1,1,sega_low/seg_scale,0,1,1,'--r');
    raster(1,1,sega_high/seg_scale,0,1,1,':r');
    raster(1,1,segb_low/seg_scale,0,1,1,'--g');
    raster(1,1,segb_high/seg_scale,0,1,1,':g');
end;


% ======== sort range markers ===============


sort_menu_item=get(findobj('Tag','trialsort'),'value');
switch sort_menu_item
    case {1,2,3,5,11,13}  % off, center, time, epoch, zero, history
        range_name='';
    case 4  % pulse
        range_name='pulse';
    case 6  % delta
        range_name='delta';
    case 7  % min
        range_name='min';    
    case 8  % max
        range_name='max';      
    case 9 % peak
        range_name='peak';    
    case 10  % pit
        range_name='pit';
    case 12   % integral
        range_name='int';   

end;

if get(findobj('Tag','sortrangeshow'),'Value') && ~isempty(range_name)
    if debugs
        fprintf(debug_fid,'Debug [make_plot]. Drawing sort range markers for %s\n',range_name);
    end;
    sort_low=str2double(get(findobj('Tag',[range_name 'sortrange1']),'String'));
    sort_high=str2double(get(findobj('Tag',[range_name 'sortrange2']),'String'));
    raster(1,1,sort_low/seg_scale,0,1,1,'--b');
    raster(1,1,sort_high/seg_scale,0,1,1,':b');
end;


% ===== Heading ============
if get(findobj('Tag','heading_on_off'),'Value')
    heading_x=str2double(get(findobj('Tag','heading_x_pos'),'String'));
    hy=str2double(get(findobj('Tag','heading_y_pos'),'String'));
    fs=str2double(get(findobj('Tag','heading_size'),'String'));
    if ~isempty(heading_x) && ~isempty(hy) && ~isempty(fs)
        hx=start_time + ((time_span)* heading_x / 100);  % percent of full scale
        hy=1-(hy/100);
        heading_text(hx,hy,fs);
    else
        if warnings
            fprintf(warning_fid,'Warning [make_plot]. Invalid heading x,y value.\n');
        end;
    end;
    
end;

segment_limits=[sega_low/seg_scale,sega_high/seg_scale,segb_low/seg_scale,segb_high/seg_scale,high_trial,low_trial];

% ======== show or keep SegmentStats ===============

if isempty(findstr(set_process.segmentstats,'noshow')) || isempty(findstr(set_process.segmentstats,'nokeep'))
    show_segmentstats(raster_timestamps,sorted_trial_list,segment_limits);
end; 


% ======== show or keep EpochStats ===============

if isempty(findstr(set_process.epochstats,'noshow')) || isempty(findstr(set_process.epochstats,'nokeep'))
    show_epochstats(raster_timestamps,sorted_trial_list,high_trial);
end;


% ======== show or keep SortValues ===============

if isempty(findstr(set_process.sortvalues,'noshow')) || isempty(findstr(set_process.sortvalues,'nokeep'))
    show_sortvalues(sorted_trial_list,high_trial);
end;

% ======== show or keep mwu ===============

if isempty(findstr(set_process.mwu,'noshow')) || isempty(findstr(set_process.mwu,'nokeep'))
    show_mwu(raster_timestamps,sorted_trial_list,segment_limits);
end; 


% ======== show or keep events ===============
if isempty(findstr(set_process.events,'noshow')) || isempty(findstr(set_process.events,'nokeep'))
   show_events(raster_timestamps,sorted_trial_list,high_trial);
end;


% ======== Plot Analog (raw, dx/dt, and average) ===============

analog_tag={'';'2';'undefined';'undefined'};  % string tags used to id analog channel option of the GUI

plot_analog(char(analog_tag(1)),xzero,sorted_trial_list); % first_analog_channel
plot_analog(char(analog_tag(2)),xzero,sorted_trial_list);  % second analog


% ======== Plot Analog X-Y ===============

if get(findobj('Tag','xy_on_off'),'Value') 
    plot_analog_xy(xzero,sorted_trial_list,handles);      % X-Y plot
end;

% ===== Histogram ============

if get(findobj('Tag','histogram_on_off'),'Value')&& ~isempty(sorted_trial_list)
   plot_histogram(start_time,end_time,xzero,raster_timestamps,sorted_trial_list,segment_limits);
end;

% ===== RIP ============

if get(findobj('Tag','RIP_on_off'),'Value') && ~isempty(sorted_trial_list)
    if debugs
        fprintf(debug_fid,'Debug [make_plot]. Plotting RIP.\n');
    end;
    
    if warnings
        fprintf(debug_fid,'Warning [make_plot]. RIP not yet supported.\n');
    end;
       %subplot(graphs_per_page,1,next_graph_number);
       %next_graph_number=next_graph_number+1;
       
       %axis([start_time end_time 0 40]);
       %axis manual;
       %hold on;
       
       % RIP PLOT COMMAND HERE SOMEDAY
end;


% ========== Text =============
if debugs
    fprintf(debug_fid,'Debug [make_plot]. Plotting Text.\n');
end;

if get(findobj('Tag','text_on_off'),'value')   % check for Text Show
    plot_text;  %  provide x scaling to plot subroutine
end;


if debugs
    fprintf(debug_fid,'Debug [make_plot]. Plot done.\n');
end;








% ==================================================================================== %
%               	              PLOT ROUTINES
% ==================================================================================== %




% ------------------------------------------------- %
%          RASTERS, MARKS & SPOTS
% ------------------------------------------------- %

function [safe_flag]=plot_raster(raster_timestamps,sorted_trial_list,xzero)
%
% Plot rasters, marks, and spots
%
% Output
%   safe_flag    0 = don't continue with make_plot, the statistic might screw up.
%                1 = ok
%
%  globals changed
%       valid_spikes_times
%
global valid_spikes_times
global spiketrials event_codes event_times
global time_zero work_trial_list selected_unit_trials
global RESCALE_TIME
global error_fid warning_fid debug_fid trace_fid
global errors warnings debugs 
%
safe_flag=1;
mark_spot_offset= -.0 ;  % controls vertical position of the mark and spot relative to the raster
if debugs
    fprintf(debug_fid,'Debug [make_plot]. Drawing rasters.\n');
end
mark=str2double(get(findobj('Tag','mark'),'String'));


% Build matrix to Validate spikes
% Create a two-column matrix of valid spike times. Each row is an unsorted
% trial; the two columns are start and end of the time window in which spikes
% are valid. Two classes are used (start_time and stop_time). The classes must be in the 
% range 1 to 10,000.
if get(findobj('Tag','validate_spikes_on_off'),'Value')
   if debugs
       fprintf(debug_fid,'Debug [make_plot]. Validating spikes.\n');
   end
   [clean_string,startclass,valid1]=check_string_value(get(findobj('Tag','valid_spikes_start_class'),'String'),1,1000);
   [clean_string,endclass,valid2]=check_string_value(get(findobj('Tag','valid_spikes_end_class'),'String'),1,1000);
   if valid1 && valid2
      valid_spikes_trial=[];  % this column vector will hold the list of trial numbers to validate
      valid_spikes_times=[];  % this matching column vector with have [start  end] times (in milliseconds) for each trial.  
      [number_of_trials,number_of_codes]=size(event_codes); 
      if debugs
       fprintf(debug_fid,'Debug [make_plot]. Validate spikes: start class=%d   end class=%d\n',startclass,endclass);
      end
      for trial=1:number_of_trials        % for trials that match the sequence
         selected_trial=selected_unit_trials(trial);   % find which trial this match came from  
         % Get a 2 row array of classes and class values for this trial.
         list=list_trial(selected_trial);  % list_trial() uses unit trial number before sequence matching
         % find the class that has the validate start time, and the class that has the validate end time
         if ~isempty(list)
            classes=list(1,:);
            values=list(2,:);     
         else 
            if debugs
               fprintf(debug_fid,'Debug [make_plot]. Validate spikes: no class values at all for trial %d\n',trial);
            end;
            classes=[];
            values=[];          
         end

         start_class_index=find(classes==startclass);
         if isempty(start_class_index)
            start_time=0;  % start_time class entry was not found
         else
            start_time=values(start_class_index);
         end;
         time_shift=time_zero(trial)/RESCALE_TIME; % get the center code time shift for this trial
         normalized_start_time=(start_time/1000) - time_shift;  % convert to seconds and zero on centering code
         end_class_index=find(classes==endclass);
         if isempty(end_class_index)
            end_time=60000;  % Assumes trials are always less than 60 seconds
         else
            end_time=values(end_class_index);
         end
         time_shift=time_zero(trial)/RESCALE_TIME; % get the center code time shift for this trial
         normalized_end_time=(end_time/1000) - time_shift;  % convert to seconds and zero on centering code
         valid_spikes_trial = [ valid_spikes_trial ; trial]; % add current trial to trial list
         valid_spikes_times = [ valid_spikes_times ; normalized_start_time-xzero   normalized_end_time-xzero ];
            
         if debugs
            fprintf(debug_fid,'Debug [make_plot]. Validate spikes:trial %4d  start %7.3f  end %7.3f\n',...
                trial,normalized_start_time-xzero,normalized_end_time-xzero);
         end      
      end %  for trial=
   else
      if warnings
          fprintf(warning_fid,'Warning [make_plot]. One or both validate spike classes are not valid.  Validate spikes disabled.\n');
      end  
      set(findobj('Tag','validate_spikes_on_off'),'Value',0);   % turn off validate spikes
   end
end  % Matrix to Validate spikes

% Display raster
ypos=str2double(get(findobj('Tag','raster_y_pos'),'String')) / 100;  % convert to percent
sep=str2double(get(findobj('Tag','raster_separation'),'String'))/ 100;  % convert to percent
tic_size=str2double(get(findobj('Tag','raster_tic_size'),'String'))/ 100;  % convert to percent
style='-k';  % solid black line

if ~isempty(spiketrials)
   if get(findobj('Tag','validate_spikes_on_off'),'Value')
      spikelist=spiketrials;
      spikelist(:,2)=(spiketrials(:,2)/RESCALE_TIME)-xzero;  % rescale the spike times
      valid_spikelist=[];
      invalid_spikelist=[];
      for sorted_trial=1:length(sorted_trial_list) 
         % get the unsorted trial number for this sorted trial
         unsorted_trial=sorted_trial_list(sorted_trial); 
         % get the Validate Spike START and END times for this trial.  
         valid_start_time= valid_spikes_times(unsorted_trial,1);  
         valid_end_time  = valid_spikes_times(unsorted_trial,2);
         spikelist_ndx   = find(spikelist(:,1)==unsorted_trial);  % index to the spike times for this trial
         spikes_in_trial = spikelist(spikelist_ndx,2);            % get the spike times for this trial
         % find spikes that are within the valid period for this trial
         valid_spikes = ...
            spikes_in_trial(find((spikes_in_trial >= valid_start_time) & (spikes_in_trial <= valid_end_time)));
         invalid_spikes = ...
            spikes_in_trial(find((spikes_in_trial < valid_start_time)| (spikes_in_trial > valid_end_time)));
         
         % Rebuild spikelist into two separate spikelists, validated and invalidated spikes. 
         % each of these spikelists is structured like spiketrials, except 
         % the timestamps are scaled to seconds and time zero is the centering code.
         trial_list=ones(size(valid_spikes))*unsorted_trial;
         valid_spikelist=[valid_spikelist ; [trial_list  valid_spikes ]];  % spikes to include in histogram

         trial_list=ones(size(invalid_spikes))*unsorted_trial;
         invalid_spikelist=[invalid_spikelist ; [trial_list  invalid_spikes ]];  % spikes not being included
      end %  for sorted_trial=1:length_sorted_trial_list

      % now plot these rasters separately, with different colors
      raster(sorted_trial_list,valid_spikelist(:,1),valid_spikelist(:,2),ypos,sep,tic_size,style);

      invalid_spike_list=get(findobj('Tag','invalid_spike_color'),'String');  % pointer to color option
      invalid_spike_choice=get(findobj('Tag','invalid_spike_color'),'value');  % pointer to chosen option
      color_name=strtrim(invalid_spike_list(invalid_spike_choice,:)); 
      
      if strcmp(color_name,'yellow')
         style='-y';
      elseif strcmp(color_name,'magenta')
         style='-m';
      elseif strcmp(color_name,'cyan')
         style='-c';
      elseif strcmp(color_name,'red')
         style='-r';
      elseif strcmp(color_name,'green')
         style='-g';     
      elseif strcmp(color_name,'blue')
         style='-b';
      elseif strcmp(color_name,'white')
         style='-w';
      elseif strcmp(color_name,'black')  
         style='-k';
      end      
      raster(sorted_trial_list,invalid_spikelist(:,1),invalid_spikelist(:,2),ypos,sep,tic_size,style);
   else
      raster(sorted_trial_list,spiketrials(:,1),raster_timestamps,ypos,sep,tic_size,style);
   end % if validate spikes
end % if length(spiketrials) > 0

label_size=str2double(get(findobj('Tag','raster_label_size'),'String'))/100;   % needed for mark and spot

% Display mark
if mark <= size(event_times,2)
    style='s';
    event_mark_times=(event_times(:,mark)/RESCALE_TIME)-xzero;
    trial_range=1:size(event_times,1);   % all the rows in event_times
    if  ~(isempty(trial_range) || isempty(event_mark_times))
        marks(sorted_trial_list',trial_range',event_mark_times,... 
            ypos+mark_spot_offset+(1.0*tic_size)+(0.5*label_size),sep,label_size,style);
    end
else
    if errors
        fprintf(error_fid,'Error [make_plot]. Mark value set too high.  No matching sequence group.\n');
        safe_flag=0;
    end
end    

% Display spots
% The SPOT command holds a list of event codes to spot in each trial
spot_list=get(findobj('Tag','spot'),'String');   % fetch list of event codes from GUI
spot_list=strrep(spot_list,']',''); 
spot_list=strrep(spot_list,'[',''); 
if ~isempty(spot_list)
    spot_list=strrep(spot_list,'-',':'); 
    eval(['spots= [' spot_list '];']);   % convert to vector
    
    % loop through each event code and see if it gets a spot marker
    spot_mark_trial=[];  % these column vectors will hold the list of trials and times to spot
    spot_mark_time=[];
    [number_of_trials,number_of_codes]=size(event_codes);  % loop through all event codes in all trials
    for trial=1:number_of_trials         
        for code=1:number_of_codes
            if any(spots==event_codes(trial,code))    % is this code spotted?
                spot_mark_trial=[spot_mark_trial;trial]; % mark its trial number
                spot_mark_time=[spot_mark_time;event_times(trial,code)];  % mark its time
            end %if
        end %for code
    end %for trial
    spot_mark_time=(spot_mark_time/RESCALE_TIME) - xzero;   % rescale for plot
    style='+';
    if  ~(isempty(spot_mark_trial) | isempty(spot_mark_time))
        marks(sorted_trial_list',spot_mark_trial,spot_mark_time, ...
            ypos+mark_spot_offset+(1.0*tic_size)+(0.5*label_size),sep,label_size,style);        
    end
end % spot_list

% Display history spots
% A contiguous group of history classes are set up to place markers. If
% there are 10 classes, then up to 10 spots can be marked on each raster. 
% Any group of classes in the range 1 to 10,000 can be used for history spots
if get(findobj('Tag','history_spot_on_off'),'Value')
   [clean_string,value1,valid1]=check_string_value(get(findobj('Tag','history_spot_first_class'),'String'),1,10000);
   [clean_string,value2,valid2]=check_string_value(get(findobj('Tag','history_spot_last_class'),'String'),1,10000);
   if valid1 & valid2
      firstclass=min(value1,value2); % for the list of classes to be ascending
      lastclass=max(value1,value2);
      
      if (firstclass ~= value1) & warnings
          fprintf(warning_fid,'Warning [make_plot]. History spot first class and last class are out of order. Reversing them.\n');
      end        

      spot_mark_trial=[];  % these column vectors will hold the list of trials and times to spot
      spot_mark_time=[];
      [number_of_trials,number_of_codes]=size(event_codes);  % how many matching trials are there?
      for trial=1:number_of_trials        % for trials that match the sequence
         selected_trial=selected_unit_trials(trial);   % find which unit trial number this sequence match came from  
         % Get a 2 row array of classes and class values for this trial.
         list=list_trial(selected_trial);  % list_trial() uses unit trial number before sequence matching
         % find the classes that have the spot times
         if ~isempty(list)
            classes=list(1,:);
            values=list(2,:); 
            spotted_index=find( (classes >= firstclass) & (classes <= lastclass) );
            new_trials=ones(length(spotted_index),1)*trial; 
            time_shift=ones(1,length(spotted_index))*time_zero(trial)/RESCALE_TIME;   % time_zero array was created after sequence matching
            new_times=(values(spotted_index)/1000) - time_shift;   % convert to seconds and align with centering code
            spot_mark_trial=[spot_mark_trial ; new_trials];    % mark trial number
            spot_mark_time= [spot_mark_time  ; new_times' ];    % mark time
         end;
      end; %for trial
      
      spot_mark_time=spot_mark_time - xzero;   % rescale for plot  align to time_zero
      
      hist_color='g';  % default
      hist_color_list=get(findobj('Tag','history_spot_color'),'String');  % pointer to color option
      hist_color_choice=get(findobj('Tag','history_spot_color'),'value');  % pointer to chosen option
      hist_color_name=strtrim(hist_color_list(hist_color_choice,:)); 
      
      if strcmp(hist_color_name,'yellow')
         hist_color='y';
      elseif strcmp(hist_color_name,'magenta')
         hist_color='m';
      elseif strcmp(hist_color_name,'cyan')
         hist_color='c';
      elseif strcmp(hist_color_name,'red')
         hist_color='r';
      elseif strcmp(hist_color_name,'green')
         hist_color='g';     
      elseif strcmp(hist_color_name,'blue')
         hist_color='b';
      elseif strcmp(hist_color_name,'white')
         hist_color='w';
      elseif strcmp(hist_color_name,'black')  
         hist_color='k';
      end      
          
      style= [hist_color '^'];
      if  ~(isempty(spot_mark_trial) | isempty(spot_mark_time))
          marks(sorted_trial_list',spot_mark_trial,spot_mark_time, ...
              ypos+mark_spot_offset+(1.0*tic_size)+(0.5*label_size),sep,label_size,style);        
      end;
   else
      if warnings
          fprintf(warning_fid,'Warning [make_plot]. History spot classes are not valid.  History spots disabled.\n');
      end;  
      set(findobj('Tag','history_spot_on_off'),'Value',0);   % turn off history spots
   end
end  % history spots


% ------------------------------------------------- %
%          HISTOGRAM	for validated spikes
% ------------------------------------------------- %

function plot_histogram(start_time,end_time,xzero,raster_timestamps,sorted_trial_list,segment_limits)
%
% Plot histogram
%
global valid_spikes_times
global spiketrials event_codes event_times
global RESCALE_TIME
global error_fid warning_fid debug_fid trace_fid
global errors warnings debugs environment

if isempty(spiketrials)
   if debugs
      fprintf(debug_fid,'Debug  [make_plot (plot_histogram)]. Empty spiketrials. No histogram to plot.\n');
   end;
   return;
else
   if debugs
      fprintf(debug_fid,'Debug  [make_plot (plot_histogram)]. Plotting histogram.\n');
   end; 
end;
time_span=end_time-start_time;
trials_found=str2double(get(findobj('Tag','trialsfound'),'String'));
% determine how many milliseconds of data in each bin, then rescale

length_sorted_trial_list=length(sorted_trial_list);
[clean_string,binwidth,validvalue]=check_string_value(get(findobj('Tag','histogram_binwidth'),'String'),.5,200);
if ~validvalue
   if warnings
      fprintf(warning_fid,'Warning [make_plot]. Bin width setting out of range (.5 to 200 ms). Defaulting to 2 ms\n');
   end
   binwidth=2;
end
binwidth=binwidth/1000;  % convert ms to sec

bin_start_times=start_time:binwidth:end_time;  % array of bin start times
spikelist=spiketrials;
spikelist(:,2)=(spiketrials(:,2)/RESCALE_TIME)-xzero;  % rescale the spike times

% pull out only those entries that come from trials in the trial list
goodspikelist=[];


% Validate Spikes option restricts the histogram to "valid" spikes. Valid Spikes are those
% spikes that occur within a specified time window in each trial. The time window is specified
% on a trial-by-trial basis using two history classes, the START class and the END class.
% Normally he bins are divided by the total number of trials to calculate the average spikes/second.
% When not using Validate Spikes, all bins have the same number of trials. When using Validate Spikes,
% the number of trials can be different for each bin. We need to keep track of the number of trials 
% on a bin-by-bin basis. 

% start with a zero histogram
histogram_values=zeros(1,length(bin_start_times));  
% start with a zero number of trials for each bin
number_of_trials_in_bin=zeros(1,length(bin_start_times));

if get(findobj('Tag','validate_spikes_on_off'),'Value')    
   % ------- Validate Spikes ------------
   for sorted_trial=1:length_sorted_trial_list 
      % get the unsorted trial number for this sorted trial
      unsorted_trial=sorted_trial_list(sorted_trial); 
      % get the Validate Spike START and END times for this trial.  
      valid_start_time= valid_spikes_times(unsorted_trial,1);  
      valid_end_time  = valid_spikes_times(unsorted_trial,2);
      spikelist_ndx   = find(spikelist(:,1)==unsorted_trial);  % index to the spike times for this trial
      spikes_in_trial = spikelist(spikelist_ndx,2);            % get the spike times for this trial
      % find spikes that are within the valid period for this trial
      valid_spikes = ...
         spikes_in_trial(find((spikes_in_trial >= valid_start_time) & (spikes_in_trial <= valid_end_time)));

      % Add these spikes to their appropriate bins
      % Only include bins within the time window for valid spikes
      bin_start_index=find((bin_start_times >= valid_start_time) & (bin_start_times <= valid_end_time-binwidth));
      % Add spike counts and add 1 to the trial count for these specific bins
      for bin_index=bin_start_index
         % get the start time for this bin
         bin_start=bin_start_times(bin_index);  
         % find the spikes in this bin. note: bins overlap by .1 ms to
         % reduce rounding errors.
         index_of_spikes=find((valid_spikes >= bin_start) & (valid_spikes < (bin_start+binwidth+0.0001))); 
         % count the spikes and add them to the histogram count
         histogram_values(bin_index)=histogram_values(bin_index)+length(index_of_spikes);
         % update trial count for this bin
         number_of_trials_in_bin(bin_index)=number_of_trials_in_bin(bin_index)+1 ;     
      end
   end %  for sorted_trial=1:length_sorted_trial_list
else  % ------- Do not Validate Spikes ------------
   for good_trial=sorted_trial_list
       goodspikelist=[goodspikelist;spikelist(find(spikelist(:,1)==good_trial),2)];  
   end
   % sum spike counts for each bin
   % remove all spikes that occured before the first bin
   goodspikelist=goodspikelist(find(goodspikelist >= bin_start_times(1)));
   % fill each bin with spikes that fall into the bin time range
   bin=0;
   for bin_start=bin_start_times    
      bin=bin+1;
      % locate spikes within this bin
      index_of_spikes=find(goodspikelist < (bin_start+binwidth));
      histogram_values(bin)=length(index_of_spikes);  % sum these indicies
      % discard the spikes that have been tallied
      goodspikelist=goodspikelist(yank_elements(index_of_spikes,length(goodspikelist)));
   end
   % every bin has the same number of trials
   number_of_trials_in_bin=ones(1,length(bin_start_times))*length_sorted_trial_list; 
end  % validate spikes


% Raw histograms are plotted using only the spike counts in each bin. 
% Regular histograms are plotted using impulses/second (IPS = spikes/sec)
% 
% These two variable have just been calculated:
% histogram_values               count of spikes for each bin
% number_of_trials_in_bin        number of trials that contributed to each bin
%
% Now calculate average spikes/second (impulses/second = IPS) for each bin
% If no trials contribute to a bin, that bin count will be zero. 
% Take advantage of this fact to avoid a divide-by-zero. 
ntib=number_of_trials_in_bin;  % copy variable
ntib_index=find(ntib==0);      % find the zeros
ntib(ntib_index)=1;            % set them equal to 1 
IPS_in_bin = histogram_values./(ntib*binwidth); 

% Calculate mean value of bins that overlap the 'segment a' field
% This will be used to draw reference lines
   if debugs
      fprintf(debug_fid,'Debug  [make_plot (plot_histogram)]. Calculating mean activity for histogram using segment a.\n');
   end
   sega_low=segment_limits(1);  % get segment times
   sega_high=segment_limits(2)  ;
   sega_spike_count=0;     % count the number of histogram values within segment a
   sega_bin_count=0;       % count the number of bins included in this range
   sega_samples=[];
   bin=0;
   for bin_start=bin_start_times   % check each bin
      bin=bin+1;
      if (bin_start >= sega_low) & (bin_start+binwidth <= sega_high)  % is this bin completely within segment limits?
         sega_samples=[sega_samples IPS_in_bin(bin)];
      end
   end
   sega_bin_count=length(sega_samples);
   sega_spike_count=sum(sega_samples);
   if sega_bin_count==0
      ave_sega=0;
      sd_sega=0;
   else
      ave_sega=sega_spike_count/sega_bin_count;
      sd_sega=std(sega_samples);
   end

   style_list=get(findobj('Tag','histogram_style'),'String');    % get list of histogram style options
   style_choice=get(findobj('Tag','histogram_style'),'Value');   % pointer to chosen option
   style_name=strtrim(style_list(style_choice,:));  
   style='i';  % default
   if strcmp(style_name,'solid')
      style='k';
   elseif strcmp(style_name,'green')
      style='gi';
   elseif strcmp(style_name,'red')
      style='ri';
   elseif strcmp(style_name,'black')  
      style='ki';
   end 
   
   sty=get(findobj('Tag','histogram_y_pos'),'String');
   [clean_string,value,valid]=check_string_value(sty,-120,120);
   if ~valid
      if warnings
         fprintf(warning_fid,'Warning [make_plot (histogram)]. Invalid histogram position. Fixing...\n');
      end
      value=50;
   end
   ypos=value/100; 
     
   sths=get(findobj('Tag','histogram_size'),'String');
   [clean_string,value,valid]=check_string_value(sths,-120,120);
   if ~valid
      if warnings
         fprintf(warning_fid,'Warning [make_plot (histogram)]. Invalid histogram size. Fixing...\n');
      end;
      value=50;
   end
   histogram_size=value/100;  
   
   scale=get(findobj('Tag','histogram_scale'),'String'); 
   rawcounts=get(findobj('Tag','histogram_raw_on_off'),'Value');

   % ---------- Autoscaling -------------- %
   if strncmp(scale,'auto',3)
      % rawcounts draws histograms that are spike counts, not scaled to spikes/second
      if rawcounts
         % it is does not seem a good idea to do rawcounts with validate spikes at the same time, but it is allowed
         if get(findobj('Tag','validate_spikes_on_off'),'Value') && warnings
             fprintf(warning_fid,'Warning [make_plot(histogram)]. Both VALIDATE SPIKES and RAW COUNTS options are in effect.\n');
         end   
         max_spikes_per_bin=round(max(histogram_values)+.5); % find a reasonable maximum spikes_per_bin
         fprintf(1,'histogram scaled to %d counts (raw counts)\n', max_spikes_per_bin);
         if environment.logging==1
            fprintf(fid.log,'histogram scaled to %d counts (raw counts)\n', max_spikes_per_bin);
         end
      else
         % maximum spikes/second value
         max_IPS=round(max(IPS_in_bin)+.5);
         fprintf(1,'histogram scaled to %d spikes/second\n', max_IPS);
         if environment.logging==1
            fprintf(fid.log,'histogram scaled to %d spikes/second\n', max_IPS);
         end
      end
   else  % manual scaling
      [clean_string,max_IPS,valid]=check_string_value(scale,1,5000);
      if ~valid
         if warnings
            fprintf(warning_fid,'Warning [make_plot (histogram)]. Invalid histogram scale. Fixing...set to 100 IPS\n');
         end;
         max_IPS=100;
      end; 
      if rawcounts
         if (get(findobj('Tag','validate_spikes_on_off'),'Value') && warnings)
             fprintf(warning_fid,'Warning [make_plot (histogram)]. Both VALIDATE SPIKES and RAW COUNTS options are in effect.\n');
         end;
         max_spikes_per_bin=max_IPS; % the value picked up was max_spikes_per_bin, not max_IPS
      end
   end % auto scaling
   
   % clipping
   if rawcounts
      clipped_values=histogram_values;
      clipped_values(find(clipped_values > max_spikes_per_bin))=max_spikes_per_bin;  % clip count amplitude if needed
      clip_count=sum(sum((clipped_values ~= histogram_values)));
   else
      clipped_values=IPS_in_bin;
      clipped_values(find(clipped_values > max_IPS))=max_IPS;  % clip impulses/sec amplitude if needed
      clip_count=sum(sum((clipped_values ~= IPS_in_bin)));
   end
   if (clip_count > 0) && warnings
      fprintf(warning_fid,'%d histogram values clipped\n',num2str(clip_count));
   end
   
   % reference lines
   ref_color='k';   % default (no reference lines)
   ref_limits=[0];
   if get(findobj('Tag','histogram_ref_on_off'),'Value') && (ave_sega > 0)
      ref_color_list=get(findobj('Tag','histogram_ref_color'),'String');  % pointer to color option
      ref_color_choice=get(findobj('Tag','histogram_ref_color'),'value');  % pointer to chosen option
      ref_color_name=strtrim(ref_color_list(ref_color_choice,:));  
      ref_color='k';  % default
      if strcmp(ref_color_name,'yellow')
         ref_color='y';
      elseif strcmp(ref_color_name,'magenta')
         ref_color='m';
      elseif strcmp(ref_color_name,'cyan')
         ref_color='c';
      elseif strcmp(ref_color_name,'red')
         ref_color='r';
      elseif strcmp(ref_color_name,'green')
         ref_color='g';     
      elseif strcmp(ref_color_name,'blue')
         ref_color='b';
      elseif strcmp(ref_color_name,'white')
         ref_color='w';
      elseif strcmp(ref_color_name,'black')  
         ref_color='k';
      end
      rl=get(findobj('Tag','histogram_ref_limits'),'String');
      [clean_string,value,valid]=check_string_value(rl,0,10);
      if ~valid
         if warnings
            fprintf(warning_fid,'Warning [make_plot (histogram)]. Invalid reference line specification. Turning line off...\n');
         end;
         value=0;
      end
        
      value=value*sd_sega;  % multiply this reference value by standard deviation
      fprintf('Plotting histogram reference: \nSegment A covers %d bins. Mean value=%-0.2f counts  SD=%-0.2f\n',sega_bin_count,ave_sega,sd_sega);
      
      if ave_sega-value > 0
         ref_limits=[(ave_sega-value) ave_sega (ave_sega+value)];
      else 
         ref_limits=[ave_sega ave_sega (ave_sega+value)];
      end
   end
   
   if rawcounts
      drawhist(start_time,time_span+binwidth,histogram_values,max_spikes_per_bin,ypos,histogram_size,style,ref_limits,ref_color);
      sss=max_spikes_per_bin;
   else
      drawhist(start_time,time_span+binwidth,IPS_in_bin,max_IPS,ypos,histogram_size,style,ref_limits,ref_color);
      sss=max_IPS;
   end
   if get(findobj('Tag','histogram_scale_on_off'),'Value')
      sss=round(sss);
      labels=[0 sss/2 sss ];
      ascale(ypos-histogram_size,histogram_size,end_time,3,0.09,-1,labels);
   end
      


% ==================================================================================== %
%               	          SET KEEP/SHOW AND DUMP ROUTINES
% ==================================================================================== %



% --------------------------------------------------------------------------------------- %
%                     SEGMENTSTATS
% --------------------------------------------------------------------------------------- %
function show_segmentstats(raster_timestamps,sorted_trial_list,segment_limits)
%
%  keep or show segmentstats
%
%
%
global spiketrials 
global set_process environment
global error_fid warning_fid debug_fid trace_fid
global errors warnings debugs
global fid fn

sega_low=segment_limits(1);  
sega_high=segment_limits(2);
segb_low=segment_limits(3);
segb_high=segment_limits(4);
high_trial=segment_limits(5);
low_trial=segment_limits(6);

if debugs
    fprintf(debug_fid,'Debug [make_plot]. Calculating segment stats.\n');
end;
sega_trials=find((raster_timestamps > sega_low) & (raster_timestamps <= sega_high));
segb_trials=find((raster_timestamps > segb_low) & (raster_timestamps <= segb_high));
segstats=zeros(high_trial,2);
colons=findstr(set_process.segmentstats,':');
if colons(3)== length(set_process.segmentstats)
    statpath_filename='';
else
    statpath_filename=set_process.segmentstats(colons(3)+1:end);
end;
for trial=sorted_trial_list   % find spikes in each segment 
    if isempty(spiketrials)
        segstats(trial,:)=[0 0];
    else
        segstats(trial,:)=[length(find(spiketrials(sega_trials,1)==trial)) ...
                length(find(spiketrials(segb_trials,1)==trial)) ];
    end;
end;
N=[length(sorted_trial_list) length(sorted_trial_list)];
Sum=sum(segstats);
if ~isempty(sorted_trial_list)
    Mean=Sum/length(sorted_trial_list);
else
    Mean=[0 0];
end;
SSq=sum(segstats.^2);
SD=std(segstats);

if isempty(findstr(set_process.segmentstats,'noshow'))
    fprintf(1,'%s \n',environment.dumplabel);
    c=fix(clock);
    datestring=datestr(datenum(c(1),c(2),c(3)));
    fprintf(1,'%s        %02u:%02u:%02u\n',datestring,c(4),c(5),c(6));
    fprintf(1,'TRIAL    SEG-A     SEG-B\n');
    for trial=sorted_trial_list
        fprintf(1,'%4d    %6.1f    %6.1f\n',trial,segstats(trial,1)/(sega_high-sega_low), ...
            segstats(trial,2)/(segb_high-segb_low));
    end;
    fprintf(1,'\n\n  IPS   |  Segment-1  Segment-2\n');
    fprintf(1,'--------+------------------------\n');
    fprintf(1,'  N     |      %4u    %8u\n',N(1),N(2));
    fprintf(1,'  Sum   | %9.3f   %9.3f\n',Sum(1),Sum(2));
    fprintf(1,'  Mean  | %9.3f   %9.3f\n',Mean(1),Mean(2));
    fprintf(1,'  SSq   | %9.3f   %9.3f\n',SSq(1),SSq(2));
    fprintf(1,'  S.D.  | %9.3f   %9.3f\n\n',SD(1),SD(2));
end; % show

if isempty(findstr(set_process.segmentstats,'nokeep'))
    % are we in the append mode?
    if isempty(findstr(set_process.segmentstats,'noappend'))
        % yes, is there a file already open?
        filename=fopen(fid.segmentstats);
        if isempty(filename)
            % no, open a file for append
            if isempty(statpath_filename)   % use a default file name?
                fn.segmentstats=fn.segmentstats+1;  
                filename=sprintf('%04u.SEG',fn.segmentstats);
            else
                filename=statpath_filename;
            end; 
            filename=filepath(filename,environment.statpath);
            fid.segmentstats=fopen(filename,'wt');  % destructive open
        end; 
    else    % noappend
        % is a file currently open?
        filename=fopen(fid.segmentstats);
        if ~isempty(filename)
            fclose(fid.segmentstats); % yes, close it
            fid.segmentstats=-1;
        end;
        % now open a file for writing
        if isempty(statpath_filename)   % use a default file name?
            fn.segmentstats=fn.segmentstats+1;  
            filename=sprintf('%04u.SEG',fn.segmentstats);
        else
            filename=statpath_filename;
        end;
        filename=filepath(filename,environment.statpath);   
        fid.segmentstats=fopen(filename,'wt');  % destructive open
    end;
    % we now have the correct file open 
    fprintf(1,'writing segment stats to file %s\n',filename);
    if environment.logging==1
       fprintf(fid.log,'writing segment stats to file %s\n',filename);
    end;
    
    % look for and decode the segstat.fmt file
    
    %minimal values, format file completes these
    segstatfmt.header=0;
    segstatfmt.trailer=0;
    segstatfmt.delimiter='';
    segstatfmt.trial='0';
    segstatfmt.sega='0.2';
    segstatfmt.segb='0.2';
    segstatfmt.segx=0;
    segstatfmt.format='';     
    segstatfmt_name='segstat.fmt';
    segstatfmt_name=filepath(segstatfmt_name,environment.formatpath);
    segstatfmt.fid= fopen(segstatfmt_name,'rt');  % try to open format file
    if segstatfmt.fid > 1
        while ~feof(segstatfmt.fid)
            pcmd=fgetl(segstatfmt.fid);
            if strcmp(pcmd(1:1),'#')  % ignore comments
            elseif strncmp(pcmd,'HEADER',5)
                segstatfmt.header=1; 
            elseif strncmp(pcmd,'TRAILER',5)
                segstatfmt.trailer=1; 
            elseif strncmp(pcmd,'DELIMITER',5)
                [dummy,segstatfmt.delimiter]=strtok(pcmd);
                segstatfmt.delimiter=segstatfmt.delimiter(2:end);  %remove space
                segstatfmt.delimiter=strrep(segstatfmt.delimiter,'''',''); % remove quotes
            elseif strncmp(pcmd,'TRIAL',5)
                [dummy,segstatfmt.trial]=strtok(pcmd,':');
                segstatfmt.trial=segstatfmt.trial(2:end); % remove leading ":"
            elseif strncmp(pcmd,'SEGA:',5)
                [dummy,segstatfmt.sega]=strtok(pcmd,':');
                segstatfmt.sega=segstatfmt.sega(2:end);  % remove leading ":"
                segstatfmt.sega=strrep(segstatfmt.sega,':','.'); % make like printf command
            elseif strncmp(pcmd,'SEGB:',5)
                [dummy,segstatfmt.segb]=strtok(pcmd,':');
                segstatfmt.segb=segstatfmt.segb(2:end);  % remove leading ":"
                segstatfmt.segb=strrep(segstatfmt.segb,':','.'); % make like printf command
            elseif strncmp(pcmd,'FORMAT',5)
                [dummy,segstatfmt.format]=strtok(pcmd);
                segstatfmt.format=segstatfmt.format(2:end); % remove space
            end;
        end; % while              
        fclose(segstatfmt.fid); 
        segstatfmt.fid=-1;
    else    %default values         
        segstatfmt.header=1;
        segstatfmt.trailer=1;
        segstatfmt.delimiter=',';
        segstatfmt.trial='0';
        segstatfmt.sega='0.2';
        segstatfmt.segb='0.2';
        segstatfmt.segx=0;
        segstatfmt.format='TRIAL   ,SEGA   ,SEGB';
    end; % if segstatfmt.fid
    if ~isempty(findstr(segstatfmt.format,'SEGX'))
        segstatfmt.segx=1;
    end;
    
    % we now have the segstats format
    
    if segstatfmt.header  % print header?
        fprintf(fid.segmentstats,'%s \n',environment.dumplabel);
        c=fix(clock);
        datestring=datestr(datenum(c(1),c(2),c(3)));
        fprintf(fid.segmentstats,'%s        %02u:%02u:%02u\n',datestring,c(4),c(5),c(6));
    end;
    
    sega=segstats(:,1)/(sega_high-sega_low);
    segb=segstats(:,2)/(segb_high-segb_low);
    
    if (sega_high-sega_low)==0
        segxa=0;
    else
        segxa=(sega_high-sega_low);
    end;
    if (segb_high-segb_low)==0
        segxb=0;
    else
        segxb=(segb_high-segb_low);
    end;
    segx=[segxa ; segxb];
    
    % determine the variable to print
    remainder=segstatfmt.format;
    print_list='';
    while ~isempty(remainder)
        [field,remainder]=strtok(remainder,',');
        if strncmp(field,'TRIAL',5)
            print_list=[print_list ',trial'];
        elseif strncmp(field,'SEGA',4)
            print_list=[print_list ',sega(trial)'];
        elseif strncmp(field,'SEGB',4)
            print_list=[print_list ',segb(trial)'];
        elseif strncmp(field,'SEGX',4)
            print_list=[print_list ',segx(trial)'];
        end;
    end;
    
    % make appropriate substitutions for printing format      
    % enforce exclusion between SEGA/SEGB versus SEGX
    print_format_string=strrep(segstatfmt.format,',',segstatfmt.delimiter);
    if isempty(findstr(segstatfmt.format,'SEGX'))  % segx
        print_format_string=strrep(print_format_string,'TRIAL',['%' segstatfmt.trial 'u']);
        print_format_string=strrep(print_format_string,'SEGA',['%' segstatfmt.sega 'f']);
        print_format_string=strrep(print_format_string,'SEGB',['%' segstatfmt.segb 'f']); 
        print_format_string=[print_format_string '\n'''];  
        for trial=sorted_trial_list
            eval_string=['fprintf(fid.segmentstats,'''  print_format_string   print_list ');'];
            eval(eval_string);
        end;
    else  % segx
        print_format_string=strrep(print_format_string,'TRIAL',['%' segstatfmt.trial 'f']);         
        print_format_string=strrep(print_format_string,'SEGX',['%' segstatfmt.sega 'f']); % segx uses sega
        print_format_string=[print_format_string '\n'''];
        double_trial_list=[sorted_trial_list sorted_trial_list];
        for trial=double_trial
            eval_string=['fprintf(fid.segmentstats,'''  print_format_string   print_list ');'];
            eval(eval_string);
        end;   
    end;  % segx
    
    if segstatfmt.trailer  % print trailer
        fprintf(fid.segmentstats,'\n\n  IPS   |  Segment-1  Segment-2\n');
        fprintf(fid.segmentstats,'--------+------------------------\n');
        fprintf(fid.segmentstats,'  N     |      %4u    %8u\n',N(1),N(2));
        fprintf(fid.segmentstats,'  Sum   | %9.3f   %9.3f\n',Sum(1),Sum(2));
        fprintf(fid.segmentstats,'  Mean  | %9.3f   %9.3f\n',Mean(1),Mean(2));
        fprintf(fid.segmentstats,'  SSq   | %9.3f   %9.3f\n',SSq(1),SSq(2));
        fprintf(fid.segmentstats,'  S.D.  | %9.3f   %9.3f\n\n',SD(1),SD(2));   
    end;
    % close the file if we are not appending
    if ~isempty(findstr(set_process.segmentstats,'noappend'))
        fclose(fid.segmentstats);
        fid.segmentstats=-1;
    end;
end; % keep segmentstats



% --------------------------------------------------------------------------------------- %
%                     EPOCHSTATS
% --------------------------------------------------------------------------------------- %
function show_epochstats(raster_timestamps,sorted_trial_list,high_trial)
%
%  keep or show epochstats
%
%
global set_process environment
global error_fid warning_fid debug_fid trace_fid
global errors warnings debugs 
global fid fn
global spikemap event_codes event_times 
global spiketrials 
global RESCALE_TIME

if debugs
    fprintf(debug_fid,'Debug [make_plot]. Calculating epoch stats.\n');
end; % debugs
mark=str2double(get(findobj('Tag','mark'),'String'));
colons=findstr(set_process.epochstats,':');
if (colons(3)== length(set_process.epochstats))
    statpath_filename='';
else
    statpath_filename=set_process.epochstats(colons(3)+1:end);
end; % if colons(3
% epochstats( trial count dtime ips )
% trial  sorted trial number
% dtime  time between center and mark events
% count  number of spikes between center and mark events
% ips    calculated spikes/second = count/dtime
epochstats=[];
for trial=sorted_trial_list   % re-order output list to match sorted_trial_list
    if isempty(spiketrials)   % no spikes to count in this trial
        epochstats=[epochstats ; trial 0 0 0];
    else
        % count the number of pulses between zero (center) and the mark code
        mark_time=event_times(trial,mark); 
        spiketimes_for_this_trial=spiketrials(find(spiketrials(:,1)==trial),2); % get spike times
        % mark can occur either before or after center
        if mark_time > 0
            spike_count=length(find((spiketimes_for_this_trial >= 0) & ... 
                (spiketimes_for_this_trial < mark_time)));
        else
            spike_count=length(find((spiketimes_for_this_trial < 0) & ... 
                (spiketimes_for_this_trial >= mark_time)));
        end; % mark_time > 0         
        epochstats= [epochstats ; ...
                trial spike_count abs(mark_time/RESCALE_TIME) abs(spike_count*RESCALE_TIME/mark_time)];
    end; % isempty(spiketrials) 
 end; % for trial=sorted_trial_list
    
 N=[1  1   length(sorted_trial_list) length(sorted_trial_list)];  %total columns 1 and 2, average columns 3 and 4
 Sum=sum(epochstats);
 if ~isempty(sorted_trial_list)
     Mean=Sum./N;
     Mean(1)=length(sorted_trial_list);   % more meaningful to have number of trials in column 1
 else
     Mean=[0 0 0 0];
 end;  % if length(sorted_trial_list
    
 if isempty(findstr(set_process.epochstats,'noshow'))
     if debugs
         fprintf(debug_fid,'Debug [make_plot]. SHOW epoch stats.\n');
     end;
     fprintf('%s \n',environment.dumplabel);
     c=fix(clock);
     datestring=datestr(datenum(c(1),c(2),c(3)));
     fprintf('%s        %02u:%02u:%02u\n',datestring,c(4),c(5),c(6));
       fprintf('%5s    %7s      %5s    %5s\n','TRIAL','DELTA T','COUNT','IPS');
     for trial=1:size(epochstats,1)
       fprintf('%5d    %7.3f      %5d    %5.1f\n',epochstats(trial,1),epochstats(trial,3), ...
             epochstats(trial,2),epochstats(trial,4));
     end; % trial=1:
     fprintf('\n\n');
     fprintf('%6s   %7s      %5s    %5s\n','TRIALS','AVE','SUM','AVE');
     fprintf('-------------------------------------\n');
     fprintf('%5d    %7.3f    %7.2f    %5.1f\n\n',Mean(1),Mean(3),Mean(2),Mean(4));
 end; % show / noshow
    
 if isempty(findstr(set_process.epochstats,'nokeep'))
     if debugs
         fprintf(debug_fid,'Debug [make_plot]. KEEP epoch stats.\n');
     end;
     % are we in the append mode?
     if isempty(findstr(set_process.epochstats,'noappend'))
         % yes, is there a file already open?
         filename=fopen(fid.epochstats);
         if isempty(filename)
             % no, open a file for append
             if isempty(statpath_filename)   % use a default file name?
                 fn.epochstats=fn.epochstats+1;  
                 filename=sprintf('%04u.EPK',fn.epochstats);
             else
                 filename=statpath_filename;
             end; % if isempty(statpath_filename)
             if debugs
                 fprintf(debug_fid,['Debug [make_plot]. APPEND epoch stats file ' filename '\n']);
             end; % if debugs
             filename=filepath(filename,environment.statpath);
             fid.epochstats=fopen(filename,'wt');  % destructive open
         end; % if isempty(filename)
     else    % noappend
        % is a file currently open?
        filename=fopen(fid.epochstats);
        if ~isempty(filename)
            fclose(fid.epochstats); % yes, close it
            fid.epochstats=-1;
        end; % if ~isempty(filename)
        % now open a file for writing
        if isempty(statpath_filename)   % use a default file name?
            fn.epochstats=fn.epochstats+1;  
            filename=sprintf('%04u.EPK',fn.epochstats);
        else
            filename=statpath_filename;
        end; % if isempty(statpath_filename)
        if debugs
            fprintf(debug_fid,['Debug [make_plot]. NOAPPEND epoch stats file ' filename '\n']);
        end;
        filename=filepath(filename,environment.statpath);   
        fid.epochstats=fopen(filename,'wt');  % destructive open
     end; %  append / noappend
     % we now have the correct file open 
     fprintf(1,'writing epoch stats to file %s\n',filename);
     if environment.logging==1
        fprintf(fid.log,'writing epoch stats to file %s\n',filename);
     end;
       
     % look for and decode the epoch.fmt file
       
     % minimal values, format file complete this
     epochstatfmt.header=0;
     epochstatfmt.trailer=0;
     epochstatfmt.delimiter=',';
     epochstatfmt.trial='0';
     epochstatfmt.count='0.2';
     epochstatfmt.dtime='0.2';
     epochstatfmt.ips='0.2';
     epochstatfmt.format='';
     epochstatfmt_name='epoch.fmt';
     epochstatfmt_name=filepath(epochstatfmt_name,environment.formatpath);
     if debugs
         fprintf(debug_fid,['Debug [make_plot]. epoch stats default format: \n']);
         epochstatfmt  % no semicolon here
     end;
     epochstatfmt.fid= fopen(epochstatfmt_name,'rt');  % try to open format file
     if epochstatfmt.fid > 1   % does format file exist?
        if debugs
            fprintf(debug_fid,['Debug [make_plot]. epoch stats format file was found.\n']);
        end;
        while ~feof(epochstatfmt.fid)
            pcmd=fgetl(epochstatfmt.fid);
            if strcmp(pcmd(1:1),'#')  % ignore comments
            elseif strncmp(pcmd,'HEADER',5)
               epochstatfmt.header=1; 
            elseif strncmp(pcmd,'TRAILER',5)
               epochstatfmt.trailer=1; 
            elseif strncmp(pcmd,'DELIMITER',5)
               [dummy,epochstatfmt.delimiter]=strtok(pcmd);
               epochstatfmt.delimiter=epochstatfmt.delimiter(2:end);  %remove space
               epochstatfmt.delimiter=strrep(epochstatfmt.delimiter,'''',''); % remove quotes
            elseif strncmp(pcmd,'TRIAL',5)
               [dummy,epochstatfmt.trial]=strtok(pcmd,':');
               epochstatfmt.trial=epochstatfmt.trial(2:end); % remove leading ":"
            elseif strncmp(pcmd,'COUNT',5)
               [dummy,epochstatfmt.count]=strtok(pcmd,':');
               epochstatfmt.count=epochstatfmt.count(2:end);  % remove leading ":"
               epochstatfmt.count=strrep(epochstatfmt.count,':','.'); % make like printf command
            elseif strncmp(pcmd,'DTIME',5)
               [dummy,epochstatfmt.dtime]=strtok(pcmd,':');
               epochstatfmt.dtime=epochstatfmt.dtime(2:end);  % remove leading ":"
               epochstatfmt.dtime=strrep(epochstatfmt.dtime,':','.'); % make like printf command
            elseif strncmp(pcmd,'IPS',3)
               [dummy,epochstatfmt.ips]=strtok(pcmd,':');
               epochstatfmt.ips=epochstatfmt.ips(2:end);  % remove leading ":"
               epochstatfmt.ips=strrep(epochstatfmt.ips,':','.'); % make like printf command        
            elseif strncmp(pcmd,'FORMAT',5)
               [dummy,epochstatfmt.format]=strtok(pcmd);
               epochstatfmt.format=epochstatfmt.format(2:end); % remove space            
            end; % if strncmp(#)
         end; % while ~feof(epochstatfmt.fid)
         fclose(epochstatfmt.fid); 
         epochstatfmt.fid=-1;
      else % format file does not exist
         if debugs
             fprintf(debug_fid,['Debug [make_plot]. epoch stats format file was NOT found, using default.\n']);
         end;
         epochstatfmt.header=1;
         epochstatfmt.trailer=1;
         epochstatfmt.delimiter=',';
         epochstatfmt.trial='0';
         epochstatfmt.count='0.2';
         epochstatfmt.dtime='0.2';
         epochstatfmt.ips='0.2';
         epochstatfmt.format='TRIAL ,COUNT ,DTIME ,IPS';
      end; % if format file exists
      if debugs
         fprintf(debug_fid,'Debug [make_plot]. epoch stats format that will be used: \n');
         epochstatfmt  % no semicolon here
      end;          
      % we now have the epoch stats format
        
      if epochstatfmt.header  % print header?
         fprintf(fid.epochstats,'%s \n',environment.dumplabel);
         c=fix(clock);
         datestring=datestr(datenum(c(1),c(2),c(3)));
         fprintf(fid.epochstats,'%s        %02u:%02u:%02u\n',datestring,c(4),c(5),c(6));
      end;
        
      % determine the variables to print
      remainder=epochstatfmt.format;
      print_list='';
      while ~isempty(remainder)
          [field,remainder]=strtok(remainder,',');
          if strncmp(field,'TRIAL',5)
              print_list=[print_list ',epochstats(trial,1)'];
          elseif strncmp(field,'COUNT',4)
              print_list=[print_list ',epochstats(trial,2)'];
          elseif strncmp(field,'DTIME',4)  
              print_list=[print_list ',epochstats(trial,3)'];
          elseif strncmp(field,'IPS',3)
              print_list=[print_list ',epochstats(trial,4)'];
          end;
      end;  %  while ~isempty(remainder)
      
      if debugs
         fprintf(debug_fid,['Debug [make_plot]. epoch stats print list: \n']);
         print_list  % no semicolon here
      end; 
      if ~isempty(print_list)  
         % make appropriate substitutions for printing format      
         print_format_string=strrep(epochstatfmt.format,',',epochstatfmt.delimiter);
         print_format_string=strrep(print_format_string,'TRIAL',['%' epochstatfmt.trial 'd']);         
         print_format_string=strrep(print_format_string,'COUNT',['%' epochstatfmt.count 'f']);
         print_format_string=strrep(print_format_string,'DTIME',['%' epochstatfmt.dtime 'f']); 
         print_format_string=strrep(print_format_string,'IPS',['%' epochstatfmt.ips 'f']); 
         print_format_string=[print_format_string '\n'''];

        
         if debugs
             fprintf(debug_fid,['Debug [make_plot]. epoch stats print format string: \n']);
             print_format_string  % no semicolon here
             fprintf(debug_fid,['Debug [make_plot]. epoch stats print eval string: \n']);
             eval_string=['fprintf(fid.epochstats,'''  print_format_string   print_list ');'] %no semi
         end;       
         for trial=1:size(epochstats,1)
             eval_string=['fprintf(fid.epochstats,'''  print_format_string   print_list ');'];
             eval(eval_string);
         end;   
      end;
        
      if (epochstatfmt.trailer)  % print trailer     
      %    fprintf(fid.epochstats,'\n\n');
      %    fprintf(fid.epochstats,'%6s   %7s      %5s    %5s\n','TRIALS','AVE','SUM','AVE');
      %    fprintf(fid.epochstats,'-------------------------------------\n');
          fprintf(fid.epochstats,'%5d    %7.3f    %7.2f    %5.1f\n',Mean(1),Mean(3),Mean(2),Mean(4));   
      end;
      % close the file if we are not appending
      if ~isempty(findstr(set_process.epochstats,'noappend'))
          fclose(fid.epochstats);
          fid.epochstats=-1;
      end;
    end; % keep / nokeep epochstats
    
     
    

    % --------------------------------------------------------------------------------------- %
    %                     SORTVALUES
    % --------------------------------------------------------------------------------------- %
    
    function show_sortvalues(sorted_trial_list,high_trial)
    %
    %  keep or show SortValues
    %
    %
    %
    global set_process environment
    global error_fid warning_fid debug_fid trace_fid
    global errors warnings debugs 
    global fid fn
    global sort_values
    
    if debugs
        fprintf(debug_fid,'Debug [make_plot]. Calculating SortValues.\n');
    end %if debugs

    if isempty(sort_values)
        fprintf('    no sort information\n');
        return;
    end
    
    % =============== show =========================
    if isempty(findstr(set_process.sortvalues,'noshow'))
        fprintf('%s \n',environment.dumplabel);
        c=fix(clock);
        datestring=datestr(datenum(c(1),c(2),c(3)));
        fprintf('%s        %02u:%02u:%02u\n',datestring,c(4),c(5),c(6));
        fprintf('%8s    %8s    %5s\n','UNSORTED','SORTED','CRITERION VALUE');
        for trial=1:length(sort_values(:,1))
            fprintf('%8d    %8d    %5d   \n',trial,sort_values(trial,1),sort_values(trial,2));
        end % for trial=
    end % show/noshow
     
    % see if the file name for the sort process is empty
    colons=findstr(set_process.sortvalues,':');
    if colons(3)== length(set_process.sortvalues)
        statpath_filename='';
    else
        statpath_filename=set_process.sortvalues(colons(3)+1:end);
    end  % if colons
    
    
    % ============= keep ============================?
    if isempty(findstr(set_process.sortvalues,'nokeep'))    % keep/nokeep
        % are we in the append mode?
        if isempty(findstr(set_process.sortvalues,'noappend'))   %append/noappend
            % yes, is there a file already open?
            filename=fopen(fid.sortvalues);
            if isempty(filename)  % filename
                % no, open a file for append
                if isempty(statpath_filename)       % use a default file name?
                    fn.sortvalues=fn.sortvalues+1;  % yes, this is a sequential numbering scheme
                    filename=sprintf('%04u.SRT',fn.sortvalues);
                else
                    filename=statpath_filename;     % no, the user defined a name for us
                end; % default file name
                filename=filepath(filename,environment.statpath);
                fid.sortvalues=fopen(filename,'wt');  % destructive open
            end; % filename
        else    % append/noappend
            % is a file currently open?
            filename=fopen(fid.sortvalues);
            if ~isempty(filename)
                fclose(fid.sortvalues); % yes, close it
            end;
            % now open a file for writing
            if isempty(statpath_filename)      % use a default file name?
                fn.sortvalues=fn.sortvalues+1;  % yes, this is a sequential numbering scheme
                filename=sprintf('%04u.SRT',fn.sortvalues);
            else
                filename=statpath_filename;     % no, the user defined a name for us
            end;
            filename=filepath(filename,environment.statpath);   
            fid.sortvalues=fopen(filename,'wt');  % destructive open
        end; % append/noappend
        % we now have the correct file open 
        fprintf(1,'writing sortvalue stats to file %s\n',filename);
        if environment.logging==1
           fprintf(fid.log,'writing sortvalue stats to file %s\n',filename);
        end;
        
        % look for and decode the sort.fmt file
        
        % minimal values, format file completes these
        sortvaluesfmt.header=0;
        sortvaluesfmt.delimiter='';
        sortvaluesfmt.unsorted='3';
        sortvaluesfmt.ordinal='3';
        sortvaluesfmt.value='5.2';
        sortvaluesfmt.format='';     
        sortvaluesfmt_name='sort.fmt';
        sortvaluesfmt_name=filepath(sortvaluesfmt_name,environment.formatpath);
        sortvaluesfmt.fid= fopen(sortvaluesfmt_name,'rt');  % try to open format file
        
        if sortvaluesfmt.fid > 1    % format file exists?
            while ~feof(sortvaluesfmt.fid)
                pcmd=fgetl(sortvaluesfmt.fid);
                if strcmp(pcmd(1:1),'#')  % ignore comments
                elseif (strncmp(pcmd,'HEADER',5))
                    sortvaluesfmt.header=1; 
                elseif (strncmp(pcmd,'DELIMITER',5))
                    [dummy,sortvaluesfmt.delimiter]=strtok(pcmd);
                    sortvaluesfmt.delimiter=sortvaluesfmt.delimiter(2:end);  %remove space
                    sortvaluesfmt.delimiter=strrep(sortvaluesfmt.delimiter,'''',''); % remove quotes
                elseif (strncmp(pcmd,'UNSORTED',5))
                    [dummy,sortvaluesfmt.unsorted]=strtok(pcmd,':');
                    sortvaluesfmt.unsorted=sortvaluesfmt.unsorted(2:end); % remove leading ":"
                elseif (strncmp(pcmd,'ORDINAL',5))
                    [dummy,sortvaluesfmt.ordinal]=strtok(pcmd,':');
                    sortvaluesfmt.ordinal=sortvaluesfmt.ordinal(2:end);  % remove leading ":"
                elseif (strncmp(pcmd,'VALUE',5))
                    [dummy,sortvaluesfmt.value]=strtok(pcmd,':');
                    sortvaluesfmt.value=sortvaluesfmt.value(2:end);  % remove leading ":"
                    sortvaluesfmt.value=strrep(sortvaluesfmt.value,':','.'); % make like printf command
                elseif strncmp(pcmd,'FORMAT',5)
                    [dummy,sortvaluesfmt.format]=strtok(pcmd);
                    sortvaluesfmt.format=sortvaluesfmt.format(2:end); % remove space
                end; % if strcmp
             end; % while ~feof
             fclose(sortvaluesfmt.fid);             

        else  %  format file does not exist      
           sortvaluesfmt.header=1;
           sortvaluesfmt.delimiter=',';
           sortvaluesfmt.unsorted='3';
           sortvaluesfmt.ordinal='3';
           sortvaluesfmt.value='5.2';
           sortvaluesfmt.format='ORDINAL   ,UNSORTED   ,VALUE'; 
        end; % if format file exists 
        
    
    
    % we now have the sortvalues format
    
    if sortvaluesfmt.header  % print header?
        fprintf(fid.sortvalues,'%s \n',environment.dumplabel);
        c=fix(clock);
        datestring=datestr(datenum(c(1),c(2),c(3)));
        fprintf('%s        %02u:%02u:%02u\n',datestring,c(4),c(5),c(6));
    end;
    
    % determine the variable to print
    remainder=sortvaluesfmt.format;
    print_list='';
    while ~isempty(remainder)
        [field,remainder]=strtok(remainder,',');
        if strncmp(field,'ORDINAL',5)
            print_list=[print_list ',trial'];
        elseif strncmp(field,'UNSORTED',5)
            print_list=[print_list ',sort_values(trial,1)'];
        elseif strncmp(field,'VALUE',5)
            print_list=[print_list ',sort_values(trial,2)'];
        end;
    end;
    
    %       % assemble printing format      
    %       print_format_string= [ ... 
    %             '%' sortvaluesfmt.unsorted 'd' sortvaluesfmt.delimiter ...
    %             '%' sortvaluesfmt.ordinal 'd' sortvaluesfmt.delimiter ...
    %             '%' sortvaluesfmt.value 'f'   '\n'''];
    
    % make appropriate substitutions for printing format      
    print_format_string=strrep(sortvaluesfmt.format,',',sortvaluesfmt.delimiter);
    print_format_string=strrep(print_format_string,'ORDINAL',['%' sortvaluesfmt.ordinal 'd']);
    print_format_string=strrep(print_format_string,'UNSORTED',['%' sortvaluesfmt.unsorted 'd']);
    print_format_string=strrep(print_format_string,'VALUE',['%' sortvaluesfmt.value 'f']); 
    print_format_string=[print_format_string '\n'''];
    for trial=1:length(sort_values(:,1))
        eval_string=['fprintf(fid.sortvalues,'''  print_format_string   print_list ');'];
        eval(eval_string,'disp(''Error writing to file.  Bad file name?'')');
    end;
    
    % close the file if we are not appending
    if ~isempty(findstr(set_process.sortvalues,'noappend')) && fopen(fid.sortvalues)
        fclose(fid.sortvalues);
    end;
 end; %  keep/nokeep  




% --------------------------------------------------------------------------------------- %
%                                MWU
% --------------------------------------------------------------------------------------- %
function show_mwu(raster_timestamps,sorted_trial_list,segment_limits)
%
%  keep or show mwu
%
% The keep process is unique.  If a named file (not numbered) is used, or if a file is
% open in the append mode, a single file is opened and the format file is used.  
% Otherwise, two files are open as aN.mwu and bN.muw where N is the file number.
%
global spiketrials 
global set_process environment
global error_fid warning_fid debug_fid trace_fid
global errors warnings debugs
global fid fn

sega_low=segment_limits(1);  
sega_high=segment_limits(2);
segb_low=segment_limits(3);
segb_high=segment_limits(4);
high_trial=segment_limits(5);
low_trial=segment_limits(6);

if debugs
    fprintf(debug_fid,'Debug [make_plot]. Calculating mwu.\n');
end;
sega_trials=find((raster_timestamps > sega_low) & (raster_timestamps <= sega_high));
segb_trials=find((raster_timestamps > segb_low) & (raster_timestamps <= segb_high));
segstats=zeros(high_trial,2);
colons=findstr(set_process.mwu,':');
if colons(3)== length(set_process.mwu)
    statpath_filename='';
else
    statpath_filename=set_process.mwu(colons(3)+1:end);
end;
for trial=sorted_trial_list   % find spikes in each segment 
    if isempty(spiketrials)
        segstats(trial,:)=[0 0];
    else
        segstats(trial,:)=[length(find(spiketrials(sega_trials,1)==trial)) ...
                length(find(spiketrials(segb_trials,1)==trial)) ];
    end;
end;

N=length(sorted_trial_list);

if isempty(findstr(set_process.mwu,'noshow'))
    fprintf(1,'%s \n',environment.dumplabel);
    c=fix(clock);
    datestring=datestr(datenum(c(1),c(2),c(3)));
    fprintf(1,'%s        %02u:%02u:%02u\n',datestring,c(4),c(5),c(6));
    fprintf(1,'TRIAL  SEG-A   SEG-B\n');
    for trial=sorted_trial_list
        fprintf(1,'%4d    %4d    %4d\n',trial,segstats(trial,1), ...
            segstats(trial,2));
    end;
    fprintf(1,'\n\n     |  SEG-A  SEG-B\n');
    fprintf(1,    '-----+------------------------\n');
    fprintf(1,    '  N  |  %4u    %4u\n',N,N);                                 
    
end; % show

filemode=0;  % 0=numbered  1=named or appended

if isempty(findstr(set_process.mwu,'nokeep'))  % keep / nokeep
    
    % are we in the append mode?
    if isempty(findstr(set_process.mwu,'noappend'))  % append / noappend
        % yes, is there a file already open?
        filemode=1;
        filename=fopen(fid.mwu);
        if isempty(filename)
            % no, open a file for append
            if isempty(statpath_filename)   % use a default file name?
                fn.mwu=fn.mwu+1;  
                filename=sprintf('%04u.MWU',fn.mwu);
            else
                filename=statpath_filename;
            end;
            filename=filepath(filename,environment.statpath);
            fid.mwu=fopen(filename,'wt');  % destructive open
        end; % if isempty(filename)
    else    % noappend
        % is a file currently open?
        filename=fopen(fid.mwu);
        if ~isempty(filename)
            fclose(fid.mwu); % yes, close it
            fid.mwu=-1;
        end;
        
        if isempty(statpath_filename)   % use a default file name?
            % special case, open two files for writing
            filemode=0;
            fn.mwu=fn.mwu+1;  
            Afilename=sprintf('a%u.mwu',fn.mwu);
            Bfilename=sprintf('b%u.mwu',fn.mwu);
            Afn=filepath(Afilename,environment.statpath); 
            Bfn=filepath(Bfilename,environment.statpath);
            Afid=fopen(Afn,'wt');  % destructive open
            Bfid=fopen(Bfn,'wt');  % destructive open
        else
            filemode=1;
            filename=statpath_filename;
            filename=filepath(filename,environment.statpath);   
            fid.mwu=fopen(filename,'wt');  % destructive open
        end; % if isempty(statpath_filename)
        
    end;   % append / noappend

    % we now have the correct file(s) open  
    if filemode==0
        % use simplified format and write results to standard mwu files
        fprintf(1,'writing pulse counts to files %s and %s\n',Afilename,Bfilename);
        if environment.logging==1
           fprintf(fid.log,'writing pulse counts to files %s and %s\n',Afilename,Bfilename);
        end;
        for trial=sorted_trial_list
            fprintf(Afid,'%6u\n',segstats(trial,1));
            fprintf(Bfid,'%6u\n',segstats(trial,2));
        end;
        fclose(Afid);
        fclose(Bfid);
        
    else  % filemode=1   
        
        fprintf(1,'writing segment stats to file %s\n',filename);
        if environment.logging==1
           fprintf(fid.log,'writing segment stats to file %s\n',filename);
        end;
        
        % look for and decode the segstat.fmt file
        
        % minimal values, format file completes this
        mwufmt.header=0;
        mwufmt.trailer=0;
        mwufmt.delimiter='';
        mwufmt.trial='0';
        mwufmt.sega='0.2';
        mwufmt.segb='0.2';
        mwufmt.segx=0;
        mwufmt.format='';     
        mwufmt_name='mwu.fmt';
        mwufmt_name=filepath(mwufmt_name,environment.formatpath);
        mwufmt.fid= fopen(mwufmt_name,'rt');  % try to open format file
        if mwufmt.fid > 1
            while ~feof(mwufmt.fid)
                pcmd=fgetl(mwufmt.fid);
                if strcmp(pcmd(1:1),'#')  % ignore comments
                elseif strncmp(pcmd,'HEADER',5)
                    mwufmt.header=1; 
                elseif strncmp(pcmd,'TRAILER',5)
                    mwufmt.trailer=1; 
                elseif strncmp(pcmd,'DELIMITER',5)
                    [dummy,mwufmt.delimiter]=strtok(pcmd);
                    mwufmt.delimiter=mwufmt.delimiter(2:end);  %remove space
                    mwufmt.delimiter=strrep(mwufmt.delimiter,'''',''); % remove quotes
                elseif strncmp(pcmd,'TRIAL',5)
                    [dummy,mwufmt.trial]=strtok(pcmd,':');
                    mwufmt.trial=mwufmt.trial(2:end); % remove leading ":"
                elseif strncmp(pcmd,'SEGA:',5)
                    [dummy,mwufmt.sega]=strtok(pcmd,':');
                    mwufmt.sega=mwufmt.sega(2:end);  % remove leading ":"
                    mwufmt.sega=strrep(mwufmt.sega,':','.'); % make like printf command
                elseif strncmp(pcmd,'SEGB:',5)
                    [dummy,mwufmt.segb]=strtok(pcmd,':');
                    mwufmt.segb=mwufmt.segb(2:end);  % remove leading ":"
                    mwufmt.segb=strrep(mwufmt.segb,':','.'); % make like printf command
                elseif strncmp(pcmd,'FORMAT',5)
                    [dummy,mwufmt.format]=strtok(pcmd);
                    mwufmt.format=mwufmt.format(2:end); % remove space
                end;
            end; % while              
            fclose(mwufmt.fid); 
            mwufmt.fid=-1;
        else    %default values         
            mwufmt.header=1;
            mwufmt.trailer=1;
            mwufmt.delimiter=',';
            mwufmt.trial='0';
            mwufmt.sega='0.2';
            mwufmt.segb='0.2';
            mwufmt.segx=0;
            mwufmt.format='TRIAL   ,SEGA   ,SEGB';
        end; % if mwufmt.fid
        if ~isempty(findstr(mwufmt.format,'SEGX'))
            mwufmt.segx=1;
        end;
        
        % we now have the segstats format
        
        if mwufmt.header  % print header?
            fprintf(fid.mwu,'%s \n',environment.dumplabel);
            c=fix(clock);
            datestring=datestr(datenum(c(1),c(2),c(3)));
            fprintf(fid.mwu,'%s        %02u:%02u:%02u\n',datestring,c(4),c(5),c(6));
        end;
        
        sega=segstats(:,1);
        segb=segstats(:,2);
        segx=[sega ; segb];
        
        % determine the variable to print
        remainder=mwufmt.format;
        print_list='';
        while ~isempty(remainder)
            [field,remainder]=strtok(remainder,',');
            if strncmp(field,'TRIAL',5)
                print_list=[print_list ',trial'];
            elseif strncmp(field,'SEGA',4)
                print_list=[print_list ',sega(trial)'];
            elseif strncmp(field,'SEGB',4)
                print_list=[print_list ',segb(trial)'];
            elseif strncmp(field,'SEGX',4)
                print_list=[print_list ',segx(trial)'];
            end;
        end;
        
        % make appropriate substitutions for printing format      
        % enforce exclusion between SEGA/SEGB versus SEGX
        print_format_string=strrep(mwufmt.format,',',mwufmt.delimiter);
        if isempty(findstr(mwufmt.format,'SEGX'))
            print_format_string=strrep(print_format_string,'TRIAL',['%' mwufmt.trial 'u']);
            print_format_string=strrep(print_format_string,'SEGA',['%' mwufmt.sega 'f']);
            print_format_string=strrep(print_format_string,'SEGB',['%' mwufmt.segb 'f']); 
            print_format_string=[print_format_string '\n'''];  
            for trial=sorted_trial_list
                eval_string=['fprintf(fid.mwu,'''  print_format_string   print_list ');'];
                eval(eval_string);
            end;
        else
            print_format_string=strrep(print_format_string,'TRIAL',['%' mwufmt.trial 'f']);         
            print_format_string=strrep(print_format_string,'SEGX',['%' mwufmt.sega 'f']); % segx uses sega
            print_format_string=[print_format_string '\n'''];
            double_trial_list=[sorted_trial_list sorted_trial_list];
            for trial=double_trial
                eval_string=['fprintf(fid.mwu,'''  print_format_string   print_list ');'];
                eval(eval_string);
            end;   
        end;
        
        if mwufmt.trailer  % print trailer
            fprintf(fid.mwu,'\n\n     |  SEG-A  SEG-B\n');
            fprintf(fid.mwu,    '-----+------------------------\n');
            fprintf(fid.mwu,    '  N  |  %4u    %4u\n',N,N); 
        end;
        % close the file if we are not appending
        if ~isempty(findstr(set_process.mwu,'noappend'))
            fclose(fid.mwu);
            fid.mwu=-1;
        end;
        
    end;  % if filemode == 0
    
end; % keep mwu



% --------------------------------------------------------------------------------------- %
%                     EVENTS
% --------------------------------------------------------------------------------------- %
function show_events(raster_timestamps,sorted_trial_list,high_trial)
%
%  keep or show event codes that matched search criteria
%
global set_process environment
global error_fid warning_fid debug_fid trace_fid
global errors warnings debugs 
global fid fn
global spikemap event_codes event_times 
global spiketrials 
global RESCALE_TIME

   if debugs
      fprintf(debug_fid,'Debug [make_plot]. Making event code list.\n');
   end;
   mark=str2double(get(findobj('Tag','mark'),'String'));
   colons=findstr(set_process.events,':');
   if (colons(3)== length(set_process.events))
      statpath_filename='';
   else
      statpath_filename=set_process.events(colons(3)+1:end);
   end;
   % event_codes( trial , list_of_events  )
   % trial  unsorted trial number  (use:  sorted_trial_list' to select relevant trials)
   if isempty(event_codes)
      return;
   end;

   sequence_length=size(event_codes,2);   % number of events in the sequence
   
   if isempty(findstr(set_process.events,'noshow'))
      if debugs
         fprintf(debug_fid,'Debug [make_plot]. SHOW event codes.\n');
      end;
      fprintf('%s \n',environment.dumplabel);
 
      fprintf('Unsorted \nTrial       Sequence\n');  
      % print list of found event codes for each of the sorted trials
      for line=1:length(sorted_trial_list)
         fprintf('%3d     ',sorted_trial_list(line));   % print trial number
         for group=1:sequence_length
            fprintf(' %6d',event_codes(sorted_trial_list(line),group));
         end;
         fprintf('\n');
      end;
   end; % show

   if isempty(findstr(set_process.events,'nokeep'))
     if debugs
       fprintf(debug_fid,'Debug [make_plot]. KEEP event codes.\n');
     end;
     % are we in the append mode?
     if isempty(findstr(set_process.events,'noappend'))
        % yes, is there a file already open?
        filename=fopen(fid.events);
        if isempty(filename)
           % no, open a file for append
           if isempty(filename)   % use a default file name?
               fn.events=fn.events+1;  
               filename=sprintf('%04u.EVT',fn.events);
           else
               filename=statpath_filename;
           end; 
           if debugs
              fprintf(debug_fid,['Debug [make_plot]. APPEND event codes file ' filename '\n']);
           end;
           filename=filepath(filename,environment.statpath);
           fid.events=fopen(filename,'wt');  % destructive open
        end; 
     else    % noappend
         % is a file currently open?
         filename=fopen(fid.events);
         if ~isempty(filename)
            fclose(fid.events); % yes, close it
            fid.events=-1;
         end;
         % now open a file for writing
         if isempty(statpath_filename)   % use a default file name?
            fn.events=fn.events+1;  
            filename=sprintf('%04u.EVT',fn.events);
         else
            filename=statpath_filename;
         end;
         if debugs
            fprintf(debug_fid,['Debug [make_plot]. NOAPPEND event code file ' filename '\n']);
         end;
         filename=filepath(filename,environment.statpath);   
         fid.events=fopen(filename,'wt');  % destructive open
     end;
     % we now have the correct file open 
     fprintf(1,'writing event codes to file %s\n',filename);
     if environment.logging==1
        fprintf(fid.log,'writing event codes to file %s\n',filename);
     end;
     
     % look for and decode the events.fmt file
     
     %minimal values, format file complete these
     eventsfmt.header=0;
     eventsfmt.delimiter=','; 
     eventsfmt.trial='0';
     eventsfmt.events='0';
     eventsfmt.format='';
     eventsfmt_name='events.fmt';
     eventsfmt_name=filepath(eventsfmt_name,environment.formatpath);
     if debugs
        fprintf(debug_fid,['Debug [make_plot]. event code default format: \n']);
        eventsfmt  % no semicolon here
     end;
     eventsfmt.fid= fopen(eventsfmt_name,'rt');  % try to open format file
     if eventsfmt.fid > 1   % format file exists?
        if debugs
           fprintf(debug_fid,['Debug [make_plot]. event code format file was found.\n']);
        end; % debugs
        while ~feof(eventsfmt.fid)
           pcmd=fgetl(eventsfmt.fid);
           if strcmp(pcmd(1:1),'#')  % ignore comments
           elseif (strncmp(pcmd,'HEADER',5))
               sortvaluesfmt.header=1; 
           elseif strncmp(pcmd,'DELIMITER',5)
               [dummy,eventsfmt.delimiter]=strtok(pcmd);
               eventsfmt.delimiter=eventsfmt.delimiter(2:end);  %remove space
               eventsfmt.delimiter=strrep(eventsfmt.delimiter,'''',''); % remove quotes
           elseif strncmp(pcmd,'TRIAL',5)
               [dummy,eventsfmt.trial]=strtok(pcmd,':');
               eventsfmt.trial=eventsfmt.trial(2:end); % remove leading ":"
               eventsfmt_trialflag=1;   % include trials
           elseif strncmp(pcmd,'EVENTS',5)
               [dummy,eventsfmt.count]=strtok(pcmd,':');
               eventsfmt.events=eventsfmt.count(2:end);  % remove leading ":"
           elseif strncmp(pcmd,'FORMAT',5)
              [dummy,eventsfmt.format]=strtok(pcmd);
              eventsfmt.format=eventsfmt.format(2:end); % remove space            
           end; % if '#'
        end; % while ~feof(eventsfmt.fid)             
        fclose(eventsfmt.fid); 
        eventsfmt.fid=-1;
     else % format file cannot be opened
          if debugs
             fprintf(debug_fid,['Debug [make_plot]. event code format file was NOT found, using default.\n']);
          end;
        eventsfmt.header=1;
        eventsfmt.delimiter=',';
        eventsfmt.trial='0';
        eventsfmt.events='0';
        eventsfmt.format='TRIAL ,EVENTS';
     end; % if format file can be opened
     
     if debugs
        fprintf(debug_fid,['Debug [make_plot]. event code format that will be used: \n']);
        eventsfmt  % no semicolon here
     end;          
     % we now have the epoch stats format

     if eventsfmt.header  % print header?
         if ~isempty(environment.dumplabel)
            fprintf(fid.events,'%s \n',environment.dumplabel);
         end;   
         c=fix(clock);
         datestring=datestr(datenum(c(1),c(2),c(3)));
         fprintf(fid.events,'%s        %02u:%02u:%02u\n',datestring,c(4),c(5),c(6));
     end; % print header
  
     % use the formatting to make list of found event codes for each of the sorted trials

      % determine the variables to print
      remainder=eventsfmt.format;
      print_list='';
      while ~isempty(remainder)
         [field,remainder]=strtok(remainder,',');
         if strncmp(field,'TRIAL',5)
            print_list=[print_list ',sorted_trial_list(trial)'];
         elseif strncmp(field,'EVENTS',4) 
             for cl=1:length(event_codes(1,:)) 
                print_list=[print_list ', event_codes(strial,'  int2str(cl) ')' ];  % list of events in sequence 
             end;  % for
         end;  % TRIAL
      end;  % while ~isempty(remainder)

      if debugs
         fprintf(debug_fid,['Debug [make_plot]. events print list: \n']);
         print_list  % no semicolon here
      end; 
      
      % make appropriate substitutions for printing format      
      print_format_string=strrep(eventsfmt.format,',',eventsfmt.delimiter);
      print_format_string=strrep(print_format_string,'TRIAL',['%' eventsfmt.trial 'd']);         
      % make string for whole group of events
      events_format_string='';     
      events_format_string=['%' eventsfmt.events 'd' eventsfmt.delimiter];
      if length(event_codes(1,:)) > 2
         for cl=1:(length(event_codes(1,:))-2)
            events_format_string=[events_format_string '%' eventsfmt.events 'd' eventsfmt.delimiter];
         end; 
      end;
      events_format_string=[events_format_string '%' eventsfmt.events 'd' ];  % last event has no delimiter
      print_format_string=strrep(print_format_string,'EVENTS',events_format_string);  % add group of events
      print_format_string=[print_format_string '\n'''];

      eval_string=['fprintf(fid.events,'''  print_format_string   print_list ');'];       

      if debugs
         fprintf(debug_fid,['Debug [make_plot]. events print format string: \n']);
         print_format_string  % no semicolon here
         fprintf(debug_fid,['Debug [make_plot]. events print eval string: \n']);
         eval_string %no semi
      end;  
      
      for trial=1:length(sorted_trial_list)
         strial=sorted_trial_list(trial);  % unsorted trial number
         eval(eval_string);
      end;   

     % close the file if we are not appending
     if ~isempty(findstr(set_process.events,'noappend'))
        fclose(fid.events);
        fid.events=-1;
     end;
   end; % keep events


  
  

% ------------------------------------------------- %
%          Text
% ------------------------------------------------- %

function plot_text;  
%
%  Read Text formatting from GUI and write text on plots
%
%  ***** May 2006:  No longer scaled relative to time axis. Is now scaled
%                   relative to current plot (plot_area), or whole page.
%
%

global error_fid warning_fid debug_fid trace_fid
global errors warnings debugs 
global super_handle plot_area_handle main_handle

for text_line=1:9
    stnum=num2str(text_line);
    if get(findobj('Tag',['text' stnum '_on_off']),'value');

        frame=get(findobj('Tag',['text' stnum '_frame']),'value');

        stx=get(findobj('Tag',['text' stnum '_x_pos']),'string');
        [clean_string,x,valid]=check_string_value(stx,0,100);
        if ~valid
            if warnings
                fprintf(warning_fid,'Warning [make_plot (text)]. Invalid string position.\n');
            end;
            x=50;
        end;
   
        sty=get(findobj('Tag',['text' stnum '_y_pos']),'string');
        [clean_string,y,valid]=check_string_value(sty,0,100);
        if ~valid
            if warnings
                fprintf(warning_fid,'Warning [make_plot (text)]. Invalid string position.\n');
            end;
            y=50;
        end;
        
        stsize=get(findobj('Tag',['text' stnum '_size']),'string');      
        [clean_string,value,valid]=check_string_value(stsize,-50,120);
        if ~valid
            if warnings
                fprintf(warning_fid,'Warning [make_plot (text)]. Invalid font size.\n');
            end;
            font_size=10;
        else
            font_size=value;
        end;
        
        angle_list=get(findobj('Tag',['text' stnum '_angle']),'string');
        angle_item_number=get(findobj('Tag',['text' stnum '_angle']),'value');
        rotation_value=str2double(angle_list(angle_item_number,:));  
        
        color_list=get(findobj('Tag',['text' stnum '_color']),'string');
        color_item_number=get(findobj('Tag',['text' stnum '_color']),'value');
        color_value=color_list(color_item_number,:);      
        
        ststr=get(findobj('Tag',['text' stnum '_string']),'string');

        
        y= 1 - (y/100);       % flip so that origin is at top of page.
        x= x/100;
        current_handle=get(gcf,'CurrentAxes');
        if frame==1
           set(gcf,'CurrentAxes',plot_area_handle);
        else
           set(gcf,'CurrentAxes',super_handle);
        end;
        text(x,y,ststr,'color',color_value,'fontsize',font_size,'rotation',rotation_value);
        set(gcf,'CurrentAxes',current_handle);

        
    end;
end;


