function [accept,status]=user_history_function(current_trial,last_trial,history,user_history_file_name,allcodes,codes)
%  Run user's history script
%
%  Called by work_scan.m
%  
%  Inputs
%    current_trial            trial number of trial that has just matched the search criteria
%    last_trial               last trial number of this unit
%    history.class            class 
%           .trial_list       = [] array of trial numbers that belong in this class
%           .values           = [] array of matching class values for each trial
%    user_history_file_name   name of the history file to call
%    allcodes                 array of every code in the trial
%    codes                    array of sequence matching codes (codes that are not in the GlobalIgnore list)
%
%
%
%    user_history_file_name   name of user history file.  Does not include an extension, but disk file must be '.m'
%  Outputs
%    accept              1 = accept this sequence,  0 = do not match this sequence, -1 = end the scan
%    status              1 = successful run,  negative value is an error code
%
%
%
global uh_current_trial uh_last_trial    % to support special user functions
global history_crash_allowed
global selected_event_data selected_fid selected_file_trials

uh_current=current_trial;
uh_last_trial=last_trial;
% for passing to history function:
data_file_name=get(findobj('Tag','filename'),'String'); 

entry_number=get(findobj('Tag','unit'),'Value');
unit_string=get(findobj('Tag','unit'),'String');
unit_name=strtrim(unit_string(entry_number,:));

center_event_number=str2double(get(findobj('Tag','center'),'String'));
mark_event_number=str2double(get(findobj('Tag','mark'),'String'));
if center_event_number <= length(codes)
   center_event=codes(center_event_number);
else
   center_event=0;  % CENTER must point to a class number
end;

mark_event=codes(mark_event_number);

selected_event_data=[];   % clear event data cache
selected_fid=0;
selected_file_trials=[];

accept=[];
DEBUG_M=1;    % three types for issue_message
WARNING_M=2;
ERROR_M=3;


if ~history_crash_allowed   % this global variable was implemented, but never used.  initialized in matoff.m.
    try
       run(eval('user_history_file_name'));
    catch
       status=-1;
       accept=-1;
       user_history_file_name=get(findobj('Tag','historyfile'),'String');
       fprintf(1,'\n** User history script > %s < generated an error and was terminated *************\n',user_history_file_name);
       fprintf(1,'%s',lasterr);
       logfile_write(' ****** User history error. History file terminated. *******');
       return;
    end;
else
    run(eval('user_history_file_name'));
end;
status=1;
if isempty(accept)
   sprintf(message_string,'Warning: User did not assign the  accept  variable in the user script. Using the default value: 1.\n');
   issue_message(WARNING_M,message_string);
   accept=1;
end;