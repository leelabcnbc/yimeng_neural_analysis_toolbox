function plot_analog(chan_marker,xzero,sorted_trial_list)
%
% Draw a plot of one or more of these analog functions:
%   raw analog
%   first derivative
%   average 
%
% Inputs
%    chan_marker        string used in GUI: '' (empty) for first analog, '2' for second analog
%    xzero              location of 0 on the x axis
%    sorted_trial_list         sorting index for work_trial_list, to select sorted trials for display 
% Outputs
%    none
%
global RESCALE_TIME ANALOG_RANGE
global work_trial_list work_analog_start_stop
global time_zero
global work_fid environment fid
global error_fid warning_fid debug_fid
global errors warnings debugs

millisecond_scale=10000;   % 

x_at_zero=get(findobj('Tag','xatzero'),'Value');   % if true, forces time scale to have zero on left
shift=str2double(get(findobj('Tag','shift'),'String'));  % time shift of center alignment
window=str2double(get(findobj('Tag','window'),'String')); % number of milliseconds to display
start_time=10 * (-(window/2)+shift) / RESCALE_TIME;   % convert to seconds
end_time= 10 * ((window/2)+shift) / RESCALE_TIME;     % convert to seconds
if x_at_zero
   xzero=start_time;
   end_time=end_time-start_time; 
   start_time=0; 
else
   xzero=0;
end

% sorted_trial_list is the ordered list of trials to analyze based on the TRIALS command
if isempty(work_trial_list)
   if debugs
      fprintf(debug_fid,'Debug [plot_analog]. No analog trials to plot.\n');
   end
   return;
end

% which type of traces need to be displayed?

raw_trace=0;
dxdt_trace=0;
average_trace=0;

% chan_marker is based on the 'Tag' names in the GUI.  First analog channel Tags always
% start with 'analog_', second analog Tags start with 'analog2_'.  Here are the
% only exceptions:
if isempty(chan_marker)
   chan=get(findobj('Tag','xchannelmenu'),'Value')-1;   % first analog
elseif strcmp(chan_marker,'2')
   chan=get(findobj('Tag','ychannelmenu'),'Value')-1;   % second analog
else
   if errors
      fprintf(error_fid,'Internal error [plot_analog].  Unknown channel marker request.\n');
   end
   return;
end

prefix=['analog' chan_marker];
if get(findobj('Tag',[prefix '_on_off']),'Value');
   raw_trace=1;
end
prefix=['dxdt' chan_marker];
if get(findobj('Tag',[prefix '_on_off']),'Value');
   dxdt_trace=1;
end
prefix=['average' chan_marker];
if get(findobj('Tag',[prefix '_on_off']),'Value');
   average_trace=1;
end

if ~(raw_trace || dxdt_trace || average_trace)
   return;
end


if debugs
   if isempty(chan_marker)
      fprintf(debug_fid,'Debug [plot_analog]. Plotting analog channel %d as primary analog channel (X).\n',chan);
   elseif strcmp(chan_marker,'2')
      fprintf(debug_fid,'Debug [plot_analog]. Plotting analog channel %d as secondary analog channel (Y).\n',chan);
   end
end

% fetch analog data (amplitude values)in the exact order that it should be displayed
if debugs
   fprintf(debug_fid,'Debug [plot_analog]. Fetching analog using fid=%d\n',work_fid.analog);
end


% Rescale all analog data to the range -1 to +1

% OLD method, before environmental variables
% rescale_analog= ANALOG_RANGE / 1;  % analog range / full scale of Y axis (full scale = 1.0)
% analog_zero= ANALOG_RANGE / 2;   % center of Y axis

rescale_analog = (abs(environment.analogmin)+abs(environment.analogmax)) / 2 ;  % range of analog values
analog_zero = rescale_analog / 2; 

analog_value= ...
   (read_analog_record(work_fid.analog,work_trial_list(sorted_trial_list),chan)-analog_zero)/rescale_analog;

if isempty(analog_value)
   if warnings
      fprintf(warning_fid,'Warning [plot_analog]. No analog data on this channel (%d).\n',chan);
   end
   return;
end

% estimate sample rate
if debugs
   fprintf(debug_fid,'Debug [plot_analog]. Estimated sample rate:\n'); 
end

rates=[];
for t=1:length(sorted_trial_list)
   number_of_samples = length(find(~isnan(analog_value(t,:))));  % find the number of non-NaN data points
   trial_duration=abs(work_analog_start_stop(sorted_trial_list(t),2)' - ...
                   work_analog_start_stop(sorted_trial_list(t),1)' )  ;  % duration of this trial in ms.
   if trial_duration==0
      if warnings
         fprintf(warning_fid,'Warning [plot_analog]. No analog data, or analog start/stop event codes missing from sequence.\n');
      end  
   else   
      rates=[rates (number_of_samples/trial_duration)];
   end   
   if debugs
      fprintf(debug_fid,'%d samples / %d msec = %d samp/s from unsorted trial %d (sorted trial %d)\n',...
         number_of_samples,trial_duration/10,round(millisecond_scale*(number_of_samples/trial_duration)),sorted_trial_list(t),t );
   end
end

freq=str2double(get(findobj('Tag','frequency'),'String')); 
if freq==0
   if warnings
      fprintf(warning_fid,'Warning [plot_analog]. Invalid A/D frequency.  Using default of 250.\n');
   end  
   freq=250;
end   
freq_error=abs(round(millisecond_scale * rates)-freq);

error_count=length(find(freq_error > 5));
if warnings && (error_count > 0)
   fprintf(1,'Warning [plot_analog]. Estimated A/D sample rate does not agree with sample rate in %d trial(s).\n',...
      error_count);
   if environment.logging==1
      fprintf(fid.log,'Warning [plot_analog]. Estimated A/D sample rate does not agree with sample rate in %d trial(s).\n',...
      error_count);
   end
end

% Every analog value requires a timestamp.  Generate timestamps based on
% the time between the centering code and code analogstart (analog start time, usually 100).
time_step=1/freq;  % seconds
centered_starting_time=((work_analog_start_stop(:,1)'-time_zero)/RESCALE_TIME)-xzero; % seconds
analog_time=zeros(size(analog_value));  % initialize time matrix
samples=size(analog_value,2);  % number of timestamps for each trial
% for trial=1:size(analog_value,1)  % over all trials
for trial=1:length(sorted_trial_list)
   %estimate and intentionally overshoot the range of timestamps
   ending_time= (samples*time_step) + centered_starting_time(sorted_trial_list(trial)) + 10 ;
   timestamps=centered_starting_time(sorted_trial_list(trial)):time_step:ending_time;
   % now use exactly the correct number of time stamps
   analog_time(trial,:)=timestamps(1:samples);   
end

% raw trace

if raw_trace  
   prefix=['analog' chan_marker];
   if debugs
      fprintf(debug_fid,'Debug [plot_analog]. Plotting raw analog.\n');
   end
   style_list=get(findobj('Tag',[prefix '_style']),'String');   % get list of options
   style_choice=get(findobj('Tag',[prefix '_style']),'Value');  % pointer to chosen option
   style_name=deblank(style_list(style_choice,:));
   style='-k';  % default
   if strcmp(style_name,'solid')
      style='-k';
   elseif strcmp(style_name,'dot')
      style=':k';
   elseif strcmp(style_name,'dash')
      style='--k';
    elseif(strcmp(style_name,'red'))
        style='-r';
    elseif(strcmp(style_name,'blue'))
        style='-b';
    elseif(strcmp(style_name,'green'))
        style='-g';
    elseif(strcmp(style_name,'cyan'))
        style='-c';
   end 
   [clean_string,sep,valid]=check_string_value( ...
      get(findobj('Tag',[prefix '_separation']),'String'),-100,+100);
   if ~valid
      if warnings
         fprintf(warning_fid,'Warning [plot_analog]. Invalid trace separation value. Defaulting to 5.\n');
      end
      sep=5;
   end
   sep=sep/100;  % convert to percent
   [clean_string,ypos,valid]=check_string_value( ...
      get(findobj('Tag',[prefix '_y_pos']),'String'),-300,+300);
   if ~valid
      if warnings
         fprintf(warning_fid,'Warning [plot_analog]. Invalid y position. Defaulting to 25.\n');
      end
      ypos=25;
   end
   ypos=ypos/100;  % convert to percent
   [clean_string,analog_size,valid]=check_string_value( ...
      get(findobj('Tag',[prefix '_trace_size']),'String'),-10000,+10000);
   if ~valid
      if warnings
         fprintf(warning_fid,'Warning [plot_analog]. Invalid size. Defaulting to 5.\n');
      end
      analog_size=5;
   end
   analog_size=analog_size/100;  % convert to percent
   analog(1:length(sorted_trial_list),analog_time,analog_value,ypos,sep,analog_size,style);
end


%     dxdt trace
%  note, derivative is smoothed with 3 point moving average.
if dxdt_trace 
   prefix=['dxdt' chan_marker];
   if debugs
      fprintf(debug_fid,'Debug [plot_analog]. Plotting first Dx.\n');
   end
   style_list=get(findobj('Tag',[prefix '_style']),'String');   % get list of options
   style_choice=get(findobj('Tag',[prefix '_style']),'Value');  % pointer to chosen option
   style_name=deblank(style_list(style_choice,:));
   style='-k';  % default
   if strcmp(style_name,'solid')
      style='-k';
   elseif strcmp(style_name,'dot')
      style=':k';
   elseif strcmp(style_name,'dash')
      style='--k';
    elseif(strcmp(style_name,'red'))
        style='-r';
    elseif(strcmp(style_name,'blue'))
        style='-b';
    elseif(strcmp(style_name,'green'))
        style='-g';
    elseif(strcmp(style_name,'cyan'))
        style='-c';
   end 
   
   [clean_string,sep,valid]=check_string_value( ...
      get(findobj('Tag',[prefix '_separation']),'String'),-100,+100);
   if ~valid
      if warnings
         fprintf(warning_fid,'Warning [plot_analog]. Invalid trace separation value. Defaulting to 5.\n');
      end
      sep=5;
   end
   sep=sep/100;  % convert to percent
   [clean_string,ypos,valid]=check_string_value( ...
      get(findobj('Tag',[prefix '_y_pos']),'String'),-300,+300);
   if ~valid
      if warnings
         fprintf(warning_fid,'Warning [plot_analog]. Invalid y position. Defaulting to 25.\n');
      end
      ypos=25;
   end
   ypos=ypos/100;  % convert to percent
   [clean_string,analog_size,valid]=check_string_value( ...
      get(findobj('Tag',[prefix '_trace_size']),'String'),-10000,+10000);
   if ~valid
      if warnings
         fprintf(warning_fid,'Warning [plot_analog]. Invalid size. Defaulting to 5.\n');
      end
      analog_size=5;
   end
   analog_size=analog_size/100;  % convert to percent

   % calculate the ratio of differences and transpose back.
   first_dx= (diff(analog_value')./diff(analog_time'))';
   % this dx/dt is noisy, so smooth it a bit
   smooth_dx=(first_dx(:,3:end)+first_dx(:,2:end-1)+first_dx(:,1:end-2))/3;
   % transpose time array back and length by one to match length of first_dx
   %  +(3 * time_step) ==> the processing shifted us 4 steps backwords in time,
   %  1 step for dx/dt = 3 steps for average.  
   scaled_time=analog_time(:,1:size(smooth_dx,2)) + 3 * time_step;
   analog(1:length(sorted_trial_list),scaled_time,smooth_dx,ypos,sep,analog_size,style);
end

%   average_trace

if average_trace 
   prefix=['average' chan_marker];
   if  debugs
      fprintf(debug_fid,'Debug [plot_analog]. Plotting average analog.\n');
   end
   style_list=get(findobj('Tag',[prefix '_style']),'String');   % get list of options
   style_choice=get(findobj('Tag',[prefix '_style']),'Value');  % pointer to chosen option
   style_name=deblank(style_list(style_choice,:));
   style='-k';  % default
   if strcmp(style_name,'solid')
      style='-k';
   elseif strcmp(style_name,'dot')
      style=':k';
   elseif strcmp(style_name,'dash')
      style='--k';
    elseif(strcmp(style_name,'red'))
        style='-r';
    elseif(strcmp(style_name,'blue'))
        style='-b';
    elseif(strcmp(style_name,'green'))
        style='-g';
    elseif(strcmp(style_name,'cyan'))
        style='-c';
   end 
   sep=0; 
   
      [clean_string,ypos,valid]=check_string_value( ...
      get(findobj('Tag',[prefix '_y_pos']),'String'),-300,+300);
   if ~valid
      if warnings
         fprintf(warning_fid,'Warning [plot_analog]. Invalid y position. Defaulting to 25.\n');
      end
      ypos=25;
   end
   ypos=ypos/100;  % convert to percent
   [clean_string,analog_size,valid]=check_string_value( ...
      get(findobj('Tag',[prefix '_trace_size']),'String'),-10000,+10000);
   if ~valid
      if warnings
         fprintf(warning_fid,'Warning [plot_analog]. Invalid size. Defaulting to 5.\n');
      end
      analog_size=5;
   end
   analog_size=analog_size/100;  % convert to percent
   
   % align all analog data on one timescale
   [A,T]=thin_mean_alignment(1:length(sorted_trial_list),analog_time,analog_value,time_step); 
   analog(1,T,thin_mean(A),ypos,sep,analog_size,style);  % use a special version of "mean()"
end

