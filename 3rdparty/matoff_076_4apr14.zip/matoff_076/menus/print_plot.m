function [response]=print_plot(figure_number)
%
% print_plot  make hard copy of current plot.  See also: store_plot
% 
%  Inputs
%    figure_number   figure number of plot to print = figure handle
%  Outputs
%    response
%
global environment
global error_fid warning_fid debug_fid
global errors warnings debugs
%
response='';
if isempty(figure_number)   % this should never happen
   if errors     
      fprintf(error_fid,'Error [print_plot]. How did we get an empty figure number?\n');
   end
   return;   
end

if ~ishandle(figure_number)
   if warnings     
      fprintf(warning_fid,'Warning [print_plot]. No such figure number (%d)\n',figure_number);
   end
   return;
end

o_number=get(findobj('Tag','print_orientation'),'Value');
o_string=get(findobj('Tag','print_orientation'),'String');
orientation=deblank(strjust(o_string(o_number,:),'left'));   % landscape or portrait
set(figure_number,'PaperOrientation',orientation);

pt_number=get(findobj('Tag','print_paper'),'Value');
pt_string=get(findobj('Tag','print_paper'),'String');
paper_type=deblank(strjust(pt_string(pt_number,:),'left'));  % 'US Letter','US Legal','A4'

enable_color=get(findobj('Tag','enable_color'),'Value');

set(figure_number,'PaperPositionMode','Manual');
switch paper_type
case 'US Letter'
   set(figure_number,'PaperUnits','Inches');
   position_spec=[.25 .25 10.5 8];
   set(figure_number,'PaperType','usletter');
case 'US Legal'
   set(figure_number,'PaperUnits','Inches');
   position_spec=[.25 .25 13.5 8];
   set(figure_number,'PaperType','uslegal');
case 'A4'
   set(figure_number,'PaperUnits','Centimeters');
   position_spec=[1.0 1.0 27.5 19.0];
   set(figure_number,'PaperType','A4');
end

if strcmp(orientation,'portrait')
   holder=position_spec(3);
   position_spec(3)=position_spec(4);   % Reverse width and height...
   position_spec(4)=position_spec(3);
end

set(figure_number,'PaperPosition',position_spec);


if debugs     
   fprintf(debug_fid,'Debug [print_plot]. Printing figure >%d<\n',figure_number);
end

foption=sprintf('-f%d',figure_number);
if enable_color
   print('-dwinc',foption);
else
   print('-dwin',foption);
end
response='printing...';



      