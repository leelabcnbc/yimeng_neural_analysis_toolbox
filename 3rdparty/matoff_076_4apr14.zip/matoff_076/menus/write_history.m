function [history_length]=write_history(history_fid,history,unit_name)
%
%  Write the history for one unit into a previously opened file.
%  
%  Inputs
%    history_fid                 pointer to open file.
%    history().                 .class, .trial_list and .values for unit
%    unit_name                   name of the unit 
%  Output   
%    history_length              number of bytes written, or negative value if error encountered
%
%  history structure
%    history(n).class       class (n is an index into each class)
%              .trial_list  = [] array of trial numbers that belong in this class
%              .values      = [] array of matching class values for each trial
%
%  Globals modified
%  none
%
global error_fid warning_fid debug_fid
global errors warnings debugs
global MAX_UNIT_NAME

max_unit_name=num2str(eval('MAX_UNIT_NAME'));
history_length=0;   
byte_count=0;   % becomes history_length after a successful write

if isempty(history) | (length(history)==0)
   if debugs
      fprintf(debug_fid,'Debug [write_history]. Empty history.\n');
   end;
   return;
end;

if isempty(unit_name)
   if warnings
      fprintf(warning_fid,'Warning [write_history]. Empty unit name.\n');
   end;
   return;
end;

if debugs
   fprintf(debug_fid,'Debug [write_history]. Will write to history fid= %d\n',history_fid);
end;
% check for valid, open history file
if isempty(fopen(history_fid))
   if errors
      fprintf(error_fid,'Error [write_history]. History file is not open.  Cannot write history.\n');
   end;
   return;  % return with zero length
end;


%      write header for this unit

% Check length of unit name for sanity
if length(unit_name) > MAX_UNIT_NAME 
   if errors
      fprintf(error_fid,'Error [write_history].  Illegal unit name: %s.\n',unit_name);
   end;
   history_length= -1;  % exit with error signal
   return;  
end;

try
   byte_count=2*fwrite(history_fid,-1,'int16');   % 2 byte header marker
   unit_name=[unit_name zeros(1,MAX_UNIT_NAME-length(unit_name))];     % force unit name to full size of field
   byte_count=byte_count+ 1*fwrite(history_fid,unit_name,[max_unit_name '*char']);   % 12 byte unit name
catch
   if errors
      fprintf(error_fid,'Error [write_history].  Error writing header marker.\n');
   end;   
   history_length= -2;  % exit with error signal
   return;  
end;

for cindex=1:length(history)
    % write size information to data file
    number_of_trials=length(history(cindex).values);             % number of trials as an integer
    number_of_trials_string=num2str(eval('number_of_trials'));   % number of trials as a string
    list_size=length(history(cindex).trial_list);                % list size as an integer
    list_size_string=num2str(eval('list_size'));                 % list size as a string
    try
       byte_count=byte_count + 2*fwrite(history_fid,history(cindex).class,'int16');   % 2 byte class
       byte_count=byte_count + 2*fwrite(history_fid,number_of_trials,'int16');        % 2 byte number of trials
       byte_count=byte_count + 2*fwrite(history_fid,list_size,'int16');               % 2 byte length of trial list
    catch
       if errors
          fprintf(error_fid,'Error [write_history].  Error writing unit header.\n');
       end;   
       history_length= -3;  % exit with error signal
       return;  
    end;

    try    % variable length record fields
       if list_size > 0
          byte_count=byte_count+1*fwrite(history_fid,history(cindex).trial_list,[list_size_string '*char']);   % 
          byte_count=byte_count+2*fwrite(history_fid,history(cindex).values,'int16');   %  
       end;
    catch
       if errors
          fprintf(error_fid,'Error [write_history].  Error writing unit header.\n');
       end;   
       history_length= -4;  % exit with error signal
       return;  
    end;
end;

history_length=byte_count;
if debugs
   fprintf(debug_fid,'Debug [write_history]. Unit written to history file.  %d bytes in record.\n',history_length);
end;


