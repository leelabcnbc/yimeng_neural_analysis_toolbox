function [response]= set_process_command(command)
%
% Implement 'set' command, e.g., set segment keep
%
% Inputs
%   command    a set command, e.g. set segment keep
% Outputs
%   response   ascii string to return to user.
% Globals modified
%   set_process   structure that holds all set options.
%                 format: set_process.histogram='noshow:nokeep:noappend:filename'; 

global set_process
global fid fn
global error_fid warning_fid debug_fid
global errors warnings debugs

response='';
valid=0;  % becomes valid when a command is recognized

yesstates={'show','keep','append'};
nostates={'noshow','nokeep','noappend'};  

[cmd,params]=strtok(deblank(command));  % separate command (process) name from parameters
cmd=lower(deblank(strjust(cmd)));  % all process names to lower case
params=deblank(strjust(params,'left'));  % squeeze out spaces from parameters
lparams=lower(params);    % lower case version of parameters 

if debugs
   fprintf(debug_fid,'Debug [set_process_command]. Processing >%s< with parameters >%s<',cmd,lparams);
   fprintf('\n');  % resolves problem with incomplete set command
end;
if isempty(params)  % skip if command string is empty
   response='Incomplete SET command. Perhaps you mean setenv.';
   return;
end;

if strncmp(cmd,'segmentstats',3)
   % check first for a new file name, since the name could be almost anything
   if strncmp(lparams,'name',4)     % set segmentstats name <filename>
      valid=1;
      [dummy,file_name]=strtok(params);  % fetch file name
      file_name=deblank(strjust(file_name,'left')) ;  % do the best we can to clean up name
      set_process.segmentstats=replace_process_string(set_process.segmentstats,4,file_name);
   % filenumber      
   elseif strncmp(lparams,'filenumber',4) 
      [dummy,file_number]=strtok(params);  % fetch file name
      [dummy,ss_fn,valid]=check_string_value(file_number,0,9999);
      if ~valid
         response='Invalid file number. Allowed range is 0 to 9999';
         valid=1;  % to skip other error messages
      else 
         fn.segmentstats=ss_fn;
      end;
   % noshow/nokeep/noappend or show/keep/append commands
   else  
      if ~isempty(findstr(lparams,'no'))  % noshow/nokeep/noappend
         states=nostates;
      else
         states=yesstates;     % show/keep/append
      end;
      for i=1:3
         if ~isempty(findstr(lparams,states{i}))  % look for a match
            valid=1;
            set_process.segmentstats=replace_process_string(set_process.segmentstats,i,states{i}); % update
         end;
      end;
    end;
      
elseif strncmp(cmd,'epochstats',3)
   % check first for a new file name, since the name could be almost anything
   if strncmp(lparams,'name',4)  
      valid=1;
      [dummy,file_name]=strtok(params);  % fetch file name
      file_name=deblank(strjust(file_name,'left')) ;  % do the best we can to clean up name
      set_process.epochstats=replace_process_string(set_process.epochstats,4,file_name);
   % filenumber      
   elseif strncmp(lparams,'filenumber',4) 
      [dummy,file_number]=strtok(params);  % fetch file name
      [dummy,es_fn,valid]=check_string_value(file_number,0,9999);
      if ~valid
	 response='Invalid file number. Allowed range is 0 to 9999';
	 valid=1;  % to skip other error messages
      else 
	 fn.epochstats=es_fn;
      end;   
   else   % this is either a noshow/nokeep/noappend or a show/keep/append
      if ~isempty(findstr(lparams,'no'))  % noshow/nokeep/noappend
	 states=nostates;
      else
	 states=yesstates;     % show/keep/append
      end;
      for i=1:3
	 if ~isempty(findstr(lparams,states{i}))  % look for a match
	    valid=1;
	    set_process.epochstats=replace_process_string(set_process.epochstats,i,states{i}); % update
	 end; 
      end; 
    end; 
      
    
 elseif strncmp(cmd,'sort',3)
   % check first for a new file name, since the name could be almost anything
   if strncmp(lparams,'name',4)  
      valid=1;      
      [dummy,file_name]=strtok(params);  % fetch file name
      file_name=deblank(strjust(file_name,'left')) ;  % do the best we can to clean up name
      set_process.sortvalues=replace_process_string(set_process.sortvalues,4,file_name);
   % filenumber      
   elseif strncmp(lparams,'filenumber',4) 
      [dummy,file_number]=strtok(params);  % fetch file name
      [dummy,sv_fn,valid]=check_string_value(file_number,0,9999);
      if ~valid
         response='Invalid file number. Allowed range is 0 to 9999';
         valid=1;  % to skip other error messages
      else 
         fn.sortvalues=sv_fn;
      end;    
   elseif strncmp(lparams,'reverse',3)
      set(findobj('Tag','sort_reverse_on_off'),'Value',1);  % set sort reverse
      valid=1;
   elseif strncmp(lparams,'noreverse',5)
      set(findobj('Tag','sort_reverse_on_off'),'Value',0);  % set sort noreverse
      valid=1;
   else   % this is either a noshow/nokeep/noappend or a show/keep/append
      if ~isempty(findstr(lparams,'no'))  % noshow/nokeep/noappend
         states=nostates;
      else
         states=yesstates;     % show/keep/append
      end;
      for i=1:3
         if ~isempty(findstr(lparams,states{i}))  % look for a match
            valid=1;
            set_process.sortvalues=replace_process_string(set_process.sortvalues,i,states{i}); % update
         end; 
      end; 
    end;    
    
    
 % for the Plot process:    Show/Noshow  hide and reveal the plot on the screen
 %                                                      
 elseif strncmp(cmd,'plot',3)  % show/noshow have special meaning
    if strncmp(lparams,'name',4) 
      valid=1;      
      [dummy,file_name]=strtok(params);  % fetch file name
      file_name=deblank(strjust(file_name,'left')) ;  % do the best we can to clean up name
      set_process.plot=replace_process_string(set_process.plot,4,file_name);
   % filenumber      
   elseif strncmp(lparams,'filenumber',4) 
      [dummy,file_number]=strtok(params);  % fetch file name
      [dummy,p_fn,valid]=check_string_value(file_number,0,9999);
      if ~valid
         response='Invalid file number. Allowed range is 0 to 9999';
         valid=1;  % to skip other error messages
      else 
         fn.plot=p_fn;
      end; 
   else   % this is either a noshow/nokeep/noappend or a show/keep/append
      if ~isempty(findstr(lparams,'show'))
         valid=1;
         if ~isempty(findstr(lparams,'no'))
            set(findobj('Tag','hide_plot'),'value',1); % special meaning: hide plot
         else
            set(findobj('Tag','hide_plot'),'value',0);
         end;
      end; 
      if ~isempty(findstr(lparams,'append'))
         valid=1;   % give error message here, not at end
         response='cannot append plot files';
      end;
      if ~isempty(findstr(lparams,'no'))  % noshow/nokeep/noappend
         states=nostates;
      else
         states=yesstates;     % show/keep/append
      end;
      for i=2:2  % only keep/nokeep is valid here
         if ~isempty(findstr(lparams,states{i}))  % look for a match
            valid=1;
            set_process.plot=replace_process_string(set_process.plot,i,states{i}); % update
         end; 
      end; 
    end;       
    
 
 % for Print:    color/Nocolor
 %                                                      
 elseif strncmp(cmd,'print',3)  
    if strncmp(lparams,'color',4) 
      valid=1;      
      set(findobj('Tag','enable_color'),'Value',1);
    elseif strncmp(lparams,'nocolor',4)       
      valid=1;      
      set(findobj('Tag','enable_color'),'Value',0);
    end;
  

 elseif strncmp(cmd,'mwu',3)
   % check first for a new file name, since the name could be almost anything
   if strncmp(lparams,'name',4)  
      valid=1;      
      [dummy,file_name]=strtok(params);  % fetch file name
      file_name=deblank(strjust(file_name,'left')) ;  % do the best we can to clean up name
      set_process.mwu=replace_process_string(set_process.mwu,4,file_name);
   % filenumber      
   elseif strncmp(lparams,'filenumber',4) 
      [dummy,file_number]=strtok(params);  % fetch file name
      [dummy,m_fn,valid]=check_string_value(file_number,0,9999);
      if ~valid
         response='Invalid file number. Allowed range is 0 to 9999';
         valid=1;  % to skip other error messages
      else 
         fn.mwu=m_fn;
      end;    
   else   % this is either a noshow/nokeep/noappend or a show/keep/append
      if ~isempty(findstr(lparams,'no'))  % noshow/nokeep/noappend
         states=nostates;
      else
         states=yesstates;     % show/keep/append
      end;
      for i=1:3
         if (~isempty(findstr(lparams,states{i})))  % look for a match
            valid=1;
            set_process.mwu=replace_process_string(set_process.mwu,i,states{i}); % update
         end; 
      end; 
    end;       
    
    
  elseif strncmp(cmd,'histogram',3)
   % check first for a new file name, since the name could be almost anything
   if strncmp(lparams,'name',4)  
      valid=1;     
      [dummy,file_name]=strtok(params);  % fetch file name
      file_name=deblank(strjust(file_name,'left')) ;  % do the best we can to clean up name
      set_process.histogram=replace_process_string(set_process.histogram,4,file_name);
   % filenumber      
   elseif strncmp(lparams,'filenumber',4) 
      [dummy,file_number]=strtok(params);  % fetch file name
      [dummy,hist_fn,valid]=check_string_value(file_number,0,9999);
      if ~valid
         response='Invalid file number. Allowed range is 0 to 9999';
         valid=1;  % to skip other error messages
      else 
         fn.histogram=hist_fn;
      end;    
   else   % this is either a noshow/nokeep/noappend or a show/keep/append
      if ~isempty(findstr(lparams,'no'))  % noshow/nokeep/noappend
         states=nostates;
      else
         states=yesstates;     % show/keep/append
      end;
      for i=1:3
         if ~isempty(findstr(lparams,states{i}))  % look for a match
            valid=1;
            set_process.histogram=replace_process_string(set_process.histogram,i,states{i}); % update
         end; 
      end; 
   end;      



 elseif strncmp(cmd,'events',3)
   % check first for a new file name, since the name could be almost anything
   if strncmp(lparams,'name',4)  
      valid=1;      
      [dummy,file_name]=strtok(params);  % fetch file name
      file_name=deblank(strjust(file_name,'left')) ;  % do the best we can to clean up name
      set_process.events=replace_process_string(set_process.events,4,file_name);
   % filenumber      
   elseif strncmp(lparams,'filenumber',4) 
      [dummy,file_number]=strtok(params);  % fetch file name
      [dummy,m_fn,valid]=check_string_value(file_number,0,9999);
      if ~valid
         response='Invalid file number. Allowed range is 0 to 9999';
         valid=1;  % to skip other error messages
      else 
         fn.events=m_fn;
      end;    
   else   % this is either a noshow/nokeep/noappend or a show/keep/append
      if ~isempty(findstr(lparams,'no'))  % noshow/nokeep/noappend
         states=nostates;
      else
         states=yesstates;     % show/keep/append
      end;
      for i=1:3
         if (~isempty(findstr(lparams,states{i})))  % look for a match
            valid=1;
            set_process.events=replace_process_string(set_process.events,i,states{i}); % update
         end; 
      end; 
    end;   



end;
      
if ~valid
   response='Improper SET command. Perhaps you mean setenv.';
end;
       
    

   
