function ascale(shift_from_top, y_height, x, number_of_ticks, tick_length, tick_direction, ticklabels)
%
%  Draw a vertical scale on a plot
% example:
%   axis([0 10 0 1]);
%   axis manual;
%   hold on;
%   ascale(0.6, 0.3, 5, 3, 0.1, [0 50 100]);
%
% Inputs
%  shift_from_top     0 to 1  location of the top of the scale
%  y_height           0 to 1  bottom of scale = shift_from_top + y_height
%  x                  absolute time value for vertical axis
%  number_of_ticks    includes bottom and top tick.  3 ticks = 1 bottom, 1 center, 1 top
%  tick_length        0 to 1 horizontal tick length
%  tick_direction     +1 = right, -1 = left
%  ticklabels         [ ]   first value goes on bottom, last value goes on top

y_bottom = 1-shift_from_top-y_height;
y_top = 1-shift_from_top;

plot([x x],[y_bottom y_top],'-k');

y = y_bottom;
for i = 1:number_of_ticks,
   
   plot([x (x+(tick_direction * tick_length))], [y y], '-k');
   text(x + tick_length*1.2, y, num2str(ticklabels(i)));
   
   y = y + y_height/(number_of_ticks-1);   
   
end;
