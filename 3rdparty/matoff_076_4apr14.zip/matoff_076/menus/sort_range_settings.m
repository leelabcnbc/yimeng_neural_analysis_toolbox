function sort_range_settings(sort_menu_item)
%
%  Turn on appropriate sort range
%  Find the low and high range values
%  Reset values if they are out of bounds
%  
%  Input
%     sort_menu_item
%           1       off
%           2       center
%           3       time
%           4       pulse <low> <high>
%           5       epoch
%           6       delta <low> <high>
%           7       min   <low> <high>
%           8       max   <low> <high>
%           9       peak  <low> <high>
%          10       pit   <low> <high>
%          11       zero
%          12       integral <low> <high>
%          13       history <class>
%

global error_fid warning_fid debug_fid
global errors warnings debugs

low=NaN;
high=NaN;

ranges_off;  % clear sort history ranges first

set(findobj('Tag','trialsort'),'Value',sort_menu_item);

switch sort_menu_item
case {1,2,3,5,11}  % off, center, time, epoch, zero
   range_name='';
case 4  % pulse
   range_name='pulse';
case 6  % delta
   range_name='delta';
case 7  % min
   range_name='min';    
case 8  % max
   range_name='max';      
case 9 % peak
   range_name='peak';    
case 10  % pit
   range_name='pit';
case 12   % integral
   range_name='int';   
case 13   % history
   range_name='history';  
end;

if ~isempty(range_name)   % does this sort use a range?
   range_on(range_name);  % turn on this range
   low_string=get(findobj('Tag',[range_name 'sortrange1']),'string');
   [clean_string,low,low_valid]=check_string_value(low_string,0,600);
   if strcmp(range_name,'history')
      high_string=0;
   else
      high_string=get(findobj('Tag',[range_name 'sortrange2']),'string');  
   end;
end; % ~isempty(range_name)


function range_on(range_name)
%
%  Turn on display of one pair of sort range windows and the range-show checkbox
%  History has a single range value and no checkbox

r1=[char(range_name) 'sortrange1'];   % strings with the range names
r2=[char(range_name) 'sortrange2'];

set(findobj('Tag',r1),'visible','on');
if strcmp(range_name,'history')      % history is the exception
   range_show=0;
else
   set(findobj('Tag',r2),'visible','on');
   set(findobj('Tag','sortrangeshow'),'visible','on');
   range_show=get(findobj('Tag','sortrangeshow'),'Value');
end;

if range_show
    set(findobj('Tag',r1),'BackgroundColor',[0.5 1 1]);   % normal coloring
    set(findobj('Tag',r2),'BackgroundColor',[0.5 1 1]);  
else
    set(findobj('Tag',r1),'BackgroundColor',[1 1 1]);     % white
    set(findobj('Tag',r2),'BackgroundColor',[1 1 1]);
end;
 
 
   
function ranges_off
%
%   Turn off display of all sort range windows and range-show checkbox
%
rangetype={'pulse','peak','pit','delta','max','min','int'};
for rt=1:length(rangetype)
   typename=char(rangetype(rt));  % necessary conversion
   set(findobj('Tag',[typename 'sortrange1']),'visible','off');
   set(findobj('Tag',[typename 'sortrange2']),'visible','off');   
end;
set(findobj('Tag','historysortrange1'),'visible','off');
set(findobj('Tag','sortrangeshow'),'visible','off');