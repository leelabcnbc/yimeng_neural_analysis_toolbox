fprintf(1,'Already out of command mode. Use CMD to return to command mode.\n');
