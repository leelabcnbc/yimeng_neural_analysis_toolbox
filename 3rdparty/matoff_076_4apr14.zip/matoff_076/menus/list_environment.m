function [env]=list_environment()
%
% Returns a copy of the environment for use in a history script
%
% Inputs
%    none
% Outputs
%    env           copy of environment
% 
%
global environment


env=environment;
