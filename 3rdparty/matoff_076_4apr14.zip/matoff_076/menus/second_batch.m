function [return_value]=second_batch(replacement)
%
% Process a DOS batch file "call"-ed from another DOS batch file
% Do not allow another "call" after this one.
%
% Inputs
%   replacement    structure of strings to use as replacements in batch file (%0, %1, etc.)
%                  Also has the name of the file that is being called (.B0)
% Outputs
%  return_values
%       Inhereted from LOAD
%           -1  protocol file not found
%           -2  file error (opening data file)
%           -3  EXIT requested
%            1  normal
%            2  BREAK requested, protocol file not closed
%       New
%           -4  Too many levels of batch indirection
%           -5  second batch file not found
% Globals modified
%   call_fid
%   pcoff_arguement   if a PCOFF command is in batch file
%
%
global environment pcoff_argument call_fid fid
global load_state
global error_fid warning_fid debug_fid
global errors warnings debugs

% Get the name of the new batch file
call_file_name=replacement.B0;
if (isempty(call_file_name))
   return_value= -5;
   return;
end;

% add ".bat" if it has no extension
[name,extension]=strtok(call_file_name,'.');
if (isempty(extension))
   call_file_name=[call_file_name '.bat'];
end;   

% see if a called batch file was left open
test_fid=call_fid;
call_fid=fopen(call_file_name,'rt');  
if ((call_fid==test_fid) & (call_fid > 1))  % was this file already open?
   if (warnings)
      fprintf(warning_fid,'Warning [second_batch]. Secondary batch file was already open. Resetting it.\n');
   end;
   fclose(call_fid);
   call_fid=-1;
   call_fid=fopen(call_file_name,'rt');
end;

% see if a valid file was opened up
if (call_fid >= 0) 
   return_value=1; % normal                 
else
   if (errors)
      fprintf(error_fid,'Error [second_batch]. Could not find batch file: %s\n',call_file_name);
   end;
   return_value=-5;
   return;
end;

% process each line of the new batch file   
while (~feof(call_fid))
   rcmd=fgetl(call_fid);  % fetch command from batch file
   fprintf(1,'= %s\n',rcmd);  % echo batch command
   if environment.logging==1
      fprintf(fid.log,'= %s\n',rcmd);  % echo batch command
   end;
   % replace batch replacement variables 
   if (~isempty(replacement.B0))
      rcmd=strrep(rcmd,'%0',replacement.B0);
   end;
   if (~isempty(replacement.B1))
      rcmd=strrep(rcmd,'%1',replacement.B1);
   end;
   if (~isempty(replacement.B2))
      rcmd=strrep(rcmd,'%2',replacement.B2);
   end;
   if (~isempty(replacement.B3))
      rcmd=strrep(rcmd,'%3',replacement.B3);
   end;   
   if (~isempty(replacement.B4))
      rcmd=strrep(rcmd,'%4',replacement.B4);
   end;
   if (~isempty(replacement.B5))
      rcmd=strrep(rcmd,'%5',replacement.B5);
   end;
   if (~isempty(replacement.B6))
      rcmd=strrep(rcmd,'%6',replacement.B6);
   end;
   if (~isempty(replacement.B7))
      rcmd=strrep(rcmd,'%7',replacement.B7);
   end;
   if (~isempty(replacement.B8))
      rcmd=strrep(rcmd,'%8',replacement.B8);
   end;
   if (~isempty(replacement.B9))
      rcmd=strrep(rcmd,'%9',replacement.B9);
   end;

   c=deblank(rcmd);  % check for control commands
   [c,params]=strtok(c);  % separate command name from any parameters
   c=lower(deblank(strjust(c)));  % command to lower case

   if (strncmp(c,'set',3))
      good=setenv(rcmd);
      if good==0
         if warnings
            fprintf(warning_fid,'Warning [second_batch]. %s   environmental variable not recognized.\n',rcmd);
         end;
      elseif good==2
         if warnings
            fprintf(warning_fid,'Warning [second_batch]. %s   environmental variable no longer used.\n',rcmd);
         end;
      end; % if good

   elseif strncmp(c,'pcoff',5)
      % determine the replaceable parameters  
      pcoff_argument.P0=''; pcoff_argument.P1=''; pcoff_argument.P2='';
      pcoff_argument.P3=''; pcoff_argument.P4=''; pcoff_argument.P5='';
      pcoff_argument.P6=''; pcoff_argument.P7=''; pcoff_argument.P8='';
      pcoff_argument.P9='';
      pcoff_argument.P0='PCOFF';       % pcoff command
      [pcoff_argument.P1,rem]=strtok(params);  % protocol file name
      [pcoff_argument.P2,rem]=strtok(rem);     % data file name
      [pcoff_argument.P3,rem]=strtok(rem);     % unit
      [pcoff_argument.P4,rem]=strtok(rem);     % metafile parameter 1
      [pcoff_argument.P5,rem]=strtok(rem);     % metafile parameter 2
      [pcoff_argument.P6,rem]=strtok(rem);     % metafile parameter 3
      [pcoff_argument.P7,rem]=strtok(rem);     % metafile parameter 4...
      [pcoff_argument.P8,rem]=strtok(rem);     % 5
      [pcoff_argument.P9,rem]=strtok(rem);     % 6
      
      if debugs
         pcoff_argument    % omit ";" to print
      end; 
      
      % issue file and unit commands first
      if ~strncmp(pcoff_argument.P2,'-',1)
         issue_command(['file ' pcoff_argument.P2]);  % file command (check for place holder)
      else
         pcoff_argument.P2='';
      end;      
      if ~strncmp(pcoff_argument.P3,'-',1)
         issue_command(['unit ' pcoff_argument.P3]);  % Unit command 
      else
         pcoff_argument.P3='';
      end;         
      if strncmp(pcoff_argument.P4,'-',1)| isempty(pcoff_argument.P4)
         pcoff_argument.P4='';    % first metafile argument
      end;     
      if strncmp(pcoff_argument.P5,'-',1)| isempty(pcoff_argument.P5)
         pcoff_argument.P5='';    % second metafile argument
      end;               
      if strncmp(pcoff_argument.P6,'-',1)| isempty(pcoff_argument.P6)
         pcoff_argument.P6='';    % third metafile argument
      end;      
      if strncmp(pcoff_argument.P7,'-',1)| isempty(pcoff_argument.P7)
         pcoff_argument.P7='';    % fourth metafile argument
      end;
      if strncmp(pcoff_argument.P8,'-',1)| isempty(pcoff_argument.P8)
         pcoff_argument.P8='';    % fifth metafile argument
      end;
      if strncmp(pcoff_argument.P9,'-',1)| isempty(pcoff_argument.P9)
         pcoff_argument.P9='';    % sixth (last) metafile argument
      end;
      if (~strncmp(pcoff_argument.P1,'-',1))   % protocol file
         return_value=load_file(pcoff_argument.P1);
         if (load_state)   % cannot LOAD during a LOAD
            response='Error [second_batch]. Attempt to open a second protocol from within a protocol file';
         else
            r=load_file(params);
              if (r == -2) % file error 
                 response='';
              % since the error was called during a command line entry,
              % there is no batch file to break or exit from.  
              elseif (r==-3)  % exit request.  Don't exit.
                 response='Exit command in protocol file has been ignored.';
              elseif (r==2)  % BREAK
                 response='<<BREAK>>  use CONTINUE to resume protocol file.';
              end; % if r==-2
         end; % if load_state
      end;  % ~strncmp    
      
   elseif (strncmp(c,'call',3))  % Yikes! This calls another batch file
      return_value=-4;
      if errors
         fprintf(error_fid,'Error [second_batch]. Too many levels of indirection in batch file.\n');
      end;
      fclose(call_fid);
      call_fid=-1;
      return;
   end; % if strncmp      
end; % end while
fclose(call_fid);
call_fid=-1;
 
      
 
 
