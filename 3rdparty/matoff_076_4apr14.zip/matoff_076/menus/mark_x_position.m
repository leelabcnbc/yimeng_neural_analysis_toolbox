function[x_position]=mark_x_position
% 
% Use the mouse to move a vertical bar along the x axis 
% Return the X axis position when the mouse is released
% 
% Outputs
%   x_position    position along x axis

% main_handle=axes('Position',main_rect,'YColor',hide,'TickDir','out');

global error_fid warning_fid debug_fid
global errors warnings debugs

% assume normalized units??


waitforbuttonpress;   % wait for the mouse button
point = get(gcf,'CurrentPoint'); % locate the mouse
apos=get(gca,'Position'); % locate the axis
rect = [apos(1) apos(2) point(1)-apos(1) point(2)-apos(2)];  % initial rectangle
new_rec = rbbox(rect);
arange=get(gca,'XLim');
x_position = arange(1) + (new_rec(3) / apos(3))*(arange(2)-arange(1));

