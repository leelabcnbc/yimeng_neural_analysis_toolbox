function [analog_value]=read_analog_record(analog_fid,file_trial_list,chan)
%
%  Collect analog channels and their data from a range of trials 
%  in the data file. Return just the analog data trials requested, 
%  in the exact order it was requested.
%
%  3 August 2012  
%  Modulo function used to calculate trial_number to greatly expand the number of file trials 
%  that can be handled.
%  
%  
%  Inputs
%     analog_fid          handle of analog file
%     file_trial_list     ordered list of file trials to fetch from disk
%     chan                analog channel number
%  Outputs
%    analog_value         Each row is one trial.  These are "sorted trials" and include
%                         only the trials requested. Each row has n columns of data followed 
%                         by NaNs. There is at least one longest row with no NaNs
%             
%  Globals modified
%    cache_trials.analog   vector with 2 entries: [lowest highest] file trial numbers in cache
%    analog_data_cache     row 1: analog channels, row 2: analog data
%
global cache_trials work_index work_udf
global analog_data_cache analog_cache_pointers
global error_fid warning_fid debug_fid
global errors warnings debugs

analog_value=[];

if isempty(file_trial_list)
   if debugs
      fprintf(debug_fid,'Debug [read_analog_record]. Empty trial list requested.\n');
   end;
   return;
end;

if debugs
   fprintf(debug_fid,'Debug [read_analog_record]. %d trials of analog data requested.\n',length(file_trial_list));
end;

low_trial=min(file_trial_list);
high_trial=max(file_trial_list);

if high_trial > length(work_index)
   fprintf(error_fid, 'Error [read_analog_record]. Requested trial exceeds index size.\n');
   return;
end;

% are the requested file trials in the cache?

if (low_trial >= cache_trials.analog(1)) & (high_trial <= cache_trials.analog(2))
   if debugs
      fprintf(debug_fid,'Debug [read_analog_record]. Requested analog data trials were found in cache.\n');
   end;
else
   if debugs
      fprintf(debug_fid,'Debug [read_analog_record]. Requested analog data trials not in cache, reading from file.\n');
   end;

   % File trials are not in cache, go get them from data file
   starting_file_position=work_index(low_trial).analog_start_position;
   number_of_records=0;
   for t=low_trial:high_trial
      number_of_records=number_of_records+work_index(t).analog_length;  % size of datablock to pull from file
   end;

   try
      fseek(analog_fid,starting_file_position,'bof');
   catch
      if errors
         fprintf(error_fid,'Error [read_analog_record]. Tried to read past end of the analog file.\n');
         fprintf(error_fid,'                            Perhaps there is no analog file.\n');
      end;
      return;
   end; % try fseek
   
   try
      analog_data_cache=fread(analog_fid,[2 number_of_records],'int16');   % read from file
      cache_trials.analog=[low_trial high_trial];
      % build analog_cache_pointers to navigate the data in analog_data_cache
      %   col 1=file trial number   col 2=start of data for that trial  col 3=end of data for that trial  
      % find the marker for each trial
      analog_cache_pointers=find(analog_data_cache(1,:)== -1) ;  
      analog_cache_pointers=[ analog_data_cache(2,analog_cache_pointers)' ...  % column 1, trial numbers
         (analog_cache_pointers+1)'  ...  % column 2, start of trial data.  could crash on last trial if no data there
         [(analog_cache_pointers(2:end)-1) length(analog_data_cache(2,:))]'  ];  ... column 3, end of trial data
   catch
      if errors
         fprintf(error_fid,'Error [read_analog_record].  Error reading analog data.\n');
         fprintf(error_fid,'Starting offset: %-5d , number of records: %-5d \n', ...
                starting_file_position,number_of_records);
      end;
      cache_trials.analog=[0 0];   % values no longer valid   
      analog_cache_pointers=[0 0 0];
      return;
   end; % try analog_data_cache
   
   % sanity check, did we retrieve the trials that we expected?
   % Updated 3 August 2012 with modulo function.  Backwards compatible with prior versions,
   % but now handles master trial numbers up to 2,147,483,647. (Was limited to 32,767.)
   % The analog data file stores the trial numbers as modulo 32768.

   expected_trials=uint32(low_trial:high_trial);    % trials we expect
   % modulo of each value. Will always fit into int16.
   modulo_expected_trials =  int16(mod(uint32(expected_trials),uint32(intmax('int16')+1))); 
   if ~isequal(analog_cache_pointers(:,1),modulo_expected_trials')
      if errors
         fprintf(error_fid,'Error [read_analog_record]. Trial numbers found are not the trials expected.\n');
      end;
      cache_trials.analog=[0 0];   % values no longer valid   
      analog_cache_pointers=[0 0 0];
      return;
   end;
   
end; % if (low_trial >= cache

% locate data for requested file trials.  Preserve order of file_trial_list
[wanted,dummy,missing]=find_in_list(analog_cache_pointers(:,1),file_trial_list);

% another sanity check
if ~isempty(missing) & errors
   fprintf(error_fid,'Internal error [read_analog]. Some requested trials were not found in the analog file.\n');
end;

% estimate size of analog value matrix and initialize it with NaNs
num_columns=max( analog_cache_pointers(wanted,3)-analog_cache_pointers(wanted,2) + 1 ); % find longest trial
num_rows=length(wanted);  % find the number of trials (rows)
analog_value=ones(num_rows,num_columns)*NaN;   % one row per trial

% fetch each trial of data from cache and keep only data for desired analog channel
trial_length=[];
for t=1:num_rows % sorted trials
   starting=analog_cache_pointers(wanted(t),2);  % starting cache position for this trial
   ending=analog_cache_pointers(wanted(t),3);  % ending cache position for this trial
   this_chan_this_trial=find(analog_data_cache(1,starting:ending)==chan); % find array elements data for this channel
   this_chan_this_trial=this_chan_this_trial + starting - 1;  % offset from starting value
   trial_length(t)=length(this_chan_this_trial);  % save length information; use later to truncate array
   analog_value(t,1:trial_length(t))= analog_data_cache(2,this_chan_this_trial); % get amplitude data points
end;
% remove pure-NaN columns
longest_trial=max(trial_length);
analog_value=analog_value(:,1:longest_trial);
a=1;

