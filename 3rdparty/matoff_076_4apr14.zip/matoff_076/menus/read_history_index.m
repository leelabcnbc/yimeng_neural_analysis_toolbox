function [hindex]=read_history_index(file_name)
%
%  Read entire history index file.
% Inputs
%   file_name    name of data file with no extension, includes all path information
% Output
%   hindex(entry_number).unitname          unit name ascii string (1 to 12 characters)
%                       .history_start     pointer to start of this trial history in the history file
%                       .history_length    number of bytes in history record
%
%
%  hindex=[] if an error occurs or no history data.
%
global error_fid warning_fid debug_fid
global fid fn
global errors warnings debugs
global environment
global MAX_UNIT_NAME

max_unit_name=num2str(eval('MAX_UNIT_NAME'));

if isempty(file_name)
   if errors
      fprintf(error_fid,'Error [read_history_index]. History index file name is empty. Cannot read history index.\n');
   end;
   hindex=[];
   return;
end;

hindex_file_name=[file_name '.hindex'];
if debugs
   fprintf(debug_fid,'Debug [read_history_index]. Opening file to read %s\n',hindex_file_name);
end;
hindex_fid=fopen(hindex_file_name,'rb');
if hindex_fid < 1
   if debugs
      fprintf(debug_fid,'Debug [read_history_index]. No history index found for: %s.\n',hindex_file_name);
   end;
   if warnings
      fprintf(warning_fid,'No prior history information in this unit.\n');
   end;
   hindex=[];
   return;
end;
if debugs
   fprintf(debug_fid,'Debug [read_history_index]. history index fid= %d\n',hindex_fid);
end;

unit=1;
while (1)
   try   
      if ~feof(hindex_fid)

          uname=fread(hindex_fid,[1 MAX_UNIT_NAME],[max_unit_name '*char']);    % 12 byte unit name as row vector
          unitname=char(uname(find(uname)));                 % convert to string and squeeze nulls out of unit name
          history_start=fread(hindex_fid,1,   'uint32');  % location of first history record for this trial in history file
          history_length=fread(hindex_fid,1,  'uint32');  % size of history record for this trial
      else
          if errors
             fprintf(error_fid,'Error [read_history_index]. Unexpected end of history index file encountered.\n');
          end;          
          fclose(hindex_fid);
          hindex_fid=-1;
          return;   % return with whatever has been found so far
      end;
   catch
      if errors
         fprintf(error_fid, 'Error [read_history_index]. History index file ended unexpectedly.\n');
         fprintf(error_fid, 'Error [read_history_index]. %d units were found before end-of-file\n',unit-1);
      end;
      fclose(hindex_fid);
      hindex_fid=-1;
      return;    % return with whatever has been found so far
   end;  % try/catch

   if debugs
      fprintf(debug_fid,'Debug [read_history_index]. Found history entry for: %s\n',unitname);
      fprintf(debug_fid,'Debug [read_history_index].     start: %d    length: %d\n',...
               history_start,history_length);
   end;
   
   if strcmp(unitname,'END_OF_FILE') & (history_start==0) & (history_length==0)
      if debugs
         fprintf(debug_fid,'Debug [read_history_index]. End of history index verifed.\n');
      end;
      fclose(hindex_fid);
      hindex_fid=-1;
      break;  % Normal exit
   elseif (history_length >= 0) & (history_start >= 0) 
      hindex(unit).unitname=unitname;            % copy to output file
      hindex(unit).history_start=history_start; 
      hindex(unit).history_length=history_length;
      unit=unit+1;
   else
      if errors
         fprintf(error_fid, '\nError [read_history_index]. Error in history index file.\n');
      end;
      hindex=[];
      fclose(hindex_fid);
      hindex_fid=-1;
      return;
   end;
end;

if debugs
   fprintf(debug_fid,'Debug [read_history_index]. Normal close of history index file.\n');
end;

fprintf(1,'History information has been loaded for this unit.\n');
if environment.logging==1
   fprintf(fid.log,'History information has been loaded for this unit.\n');
end;

