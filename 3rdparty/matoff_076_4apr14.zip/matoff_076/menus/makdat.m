function makdat(list_file,output_file,option_list)
%
%  Convert Cortex data files to MatOFF data files using a "list file"
%
%  v 18.1  6 Jun 2008
%  v 19.0  3 Aug 2012  master_trial number is now stored in the analog file as modulo 32768.
%                         This is backwards compatible with the old method, which limited analog
%                         to a maximum of 32767 master trials. 
%  v 19.1 13 Sep 2012  XGAIN and YGAIN were not implemented. They are now.
%
%  Inputs
%   list_file    list file name see makdat documentation
%   output_file  output file name
%   option_list  list of single character options
% 
%
global environment 
global makdat_error_fid makdat_warning_fid makdat_debug_fid
global errors warnings debugs
global index_fid udef_fid pulse_fid event_fid analog_fid
global input_fid
global MAX_UNIT_NAME   % don't change this value without reviewing all its effects.

dump_cortex_trial_codes=0;   % set to 1 to dump all event codes of every trial

MAX_EVENT_CODES=32000; % could be set to largest possible integer
MAX_EVENT_CODE_NAME=40;  % limit to number of characters used from event code file
str_format=['%' num2str(MAX_EVENT_CODE_NAME) 's'];  % format string for event name
MAX_NAMED_EVENTS=1000;  % only the first 1000 event codes can be named
%
timestep=1000;        % .1 ms time steps
start_of_trial=198;   % start of trial code
end_of_trial=199;     % end of trial code;
trial_start_time=0;
active_channels=[];
udef_count=0;
udef.trials=[];
file_number=0;
trim_code=-1;
insert_filename='OFF';
insert_list=[];
ignore_list=[];
thin_list=[];
channel=[];
tags=[];
tag_pointer=0;
tag_master_trial=0;
tag_event_code=[];
invalidate_unit=0;  % set to 1 if unit data is untrustworthy (introduced version 0.61)

xgain=1;
ygain=1;
index.event_start_position=0;
index.event_records=0;
index.pulse_start_position=0;
index.pulse_records=0;
index.analog_start_position=0;
index.analog_length=0;
master_clock=0;
master_trial=0;
debug_trial_limit=0;  % sets a limit to the number of trials processed
spiketimeoffset=0;

list_fid=-3;
index_fid=-3;
udef_fid=-3;
pulse_fid=-3;
event_fid=-3;
analog_fid=-3;
input_fid=-3;
eventcode_fid=-3;
insert_fid=-3;
remap_fid=-3;
dump_fid=-3;

dump_fid=1;                   % set the dump output to console device
makdat_error_fid=dump_fid;    % these are not the same fid's as used elsewhere in MatOff
makdat_warning_fid=dump_fid;
makdat_debug_fid=dump_fid;

%
if isempty(list_file)
   if errors
      fprintf(makdat_error_fid,'----- Error. No list file given.\n');
   end
   return;
end

if isempty(option_list)
   option_list=[];
end

list_file=filepath(list_file,environment.datapath);
list_fid=fopen(list_file,'rt');
if list_fid < 1
   if errors
      fprintf(makdat_error_fid,'----- Error. Could not open list file: %s\n',list_file);
   end
   return;
end

% process environmental variables
   
if ~isempty(environment.maxinputtrials)
   debug_trial_limit=str2num(environment.maxinputtrials);
   if debug_trial_limit < 1 % always warn this
      fprintf(makdat_warning_fid,'----- Warning [makdat]. Environmental variable MAXINPUTTRIALS incorrectly set. It will be ignored.\n');
      debug_trial_limit=0;
   end
end

if ~isempty(environment.spiketimeoffset)
   if abs(environment.spiketimeoffset) > 20
      fprintf(makdat_warning_fid,'----- Warning [makdat]. Environmental variable SPIKETIMEOFFSET may be incorrectly set! value=%d msec\n',...
                  environment.spiketimeoffset);
   end
   spiketimeoffset=environment.spiketimeoffset;
end

if ~isempty(environment.makdat)
   more_options=lower(strrep(environment.makdat,'-',''));  % remove '-' and use lower case
   option_list=[option_list more_options];
end

if ~isempty(environment.makdump)
   dump_filename=environment.makdump;
   dump_filename=filepath(dump_filename,environment.datapath);   
   dump_fid=fopen(dump_filename,'wt'); 
   if dump_fid < 1
      fprintf(1,'----- Warning. Could not open dump file: %s.\n',dump_filename);
      dump_fid=1;  % return it to the default (console)
   else
      fprintf(1,'----- Warning. All console information will be sent to dump file: %s.\n',dump_filename); 
   end
   % reset these if necessary
   makdat_error_fid=dump_fid;    % these are not the same fid's as used elsewhere in MatOff
   makdat_warning_fid=dump_fid;
   makdat_debug_fid=dump_fid;
end

   
% note: strrep in this statement is in case makdat is called directly from the Matlab command line
%       rather than from the MatOFF prompt
if ~isempty(option_list)
   option_list=lower(deblank(strjust(strrep(option_list,'-',''))));  % all options to lower case
end

% initialize option flags
nof=0;          % no output files 'n'
hshow=0;        % show headers 'h'
xeog=0;         % exclude eog 'r' or 'x'
xepp=0;         % exclude epp 'p' or 'x'
xana=0;			 % exclude analog 'x'
overwrite=0;    % overwrite files 'o'
ashow=0;        % show analog 'a'
psteps=0;       % show processing steps 'd' (debug)
nowarn=0;       % inhibit warning messages 'e' (errors only)
eshow=0;        % show events 'f'
verbose=0;      % verbose 'v'
icc=0;          % ignore condition codes 't'
spike8=0;       % default to 8 spike channels '8'
usecase=0;      % case sensitive input dat file names 'c'
pshow=0;        % show pulses 's'

% modify option flags based on options list
for i=1:length(option_list)
   if strcmp(option_list(i),'n')  % no output file
      nof=1;
   elseif strcmp(option_list(i),'h')  % show header
      hshow=1;
   elseif strcmp(option_list(i),'x')  % exclude all analog
      xana=1;
      xeog=1;
      xepp=1;
   elseif strcmp(option_list(i),'o')  % allow overwrite of output file
      overwrite=1;
   elseif strcmp(option_list(i),'p')  % exclude epp analog
      xepp=1;
   elseif strcmp(option_list(i),'r')  % exclude eog analog
      xeog=1;
   elseif strcmp(option_list(i),'a')  % show each analog value
      ashow=1;
   elseif strcmp(option_list(i),'d')  % show processing steps
      psteps=1;
   elseif strcmp(option_list(i),'e')  % inhibit warning messages
      nowarn=1;
   elseif strcmp(option_list(i),'f')  % show events
      eshow=1;
   elseif strcmp(option_list(i),'v')  % verbose
      verbose=1;
   elseif strcmp(option_list(i),'t')  % ignore condition codes
      icc=1;
   elseif strcmp(option_list(i),'8')  % default to 8 spike channels
      spike8=1;   
   elseif strcmp(option_list(i),'c')  % case sensitive input data file names
      usecase=1;   
   elseif strcmp(option_list(i),'s')  % show each spike (pulse)
      pshow=1;        
   else
      if ~nowarn
         fprintf(makdat_warning_fid,'----- Warning.  Unrecognized option in option list: %c\n',option_list(i));
      end
   end % if strncmp
end % for i=

if verbose
   fprintf(makdat_debug_fid,' ----- Options in effect:  no output file=%d, show header=%d, exclude EOG=%d, exclude EPP=%d,\n'... 
      ,nof,hshow,xeog,xepp);
   fprintf(makdat_debug_fid,' overwrite output files=%d, show analog=%d, show processing steps=%d, inhibit warnings=%d,\n'... 
      ,overwrite,ashow,psteps,nowarn);
   fprintf(makdat_debug_fid,' show events=%d, verbose=%d, ignore condition codes=%d, default to 8 spike channels=%d.\n'... 
        ,eshow,verbose,icc,spike8);
end
  

if ~isempty(environment.eventcodefile)    % is the event code file defined in the environment?
   eventcode_filename=environment.eventcodefile;
else
   eventcode_filename='default.evt';      % no, use default
end
if verbose | psteps
   fprintf(makdat_debug_fid,'----- Looking for event code file.\n');
end
eventcode_fid=fopen(eventcode_filename,'rt');    
if eventcode_fid < 1
   if ~nowarn
      fprintf(makdat_warning_fid,'----- No event code file in use.\n');
   end
   str_format=['%' num2str(MAX_EVENT_CODE_NAME) 's'];  % format string for event name
   for i=1:MAX_NAMED_EVENTS
      eventcodenames(i,:)=sprintf(str_format,'     ');
   end
else
   line_count=0;
   while ~feof(eventcode_fid)
      line_count=line_count+1;
      [event_number,event_string]=strtok(fgetl(eventcode_fid));
      [dummy,value,valid]=check_string_value(event_number,0,MAX_EVENT_CODES);
      if valid
         max_chars=MAX_EVENT_CODE_NAME;
         if length(event_string) < MAX_EVENT_CODE_NAME
            max_chars=length(event_string);
         end
         if value ~= 0  % zero is just ignored
            eventcodenames(value,:)=sprintf(str_format,event_string(1:max_chars));
         end
      else
         if ~nowarn 
            fprintf(makdat_warning_fid,'----- Warning. Invalid entry in line %d of event code file: \n',line_count);
         end
      end
   end %end while
   fclose(eventcode_fid);
   eventcode_fid=-1;
end % end if eventcode_fid < 1
   

if ~isempty(output_file) & ~nof
   if verbose | psteps
      fprintf(makdat_debug_fid,'----- Closing any open output files.\n');
   end
   close_output_files;
   [path,name,ext]=fileparts(output_file);
   if strncmp('lst',lower(deblank(strjust(ext))),3)
      if errors
         fprintf(makdat_error_fid,'---- Error. Output file cannot have the extension  .LST\n');
      end
      return;
   end

   output_file=filepath(output_file,environment.datapath);
   % open a new set of output files
   if verbose || psteps
      fprintf(makdat_debug_fid,'----- Opening output file %s\n',output_file);
   end

   open_output_files(output_file,overwrite);  % fids are all global
   if index_fid < 0
      if errors
         fprintf(makdat_error_fid,'----- Error. Cannot create output files. Makdat is giving up.\n');
      end
      if list_fid > 0
         fclose(list_fid);
         list_fid=-1;
      end  
      if dump_fid > 1
        fclose(dump_fid);
        dump_fid=1;   % default to console
      end
      return;
   end
   % report normal progress 
   if ~( psteps || verbose)        
      fprintf(makdat_debug_fid,'\n      Output file: %s\n',output_file);
   end

   % initialize index variable for .index file
   index.event_start_position=0;
   index.event_records=0;
   index.pulse_start_position=0;
   index.pulse_records=0;
   index.analog_start_position=0;
   index.analog_length=0;
         
   % initialize time and trial counters
   master_clock=0;
   master_trial=0;
end % output file

% open pulse mapping file
% The pulse mapping file is a list of Cortex event codes.
% The event codes are assigned to pulse channels in order, e.g.
% file entry
%    150           ==> becomes pulse chan 0
%    151           ==> becomes pulse chan 1
%    200           ==> becomes pulse chan 2
%    250           ==> becomes pulse chan 3 
pulse_map=[];
if ~isempty(environment.remapfile)    % is the file defined in the environment?
   remap_filename=environment.remapfile;
else
   remap_filename='default.rmp';      % no, use default
end
if verbose | psteps
   fprintf(makdat_debug_fid,'----- Opening pulse mapping file (remap file):  %s.\n',remap_filename);
end
remap_fid=fopen(remap_filename,'rt');    
if remap_fid < 1
   if ~nowarn
      fprintf(makdat_warning_fid,'----- No remap file defined in the environment. Starting with default spike channel mapping.\n');
   end
   if spike8
      pulse_map=[1 2 3 4 5 6 7 8];
   else
      pulse_map=[1 2];
   end
else
   while ~feof(remap_fid)
      pulse_map=[pulse_map str2num(fgetl(remap_fid))];
   end
   fclose(remap_fid);
   remap_fid=-1;
end



  % ===============   Preprocessor ================================
% pre-process the list file to identify all channel numbers used for each Cortex file
% active_channels(n).file name= file name;
% active_channels(n).channels= list of channels from that file that are used;

channels=-1;    % flag to detect a list file with missing UNIT command
while ~feof(list_fid)
   rcmd=deblank(fgetl(list_fid));  % fetch command from list file
   [rcmd,params]=strtok(rcmd);  % grab first part of list file command
   if isempty(rcmd)  % deal with a blank line
      rcmd='<blank>';
   end
   

   switch rcmd
      
   case 'UNIT'
     % Get unit name and channel number list
     [unit_name,params]=strtok(params); % get new unit name
     if findstr(params,'CHAN')
        [dummy,params]=strtok(params);  % fetch channel numbers
        channels=expand_range_list(strtrim(params));
        if strcmp(channels,'@') 
           channels=1;  % default to channel 1
        end
     else
        channels=1;   % default list
     end % if findstr(params,'CHAN'
      
   case {'<blank>','OUTPUT','PARAM'}
      % nothing
      
   otherwise   % Cortex file name
     if channels < 0   % Missing UNIT command at start of list file
        if errors
           fprintf(makdat_error_fid,'----- Error. File name found before UNIT command in the list file. Makdat is giving up.\n');
        end
        if list_fid > 0   %    ABORT
           fclose(list_fid);
           list_fid=-1;
        end  
        if dump_fid > 1
          fclose(dump_fid);
          dump_fid=1;  % default to console
        end
        return;                 
     end
     % Get cortex file name
     input_file=rcmd;
     if ~usecase     % force lower case unless 'c' option was used
         input_file=lower(rcmd);
     end
     input_file=filepath(input_file,environment.datapath);

     if isempty(active_channels)   % is this the first input file?
        active_channels(1).file_name=input_file;
        active_channels(1).channels=channels;  % from most recent UNIT command
     else
        new_active_channel=1; % assume this is a new file name
        for ach=1:length(active_channels)
           % have we seen this file name before?
           if strcmp(active_channels(ach).file_name,input_file)
              new_active_channel=0;  % this file has been seen before
              for ach2=1:length(channels)   % add channels that aren't already in the list
                 if isempty(find(active_channels(ach).channels==channels(ach2)))
                    active_channels(ach).channels=[active_channels(ach).channels channels(ach2)]; 
                 end
              end
           end % if strcmp(active_
        end % for ach=1:length(active_
        if new_active_channel
           ach=length(active_channels)+1;
           active_channels(ach).file_name=input_file;
           active_channels(ach).channels=channels;
        end
     end % if isempty(active_channels)
  end % switch
end % while(~feof)  
  
if verbose | psteps
   for ach=1:length(active_channels)
      fprintf(makdat_debug_fid,'data file: %s has active channels:\n',active_channels(ach).file_name);
      for ach1=1:length(active_channels(ach).channels)
         fprintf(makdat_debug_fid,'%d\n',active_channels(ach).channels(ach1));
      end
   end
end
 % ===============   End of Preprocessor ================================    



%  ===============  List file command processor ============================
% now process the list file command-by-command
fseek(list_fid,0,'bof');  % rewind list file

while ~feof(list_fid)
   
   % decode list file
   rcmd=fgetl(list_fid);  % fetch command from list file
   if verbose | psteps
      fprintf(makdat_debug_fid,'<L>  %s\n',rcmd);   % echo command
   end
   rcmd=deblank(rcmd);
   [rcmd,params]=strtok(rcmd);  % grab first part of list file command
   
   if isempty(rcmd)  % deal with a blank line
      rcmd='<blank>';
   end
   
   if strncmp(rcmd,'unit',4)
     if ~nowarn
        fprintf(makdat_warning_fid,'----- Warning. The keyword UNIT must be in upper case. \n');
     end
   end
   
   if strncmp(rcmd,'param',5)
     if ~nowarn
        fprintf(makdat_warning_fid,'----- Warning. The keyword PARAM must be in upper case. \n');
     end
   end
  
   if strncmp(rcmd,'output',6)
     if ~nowarn
        fprintf(makdat_warning_fid,'----- Warning. The keyword OUTPUT must be in upper case. \n');
     end
   end  
   
   switch rcmd
      
   case '<blank>'
      % just skip
      
   case 'OUTPUT'  % OUTPUT <filename> 

     % ----  close out previous file -------------
      
     % -----  update unit definition file with last data of unit ----
     if (udef_fid > 0) &  (length(udef.trials) > 0)  && (invalidate_unit==0)           
        if verbose | psteps
            fprintf(makdat_debug_fid,'----- Saving last unit of previous file.\n');
        end

        udef_count=udef_count+1;            % this unit has data
        % convert list of trials into ASCII
        trial_string=num2str(udef.trials(1));
        if length(udef.trials > 1)
           for i=2:length(udef.trials)
              trial_string=[trial_string ',' num2str(udef.trials(i))];
           end
        end
        % reformat list into compact notation
        trial_string=number_range_list(trial_string);
        if ~nof
           write_udef(udef_fid,udef.name,udef.channel,trial_string); % write to file
           index.event_records=index.event_records+write_event_record(event_fid,end_of_trial,master_clock);    % end trial
           write_index(index_fid,master_trial,index);  % write out index entry
        end      

         if verbose | psteps
            fprintf(makdat_debug_fid,'----- Saving last data to disk (if a file was open).\n');
         end  

        % add special end-of-index record
         index.event_start_position=0;
         index.event_records=0;
         index.pulse_start_position=0;
         index.pulse_records=0;
         index.analog_start_position=0;
         index.analog_length=0;
         if ~nof
            write_index(index_fid,-1,index);                % END-OF-INDEX
            write_udef(udef_fid,'END_OF_FILE',255,'0-0');   % END-OF-UDEF
         end
     end % if udef_fid > 0
     if verbose | psteps
        fprintf(makdat_debug_fid,'----- Closing any open data files.\n');
     end  
     close_output_files;   % execute close command even if nothing was opened

      udef_count=0;
      udef.trials=[];
  
      [output_file,params]=strtok(params);
      [output_file,extension]=strtok(output_file,'.');  % remove any extension
      if ~isempty(output_file) & ~nof   % new file 
         % open a new set of output files
         if verbose | psteps
            fprintf(makdat_debug_fid,'----- Opening new output file %s.\n',output_file);
         end

         % report normal progress 
         if ~( psteps | verbose)            
            fprintf(makdat_debug_fid,'\n      Output file: %s\n',output_file);
         end

         open_output_files(output_file,overwrite);  % fids are global
         if index_fid < 0
            if errors
               fprintf(makdat_error_fid,'----- Error. Cannot create output files. Makdat is giving up.\n');
            end
            if list_fid > 0
               fclose(list_fid);
               list_fid=-1;
            end  
            if dump_fid > 1
              fclose(dump_fid);
              dump_fid=1;   % default to console
            end
            return;
         end
            
         % initialize index variable for .index file
         index.event_start_position=0;
         index.event_records=0;
         index.pulse_start_position=0;
         index.pulse_records=0;
         index.analog_start_position=0;
         index.analog_length=0;

         % initialize file scanning
         file_number=0;
         clear files_scanned;
  %       active_channels=[];
  %       channel=[];
         % initialize time and trial counters
         master_clock=0;
         master_trial=0;
         tag_master_trial=0;
         if length(tags) == 0
             tag_pointer=0;
         else
             tag_pointer=1;
         end

      end % is empty output_file
           
  case 'UNIT'   %   UNIT <unitname> CHAN <channel>      
     
     % Get unit name and channel number
     [unit_name,params]=strtok(params); % get new unit name
     
     if length(unit_name) > MAX_UNIT_NAME
        unit_name=unit_name(1:MAX_UNIT_NAME);
        if ~nowarn
           fprintf(makdat_warning_fid,'---- Warning. Unit name truncated to %d characters: %s\n',MAX_UNIT_NAME,unit_name);
        end
     end
     
     if findstr(params,'CHAN')
        [dummy,params]=strtok(params);  % fetch channel number
        channels=expand_range_list(strtrim(params));
        if isempty(channels)   % empy list?
           if ~nowarn
              fprintf(makdat_warning_fid,'----- Warning. No default channel number for this unit.  Will use Channel 1.\n');
           end
           channels=1;          % default to channel 1
        else 
           if strcmp(channels,'@')  % error decoding list?
              if ~nowarn
                 fprintf(makdat_warning_fid,'----- Warning. Could not read the channel list.  Will use Channel 1.\n');
              end
              channels=1;   % default to channel 1
           end
        end
        channel=channels(1);   % reduce this list to just the first element (default channel is lowest channel number)
     end
    
      % close out any previous unit
      if (length(udef.trials) > 0) && (invalidate_unit==0)          % convert trial list to string if unit has all valid data
         udef_count=udef_count+1;            % this unit has data
         % convert list of trials into ASCII
         trial_string=num2str(udef.trials(1));
         if length(udef.trials > 1)
            for i=2:length(udef.trials)
               trial_string=[trial_string ',' num2str(udef.trials(i))];
            end
         end
         % reformat list into compact notation
         trial_string=number_range_list(trial_string);
         if ~nof
            write_udef(udef_fid,udef.name,udef.channel,trial_string); % write to file
         end
      end
      
      % initialize unit definition entry
      invalidate_unit=0;  % assume it will be a valid unit
      udef.trials=[];
      udef.name=unit_name;
      if isempty(channel)
         if ~nowarn
            fprintf(makdat_warning_fid,'---- Warning. Missing channel number. Default channel 1\n');
         end 
         channel=1;
      end
      udef.channel=channel;

  case 'PARAM'
     [pcmd,params]=strtok(params);
     sparam=strtok(params);   % extract single parameter 
     
     if verbose || psteps
         disp(['----- Processing parameter: ' pcmd]);
     end
     switch pcmd
     % The EOG sample rate value is parsed, but is not saved to the MatOFF data file
     case 'EOG'
           eog_sample_rate=str2num(sparam);
           if eog_sample_rate==0
              xeog=1;
           elseif eog_sample_rate > 20
              eog_sample_rate=(1/eog_sample_rate)* timestep;  % .1 ms steps
           else
              eog_sample_rate=eog_sample_rate * 10;    % .1 ms steps
           end
           
     case 'EPP'
        if ~nowarn
           fprintf(makdat_warning_fid,' ----- Warning. PARAM EPP not implemented.\n');
        end
     case 'XEOG'
        if isempty(sparam)
           xeog=1;
        elseif strncmp(sparam,'FALSE',5) || strncmp(sparam,'OFF',3)
           xeog=0;
        else
           xeog=1;
        end
     case 'XEPP'
        if isempty(sparam)
           xepp=1;
        elseif strncmp(sparam,'FALSE',5) || strncmp(sparam,'OFF',3)
           xepp=0;
        else
           xepp=1;
        end       
     case 'XGAIN'
        if verbose || psteps
            fprintf(makdat_debug_fid,'----- X gain scale factor: %s\n', sparam);
        end        
        xgain=str2num(sparam);
     case 'YGAIN'
        if verbose || psteps
            fprintf(makdat_debug_fid,'----- Y gain scale factor: %s\n',sparam);
        end         
        ygain=str2num(sparam);

     case 'SPIKETIMEOFFSET'
        if verbose || psteps
            fprintf(makdat_debug_fid,'----- Spike Time Offset: %s\n', sparam);
        end        
        spiketimeoffset=str2num(sparam);
        if abs(spiketimeoffset) > 20
           fprintf(makdat_warning_fid,'----- Warning [makdat]. List file parameter SPIKETIMEOFFSET may be incorrectly set! value=%d msec\n',...
                        spiketimeoffset);
        end


     case 'INSERT'
        insert_filename=deblank(strjust(sparam,'left'));
        if isempty(insert_filename)
           insert_filename='OFF';
           if ~nowarn
              fprintf(makdat_warning_fid,'----- Warning. Empty insert file name.  insert OFF.\n');
           end
        end
        if strcmp(insert_filename,'OFF')
           insert_list=[];
        else 
           if verbose | psteps
               fprintf(makdat_debug_fid,'----- Opening insert file: %s\n',insert_filename);
           end         
           
           insert_fid=fopen(insert_filename,'rt');    
           if insert_fid < 1
              if ~nowarn
                 fprintf(makdat_warning_fid,'----- Warning. Insert file >%s< not found, insert OFF.\n',insert_filename);
              end
              insert_list=[];
              insert_filename='OFF';
           else
              insert_list=[];
              while ~feof(insert_fid)
                 new_list=str2num(fgetl(insert_fid));  % a bad insert file can crash this
                 if ~isempty(new_list)
                    % equalize number of columns
                    [dummy,current_length]=size(insert_list);
                    new_length=length(new_list);
                    if current_length==0
                       insert_list=new_list;                     
                    elseif new_length > current_length
                       insert_list(end,new_length)=0;    % create space in list matrix, pad with zeros
                       insert_list=[insert_list ; new_list];
                    elseif new_length < current_length
                       new_list(current_length)=0;      % expand this new list
                       insert_list=[insert_list ; new_list];
                    else
                       insert_list=[insert_list ; new_list];
                    end
                 end
              end % while ~feof
              fclose(insert_fid);
              insert_fid=-1;
              if verbose | psteps
                 fprintf(makdat_debug_fid,'Insert matrix:');
                 insert_list     % no semicolon here
              end  
           end % if insert_fid
        end % if strcmp(insert_filename
        
     case 'TAG' 
        % Get the tag list
        tag_parameter=deblank(strjust(params,'left'));
        if isempty(tag_parameter)
           tag_pointer=0;
           tags=[];
           if verbose | psteps 
              fprintf(makdat_debug_fid,'---- TAG codes off. \n');
           end
        elseif strcmp(deblank(strjust(sparam,'left')),'RESET')
           tag_master_trial=master_trial-1;
	       if verbose | psteps 
	          fprintf(makdat_debug_fid,'---- TAG trial count reset at input trial #%d. \n',master_trial);
	       end
        else
           tags=str2num(tag_parameter);
           if isempty(tags)
	      if verbose | psteps | (~nowarn)
	         fprintf(makdat_warning_fid,'---- Warning. Invalid TAG parameter. Ignored. \n');
	      end
	      tag_pointer=0;
           else
              tag_pointer=1;
           end
        end

        if (length(tags) > 1) & (rem(length(tags),2) ~= 0)  % must be one value or an even number of values
            if verbose | psteps | (~nowarn)
               fprintf(makdat_warning_fid,'---- Warning. Invalid TAG parameter.  Ignored. \n');
            end
            tags=[];  % default: no tags
            tag_pointer=0;
         end              

         if (verbose | psteps ) & (length(tags) > 0)
            fprintf(makdat_debug_fid,'---- TAGS   Event Code    Last Trial\n ');
            if length(tags)==1
               fprintf(makdat_debug_fid,'               %d          all trials\n',tags(1));
            else
               for tag_entry=1:2:(length(tags)/2)
                  fprintf(makdat_debug_fid,'                %d            %d\n',tags(tag_entry),tags(tag_entry+1));
               end
            end 
         end
        
     case 'REMAP'
      
        remap_filename=filepath(sparam,'');   % attach defaultpath if full path not given
        if isempty(remap_filename)
           remap_filename='default.rmp';      % use default
        end
        if ~nowarn
           fprintf(makdat_debug_fid,'----- Opening pulse mapping file (remap file):  %s.\n',remap_filename);
        end  
        remap_fid=fopen(remap_filename,'rt');    
        if remap_fid < 1
           if ~nowarn
              fprintf(makdat_warning_fid,'----- Warning. Requested remap file not found, using default spike channel mapping.\n');
           end
           if icc   % ignore condition codes?
              pulse_map=[1 2 3 4 5 6 7 8];   % yes, room for 8 channels
           else
              pulse_map=[1 2];
           end
        else
           if verbose || psteps
              fprintf(makdat_debug_fid,'----- New pulse mapping file (remap file) %s.\n',remap_filename);
           end  
           pulse_map=[];
           while ~feof(remap_fid)
              pulse_map=[pulse_map str2num(fgetl(remap_fid))];
           end
           if verbose || psteps
              for reu=1:length(pulse_map)
                 fprintf(makdat_debug_fid,'- channel: %d  Pulse event code: %d\n',reu-1,pulse_map(reu));
              end
              if isempty(pulse_map)
                 fprintf(makdat_debug_fid,' --- Warning. Did not find any remap information in remap file.\n');
              end
           end 
           fclose(remap_fid);     
           remap_fid=-1; 
        end
        
     case 'TRIM'
        trim_code=str2num(sparam);
        if isempty(trim_code)
           trim_code=-1;
           if ~nowarn
              fprintf(makdat_warning_fid,'----- Warning. Bad TRIM code: %s\n',sparam);
           end
        end  
        
     case 'IGNORE'
        % Get the ignore list
        ignore_list=expand_range_list(deblank(strjust(sparam,'left')));
        if strcmp(ignore_list,'@') 
           ignore_list=[];  % default: no ignore codes
        end
 
     case 'THIN'
        [event_param,thin_param]=strtok(params);
        if isempty(event_param) | isempty(thin_param)
           if ~nowarn
              fprintf(makdat_warning_fid,'----- Warning. Bad THIN entry: %s\n',params);
           end
        else
            event_param=str2num(event_param);   %convert to numbers
           thin_param=str2num(thin_param);
           if thin_param <= 1   % remove event code from thin list?
              if ~isempty(thin_list)
                 thin_list=thin_list(:,find(thin_list(1,:) ~= event_param));
                 if verbose | psteps
                    fprintf(makdat_debug_fid,'Removing event code %d from thinning list\n',event_param);
                 end                 
              end
           else    % add or change thinning for this event code
              if verbose | psteps
                 fprintf(makdat_debug_fid,'Thinning event code %d with factor %d\n',event_param,thin_param);
              end	   
	           if length(thin_list)==0   % first event code in the list?
	              thin_code_index=0;     % yes
	           else                      % no
                 thin_code_index=find(thin_list(1,:)==event_param); 
	           end  % first event code in list
              if thin_code_index > 0   % event code already in thinning list?
                 thin_list(2,thin_code_index)=thin_param;  % reassign thinning value
              else    % new event code
                 thin_list=[thin_list [event_param;thin_param;1]];
              end  % event code already exists
           end  % remove/add/change
        end % command error

  end  % End of Switch pcmd (PARAM processing)
      
  otherwise  % open a new Cortex input data file
    for quickloop=1:1    % this allows using the BREAK command to skip reading the input file
      input_file=rcmd;
      if ~usecase     % force lower case unless 'c' option was used
         input_file=lower(rcmd);
      end
      input_file=filepath(input_file,environment.datapath);

      if input_fid > 0  % close old file if one was open
         fclose(input_fid);
         input_fid=-1;
      end 
      
      if event_fid < 0
         if ~nowarn
            fprintf(makdat_warning_fid,'----- Warning. No output file open, data will not be saved.\n');
         end
         if ~nof
            fprintf(makdat_error_fid,'----- Error. Expected Output file.\n');
            break;
         end
      end
      

      % locate the active_channels entry number for this file
      sane_flag=0;
      for ach=1:length(active_channels)
         if strcmp(active_channels(ach).file_name,input_file)
            active_channels_entry=ach;
            sane_flag=1;
            break;
         end
      end
      if ~sane_flag
         fprintf(makdat_error_fid,'----- Error. Failed to find active channel list for\n %s.\n',input_file);   
      end

      
      
      % Check to see if requested file is already in dataset
      if file_number > 0    % is this the first file?
         new_file_flag=1;  % assume this is a new file
         for fn=1:file_number
            if strcmp(input_file,files_scanned(fn).name)  % already read this file?
               udef.trials=[udef.trials files_scanned(fn).trials];  % yes, grab the trial numbers
               new_file_flag=0;
            end
         end
         if ~new_file_flag
            if verbose | psteps
               fprintf(makdat_debug_fid,'----- %s was processed earlier. Adding its trials to this unit.\n',input_file); 
            end 
            if ~(hshow | ashow | psteps | eshow | verbose)
               fprintf(makdat_debug_fid,'%12s / Ch%-3d %-12s   0..10..20..30..40..50..60..70..80..90..100\n', ...
                    unit_name,udef.channel,input_file);
            end
            break;   % done with this file, use the quickloop to exit processing
         end
      end % if file_number==0

      
      if verbose | psteps
          fprintf(makdat_debug_fid,'----- Opening new input file: %s\n',input_file);
      end 
      % fetch entire index of new cortex file
      cortex_index=read_cortex_index(input_file);
      if isempty(cortex_index)
         if errors
            fprintf(makdat_error_fid,'----- Error. Cannot open requested input data file: %s.\n', input_file);
            fprintf(makdat_debug_fid,'%12s / Ch%-3d   Entire unit invalidated.\n', unit_name,udef.channel);
         end
         invalidate_unit=1;    % skip entire unit (new behavior. It used to just skip the file)
         break; 
      end

      if verbose | psteps
         fprintf(makdat_debug_fid,'     %s        trial   %d \n', ...
               unit_name,master_trial);
      end  
                
      input_fid=fopen(input_file,'r');
      if input_fid < 1
         if errors
            fprintf(makdat_error_fid,'----- Error. Cannot open requested input data file: %s. \n', input_file);
            fprintf(makdat_debug_fid,'%12s / Ch%-3d   Entire unit invalidated.\n', unit_name,udef.channel);
         end 
         invalidate_unit=1;    % skip entire unit (new behavior. It used to just skip the file)
         break;
      end   
      
      if  debug_trial_limit ~= 0
         %  this message is not suppressed with nowarn
         fprintf(makdat_warning_fid,'\n ---- WARNING DEBUG TRIAL LIMIT SET TO %d \n',debug_trial_limit);
         if length(cortex_index) > debug_trial_limit
            cortex_index=cortex_index(1:debug_trial_limit);
         end
      end 
      
      number_of_trials=length(cortex_index);   % number of trials in this file
      
      if number_of_trials == 0
         if errors
            fprintf(makdat_error_fid,'----- Error. No trials in input data file: %s\n', input_file); 
         end 
         break;
      end  


      % process each trial in the cortex data file
      if ~(psteps | verbose)  
         fprintf(makdat_debug_fid,'%12s / Ch%-3d %-12s   0',unit_name,udef.channel,input_file);
         if hshow | ashow | eshow   
            fprintf(makdat_debug_fid,'\n');
         end
         index_percent_length=100 / number_of_trials ; % used to track progress
         pct_report=0;  % used to track progress
      end     

   
      % append the list of trials to the unit definition file
      new_trial_list=(master_trial+1):(master_trial+number_of_trials);
      udef.trials=[udef.trials new_trial_list];
      % add this data file to the list of files we have processed
      file_number=file_number+1;
      files_scanned(file_number).name=input_file;
      files_scanned(file_number).trials=new_trial_list;      
      
      for header=1:number_of_trials
         analog_counter=0;  % used by 'verbose'
         if verbose
            fprintf(makdat_debug_fid,'----- Finishing off previous trial.\n');
         end
         % ------- finish off index of previous trial
         if master_clock > 0
            if ~nof
               index.event_records=index.event_records+write_event_record(event_fid,end_of_trial,master_clock);    % end trial
               write_index(index_fid,master_trial,index);  % write out index entry
            end
         end      
         
         % update clock and trial counters
         
            master_clock=1;   % each trial starts from this time
            trial_start_time=master_clock;
            master_trial=master_trial+1;   

         if verbose | hshow
            if verbose
               fprintf(makdat_debug_fid,'\n');
            end
            fprintf(makdat_debug_fid,'\n Trial # %d   unit : %s \n',master_trial-1,unit_name);
            fprintf(makdat_debug_fid,'Cortex header #%-d  trial %-d  block %-d  condx %-d  starts at: %-d\n', ...
               header,cortex_index(header).trial,cortex_index(header).block, ...
               cortex_index(header).condition,cortex_index(header).start_of_header);
            fprintf(makdat_debug_fid,'code size:%-d  time size:%-d  EOG size:%-d  EPP size:%-d\n', ... 
               cortex_index(header).code_size,cortex_index(header).isi_size, ... 
               cortex_index(header).eog_size,cortex_index(header).epp_size);
            if (cortex_index(header).resolution==0)|(cortex_index(header).resolution==1)
               khr='1 ms';
            else
               khr='.1 ms';
            end
            if cortex_index(header).storage_rate==0
               cortex_index(header).storage_rate=1;
            end
            adsr= round(1000/cortex_index(header).storage_rate);
            fprintf(makdat_debug_fid,'A/D storage rate: %d Hz resolution: %s\n\n',adsr,khr);
         end 
            
         % calibrate time 
         if  (cortex_index(header).resolution==0)|(cortex_index(header).resolution==1)
              cortex_resolution_factor=10;
         else
              cortex_resolution_factor=1;   % ???? UNTESTED, PERHAPS WRONG.
         end
         % initialize index variable for new trial
         if nof
            index.event_start_position=1;
            index.pulse_start_position=1;
            index.analog_start_position=1;       
         else   
            index.event_start_position=ftell(event_fid);
            index.pulse_start_position=ftell(pulse_fid);
            index.analog_start_position=ftell(analog_fid); 
         end
        
         index.event_records=0;

         index.pulse_records=0;
         index.analog_length=0;

         % Add markers to each file indicating new trial. Include the trial number as a way for
         % MatOFF to verify the data in the file matches the data in the index when reading the file.
         if ~nof
            index.event_records=index.event_records+write_event_record(event_fid,-1,master_trial);
            index.event_records=index.event_records+write_event_record(event_fid,start_of_trial,master_clock);    
            index.pulse_records=index.pulse_records+write_pulse_record(pulse_fid,-1,master_trial);
            % Updated 3 August 2012. 
            % The analog file only allows a signed int16 for the master_trial.  This limits the maximum 
            % master_trial number stored in the analog file to 32767.  To allow an unlimited number of 
            % trials, the trial number wraps around to zero. The calculation is a modulo function.
            modulo_master_trial =  int16(mod(uint32(master_trial),uint32(intmax('int16')+1)));
            index.analog_length=index.analog_length+write_analog_record(analog_fid,-1,modulo_master_trial);
         end
         
         if ~icc & ~nof  % store condition code
            index.event_records=index.event_records + ... 
                  write_event_record(event_fid,cortex_index(header).condition+200,master_clock);
         end 
         
         % look for a TAG event code
         tag_event_code=[];
         if tag_pointer > 0     % add a tag?
            if length(tags) == 1   % if its a single tag value, it goes on all trials
                tag_event_code=tags(tag_pointer);
            else
                if (master_trial-tag_master_trial) <= tags(tag_pointer+1)  % can we continue to use current tag?
                   tag_event_code=tags(tag_pointer);
                else                                                       % no, is there another tag to advance to ?
                   if length(tags) > (tag_pointer+1)
                       tag_pointer=tag_pointer+2;        % advance the tag: use the new tag at least once
                       tag_event_code=tags(tag_pointer);
                   else
                       tag_pointer=0;    % no tags left, turn off TAGS 
                   end % if length(tags) > (tag_pointer+1)
                end  % if (master_trial-tag_master_trial) <= tags
             end % if length(tags) == 1
          end % if tag_pointer > 0
                
      
         % read next trial
         cortex_record=read_cortex_record(cortex_index(header),xana);
         if verbose 
            fprintf(makdat_debug_fid,' Cortex_record: event record length  %d \n',length(cortex_record.event_time) );
            fprintf(makdat_debug_fid,' Cortex_record: eog record length  %d \n',length(cortex_record.eog) );
            fprintf(makdat_debug_fid,' Cortex_record: epp record length  %d \n',length(cortex_record.epp) );
         end 
         if isempty(cortex_record) | length(cortex_record.event_time) < 1
            break;
         end

         if dump_cortex_trial_codes == 1
            fprintf(makdat_debug_fid,' All event codes:\n');
            fprintf(makdat_debug_fid,'%d\n',cortex_record.event_code);
         end
                  
         % recalibrate array of events to global time
         % changed 10 March 2004, Matoff V0.48 beta 3 so that time zero is the time of the earliest event code
         %  cortex_record.event_time= (cortex_record.event_time * cortex_resolution_factor) + trial_start_time;
         cortex_record.event_time= ((cortex_record.event_time - min(cortex_record.event_time)) * cortex_resolution_factor) + trial_start_time;

         %insert tag code as the first event
         if ~isempty(tag_event_code) 
            cortex_record.event_time= [trial_start_time ; cortex_record.event_time];
            cortex_record.event_code= [tag_event_code ; cortex_record.event_code];
         end

         % we won't use this for a while, but we want to mark when the very
         % last event occurred.
         master_clock=max(cortex_record.event_time); 
         
         % process IGNORE list early
         ignore_these=[];
         for ign=1:length(ignore_list)         % create list of indicies to ignore
            ignore_these=[ignore_these find(cortex_record.event_code==ignore_list(ign))'];
         end
         if ~isempty(ignore_these)
            % convert that to a list of indicies to keep
            not_ignored=yank_elements(ignore_these,length(cortex_record.event_code));
            % update records to include only kept ones
            cortex_record.event_code=cortex_record.event_code(not_ignored);
            cortex_record.event_time=cortex_record.event_time(not_ignored);          
         end

         % process THIN parameter
         %  Thin _list looks like this
         %  row 1  <event code>             104   105   106  107
         %  row 2  <thinning factor>          3     2     2    2    
         %  row 3  <restart>                  2     0     1    0
         %  Thinning factor:  1=keep every one, 2=keep every other, 3=keep every third
         %  restart: where to start looking in the next buffer.  Note how the
         %  thinning search is simply:  [restart:thinning_factor:end]
         if length(thin_list) > 0   % any codes to look for?
            for thinentry=1:length(thin_list(1,:))  % step through list of codes
               % find every occurrence of this thin code    
               thin_event=thin_list(1,thinentry);
               thin_factor=thin_list(2,thinentry);
               thin_restart=thin_list(3,thinentry);
               thins=find(cortex_record.event_code==thin_event);
               if length(thins) > (thin_factor-thin_restart)   % remove excess occurences of this event code                   
                  keepthins=thins(thin_restart:thin_factor:end);
                  not_thins=find(cortex_record.event_code~=thin_event);
                  not_thinned=sort([not_thins ; keepthins]);
                  cortex_record.event_code=cortex_record.event_code(not_thinned);
                  cortex_record.event_time=cortex_record.event_time(not_thinned);
                  % make restart value from remainder events (e.g. 3 event occurences when thinning value is 5)
                  thin_list(3,thinentry)=thin_factor-(length(thins)-find(thins==keepthins(end)));
               else
                  thin_list(3,thinentry)=thin_restart-length(thins);  % only calculate restart
               end 

            end % for thinentry=
          end  % if thin_list > 0
     

         % process TRIM parameter
         trim_list=[];
         if trim_code > 0
            % Find every occurrence of the TRIM code in this trial
            trim_list=find(cortex_record.event_code==trim_code)';
            if length(trim_list) > 1
               trim_list=trim_list(2:end);  % prepare to remove all but the first occurance 
            end
            % condense the cortex_record to omit the trimmed events
            not_trimmed=yank_elements(trim_list,length(cortex_record.event_code));  
            cortex_record.event_code=cortex_record.event_code(not_trimmed);
            cortex_record.event_time=cortex_record.event_time(not_trimmed);              
         end
         
         % Find the pulse data entries for all the spike channels
         % The pulse_map shows which event codes to treat as spikes
         pulses=[];
         delete_list=[];  % list of entries that will not be used as event codes
         % cycle through all the possible spike channels 
         for map_index=1:length(pulse_map)
            channel_code=pulse_map(map_index);
            channel=map_index-1;   % First code gets mapped to channel 0 
            % candidate pulses are any event codes in the pulse map, even if not active
            candidate_pulse_entry_list=find(cortex_record.event_code==channel_code)';
            delete_list=[delete_list candidate_pulse_entry_list]; % used later to locate non-pulse and not trimmed events
            % pulses saved to the pulse file are from only those channels in the active channels list
            if find(active_channels(active_channels_entry).channels==channel)
               % Get index values for the spikes on this channel. Remove any spike at
               % time zero (= time 0001). These time zero spikes are garbage.
               pulse_entry_list=find((cortex_record.event_code==channel_code) &(cortex_record.event_time > 1))';
               % convert spike time offset to 0.1 ms tics and add to spike times
               new_pulse_times=cortex_record.event_time(pulse_entry_list)+(spiketimeoffset*10); 
               % col 1 is saved as the spike channel ; col 2 is saved as the spike time
               pulses=[pulses; (ones(length(pulse_entry_list),1)* channel)  new_pulse_times]; 
               if verbose & (length(pulse_entry_list) > 0)
                  fprintf(makdat_debug_fid,'----- %d  pulses found on pulse channel %d \n',length(pulse_entry_list),channel);            
                  if pshow 
                     for si=1:length(pulse_entry_list)
                        fprintf(makdat_debug_fid,'pulse chan %d  time %d\n',channel,cortex_record.event_time(si));
                     end
                  end
               end % if verbose
                     
            end % if find(active_channels
         end % for map_index=1:

         if ~isempty(pulses)   % circumvent bug in sortrows
            pulses=sortrows(pulses,2);  % time sort of all spike channels   
            % store all the spike from this trial into the pulse file
            if ~nof
               index.pulse_records=index.pulse_records + ...
                  write_pulse_record(pulse_fid,pulses(:,1),pulses(:,2));
            end
         end
         % which event entries are not pulses?
         % note: delete_list will be empty if there were no pulses 
         array_size=length(cortex_record.event_code);  % recalculate this array size because we condensed it after trim
         not_pulses=yank_elements(delete_list,array_size);
         % store all non-pulse, not trimmed events from this trial into event file
         
         % process insert codes here
         if ~isempty(insert_list) & ~strcmp(insert_filename,'OFF') & (length(not_pulses) > 1)
            % the first step is to simplify the arrays
            cortex_record.event_code=cortex_record.event_code(not_pulses(:));
            cortex_record.event_time=cortex_record.event_time(not_pulses(:));
            not_pulses=1:length(cortex_record.event_code);
            
            % there can be many primary insert codes to find, one per line of the insert_list
            for insert_entry=1:size(insert_list,1)
               % look for any instances of the primary code.  The primary code is in column 1
               % of the insert_list
               primary_code=insert_list(insert_entry,1);
               if ~isempty(find(cortex_record.event_code==primary_code))
                  if verbose
                     fprintf(makdat_debug_fid,'----- primary code %d found \n',primary_code);
                  end    
                  % the primary code is in this trial, now hunt for triggers
                  for trigger_entry=2:length(insert_list(1,:))
                     trigger_code=insert_list(insert_entry,trigger_entry);
                     if trigger_code > 0  % skip padding                        
                        trigger_list=find(cortex_record.event_code==trigger_code);
                        % insert primary code before each trigger
                        if ~isempty(trigger_list)
                           if verbose
                              fprintf(makdat_debug_fid,'----- %d triggers found \n',length(trigger_list));
                           end
                           % Introduce temporary arrays and use them to 
                           % squeeze a zero in between each element of the lists
                           %    make a list of zeros twice the size of each array (these are column arrays)
                           d_cortex_record.event_code=zeros(2*length(cortex_record.event_code),1); 
                           d_cortex_record.event_time=d_cortex_record.event_code;
                           %    fill every other element with the original list
                           d_cortex_record.event_code(2:2:end)=cortex_record.event_code;
                           d_cortex_record.event_time(2:2:end)=cortex_record.event_time;
                           % place the primary code just before each occurrence of the trigger
                           d_cortex_record.event_code((2*trigger_list)-1)=ones(length(trigger_list),1)*primary_code;
                           % place a duplicate time stamp in the matching positions of the time array  
                           d_cortex_record.event_time((2*trigger_list)-1)=d_cortex_record.event_time((2*trigger_list));
                           % squeeze out the remaining zeros
                           cortex_record.event_code=d_cortex_record.event_code(find(d_cortex_record.event_code > 0));
                           cortex_record.event_time=d_cortex_record.event_time(find(d_cortex_record.event_time > 0));
                           % update the array used to index these data arrays
                           not_pulses=1:length(cortex_record.event_code);
                        end  % ~isempty(trigger list)
                     end  % if trigger_code > 0
                  end  % for trigger_entry =2:length ...
               end  % if ~isempty(find(cortex_record.event_c
            end % for insert_entry=1:size...
         end % if ~isempty(insert_list) & ~strcmp(i

         if ~nof
            index.event_records=index.event_records + ...
               write_event_record(event_fid,cortex_record.event_code(not_pulses(:)),cortex_record.event_time(not_pulses(:)));
         end
           
         if eshow   % display the event codes and their meanings
            for np=not_pulses
               ec=cortex_record.event_code(np);
               et=cortex_record.event_time(np);
               ecn=' ';
               if (ec > MAX_NAMED_EVENTS) | (ec > length(eventcodenames))
                  ecn=' ';
               elseif ec <= 0
                  if ~nowarn
                     fprintf(makdat_warning_fid,'----- Warning. Event code is negative or zero: %d\n',ec);
                  end 
                  ecn=' ';
               else
                  if ~isempty(eventcodenames(ec,1))  % do we know the meaning of this code?
                     ecn=strtrim(eventcodenames(ec,:));
                  end
               end
               fprintf(makdat_debug_fid,'EVENT %6d at %6d %s\n',ec,et,ecn);
            end
         end
            
         
         % Any analog data in this trial? 
         if  (~xeog | ~xepp) & ~isempty(cortex_record.eog)  % Note: Don't process EPP unless there is EOG
            
            if ~xepp & ~isempty(cortex_record.epp)    
               EPP_channels=bitand(fix(cortex_record.epp),15);  % row vector of channel numbers for entire trial
               EPP_data=bitshift(fix(cortex_record.epp),-4);    % matching row vector of 12-bit A/D values
               for epp_chan=unique(EPP_channels)    % for each channel number found in the epp data set
                  if (epp_chan==3) | (epp_chan==4)  % Channels 3 and 4 are reserved for EOG data
                     if ~nowarn
                        fprintf(makdat_warning_fid,'----- Warning. EPP Channel %d is not allowed. Cortex channels 3 and 4 are reserved for EOG data\n',epp_chan);
                     end
                  else
                     this_chan_data=EPP_data(find(EPP_channels==epp_chan));  % grab (row) data for this channel, this trial
                     epp_chan_markers=ones(size(this_chan_data))*epp_chan;
                     if ~nof
                        index.analog_length=index.analog_length + ...
                           write_analog_record(analog_fid,epp_chan_markers',this_chan_data'); % save as positive integers (column data)
                     end
                     analog_counter=analog_counter+length(epp_chan_markers)*2;  % for 'verbose'
                  end
               end           
            end % if ~xepp        
             
            % fetch EOG data - for historical reasons, EOG data are always saved on channels 3 and 4
            if ~xeog & ~isempty(cortex_record.eog)

               % Rescale analog data
a               cortex_record.eog(:,1)= cortex_record.eog(:,1) * XGAIN;
               cortex_record.eog(:,2)= cortex_record.eog(:,2) * YGAIN;
            
               for analog_chan=3:4
                 analog_chan_markers=ones(size(cortex_record.eog(:,analog_chan-2)))*analog_chan;
                  if ~nof
                     index.analog_length=index.analog_length + ...
                    write_analog_record(analog_fid,analog_chan_markers,cortex_record.eog(:,analog_chan-2));
                  end
                  analog_counter=analog_counter+length(analog_chan_markers)*2;  % for 'verbose'
               end             
            end % if ~xeog               

            if verbose
               fprintf(makdat_debug_fid,'\n  %d analog data points stored \n',analog_counter);
            end
            
            if ashow
               for i=1:length(cortex_record.eog(:,1))
                  fprintf(makdat_debug_fid,'sample %d    ',i);
                  if ~xepp & ~isempty(cortex_record.epp)
                     fprintf(makdat_debug_fid,'analog 1=%d    analog 2=%d', ... 
                           cortex_record.epp(i,1),cortex_record.epp(i,2));
                  end % if ~xepp
                  if ~xeog & ~isempty(cortex_record.eog)
                     fprintf(makdat_debug_fid,'analog 3=%d    analog 4=%d', ... 
                           cortex_record.eog(i,1),cortex_record.eog(i,2));
                  end % if ~xeog
                  fprintf(makdat_debug_fid,'\n');
               end % for i=1:length cortex_record.eog
            end % if ashow

         end % if ~xeog | ~xepp
         
         % report the progress 
         if ~(hshow | ashow | psteps | eshow | verbose)            
            percent_done= floor(round(header * index_percent_length) / 10)*10;  % count in 10% steps
            if percent_done > pct_report
               pct_report=percent_done;
               fprintf(makdat_debug_fid,'..%d',pct_report);
               if pct_report==100
                  fprintf(makdat_debug_fid,'\n');
               end
            end
         end
               
      end % for header=1:n
    end % quickloop (Otherwise of switch command)
   end % switch rcmd

end % while ~feof
if list_fid > 0
   fclose(list_fid);
   list_fid=-1;
end 
if verbose
   fprintf(makdat_debug_fid,'----- Finishing off last trial.\n');
end
% ------- finish off last trial
if master_clock > 0  % this is no longer a good way to see if data was stored
   if ~nof
      index.event_records=index.event_records+write_event_record(event_fid,end_of_trial,master_clock);    % end trial
      write_index(index_fid,master_trial,index);  % write out index entry
   end
   
   % add special end-of-index record
   index.event_start_position=0;
   index.event_records=0;
   index.pulse_start_position=0;
   index.pulse_records=0;
   index.analog_start_position=0;
   index.analog_length=0;
   if ~nof
      write_index(index_fid,-1,index);  % trial=-1
   end
   % save final unit definition information
   if (length(udef.trials) > 0)  && (invalidate_unit==0)          % convert list to string
      udef_count=udef_count+1;            % this unit has data
      % convert list of trials into ASCII
      trial_string=num2str(udef.trials(1));
      if length(udef.trials > 1)
         for i=2:length(udef.trials)
            trial_string=[trial_string ',' num2str(udef.trials(i))];
         end
      end
      % reformat list into compact notation
      trial_string=number_range_list(trial_string);
      if ~nof
         write_udef(udef_fid,udef.name,udef.channel,trial_string); % write to file
      end
   end
   % add special end-of-definition file marker
   if ~nof
      write_udef(udef_fid,'END_OF_FILE',255,'0-0');
   end
   
   close_output_files;

end % if master_clock


if dump_fid > 1
   fclose(dump_fid);
   dump_fid=1;
end

clear global index_fid 
clear global udef_fid 
clear global pulse_fid 
clear global event_fid 
clear global analog_fid
clear global input_fid

fprintf(1,'\n -- makdat done --\n');



% ===================================================================================== %
% ============================= SUBROUTINES =========================================== %
% ===================================================================================== %

% ------------   Subroutines for Writing MatOFF files ------------------------------ %

%  ----------------- open_output_files --------------------------------------
function success=open_output_files(output_file,overwrite)
%
global index_fid udef_fid pulse_fid event_fid analog_fid
%
% Open a full set of output files.  overwrite=1 means allow overwrite
% Makdat initializes all the fid's to -3.  A file that has been closed should
% have a fid of -1.
%
global environment
global makdat_error_fid makdat_warning_fid makdat_debug_fid
global errors warnings debugs

if (index_fid > 0) | (pulse_fid > 0) | (event_fid > 0) | (analog_fid > 0) | (udef_fid > 0)
   if errors
      fprintf(makdat_error_fid,'----- Warning. Output files were not properly closed before new output file (%s) was requested.\n',output_file);
   end   
   success= -1;
   close_output_files;
end

if ~overwrite    % abort if one or more file exists.
   a=fopen([output_file '.index'],'r');
   if a > 0
      fclose(a);
      if errors
         fprintf(makdat_error_fid,'----- Error. Cannot open requested output file: %s.index already exists.\n',output_file);
      end
      return;
   end
   a=fopen([output_file '.pulse'],'r');
   if a > 0
      fclose(a);
      if errors
         fprintf(makdat_error_fid,'----- Error. Cannot open requested output file: %s.pulse already exists.\n',output_file);
      end
      return;
   end
   a=fopen([output_file '.event'],'r');
   if a > 0
      fclose(a);
      if errors
         fprintf(makdat_error_fid,'----- Error. Cannot open requested output file: %s.event already exists.\n',output_file);
      end
      return;
   end 
   a=fopen([output_file '.analog'],'r');
   if a > 0
      fclose(a);
      if errors
         fprintf(makdat_error_fid,'----- Error. Cannot open requested output file: %s.analog already exists.\n',output_file);
      end
      return;
   end
   
   a=fopen([output_file '.udef'],'r');
   if a > 0
      fclose(a);
      if errors
         fprintf(makdat_error_fid,'----- Error. Cannot open requested output file: %s.udef already exists.\n',output_file);
      end
      return;
   end
end  % if ~overwrite
   
index_fid=fopen([output_file '.index'],'w');
if index_fid < 1
   if errors
      fprintf(makdat_error_fid,'----- Error. Cannot open requested output file: %s.index.\n',output_file);
   end
   index_fid=-1;
   return;
end
pulse_fid=fopen([output_file '.pulse'],'w');
if pulse_fid < 1
   if errors
      fprintf(makdat_error_fid,'----- Error. Cannot open requested output file: %s.pulse.\n',output_file);
   end
   index_fid=-1; 
   return;
end
event_fid=fopen([output_file '.event'],'w');
if event_fid < 1
   if errors
      fprintf(makdat_error_fid,'----- Error. Cannot open requested output file: %s.event.\n',output_file);
   end
   index_fid=-1;
   return;
end    
analog_fid=fopen([output_file '.analog'],'w');
if analog_fid < 1
   if errors
      fprintf(makdat_error_fid,'----- Error. Cannot open requested output file: %s.analog.\n',output_file);
   end
   index_fid=-1;
   return;
end
udef_fid=fopen([output_file '.udef'],'w');
if udef_fid < 1
   if errors
      fprintf(makdat_error_fid,'----- Error. Cannot open requested output file: %s.udef.\n',output_file);
   end
   index_fid=-1;
   return;
end   
   

%  ----------------- close_output_files --------------------------------------

function close_output_files
%
global index_fid udef_fid pulse_fid event_fid analog_fid
%
success=0;
% Close down all the old files   
if pulse_fid > 0
   success=fclose(pulse_fid);   % close pulse file
   pulse_fid= -1;
end 
if event_fid > 0
   success=success+fclose(event_fid);       % close event file
   event_fid= -1;
end 
if analog_fid > 0
   success=success+fclose(analog_fid);      % close analog file
   analog_fid=-1;
end     
if index_fid > 0
   success=success+fclose(index_fid);        % close index file
   index_fid= -1;
end
if udef_fid > 0
   success=success+fclose(udef_fid);        % close unit definition file
   udef_fid= -1;
end    
if success < 0
   if errors
      fprintf(makdat_error_fid,'----- Error. An error occurred trying to close data files.\n');
   end   
end

% --------------- write index entry   size=28 (1CH) -------------------
function write_index(index_fid,trial,index)
global makdat_error_fid makdat_warning_fid makdat_debug_fid
global errors warnings debugs

n=ftell(index_fid);
fwrite(index_fid,trial,'int32');
fwrite(index_fid,index.event_start_position,'int32');
fwrite(index_fid,index.event_records,'int32');
fwrite(index_fid,index.pulse_start_position,'int32');
fwrite(index_fid,index.pulse_records,'int32');
fwrite(index_fid,index.analog_start_position,'int32');
fwrite(index_fid,index.analog_length,'int32');      
if ( (ftell(index_fid)-n) ~= 28 )
   if errors
      fprintf(makdat_error_fid,'----- Error. Problem writing to index file.\n');
   end
end

% --------------- write event record   size=8  ------------------------
function [records]=write_event_record(event_fid,event_code,event_time)
%
%  Event code=-1 and event_time=trial number  for new trial marker
%  Event code=0  and event_time=0             for restart marker
%
global makdat_error_fid makdat_warning_fid makdat_debug_fid
global errors warnings debugs

events=[event_code' ; event_time'];
a=fwrite(event_fid,events,'int32');
records=size(events,2);
if a ~= (records*2)
   if errors
      fprintf(makdat_error_fid,'----- Error writing to event file. Count= %d.\n',a);
   end
end
 
% ---------------- write pulse record    size=8  ---------------------
function [records]=write_pulse_record(pulse_fid,pulse_chan,pulse_time)
% 
%  new header:  pulse_chan=-1,   pulse_time=trial number
%  data:        pulse_chan=chan, pulse_time=time
%
global makdat_error_fid makdat_warning_fid makdat_debug_fid
global errors warnings debugs

pulses=[pulse_chan' ; pulse_time'];
a=fwrite(pulse_fid,pulses,'int32');
records=size(pulses,2);
if  a ~= (records*2)
   if errors
     fprintf(makdat_error_fid,'----- Error writing to pulse file. Count= %d.\n',a+b+c);
   end
end 
   
%  ---------------- write analog record    size=8 ---------------------------
function [records]=write_analog_record(analog_fid,chan,data)
%
%  new header:    chan=-1,   data=trial number
%  data:          chan=chan  data=data
% 
global makdat_error_fid makdat_warning_fid makdat_debug_fid
global errors warnings debugs

analog=[chan' ; data'];
a=fwrite(analog_fid,analog,'int16');
records=size(analog,2);
if a ~= (records*2)
   if errors
      fprintf(makdat_error_fid,'----- Error writing to analog file. Count= %d.\n',a);
   end
end 

%  ---------------- write unit definition entry    size=100 ---------------------------
function [records]=write_udef(udef_fid,unit_name,channel,trial_string)
%
%  unit_name      MAX_UNIT_NAME bytes   left justified, nulls in unused space 
%  channel        1 byte     expected channel number
%  trial_string   87 bytes   ASCII list of which index trial numbers are to be included
%                            in the unit. example:   '22-55,56-60,60-120,135-240'
% 
global makdat_error_fid makdat_warning_fid makdat_debug_fid
global errors warnings debugs
global MAX_UNIT_NAME

name=[unit_name zeros(MAX_UNIT_NAME-length(unit_name),1)'];
 
max_unit_name=num2str(eval('MAX_UNIT_NAME'));
a=fwrite(udef_fid,name,[max_unit_name '*char']);  % max_unit_name='12'
b=fwrite(udef_fid,channel,'uint8');
if length(trial_string) > 87
   if errors
      fprintf(makdat_error_fid,'----- Error. String of trials in this unit is too long to store.\n');
   end
   trial_string=trial_string(1:87);  % very poor recovery
end
trials=[trial_string zeros(87-length(trial_string),1)'];
c=fwrite(udef_fid,trials,'87*char');
records=1; 
if (a+b+c) ~= 100 
   if errors
      fprintf(makdat_error_fid,'----- Error writing to udef file. Count= %d.\n',a+b+c);
   end
end 
   
   
% ============= Subroutines for reading Cortex files =============================== %


% -------- Read Cortex Index -----------------------------------

function [index]=read_cortex_index(file_name)
%
%  Read all cortex indexes from a cortex data file.
% Inputs
%   file_name      name of Cortex data file
% Outputs
%   index
%       index(n).start_of_header   offset from start of file
%       index(n).length
%       index(n).condition
%       index(n).repeat
%       index(n).block
%       index(n).trial
%       index(n).isi_size
%       index(n).code_size
%       index(n).eog_size
%       index(n).epp_size
%       index(n).resolution
%       index(n).storage_rate
%       index(n).expected
%       index(n).response
%       index(n).response_error
% Globals modified
%    cortex_header_size
%

global cortex_header_size
global environment
global makdat_error_fid makdat_warning_fid makdat_debug_fid
global errors warnings debugs

ci_fid=-3;
cortex_header_size=26;  % number of bytes in a Cortex header

if isempty(file_name)
   if errors
      fprintf(makdat_error_fid,'----- Error [read_cortex_index]. No file name given.\n');
   end
   index=[];
   return;
end
file_name=filepath(file_name,environment.datapath);
ci_fid=fopen(file_name);
if ci_fid < 1
   if warnings
      fprintf(makdat_warning_fid,'----- Warning [makdat read_cortex_index]. Cortex file  %s  not found.\n',file_name);
   end
   index=[];
   return;
end

i=1;
offset=ftell(ci_fid);
while 1 
   if fseek(ci_fid,offset,'bof');  % find start of next index entry
      break;
   end
   index_entry.start_of_header=ftell(ci_fid);  % mark the location of this entry
   [index_entry.length,n]=fread(ci_fid,1,'uint16'); % 2 bytes
   if n==0  % eof
      if (i==1) 
         if warnings
            fprintf(makdat_warning_fid,'----- Warning [makdat read_cortex_index]. Cortex file ended with no headers.\n');
         end   
         if ci_fid > 0
            fclose(ci_fid);
            ci_fid=-1;
         end
         index=[];
         return;
      end
      break;
   end
   [index_entry.condition,n]=fread(ci_fid,1,'uint16'); % 2 bytes
   index_entry.condition=index_entry.condition+1;  % stored as condx-1
   [index_entry.repeat,n]=fread(ci_fid,1,'uint16'); % 2 bytes
   [index_entry.block,n]=fread(ci_fid,1,'uint16'); % 2 bytes
   index_entry.block=index_entry.block+1;  % stored as block-1
   [index_entry.trial,n]=fread(ci_fid,1,'uint16'); % 2 bytes
   [index_entry.isi_size,n]=fread(ci_fid,1,'uint16'); % 2 bytes
   [index_entry.code_size,n]=fread(ci_fid,1,'uint16'); % 2 bytes
   [index_entry.eog_size,n]=fread(ci_fid,1,'uint16'); % 2 bytes
   [index_entry.epp_size,n]=fread(ci_fid,1,'uint16'); % 2 bytes
   [index_entry.storage_rate,n]=fread(ci_fid,1,'uint8'); % 1 byte
   [index_entry.resolution,n]=fread(ci_fid,1,'uint8'); % 1 byte
   [index_entry.expected,n]=fread(ci_fid,1,'uint16'); % 2 bytes
   [index_entry.response,n]=fread(ci_fid,1,'uint16'); % 2 bytes
   [index_entry.response_error,n]=fread(ci_fid,1,'uint16'); % 2 bytes
   if n==0  % eof
      if warnings
         fprintf(makdat_warning_fid,'----- Warning [makdat read_cortex_index]. Unexpected end of Cortex file.\n');
      end
      break;
   end
   % calculate offset of next index entry
   offset=offset + cortex_header_size + index_entry.isi_size + index_entry.code_size ...
        + index_entry.eog_size + index_entry.epp_size;  
   index(i)=index_entry;
   i=i+1;
end
if ci_fid > 0
   fclose(ci_fid);
   ci_fid=-1;
end



% ----------- Read Cortex Record ------------------------

function [cortex_record]=read_cortex_record(cortex_index,exclude_analog)
%
%  Read one record from a Cortex data file.  input_fid is global
%  
%  Inputs
%    cortex_index       one Cortex index entry (see read_cortex_index()) for structure
%    exclude_analog     skip analog data, return empty analog arrays
%  Outputs
%    cortex_record
%        cortex_record.event_time[]       time stamps for event codes
%        cortex_record.event_code[]       event codes
%        cortex_record.eog[:,2]           primary (X) and secondary (Y) channel data
%        cortex_record.epp[:,2]           epp channel data converted to x and y
%  
% This program assumes all files with EPP data have exactly 2 EPP channels
%
%
global cortex_header_size
global makdat_error_fid makdat_warning_fid makdat_debug_fid
global errors warnings debugs
global input_fid
%
if isempty(cortex_index)
   if warnings
      fprintf(makdat_warning_fid,'----- Warning [makdat read_cortex_record]. Completely empty Cortex index entry encountered.\n');
   end
   cortex_record=[];
   return;
end
if input_fid < 0
   if errors
      fprintf(makdat_error_fid,'----- Error [read_cortex_record]. Cortex data file is not open.\n');
   end
   cortex_record=[];
   return;
end

data_size= cortex_index.isi_size + cortex_index.code_size + cortex_index.eog_size ...
          + cortex_index.epp_size; 

if data_size==0     % handle empty record
   cortex_record.event_time=[];
   cortex_record.event_code=[];
   cortex_record.eog=[];
   cortex_record.epp=[];
   return;
end

offset=cortex_index.start_of_header + cortex_header_size;

if fseek(input_fid,offset,'bof');  % find start of data
   cortex_record=[];
   if errors
      fprintf(makdat_error_fid, ...
         'Error [read_cortex_record]. Could not find start of cortex data at offset: %d in file %s.\n', ...
         offset, fopen(input_fid));
   end
   return;
end

num_of_codes=cortex_index.code_size / 2;
[cortex_record.event_time,n]=fread(input_fid,num_of_codes,'uint32'); % 4 bytes for each event time
[cortex_record.event_code,n]=fread(input_fid,num_of_codes,'uint16'); % 2 bytes for each event code
% epp array comes next, even though it is later in the header than the eog

%%%%%%%%%%%%% DEBUG for plx2ctx %%%%%%%%%%%
% disp('time debug!!!');
% cortex_record.event_time=cortex_record.event_time / 100;

if exclude_analog
   cortex_record.epp=[];
   cortex_record.eog=[];
else
   samples=cortex_index.epp_size / 2;
   cortex_record.epp =fread(input_fid,samples,'uint16')' ; % 2 bytes x n samples epp, saved as a row vector
   % eog always comes as two channels.  There is no channel information on these.
   samples=cortex_index.eog_size / 4;
   [eog_samples,n]=fread(input_fid,[2 samples],'int16');
   cortex_record.eog=eog_samples';  % 2 bytes x 2 channels x n samples eog
end


% MatOFF will not accept an event code of 0.  If your Cortex data has event code 0,
% uncomment these two lines.  They will replace all occurrences of event 0 with the
% replacement_code. Choose a replacement code value that suits your experiment.
%
% replacement_code= 5000;
% cortex_record.event_code(find(cortex_record.event_code==0))=replacement_code;



% done



