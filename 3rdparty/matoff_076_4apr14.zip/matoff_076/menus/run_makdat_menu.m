function run_makdat_menu
%
%  run_makdat_menu   issue a Makdat command based on the parameters
%                    in the Makdat Menu
%
%  

global error_fid warning_fid debug_fid
global errors warnings debugs

% build option list

list_file=get(findobj('Tag','listfile'),'String');
if isempty(list_file)
   if warnings
      fprintf(warning_fid,'Warning [run_makdat_menu]: You must supply a list file name\n');
   end;
   return;
end;



option_list='';
if get(findobj('Tag','8channels'),'value')==1
   option_list=[option_list '8'];
end;
if get(findobj('Tag','nooutputfile'),'value')==1
   option_list=[option_list 'N'];
end;
if get(findobj('Tag','overwrite'),'value')==1
   option_list=[option_list 'O'];
end;
if get(findobj('Tag','noepp'),'value')==1
   option_list=[option_list 'P'];
end;
if get(findobj('Tag','noeog'),'value')==1
   option_list=[option_list 'R'];
end;
if get(findobj('Tag','ignorecc'),'value')==1
   option_list=[option_list 'T'];
end;
if get(findobj('Tag','noanalog'),'value')==1
   option_list=[option_list 'X'];
end;
if get(findobj('Tag','verbosemode'),'value')==1
   option_list=[option_list 'V'];
end;
if get(findobj('Tag','showheader'),'value')==1
   option_list=[option_list 'H'];
end;
if get(findobj('Tag','showeventcodes'),'value')==1
   option_list=[option_list 'F'];
end;
if get(findobj('Tag','inhibitwarnings'),'value')==1
   option_list=[option_list 'E'];
end;
if get(findobj('Tag','showprogress'),'value')==1
   option_list=[option_list 'D'];
end;
if get(findobj('Tag','ignorecase'),'value')==1
   option_list=[option_list 'C'];
end;
if get(findobj('Tag','showanalogvalues'),'value')==1
   option_list=[option_list 'A'];
end;
if get(findobj('Tag','showspikes'),'value')==1
   option_list=[option_list 'S'];
end;

if ~isempty(option_list)
   option_list=['-' option_list];
end;

output_file=get(findobj('Tag','outputfile'),'String');

issue_command(['makdat ' list_file ' ' output_file ' ' option_list]);

