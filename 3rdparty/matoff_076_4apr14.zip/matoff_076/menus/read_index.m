function [index,udef]=read_index(file_name)
%
%  Read entire index file.
% Inputs
%   file_name    name of data file, includes all path information
% Outputs
%   index(n)      structure of size m = number of trials
%      .event_start_position
%      .event_records 
%      .pulse_start_position 
%      .pulse_records 
%      .analog_start_position
%      .analog_length
%   udef(n)
%      .name          12 byte ASCII unit name
%      .channel       pulse channel number 0-255
%      .trials        row vector of index trial numbers for this unit 
%
%  Most workoff files (.event, .pulse, .analog) are kept open, but 
%  the index and udef files are not.
%
%  index becomes the global variable work_index in work_file.
%  udef becomes the global variable work_udef in work_file.
%
%  index=[] and udef=[] if an error occurs.
%
global error_fid warning_fid debug_fid
global errors warnings debugs

if isempty(file_name)
   if errors
      fprintf(error_fid,'Error [read_index]. Index file name is empty. Cannot read index.\n');
   end
   index=[];
   udef=[];
   return;
end

slash=findstr(file_name,'\');
if isempty(slash)
   path=[];
   fname=file_name;
else
   path=file_name(1:slash(end));
   if (slash(end)+1) > length(file_name)
      if errors
         fprintf(error_fid,'Error [read_index]. Null file name %s \n',file_name);
      end
      return;
   end
   fname=file_name(slash(end)+1:end);
end


[end_of_name,extension]=strtok(fname,'.');  % remove any extension
index_file_name=[path end_of_name '.index'];
udef_file_name=[path end_of_name '.udef'];
if debugs
   fprintf(debug_fid,'Debug [read_index]. Opening file to read %s\n',index_file_name);
end
index_fid=fopen(index_file_name);
if index_fid < 1
   if errors
      fprintf(error_fid,'Error [read_index]. Cannot find index file: %s.\n',index_file_name);
   end
   index=[];
   udef=[];
   return;
end
if debugs
   fprintf(debug_fid,'Debug [read_index]. Index fid= %d\n',index_fid);
end
if debugs
   fprintf(debug_fid,'Debug [read_index]. Opening file to read %s (unit definition file).\n',udef_file_name);
end
udef_fid=fopen(udef_file_name);
if udef_fid < 1
   if errors
      fprintf(error_fid,'Error [read_index]. Cannot find udef file: %s.\n',udef_file_name);
   end
   index=[];
   udef=[];
   return;
end
if debugs
   fprintf(debug_fid,'Debug [read_index]. Unit definition fid= %d\n',udef_fid);
end

i=1;
while (1)
   try   
      if ~feof(index_fid)
         [index_entry.trial,n]=fread(index_fid,1,'int32'); % 4 bytes
         [pointers,n]=fread(index_fid,6,'6*uint32');       % 6 * 4 bytes
         index_entry.event_start_position=pointers(1);
         index_entry.event_records=pointers(2);
         index_entry.pulse_start_position=pointers(3);
         index_entry.pulse_records=pointers(4);
         index_entry.analog_start_position=pointers(5);
         index_entry.analog_length=pointers(6);
      end
   catch
      if errors
         fprintf(error_fid, 'Error [read_index]. Index file ended unexpectedly.\n');
      end
      index=[];
      udef=[];
      fclose(udef_fid);
      udef_fid=-1;
      fclose(index_fid);
      index_fid=-1;
      return;
   end
   
   if ~isempty(index_entry.trial) & (index_entry.trial > 0)
      index(i)=index_entry;
      i=i+1;
   elseif index_entry.trial==-1
      if debugs
         fprintf(debug_fid,'Debug [read_index]. End of index verifed.\n');
      end
      break;  % Normal exit     
   else
      if errors
         fprintf(error_fid, 'Error [read_index]. Index file has an empty entry.\n');
      end
      index=[];
      udef=[];
      fclose(udef_fid);
      udef_fid=-1;
      fclose(index_fid);
      index_fid=-1;
      return;
   end
end

fclose(index_fid);
index_fid=-1;
if debugs
   fprintf(debug_fid,'Debug [read_index]. Normal close of index file.\n');
end
i=1;   % read udef file
while (1)
   try    % an EOF is an error
      if ~feof(udef_fid)
         udef_entry.trials='';
         uname=fread(udef_fid,12,'12*char');            % 12 bytes
         udef_entry.name=char(uname(find(uname)))';     % squeeze out nulls
         udef_entry.channel=fread(udef_fid,1,'uint8');  % 1 byte
         trial_string=fread(udef_fid,87,'87*char');    % 87 characters
         % convert trial list string into list of trial numbers
         trial_string=char(trial_string(find(trial_string)))';
         trial_list=expand_range_list(trial_string);
      end
   catch   % abort on errors
      if errors
         fprintf(error_fid, 'Error [read_index]. udef file ended unexpectedly.\n');
      end
      index=[];
      udef=[];
      fclose(udef_fid);
      udef_fid=-1;
      return;
   end
   
   % check for an eod-of-file entry
   if (udef_entry.channel==255) & strcmp(udef_entry.name,'END_OF_FILE')
      if debugs
         fprintf(debug_fid,'Debug [read_index]. End of udef file verifed.\n');
      end
      fclose(udef_fid);
      udef_fid=-1;
      return;  % normal exit
   end
   
   % check for valid trial list
   if isstr(trial_list)   % a string means an error occurred parsing the list
      if errors
         fprintf(error_fid,'Error [read_index]. udef file has bad trial list for unit: %s\n' ...
              ,uname);
      end
      fclose(udef_fid);
      udef_fid=-1;
      return;
   elseif isempty(trial_list)
      if warnings
         fprintf(warning_fid,'Warning [read_index]. Unexpected empty trial list in udef file.\n');
      end
      % don't store this udef entry
   else
      udef_entry.trials=trial_list;   % correct string
      udef(i)=udef_entry;   % add this entry to structure
      i=i+1;      
   end
end
if warnings
   fprintf(warning_fid,'Warning [read_index]. Unit definition file ended without expected verification\n');
end
fclose(udef_fid);
udef_fid=-1;

