function [history]=read_history(hindex,unitname)
%
%  Get history classes and class values for a unit from the current file.
%  
%  Inputs
%    hindex               hindex
%    unitname             name of a unit in the current file
%  Output   
%    history(cindex).class       class 
%                   .trial_list  = [] array of trial numbers that belong in this class
%                   .values      = [] array of matching class values for each trial
%           (cindex indexes a class, range 1 to n, n = number of classes for this unit)
%
%  Globals modified
%  none
%
global error_fid warning_fid debug_fid
global errors warnings debugs
global environment
global MAX_UNIT_NAME

max_unit_name=num2str(eval('MAX_UNIT_NAME'));  % convert number to a string
history_fid=-3;
history=[];   % default

if isempty(hindex)
   if debugs
      fprintf(debug_fid,'Debug [read_history]. Empty hindex.\n');
   end;
   return;
end;

if isempty(unitname)
   if warnings
      fprintf(warning_fid,'Warning [read_history]. Empty unit name.\n');
   end;
   return;
end;

% find unit in history index
class_entry=0;
for e=1:length(hindex);    
   if strcmp(hindex(e).unitname,unitname)
      class_entry=e;
      break;
   end;
end;

if class_entry==0
   if debugs
      fprintf(debug_fid,'Debug [read_history]. No history available yet for unit: %s\n',unitname);
   end;
   return; % return with empty history
end;
   
% open history file
basefilename=get(findobj('Tag','filename'),'String');  % find current file name
if isempty(basefilename)
   if warnings
      fprintf(warning_fid,'Warning [read_history]. No file open.\n');
   end;
   return;  % return with empty history
end;

basefilename=filepath(basefilename,environment.datapath);  % find path
history_file_name=[basefilename '.history'];
if debugs
   fprintf(debug_fid,'Debug [read_history]. Opening history file: %s\n',history_file_name);
end;

history_fid=fopen(history_file_name,'rb');
if history_fid < 1
   if warnings
      fprintf(warning_fid,'Warning [read_history]. No history found for: %s.\n',history_file_name);
   end;
   return;  % return with empty history
end;
if debugs
   fprintf(debug_fid,'Debug [read_history]. history fid= %d\n',history_fid);
end;

% find history location for this unit in the file
try
   fseek(history_fid,hindex(class_entry).history_start,'bof');  
catch
   if errors
      fprintf(error_fid,'Error [read_history]. Tried to read past end of the history file.\n');
   end;
   return;
end;

% read header for this unit
try
   unit_header=fread(history_fid,1,'int16');    % 2 byte header marker
   uname=fread(history_fid,[1 MAX_UNIT_NAME],[max_unit_name '*char']);    % 12 byte unit name
   uname=char(uname(find(uname)));              % squeeze nulls out of unit name
catch
   if errors
      fprintf(error_fid,'Error [read_history].  Error reading unit header.\n');
      fprintf(error_fid,'Starting offset: %-5d \n', hindex(class_entry).history_start);
   end;   
   fclose(history_fid);
   history_fid=-1;
   return;
end;
% more validity checking
if debugs
   fprintf(debug_fid,'Debug [read_history]. Reading history file entry. \n');
   fprintf(debug_fid,'Debug [read_history].    Header marker: %d   Unit name: %s \n',unit_header,uname);
end;
if (unit_header~=-1) | ~strcmp(uname,unitname)
   if errors
      fprintf(error_fid,'Error [read_history].  Error reading unit header.\n');
      fprintf(error_fid,'header marker: %d   Unit name: %s \n',unit_header,uname);
   end;
   fclose(history_fid);
   history_fid=-1;
   return;
end; 

% read all the class entries for this unit
cindex=0;
while ~feof(history_fid)
   try
      class     =fread(history_fid,1,'int16');     % read class
      ntrials   =fread(history_fid,1,'int16');     % number of trials in the class trial list
      list_size =fread(history_fid,1,'int16');     % list size (in bytes)
   catch
      if errors
         fprintf(error_fid,'Error [read_history].  Error reading class entry in history file.\n');
      end;   
      fclose(history_fid);
      history_fid=-1;
      return;
   end;
   if class == -1  % is this a new unit header?
      if debugs       
         fprintf(debug_fid,'Debug [read_history]. End of classes for this unit.\n');
      end;
      fclose(history_fid);
      history_fid=-1;
      return;  % normal exit
   end;
   if debugs       
      fprintf(debug_fid,'Debug [read_history]. Getting trial list and class values for class=%d.\n',class);
   end;
   
   try
      list_size_str=num2str(eval('list_size'));
      class_trial_list =fread(history_fid,[1 list_size],[list_size_str '*uchar']);   % list of trials in this class
      class_trial_list=char(class_trial_list(find(class_trial_list)));   
      ntrials_str=num2str(eval('ntrials'));
      class_values     =fread(history_fid,[1 ntrials],[ntrials_str '*int16']);     % class values
   catch
      if errors
         fprintf(error_fid,'Error [read_history].  Error reading history file.\n');
      end;   
      fclose(history_fid);
      history_fid=-1;
      return;
   end;
   cindex=cindex+1;
   history(cindex).class=class;
   history(cindex).trial_list=class_trial_list;
   history(cindex).values=class_values;
end;

if errors
   fprintf(error_fid,'Error [read_history]. Unexpected end of history file encountered.\n');
end;      
fclose(history_fid);
history_fid=-1;
return; 
