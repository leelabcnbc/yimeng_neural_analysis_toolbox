function [return_value]=batch(batch_file_name)
%
% Process a DOS batch file.
% Only allows one level of indirection.  That is, the primary
% batch file can "call" another batch file, but the second batch
% file cannot issue a "call" command.
%
%  Inputs
%     batch_file_name    name of DOS batch file
%  Outputs
%    return_value
%      1    normal
%      2    BREAK
%     -1    could not open batch file
%     -2    could not honor CONTINUE request
%     -10   fatal error
%  Globals modified
%    batch_state, load_state, break_state, call_state
%    batch_fid, call_fid, load_fid, call_fid
%    pcoff_argument
%
%
global environment pcoff_argument fid
global batch_state batch_fid load_state load_fid
global call_state call_fid break_state fileerror
global error_fid warning_fid debug_fid
global errors warnings debugs 
%

return_value=1;  % assume a normal return

if isempty(batch_file_name)
   return_value= -1;
   if debugs
      fprintf(debug_fid,'Warning [batch]. Batch file name is blank. Ignoring batch request.\n');
   end
   return;
end

if ~strncmp(batch_file_name,'CONTINUE',8)  % fix file extension unless this is a continue
   [name,extension]=strtok(batch_file_name,'.');
   if isempty(extension)
      batch_file_name=[batch_file_name '.bat'];
   end
end   
   
% must deal with a CONTINUE from either load_file or call (2nd batch)
if strncmp(batch_file_name,'CONTINUE',8)
   if debugs
      fprintf(debug_fid,'Debug [batch]. This looks like a CONTINUE\n');
   end
   break_state=1;  % should be this anyway.
   % are we prepared for a CONTINUE ?
   if ~batch_state | isempty(fopen(batch_fid))
      if errors
         fprintf(error_fid,'Error [batch]. Unexpected CONTINUE request. Aborting batch file.\n');
      end
      batch_state=0;
      try 
         fclose(batch_fid); 
         batch_fid=-1;  % reset the ID
      catch  
      end
      call_state=0;
      try 
         fclose(call_fid); 
         call_fid=-1;
      catch 
      end
      load_state=0;
      try 
         fclose(load_fid); 
         load_fid=-1;
      catch 
      end
      break_state=0;
      return_value=-2;
      return;
   end
   % do we continue via a call file?
   if call_state
      % the replacement variables should still have the right values
      if debugs
         fprintf(debug_fid,'Debug [batch]. CONTINUE with Call to second level batch file.\n');
      end
      return_value=second_batch(replacement);  % continue with execution of the 2nd batch file
      switch return_value
      case 2     % BREAK
         break_state=1;
         return;
      case {-5,-4,-3,1}
         break_state=0;  % done treating this as a break, fall into regular loop
      end
   elseif load_state
      r=load_file('CONTINUE');  % file name will be ignored, LOAD has good error checking
      switch r
         case -1  % protocol file not found
            % just go on to next batch file entry
         case -2  % file error (opening data file)
            % force fileerror='exit', which just means skip this batch entry
         case -3  % EXIT requested
            % same. just go to next entry
         case  1  % normal
         case  2  % BREAK requested, protocol file not closed
            if strncmp(fileerror,'break',5)
               fprintf(1,'<<BREAK>>  use CONTINUE to resume protocol file.\n');
               if environment.logging==1
                  fprintf(fid.log,'<<BREAK>>  use CONTINUE to resume protocol file.\n');
               end
               break_state=1;
               return;  % return with batch_state=1 and batch file open.        
            end
      end % switch
   end % if call_state
else
    % this is not a CONTINUE
    % force a clean-up
    try 
       fclose(batch_fid); 
       batch_fid=-1;
    catch  
    end
    call_state=0;
    try 
       fclose(call_fid); 
       call_fid=-1;
    catch 
    end
    load_state=0;
    try 
       fclose(load_fid); 
       load_fid=-1;
    catch 
    end
    

    work_file(1);  % close files, reset GUI
    taint=10;
    %  clean; % overkill    
    
    break_state=0;
    if debugs 
       fprintf(debug_fid,'Debug [batch]. Opening batch file %s.\n',batch_file_name);
    end
    batch_fid=fopen(batch_file_name,'rt');  
    if batch_fid < 1  % open failure 
       if warnings
          fprintf(warning_fid,'Warning [batch]. Could not open batch file %s.\n',batch_file_name);
       end
       return_value=-1;
       return; 
    else  
       batch_state=1;   % while batch file is open  
    end % if batch_fid < 1
end % if CONTINUE 
   
break_state=0;
if isempty(fopen(batch_fid))
   if errors
      fprintf(error_fid,'Error [batch].  Could not open batch file. Aborting batch.\n');
   end
   return_value=-1;  % treat as an open failure, but this should never happen!
end

while ~feof(batch_fid)
   if ~break_state 
      rcmd=fgetl(batch_fid);  % fetch command from batch file
      fprintf(1,'= %s\n',rcmd);   % echo batch command
      if environment.logging==1
         fprintf(fid.log,'= %s\n',rcmd); 
      end
      c=deblank(rcmd);  % check for control commands
      [c,params]=strtok(c);  % separate command name from any parameters
      c=lower(deblank(strjust(c)));  % command to lower case
   else
      break_state=0;
   end
   if strncmp(c,'set',3)
       good=nsetenv(rcmd);
       if good==0
          if warnings
             fprintf(warning_fid,'Warning [batch]. Environmental variable not recognized\n');
          end
       elseif good==2
          if warnings
             fprintf(warning_fid,'Warning [batch]. Environmental variable no longer used\n');
          end
       end % if good
            
    elseif strncmp(c,'call',3)  % This calls another batch file
       if debugs
          fprintf(debug_fid,'Debug [batch].  Calling a second batch file from a batch file.\n');
       end
       % determine the replaceable parameters for second batch file 
       replacement.B0=''; replacement.B1=''; replacement.B2=''; 
       replacement.B3=''; replacement.B4=''; 
       replacement.B5=''; replacement.B6=''; replacement.B7=''; 
       replacement.B8=''; replacement.B9='';
       [replacement.B0,rem]=strtok(params);   % second batch file name
       [replacement.B1,rem]=strtok(rem);     
       [replacement.B2,rem]=strtok(rem);     
       [replacement.B3,rem]=strtok(rem);
       [replacement.B4,rem]=strtok(rem);
       [replacement.B5,rem]=strtok(rem);
       [replacement.B6,rem]=strtok(rem);
       [replacement.B7,rem]=strtok(rem);
       [replacement.B8,rem]=strtok(rem);
       [replacement.B9,rem]=strtok(rem);
      
       second_batch(replacement);
       
       % clear replacements
       replacement.B0=''; replacement.B1=''; replacement.B2=''; 
       replacement.B3=''; replacement.B4=''; 
       replacement.B5=''; replacement.B6=''; replacement.B7=''; 
       replacement.B8=''; replacement.B9='';
      
   elseif strncmp(c,'pcoff',5)
      % determine the replaceable parameters  
      pcoff_argument.P0=''; pcoff_argument.P1=''; pcoff_argument.P2='';
      pcoff_argument.P3=''; pcoff_argument.P4=''; pcoff_argument.P5='';
      pcoff_argument.P6=''; pcoff_argument.P7=''; pcoff_argument.P8='';
      pcoff_argument.P9='';
      pcoff_argument.P0='PCOFF';       % pcoff command
      [pcoff_argument.P1,rem]=strtok(params);  % protocol file name
      [pcoff_argument.P2,rem]=strtok(rem);     % data file name
      [pcoff_argument.P3,rem]=strtok(rem);     % unit
      [pcoff_argument.P4,rem]=strtok(rem);     % metafile parameter 1
      [pcoff_argument.P5,rem]=strtok(rem);     % metafile parameter 2
      [pcoff_argument.P6,rem]=strtok(rem);     % metafile parameter 3
      [pcoff_argument.P7,rem]=strtok(rem);     % metafile parameter 4...
      [pcoff_argument.P8,rem]=strtok(rem);     % 5
      [pcoff_argument.P9,rem]=strtok(rem);     % 6
      
      if debugs
         fprintf(debug_fid,'Debug [batch]. PCOFF replacement argument parameters:\n');
         pcoff_argument    % omit ";" to print
      end 
      
      % issue file and unit commands first
      if ~strncmp(pcoff_argument.P2,'-',1)
         issue_command(['file ' pcoff_argument.P2]);  % file command (check for place holder)
      else
         pcoff_argument.P2='';
      end      
      if ~strncmp(pcoff_argument.P3,'-',1)
         issue_command(['unit ' pcoff_argument.P3]);  % Unit command 
      else
         pcoff_argument.P3='';
      end         
      if strncmp(pcoff_argument.P4,'-',1)| isempty(pcoff_argument.P4)
         pcoff_argument.P4='';    % first metafile argument
      end     
      if strncmp(pcoff_argument.P5,'-',1)| isempty(pcoff_argument.P5)
         pcoff_argument.P5='';    % second metafile argument
      end               
      if strncmp(pcoff_argument.P6,'-',1)| isempty(pcoff_argument.P6)
         pcoff_argument.P6='';    % third metafile argument
      end      
      if strncmp(pcoff_argument.P7,'-',1)| isempty(pcoff_argument.P7)
         pcoff_argument.P7='';    % fourth metafile argument
      end
      if strncmp(pcoff_argument.P8,'-',1)| isempty(pcoff_argument.P8)
         pcoff_argument.P8='';    % fifth metafile argument
      end
      if strncmp(pcoff_argument.P9,'-',1)| isempty(pcoff_argument.P9)
         pcoff_argument.P9='';    % sixth (last) metafile argument
      end
      if ~strncmp(pcoff_argument.P1,'-',1)   % protocol file
         if debugs
            fprintf(debug_fid,'Debug [batch]. Issuing PCOFF command from batch file. Protocol file: %s\n', ...
               pcoff_argument.P1);
         end
         r=load_file(pcoff_argument.P1);
         if debugs
            fprintf(debug_fid,'Debug [batch]. Protocol file processing done. Return code= %d \n',r);
            fprintf(debug_fid,'Returning to Batch processing.\n');
         end
         switch r
            case -1  % protocol file not found
               % just go on to next batch file entry
            case -2  % file error (opening data file)
               % force fileerror='exit', which just means skip this batch entry
            case -3  % EXIT requested
               % same. just go to next entry
            case  1  % normal
            case  2  % BREAK requested, protocol file not closed
               if strncmp(fileerror,'break',5)
                  fprintf(1,'<<BREAK>>  use CONTINUE to resume protocol file.\n');
                  if environment.logging==1
                     fprintf(fid.log,'<<BREAK>>  use CONTINUE to resume protocol file.\n');
                  end
                  return;  % return with batch_state=1 and batch file open.
               end
         end % switch
      end % protocol file
      pcoff_argument.P0=''; pcoff_argument.P1=''; pcoff_argument.P2='';
      pcoff_argument.P3=''; pcoff_argument.P4=''; pcoff_argument.P5='';
      pcoff_argument.P6=''; pcoff_argument.P7=''; pcoff_argument.P8='';
      pcoff_argument.P9='';  
      
   else    % if we don't recognize the batch command, let DOS deal with it.
      rcmd=deblank(strjust(rcmd,'left')); 
      if ~isempty(rcmd)
         eval(['!' rcmd]);
      end
   end % if set

end % while batch file entry

try
   fclose(batch_fid);
   batch_fid=-1;
catch
end
batch_state=0;
if debugs
   fprintf(debug_fid,' -- Batch complete -- \n');
end
