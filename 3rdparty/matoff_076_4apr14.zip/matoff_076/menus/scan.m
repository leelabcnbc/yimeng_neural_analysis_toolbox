function [trial_count,spike_counts]=scan()
% Search trials for event code sequences that match search criteria.
% Count the number of trials found then count the number of spikes on 
% each pulse channel.  work_scan() is the real workhorse. It does 
% the trial-by-trial search for matching event codes.
% 
% Outputs
%   trial_count    number of trials that match search criteria
%   spike_counts   number of spikes in each active spike channel 
% Globals modified
%   spikemap         based on output from work_getit()
%   work_trial_list  modified by calling work_scan
%
%   spikemap structure:
%    This array has 3 columns and n rows.  
%    column 1 = trial number (chronological order starting from trial 1)  "unsorted"
%    column 2 = a spike channel number 0 to m
%    column 3 = time of occurrence of the spike
%
global spikemap work_trial_list 
global error_fid warning_fid debug_fid
global errors warnings debugs

spike_counts=zeros(1,100);  % up to 100 spike channels (0-99)
work_scan;   % create the global variable:  work_trial_list  list of work_index entries to use
trial_count=length(work_trial_list);

if ~isempty(work_trial_list)
   if debugs
      fprintf(debug_fid,'Debug [scan]. Fetching spikemap.\n');
   end;
   spikemap=work_getit('spikemap');
   if isempty(spikemap)
      highest_pulse_channel=0;
      spike_counts(1)=0;
      spikemap=[];
   else   
      spikemap=spikemap(find(sum(spikemap,2) > 0),:);  % squeeze out trials with  [0  0  0]
      highest_pulse_channel=max(spikemap(:,2));  % channel 0 is possible
      spike_counts=zeros(1,highest_pulse_channel+1);
      % count the number of spike in each channel
      for i=1:highest_pulse_channel+1           
         spike_counts(i)=size(find(spikemap(:,2)==(i-1)),1);
      end;
   end;
      
end;




   

