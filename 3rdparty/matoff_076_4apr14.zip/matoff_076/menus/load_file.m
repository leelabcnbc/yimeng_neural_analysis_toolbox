function[return_value]=load_file(file_name)
% 
%
%  Execute a protocol file
%
% Inputs
%   file_name     base name of protocol file to execute
% Outputs
%   return_value
%       -1  protocol file not found
%       -2  file error (opening data file)
%       -3  EXIT requested
%        1  normal
%        2  BREAK requested, protocol file not closed
%
% Globals modified
%   load_state, break_state, load_fid
%
global load_state fileerror load_fid environment
global auto_update
global pcoff_argument break_state
global error_fid warning_fid debug_fid
global errors warnings debugs

if isempty(file_name)
   if warnings
      fprintf(warning_fid,'Warning [load_file]. Empty protocol file name. No file to process.\n');
   end
   return_value= -1;
   return;
end

[name,extension]=strtok(file_name,'.');
if isempty(extension)
   file_name=[file_name '.pro'];
end

% prepend the path for this protocol file
file_name=filepath(file_name,environment.protocolpath); 
return_value=1;  % assume normal return
if debugs
   fprintf(debug_fid,'Debug [load_file]. Looking for protocol file: %s \n',file_name);
end

% test for inconsistencies
if break_state & ~load_state % check for impossible condition
   break_state=0;
   load_state=0;
   if warnings
      fprintf(warning_fid, 'Warning [load_file]. Fixing unexpected load state.\n');
   end
   try
      fclose(load_fid);   % close old file, if any.
      load_fid=-1;
   catch
   end
end  % if break_state
      
if ~break_state  % is this a CONTINUE ?
   open_file=fopen(load_fid);   % no, see if file was left open
   if ~isempty(open_file)
      if warnings
         fprintf(warning_fid,'Warning [load_file]. Protocol file %s (file handle %d) \n',open_file,load_fid); 
         fprintf(warning_fid,'had been left open. Closing now.\n');
      end
      fclose(load_fid);
      load_state=0;
      load_fid=-1;
   end
   if debugs
      fprintf(debug_fid,'Opening protocol file %s\n',file_name);
   end
   load_fid=fopen(file_name,'rt');  % open a file
   if load_fid < 0  % open failure
      if warnings
         fprintf(warning_fid,'Warning [load_file]. Protocol file %s not found.\n',file_name);
      end
      return_value=-1;
      load_state=0;
      return;
   else
      if debugs
         fprintf(debug_fid,'protocol file fid=%d\n',load_fid);
      end
      load_state=1;   % while file is open
      % check to see if we are in autoupdate mode.  Turn it off.
      if auto_update
         auto_update=0;
         set(findobj('Tag','autoupdate'),'Value',0);
         if warnings
            fprintf(warning_fid,'Warning [load_file]. Disabling autoupdate. Using manualupdate mode.\n',file_name);
         end         
      end
   end
   
else   % supposed to be a continue  
   if isempty(fopen(load_fid))  % is a file open ?
      if warnings
         fprintf(warning_fid, 'Warning [load_file]. Expected to CONTINUE. Opening protocol file now.\n'); % OOPS! no file open.
      end
      load_state=0;
      break_state=0;
      load_fid=fopen(file_name,'rt');  % ignore CONTINUE and open requested protocol file     
      if load_fid < 0  % open failure
         return_value=-1;
         load_state=0;
         if warnings
            fprintf(warning_fid,'Warning [load_file]. Could not open protocol file %s.\n',file_name);
         end
         return;
      else
         load_state=1;   % while file is open
      end
    end % if isempty(fopen
end % if ~break_state  

if debugs
   fprintf(debug_fid,'Debug [load_file]. Opened protocol file with file handle %d \n',load_fid);
end

date_string=date;

while ~feof(load_fid)
   rcmd=fgetl(load_fid);  % fetch command from protocol file
   if ~isstr(rcmd)  % non-string = -1 = eof
      break;
   end
   % replace pcoff replacement variables

   % special variables:  %10 = date string     %11 = time string
   tv=fix(clock);
   time_string=[num2str(tv(4)) ':' num2str(tv(5)) ':' num2str(tv(6))];
   rcmd=strrep(rcmd,[environment.metachar2 '10'],date_string); 
   rcmd=strrep(rcmd,[environment.metachar2 '11'],time_string); 

   rcmd=strrep(rcmd,[environment.metachar2 '0'],pcoff_argument.P0);
   rcmd=strrep(rcmd,[environment.metachar2 '1'],pcoff_argument.P1);
   rcmd=strrep(rcmd,[environment.metachar2 '2'],pcoff_argument.P2);
   rcmd=strrep(rcmd,[environment.metachar2 '3'],pcoff_argument.P3);
   rcmd=strrep(rcmd,[environment.metachar2 '4'],pcoff_argument.P4);
   rcmd=strrep(rcmd,[environment.metachar2 '5'],pcoff_argument.P5);
   rcmd=strrep(rcmd,[environment.metachar2 '6'],pcoff_argument.P6); 
   rcmd=strrep(rcmd,[environment.metachar2 '7'],pcoff_argument.P7);
   rcmd=strrep(rcmd,[environment.metachar2 '8'],pcoff_argument.P8);
   rcmd=strrep(rcmd,[environment.metachar2 '9'],pcoff_argument.P9);     



   c=deblank(rcmd);           % check for control commands
   [c,params]=strtok(c);      % separate command name from any parameters
   c=lower(deblank(strjust(c,'left')));  % command to lower case

   if strncmp(c,'endif',5)
      params=lower(deblank(strjust(params,'left')));  % parameters to lower case
      if debugs
         fprintf(debug_fid,'Debug [load_file].  ENDIF %s \n',params);
      end
      endif_results=endif_command(params);
      if endif_results
         break;      % exit protocol file      
      end
   end

   if strcmp(c,'end')
      if debugs
         fprintf(debug_fid,'Debug [load_file].  END encountered.\n');
      end
      break;
   elseif strncmp(c,'load',3)
      if warnings
         fprintf(debug_fid,'Error [load_file]. Cannot call a Protocol file from a Protocol file. Use metafiles. \n');
      end
      break;
   elseif strncmp(c,'exit',3)
      if debugs
         fprintf(debug_fid,'Debug [load_file].  EXIT encountered.\n');
      end
      return_value=-3;  % return by EXIT command, protocol file is closed
      break;
   elseif strncmp(c,'break',5)
      if debugs
         fprintf(debug_fid,'Debug [load_file].  BREAK encountered.\n');
      end
      return_value=2;  % return by BREAK command, file remains open
      break_state=1;  % enable "CONTINUE" command
      return;
   end
   % issue the command
   response=issue_command(rcmd);
   if strcmp(response,'FILEERROR')
      return_value=-2;  % error opening data file, close and exit
      break;
   end
 end % while
 if debugs
    fprintf(debug_fid,'Debug [load_file]. Closing protocol file, handle number %d \n',load_fid);
 end
 fclose(load_fid);
 load_fid=-1;
 load_state=0;
