function issue_message(message_type,message_string)
%  Issue a one-line Debug, Warning, or Error message
%  (Special user function)
% 
%  Inputs
%   message_type        1=Debug, 2=Warning, 3=Error
%   message_string      string
%
%
global error_fid warning_fid debug_fid
global errors warnings debugs

if (message_type==1) & (debugs)
   fprintf(debug_fid,'%s \n',message_string);
elseif (message_type==2) & (warnings)
   fprintf(warning_fid,'%s \n',message_string);
elseif (message_type==3) & (errors)
   fprintf(error_fid,'%s \n',message_string);
end;
