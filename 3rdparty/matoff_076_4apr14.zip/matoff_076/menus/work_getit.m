function [array1,array2]=work_getit(get_what)
%
%  Fetches spike data, analog data
%
%  Inputs
%    get_what
%       spikemap       get the spike map (spike data for all spike channels, for trials that match the search sequence)
%       analogmap n    get analog data:  n= analog channel (1..4), returns 2 arrays
%  Outputs
%     array1           spikemap:  spikemap
%                      analogmap: pointers to middle and end analog values
%                      events:    event code array    
%     array2           spikemap:  empty
%                      analogmap: analog data
%                      events:    event time array
%
global work_fid work_index
global work_trial_list center_is_class
global error_fid warning_fid debug_fid
global errors warnings debugs

array1=[];
array2=[];

if isempty(work_index) | isempty(work_trial_list)
   if debugs
      fprintf(debug_fid,'Debug [work_getit]. Empty work_index or work_trial_list.\n');
   end;
   return;
end
   
if findstr(get_what,'spikemap')
      
   if ~get(findobj('Tag','spikechannelmenu'),'UserData')
      if debugs
         fprintf(debug_fid,'Debug [work_getit]. Pulses are off. Not collecting spike data\n');
      end
      return;
   end
   if debugs
      fprintf(debug_fid,'Debug [work_getit]. Finding spikes for matching trials (spikemap).\n');
   end;
   % Extract the spikes for only those file trials that matched the search criteria
   % Renumber the trials consecutively from 1. 

   selected_pulse_data=read_pulse_record(work_fid.pulse,work_trial_list);   % get all the data for the selected channel
   
   for trial=1:length(work_trial_list)  % one trial of pulses at a time
      trial_marker=selected_pulse_data(1,(2*trial)-1); % skip the trial marker
      trial_number=selected_pulse_data(1,(2*trial));
      if (trial_marker ~= -1) | (trial_number ~= work_trial_list(trial))  % see if the file is properly structured
         if errors
            fprintf(error_fid,'Error [work_getit]. Error reading pulse trial marker or wrong trial found.\n');
         end;
         return;
      end;

      chans=selected_pulse_data(2:end,(2*trial)-1);  
      chans=chans(find(~isnan(chans)));   % remove nans
 
      if ~isempty(chans)   % extract spike channel data if any exists
         times=selected_pulse_data(2:end,(2*trial));
         times=times(find(~isnan(times)));   % remove nans
         low_chan=min(chans); 
         high_chan=max(chans);
         for this_chan=low_chan:high_chan   % for each spike channel recorded in this trial
            this_chan_times=times(find(chans==this_chan));   % get all spikes for one channel
            this_chan_times=this_chan_times(find(~isnan(this_chan_times))); % remove NaNs
            array1=[array1 ; ...   % add to map
                 ones(size(this_chan_times))*trial ones(size(this_chan_times))*this_chan this_chan_times];
         end; % for this_chan
      end; % if ~empty(chans)
   end; % for trial=
   
elseif findstr(get_what,'analogmap')
   if debugs
      fprintf(debug_fid,'Debug [work_getit]. Reading analog from data file.\n');
   end;
   [dummy,chan_string]=strtok(get_what);  % get the analog channel number
   work_analog_chan=str2num(chan_string);
   if isempty(work_analog_chan)
      if errors
         fprintf(error_fid,'Internal error [work_getit]. Analogmap requested without a channel number.\n');
      end;
      return;
   end;
   freq=str2num(get(findobj('Tag','frequency'),'String')); % sample freq in hz from the GUI
   time_step=10000/freq;  % time between each analog sample scaled in seconds
   center=str2num(get(findobj('Tag','center'),'String')); % centering code group
   if center > center_is_class 
      tcv=list_class(center);  % fetch all trials and class values for this class
      if isempty(tcv)
         if warnings
            fprintf(warning_fid,'Warning [work_getit]. Class %d is empty. Will Center at time zero.\n',center);
         end;
         trial_time_zero=zeros(size(trials_found,1));
      end
      trials_in_class=tcv(1,:);         % get the trial numbers
      center_times_in_class=tcv(2,:);   % get the times
   end

  
   % Read the analog values for only those "file trials" that matched the search criteria.
   % Renumber the trials consecutively from 1 as "unsorted trials".
   
   % read data for all analog channels, return them as unsorted trials
   selected_analog_data=read_analog_record(work_fid.analog,work_trial_list); 

   
   for unsorted_trial=1:length(work_trial_list)      % get each file trial that match the sequence
      if center > center_is_class
         % center code is a class value. find the centering time listed in the classes
         index_of_trial_in_class=find(trials_in_class==work_trial_list(unsorted_trial));
         if isempty(index_of_trial_in_class)
            trial_time_zero=0;    % trial was not found in the class. assign its center time = 0
         else
            % found this trial in the center class. get the stored center time. convert milliseconds to 0.1 milliseconds
            trial_time_zero=center_times_in_class(index_of_trial_in_class)*10;  
         end
      else
         % the center value points to a code group in the sequence. Find the time of the event code for this trial
         trial_time_zero=work_events_array2(unsorted_trial,center);  
      end
      % check for valid file trial marker and file trial number
      trial_marker=selected_analog_data(1,(2*unsorted_trial)-1);
      trial_number=selected_analog_data(1,(2*unsorted_trial));
      
      % file trial = work_trial_list(unsorted_trial)
      if (trial_marker ~= -1) | (trial_number ~= work_trial_list(unsorted_trial))
         if errors
            fprintf(error_fid,'Error [work_getit]. Error reading analog trial marker or wrong trial found.\n');
         end;
         return;
      end;
      
      % Locate the data for the desired analog channel (work_analog_chan)
      this_chan_trials=find(selected_analog_data(2:end,(2*unsorted_trial)-1)== work_analog_chan) ;       
      
      if ~isempty(this_chan_trials)   % skip if no entries for this channel
         this_chan_trials=this_chan_trials+1;  % jump over first entry (trial marker)
         % grab analog data for this trial and this unit
         analog_values=selected_analog_data(this_chan_trials,(2*unsorted_trial));   
         % analog_values=analog_values(find(~isnan(analog_values)));   % removing nans should not be necessary!
         
         if debugs
            if find(isnan(analog_values))
               fprintf(debug_fid,'Debug [work_getit]. NaNs found in analog data. Not good!\n');
            end;
         end;
    
         col2=length(analog_values);
         % find the center analog value based on analogstart code (usually 100, determined in work_scan)
         % work_analog_start trial number is based on trial numbers stored in work_trial_list
         % wrong?     col1=round((trial_time_zero-work_analog_start(work_trial_list(unsorted_trial)))/time_step)+1;
         col1=round((trial_time_zero-work_analog_start(unsorted_trial))/time_step)+1;
         array1=[array1 ; col1 col2];
         % add analog values to array 2, which might have different number of columns.
         length2=size(array2,2);
         length_analog_values=length(analog_values);  
         if (length_analog_values < length2)
            analog_values(length2)=0;  % force expansion with zeros
            array2=[array2 ; analog_values] ;
         elseif (work_trial_list(unsorted_trial)==work_trial_list(1))   % first trial is simple assignment
            array2=analog_values;
         elseif (length_analog_values > length2)  % pad with zeros before appending new row
            array2=[array2 zeros(size(array2,1),length_analog_values-size(array2,2)) ; analog_values];
         end;
      end; % if ~empty(this_chan_trial)
   end; % analogmap
           

   
end;  % if

