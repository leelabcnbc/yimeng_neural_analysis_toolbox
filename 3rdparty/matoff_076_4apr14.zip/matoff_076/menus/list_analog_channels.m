function [list_of_channels]=list_analog_channels
%  Make a list of the analog channels in the data file. 
%  Rather crude.  Looks only at the very first trial of the data set
%  and assumes all other trials have the same set of analog channels.
%  Only looks for analog channels 1 to 15
%  
%  Outputs
%    list_of_channels      as ascii characters, -1 if no channels
%             
%  Globals modified
%%    none 
%
global cache_trials work_index work_udf
global analog_data_cache analog_cache_pointers
global work_fid
global analog_data_cache analog_cache_pointers
global error_fid warning_fid debug_fid
global errors warnings debugs

list_of_channels='';

% Call analog_read_record to fill up cache.
read_analog_record(work_fid.analog,[1],1);

if (size(analog_cache_pointers,1)==1) & (analog_cache_pointers==[0 0 0])
    if debugs
       fprintf(error_fid,'Debug [list_analog_channels]. No analog channels found. \n');
    end;
    list_of_channels=[ -1 ];
    return;
end;

if (size(analog_cache_pointers)==0)
    if warnings
       fprintf(error_fid,'Error [list_analog_channels]. Analog data expected, but none found.\n');
    end;
    list_of_channels=[ -1 ];
    return;
end;

starting=analog_cache_pointers(1,2);  % starting cache position for first trial
ending=analog_cache_pointers(1,3);  % ending cache position for first trial

for chan=1:15                     % look for each possible channel
    if find(analog_data_cache(1,starting:ending)==chan)
        list_of_channels=[list_of_channels ; num2str(chan)];  % add it
    end;
end;

if debugs
   fprintf(error_fid,'Debug [list_analog_channels]. \n');
   list_of_channels
end;

