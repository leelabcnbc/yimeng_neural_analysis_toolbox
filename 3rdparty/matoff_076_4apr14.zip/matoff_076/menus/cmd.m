function cmd
%
% cmd    Interpret PCOFF commands using root window
%        Calls parse_command and prints response.
%        Recognizes "matlab" command
%
%  Outputs
%    exit_type     instructions to restart
%  Globals changed
%    load_state, batch_state
%

global load_state batch_state
global fid fn
global environment

% infinite loop
load_state=0;  % no load file open
batch_state=0; % no batch file open
fprintf(1,'Entering command mode.  Use MAT to exit command mode.\n');
if environment.logging==1
   fprintf(fid.log,'Entering command mode.  Use MAT to exit command mode.\n');
end;
while(1)
   command=input('>','s');
   lc=lower(deblank(strjust(command)));  % all commands to lower case
   if environment.logging==1
      fprintf(fid.log,'>%s\n',command);
   end;
   if (strncmp(lc,'matlab',3))  % exit command
      fprintf(1,'Exiting command mode. Use CMD to return to the command mode.\n');
      if environment.logging==1
         fprintf(fid.log,'Exiting command mode. Use CMD to return to the command mode.\n');
      end;
      return;
   end;
   response=parse_command(command);
   if strcmp(response,'EXITMATOFF');   % quit request
      close all hidden;
      close all;
      clear;
      fprintf(1,'MatOFF is done.\n');
      return;
   else
      fprintf(1,'%s \n',response);
      if environment.logging==1
         fprintf(fid.log,'%s \n',response);
      end;
   end;
end;
