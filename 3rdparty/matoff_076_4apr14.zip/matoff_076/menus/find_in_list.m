function [found,remainder,no_match]=find_in_list(list,targets)
%
%  scan a list for target values
%
% Inputs
%   list       list of values to scan
%   targets    list of targets
% Outputs
%   found      indexes of 'list' that have target values, values are in order of "targets"
%   remainder  indexes of 'list' that do match any target values
%   no_match   values from 'targets' that did not have a match in 'list'
%
%   Notes:
%     1) 'found' and 'remainder' are indexes to 'list', whereas 'no_match'
%        has actual values from 'targets'
%     2) if each target occurs only once in 'list', then the order
%        of the targets is preserved.
%

if isempty(list)
   found=[];
   remainder=[];
   no_match=targets;
end;

if isempty(targets)
   found=[];
   remainder=list;
   no_match=[];
end;

found=[];
no_match=[];

for i=1:length(targets)
   f=find(list==targets(i));  % is this target in the list?
   if isempty(f)
      no_match=[no_match targets(i)] ;  % this target is not in list
   else
      found=[found f]; % in list
   end;
end;

remainder=yank_elements(found,length(list));