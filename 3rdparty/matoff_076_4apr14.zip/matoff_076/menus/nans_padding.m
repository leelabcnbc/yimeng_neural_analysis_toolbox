function [nans,c]=nans_padding(matrix_size,column_length)
%
%  Create a matrix of nans to properly add an arbitrary length column to
%  an existing matrix.  
%
% Inputs
%   matrix_size      size of existing matrix
%   column_length    length of new column for this matrix
% Outputs
%   nans             matrix of NaNs
%   c                case 1, 2, or 3 as follows:
%
%   c=-1   The column is empty.  A NaN column is provided in case a placeholder is needed.
%   c=0    The matrix is empty.  Matrix should be initialized by new column
%   c=1    The new column has the same number of rows as matrix. No NaNs are needed.
%             nans=[];
%   c=2    The new column is longer than the matrix.  Rows of NaNs must be added to the
%             existing matrix.  e.g.,  matrix=[matrix ; nans]
%   c=3    The new column is shorter than the matrix. The column must be padded with nans.
%             e.g., column=[column ; nans]
%   If column_length is zero, c=1 is returned.

global errors warnings debugs
global error_fid warning_fid debug_fid

nans=[];
c=1;
difference=matrix_size(1)-column_length;
if matrix_size(1)==0
   c=0;
   return;
end;
if (difference == 0) 
   return;
elseif difference < 0 
   c=2;    % new column is larger add rows to matrix
   nans=ones(abs(difference),matrix_size(2))* NaN;    
else % difference > 0     new column is shorter than columns of matrix, pad new column
   if column_length==0
      c=-1;  % empty column
   else
      c=3;    
   end;
   nans=ones(difference,1)* NaN;  
end;
