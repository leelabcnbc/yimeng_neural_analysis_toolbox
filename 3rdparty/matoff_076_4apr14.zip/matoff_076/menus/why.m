function [response]= why(command)
%   Evaluate most recent SHOW command and look for problems that
%   might have produced results different from the expectations
%   of the user.
%
%  Input
%    command    
%  Outputs
%    response
%
%   
% Everything there is to know
global plot_number last_command taint
global x_at_zero auto_update layouts
global spike_counts work_index work_udef
global load_state batch_state call_state fileerror
global break_state
global current_layout environment walk walk_speed walk_count
global set_process
global RESCALE_TIME 
global bell_sound bell_sample_rate start_time
global fid fn
global current_text_line 
global error_fid warning_fid debug_fid
global errors warnings debugs quietly
global history

response=' ';

% Is there a file open?
fn=get(findobj('Tag','filename'),'String');
if isempty(deblank(fn))
   fprintf('There is no file open.\n');
   return;
end

file_name=filepath(get(findobj('Tag','filename'),'String'),environment.datapath);
fprintf('The open file is >%s<\n',file_name);
number_of_units=length(work_udef);
if number_of_units==0
   fprintf('This file has no units.\n');
   return;
end

% Is there a valid unit selected?
if environment.unitfound == 0
   fprintf('The unit name you requested was not found.\nThe available units are:\n');
   for unit_number=1:number_of_units
      fprintf('%-12s\n',work_udef(unit_number).name);
   end
   return;
end

unit_number=get(findobj('Tag','unit'),'Value');
trials_list=work_udef(unit_number).trials;
number_of_spikes=0;
current_pulse_channel=get(findobj('Tag','spikechannelmenu'),'Value')-1;  % spike channels start with 0
pulses_in_current_pulse_channel=str2num(get(findobj('Tag','pulsesfound'),'String'));
pulsechannel_counts=list_pulse_counts;

% can data be found in the file?
if length(work_index)==0
   fprintf('Data file appears to be empty. You can try reloading the file by using the FILE command\n');
else
   for t=trials_list 
      number_of_spikes=number_of_spikes + work_index(t).pulse_records - 1;
   end
   fprintf('  The default pulse channel is %d\n  The file has a total of %d spikes\n', ...
        work_udef(unit_number).channel, number_of_spikes);
   fprintf('  This unit has %d trials\n  The selected pulse channel is %d\n', ...
        length(trials_list), current_pulse_channel);

   fprintf('  Available pulse channels and the number of pulses in the matching sequence\n');
   for pc=1:size(pulsechannel_counts,1);
      fprintf('   %4d     %5d\n',pulsechannel_counts(pc,1),pulsechannel_counts(pc,2));
   end
end


% Were a reasonable number of trials found in search?
if length(trials_list) < 4
   fprintf ('This unit does not have very many trials.\n');
elseif number_of_spikes < 50
   fprintf('This unit does not seem to have very many spikes.\n');
elseif pulses_in_current_pulse_channel < 20
   fprintf('The selected pulse channel does not seem to have very many spikes\n');
end


% look at sequence, global ignore, center, mark events

% get globalignore list
glo_string=get(findobj('Tag','globalignore'),'String');
glo_list=expand_range_list(glo_string);


% locate each group of codes in the sequence
seq_string=get(findobj('Tag','sequence'),'String');
seq_string=strrep(seq_string,'[','');   % loose left brackets in existing string
seq_codes=[];
all_seq_codes=[];
group_number=0;
while ~isempty(seq_string)
   [group,seq_string]=strtok(seq_string,']');  % right bracket defines a group
   if isempty(group)
      break;
   end
   group_number=group_number+1;    % count groups
   seq_codes(group_number).codes=expand_range_list(group);    % codes by group
   all_seq_codes=[all_seq_codes seq_codes(group_number).codes];  % every code
end

if isempty(all_seq_codes)
   fprintf('Non-numeric or empty SEQUENCE.\n');
   return;
end

% Look for sequence event codes in the global ignore list
all_seq_codes=sort(all_seq_codes);
u=[1 diff(all_seq_codes)];  % squeeze out duplicates
all_seq_codes=all_seq_codes(find(u>0));

for i=all_seq_codes(1:end)
   if ~isempty(find(glo_list==i))
      fprintf('Event %d is in both the SEQUENCE and the GLOBAL IGNORE list.\n',i);
   end
end


% check for valid center group
[dummy,center_group,valid]=check_string_value(get(findobj('Tag','center'),'String'),1,500);
if ~valid
   fprintf ('Center value is not a number or is out of range. Valid values are from 1 to 500\n') ;
end
if (center_group > 99) && (center_group > group_number)
   fprintf ('Your CENTER points to a History Class Value. Are you sure that is what you want?\n');
else
   if center_group > group_number
      fprintf ('CENTER is too large. Remember, CENTER must be a group number in the sequence, not an event code.\n');
   end
end   


% check for valid mark group
[dummy,mark_group,valid]=check_string_value(get(findobj('Tag','mark'),'String'),1,500);
if ~valid
   fprintf ('Mark value is not a number or is out of range. Valid values are from 1 to 500\n') ;
end
if mark_group > group_number
   fprintf ('MARK is too large. Remember, MARK must be a group number in the sequence, not an event code.\n');
end   




