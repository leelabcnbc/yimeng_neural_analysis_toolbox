function [status]=remove_class(trial,class)
%  Remove a class and class value for the requested trial.  Values need not exist.
%  (Special user function)
% 
%  Inputs
%    trial        trial for history change
%    class        class to remove
%
%    history.class            class 
%           .trial_list       = [] string array of trial numbers that belong in this class, sorted 
%           .values           = [] array of matching class values for each trial
%  Outputs
%    status              1 = successful run,  negative value is an error code
%
global history
global uh_current_trial uh_last_trial    % to support special user functions
global error_fid warning_fid debug_fid
global errors warnings debugs

if debugs
   fprintf(debug_fid,'Debug [remove_class]. Removing class %d assignment for trial %d\n',class,trial);
end

% find the class in the history.
hl=length(history);
cindex=0;   % may not be in history
for c=1:hl
  if history(c).class==class
     cindex=c;
     break;
  end
end

if cindex == 0      % class does not exist
   if debugs
      fprintf(debug_fid,'Debug [assign_class_value]. Class not in the history.\n');
   end
   status=1;
   return;
end

t_list=expand_range_list(history(cindex).trial_list);  % convert string into list
if isempty(find(t_list==trial))               % does this trial have this class value?
   if debugs
      fprintf(debug_fid,'Debug [assign_class_value]. This trial was already not assigned to this class.\n');
   end
   status=1;
   return;
else
   lower=find(t_list < trial);
   upper=find(t_list > trial);
   t_list=[t_list(lower) t_list(upper)];         % omit this trial
   history(cindex).trial=string_list(t_list);    % convert to a string list
   history(cindex).values=[history(cindex).values(lower)  history(cindex).values(upper)];  % omit the same trial
   status=1;
   return;
end