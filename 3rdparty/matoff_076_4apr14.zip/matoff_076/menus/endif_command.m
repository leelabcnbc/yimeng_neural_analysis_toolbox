function[return_value]=endif_command(condition)
%
%
%  Inputs
%    condition     Name of condition to test
%
%  Outputs
%    return_value    0 = false    1 = true
%

global work_fid work_udef environment
global error_fid warning_fid debug_fid
global errors warnings debugs

condition=lower(deblank(strjust(condition,'left')));  % to lower case

if isempty(condition)
   return_value=0;
   return;
end;

return_value=1;        % assume the condition is true
if strncmp(condition,'noanalog',8)
   if debugs
      fprintf(debug_fid,'Debug [endif_command]. Checking for analog data in this unit\n');
   end;
   chan=get(findobj('Tag','xchannelmenu'),'Value')-1;   % first analog
   if chan == 0
      if warnings
         fprintf(warning_fid,'[endif_command]. Analog is off. Terminating protocol file.\n');
      end;
      return;  % No analog data         
   end;
   unit_number=get(findobj('Tag','unit'),'Value'); 
   if length(work_udef(unit_number).trials) > 0
      work_trial=work_udef(unit_number).trials(1);  
   else
      if warnings
         fprintf(warning_fid,'[endif_command]. No trials at all in this unit. Terminating protocol file.\n');
      end;
      return;  % no data at all
   end;
   analog_value=read_analog_record(work_fid.analog,work_trial,chan);  % fetch one analog value
   if isempty(analog_value)
      if warnings
         fprintf(warning_fid,'[endif_command]. No analog data found. Terminating protocol file.\n');
      end;
      return;  % No analog data
   else
      if debugs
         fprintf(debug_fid,'Debug [endif_command]. An analog value was found. NOANALOG is false.\n');
      end;
      return_value=0;   % found analog
      return;
   end;
end;  % NOANALOG condition


if strncmp(condition,'nounit',6)
   if environment.unitfound
      if debugs
         fprintf(debug_fid,'Debug [endif_command]. NOUNIT is FALSE\n');
      end;
      return_value=0;   % last unit was found, return false
   else
      if warnings
         fprintf(warning_fid,'[endif_command]. Last requested unit was not found. Terminating protocol file.\n');
      end;
      return_value=1;   % no unit found, return true
   end;
end;  % NOUNIT condition
