function [full_name]=filepath(file_name,environment_variable)
%
% filepath  returns full file path for a file name.
%           Uses the typical DOS rule set for paths
% 
%  Inputs
%    file_name      root name of file
%    environment    value of relevent environment variable
%  Outputs
%    full_name      Returns '<' if no valid file name can be created
%
global environment
global error_fid warning_fid debug_fid
global errors warnings debugs
%
if isempty(file_name)
   if debugs     % this is debug level, not warning level. Normally exits silently.
      fprintf(debug_fid,'Debug [filepath]. Empty file name.\n');
   end;
   full_name='<';   % use illegal dos name to indicate no name;
   return;   
end;

[path,name,ext]=fileparts(file_name);
if isempty(name)
   full_name='<';   % use illegal dos name to indicate no name;
   return; 
end;

if isempty(path)
   if ~isempty(environment_variable)  % was path defined in environment?
      path=environment_variable;
   elseif ~isempty(environment.defaultpath) % use default path if it exists.
      path=environment.defaultpath;
   else
      path='';  % environmental paths are empty
   end;   
end;
full_name=fullfile(path,[name ext]);
      