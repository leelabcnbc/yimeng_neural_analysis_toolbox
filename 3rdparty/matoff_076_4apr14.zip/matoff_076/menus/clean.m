global load_fid batch_fid  call_fid meta_fid
global fid fn

fid.histogram=-1; fid.mwu=-1; fid.plot=-1; fid.epochstats=-1;
fid.segmentstats=-1; fid.sortvalues=-1; fid.asciifile=-1;

open_files=fopen('all')   % no ";"   announce what files are open
for jopen=open_files
   fclose(jopen);
end
load_fid=-1;  batch_fid=-1;  call_fid=-1;  meta_fid=-1;
