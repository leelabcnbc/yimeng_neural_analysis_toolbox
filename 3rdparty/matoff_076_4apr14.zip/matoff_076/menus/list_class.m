function [list]=list_class(class)
%  Return a 2 row array of classes class values for all trials.  
%  (Special user function)
% 
%  Inputs
%    class        class to list
%  Outputs
%    list        row 1   trial numbers
%                row 2   matching class values    
%   
%    history.class            class 
%           .trial_list       = [] string array of trial numbers that belong in this class, sorted 
%           .values           = [] array of matching class values for each trial
%
global history
global uh_current_trial uh_last_trial    % to support special user functions
global error_fid warning_fid debug_fid
global errors warnings debugs

if debugs
   fprintf(debug_fid,'Debug [list_class]. Finding all class values for all trials in class %d\n',class);
end;

% find the class in the history.
hl=length(history);
list=[];
for c=1:hl
  if history(c).class==class
     list=[expand_range_list(history(c).trial_list) ; history(c).values];
     break;
  end;
end;
