function layout_menu_button(current_figure,requested_figure)
%  choose which layout menu to present to user
%  This is executed by a callback function
%
%  Inputs
%     current_figure    layout menu that is placing the call
%     requested_figure  layout menu that is being requested

if current_figure ~= requested_figure
   menu=[findobj('Tag','layout_menu') findobj('Tag','layout_menu2') ...
         findobj('Tag','layout_menu3') findobj('Tag','layout_menu_text')];
   
   set(menu(current_figure),'Visible','off');
   position=get(menu(current_figure),'Position');

   % figure 4 (text menu) has its own positioning
   if (current_figure == 4) | (requested_figure == 4)
      set(menu(requested_figure),'Visible','on');
   else
      set(menu(requested_figure),'Visible','on'); 
      set(menu(requested_figure),'Position',position);
   end;

end;

   