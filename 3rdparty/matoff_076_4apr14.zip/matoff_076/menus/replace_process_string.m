function [new_string]= replace_process_string(string,element_number,replacement) 
%
%  Change one element of a set process string.  String format 
%  is: 'noshow:nokeep:noappend:filename'
% 
%  Inputs
%     string           existing string
%     element_number   1= (no)show  2= (no)keep  3= (no)append  4= filename
%     replacement      new element value
%

% disassemble existing processing string
elements={'','','',''};
[elements{1},r]=strtok(string,':');
[elements{2},r]=strtok(r,':');
[elements{3},r]=strtok(r,':');
elements{4}=r(2:end);  % skip last ":" might produce null string

% replace appropriate element
elements{element_number}=replacement;

% rebuild string
new_string=[elements{1} ':' elements{2} ':' elements{3} ':' elements{4}];
