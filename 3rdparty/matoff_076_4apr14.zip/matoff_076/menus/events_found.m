function [event_tally]=events_found
%
% Create a list of each event sequence that matched the search criteria
% and tally how many times that seqence matched. 
%
% Inputs
%    none
% Outputs
%    event tally              for each matching sequence, lists the number of matches, then the sequence
% Globals changed
%    none
%
global event_codes 
global error_fid warning_fid debug_fid
global errors warnings debugs


event_tally=[];
if isempty(event_codes)
   return;
end;

codes=[];  % these combine later to make event_tally
count=[];

% look at each matching event sequence from last scan
for row=1:size(event_codes,1)
   % see if we have this sequence yet
   nomatch=1;
   for arow=1:size(codes,1)
      if event_codes(row,:)==codes(arow,:)
         nomatch=0;                  % we have this sequence
         count(arow)=count(arow)+1;  % keep count
      end;
   end;
   if nomatch                               % new sequence
      codes=[codes ; event_codes(row,:)];   % add sequence
      count=[count ; 1];                    % one occurance so far
   end;
end;

% build output variable
event_tally=[count  codes];