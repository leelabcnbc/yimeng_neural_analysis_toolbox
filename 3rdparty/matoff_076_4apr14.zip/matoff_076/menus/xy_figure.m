function [handles]=xy_figure(do_not_move)

%  Set up a new figure for plots that includes a window for displaying analog X-Y data.
%  Figure must be created before entering this routine.  
%  The figure will have 6 windows: 
%    main window     for data measured across the time scale (e.g. rasters, analog)
%    left window     for XY plots
%    right window    for histogram or RIP scale
%    bottom window   title
%    plot area window  for placing text relative to current plot
%    super window      for placing text relative to entire page
%
%  Inputs
%    do_not_move     if 0, move figure to the standard location on the screen.
%  Outputs
%    handles         handles to the 6 "windows" of the display
%
global environment
global error_fid warning_fid debug_fid
global errors warnings debugs
 
% constants      [left bottom width height]
std_figure_location=[.4 .4 .5 .5];



% defaults for 1 graph per plot
super_rect=[.01 .01 .99 .99];   % covers the entire page
plot_rect=[.01 .01 .99 .99];   % covers entire plot
xy_overlap=get(findobj('Tag','xy_overlap_on_off'),'Value');
if xy_overlap==0          % XY plots in a separate window on the left
   main_rect=[.225 .1 .7 .9];     % time scale data (rasters, histogram)
   left_rect=[.0 .1 .2 .9];       % xy plot
   right_rect=[.94 .1 .06 .9];    % histogram scale
   bottom_rect=[.0 .0 1 .08];     % space for title
else
   main_rect=[.05 .1 .8 .8];   
   left_rect=[.05 .1 .8 .8];   
   right_rect=[.85 .2 .025 .8];    % histogram scale
   bottom_rect=[.05 .0 .8 .08];     % space for title
end;
right_rect=[.85 .2 .025 .8];    % histogram scale
bottom_rect=[.05 .0 .8 .08];     % space for title

background_color='w';
hide=background_color;


plots_per_page=str2num(get(findobj('Tag','subplot_total'),'String'));
subplot_number=str2num(get(findobj('Tag','subplot_number'),'String'));

if debugs
   fprintf(debug_fid,'Debug [raster_figure]. Aligning plot number %d of %d plots per page\n',subplot_number,plots_per_page);
end;

% number of plots per page determines the size of each element
% plots_per_page    page positions
%        1              1
%        2              2
%        3,4            4
%        5,6,7,8        8
%        9,10,11,12    12
%        13-24         24
%        25-48         48
%        49-72         72


ppp_chart=[1 2 4 4 8*ones(1,4) 12*ones(1,4) 24*ones(1,12) 48*ones(1,24) 72*ones(1,48)];
ppp=ppp_chart(plots_per_page);

% the subplot number determines the location of each element
%
x_offset=0;  % defaults
y_offset=0;

switch ppp
   case 1  % one plot fills whole page
           %          1
           %
      right_shift= -0.04;  % a left shift
      main_rect(1)=main_rect(1)-right_shift;
      plot_rect(1)=plot_rect(1)-right_shift;
      left_rect(1)=left_rect(1)-right_shift;
      right_rect(1)=right_rect(1)-right_shift;
      bottom_rect(1)=bottom_rect(1)-right_shift;

   case 2   % side-by-side plots
            %       1         2
            %  
      main_rect(4)=main_rect(4)/2;
      plot_rect(4)=plot_rect(4)/2;
      left_rect(4)=left_rect(4)/2;
      right_rect(4)=right_rect(4)/2;
      bottom_rect(4)=bottom_rect(4)/2;
      if subplot_number==1
         y_offset=.5;
      else  % subplot_number==2
         %
      end;
   case 4   % two rows of side-by-side plots
            %      1         2
            %      3         4
            %
      main_rect(3)=main_rect(3)/2;
      main_rect(4)=main_rect(4)/2;
      plot_rect(3)=plot_rect(3)/2;
      plot_rect(4)=plot_rect(4)/2;
      left_rect(3)=left_rect(3)/2;
      left_rect(4)=left_rect(4)/2;
      right_rect(3)=right_rect(3)/2;
      right_rect(4)=right_rect(4)/2;
      bottom_rect(3)=bottom_rect(3)/2;
      bottom_rect(4)=bottom_rect(4)/2;
      if subplot_number < 3
         y_offset=.5;
      end;
      if (subplot_number==2) | (subplot_number==4)
         x_offset=.5;
      end;
   case 8   % 2 rows, 4 plots per row
            %    1    2    3     4
            %    5    6    7     8
            %
      main_rect(3)=main_rect(3)/4;
      main_rect(4)=main_rect(4)/2;
      plot_rect(3)=plot_rect(3)/4;
      plot_rect(4)=plot_rect(4)/2;
      left_rect(3)=left_rect(3)/4;
      left_rect(4)=left_rect(4)/2;
      right_rect(3)=right_rect(3)/4;
      right_rect(4)=right_rect(4)/2;
      bottom_rect(3)=bottom_rect(3)/4;
      bottom_rect(4)=bottom_rect(4)/2;
      
      % shift left slightly
      right_shift=.03;
      main_rect(1)=main_rect(1)-right_shift;
      plot_rect(1)=plot_rect(1)-right_shift;
      left_rect(1)=left_rect(1)-right_shift;
      right_rect(1)=right_rect(1)-right_shift;
      bottom_rect(1)=bottom_rect(1)-right_shift;
      
      if subplot_number < 5
         y_offset=.5;
      end;
      if (subplot_number==2) | (subplot_number==6)
         x_offset=.25;
      elseif (subplot_number==3) | (subplot_number==7)
         x_offset=.5;
      elseif (subplot_number==4) | (subplot_number==8)
         x_offset=.75;
      end;
   case 12  % 3 rows of 4 plots
            %   1    2    3    4
            %   5    6    7    8
            %   9   10   11   12
            %
      main_rect(3)=main_rect(3)/4;
      main_rect(4)=main_rect(4)/3;
      plot_rect(3)=plot_rect(3)/4;
      plot_rect(4)=plot_rect(4)/3;
      left_rect(3)=left_rect(3)/4;
      left_rect(4)=left_rect(4)/3;
      right_rect(3)=right_rect(3)/4;
      right_rect(4)=right_rect(4)/3;
      bottom_rect(3)=bottom_rect(3)/4;
      bottom_rect(4)=bottom_rect(4)/3;   
      
            % shift left slightly
      right_shift=.03;
      main_rect(1)=main_rect(1)-right_shift;
      plot_rect(1)=plot_rect(1)-right_shift;
      left_rect(1)=left_rect(1)-right_shift;
      right_rect(1)=right_rect(1)-right_shift;
      bottom_rect(1)=bottom_rect(1)-right_shift;
      
      if (subplot_number >= 1) & (subplot_number <= 4)
         y_offset=.6;
      elseif (subplot_number >= 5) & (subplot_number <= 8)
         y_offset=.3;
      elseif (subplot_number >= 9) & (subplot_number <= 12)
         y_offset=.0;
      end;
      if (subplot_number==2) | (subplot_number==6) | (subplot_number==10)
         x_offset=.25;
      elseif (subplot_number==3) | (subplot_number==7) |(subplot_number==11)
         x_offset=.5;
      elseif (subplot_number==4) | (subplot_number==8) | (subplot_number==12)
         x_offset=.75;
      end;   
      
   case 24    % 4 rows of 6 plots
              %   1   2   3   4   5   6
              %   7   8   9  10  11  12
              %  13  14  15  16  17  18
              %  19  20  21  22  23  24
              %
      main_rect(3)=main_rect(3)/6;
      main_rect(4)=main_rect(4)/4;
      plot_rect(3)=plot_rect(3)/6;
      plot_rect(4)=plot_rect(4)/4;
      left_rect(3)=left_rect(3)/6;
      left_rect(4)=left_rect(4)/4;
      right_rect(3)=right_rect(3)/6;
      right_rect(4)=right_rect(4)/4;
      bottom_rect(3)=bottom_rect(3)/6;
      bottom_rect(4)=bottom_rect(4)/4;   
      
            % shift left slightly
      right_shift=.02;
      main_rect(1)=main_rect(1)-right_shift;
      plot_rect(1)=plot_rect(1)-right_shift;
      left_rect(1)=left_rect(1)-right_shift;
      right_rect(1)=right_rect(1)-right_shift;
      bottom_rect(1)=bottom_rect(1)-right_shift;
      
      if (subplot_number >= 1) & (subplot_number <=6)
         y_offset=.75;
      elseif (subplot_number >= 7) & (subplot_number <=12)
         y_offset=.5;
      elseif (subplot_number >= 13) & (subplot_number <=18)
         y_offset=.25;
      elseif (subplot_number >= 19) & (subplot_number <=24)
         y_offset=.0;
      end;
      if (subplot_number==2) | (subplot_number==8) | (subplot_number==14) | (subplot_number==20)
         x_offset=.17;
      elseif (subplot_number==3) | (subplot_number==9) |(subplot_number==15)| (subplot_number==21)
         x_offset=.33;
      elseif (subplot_number==4) | (subplot_number==10) | (subplot_number==16)| (subplot_number==22)
         x_offset=.5;
      elseif (subplot_number==5) | (subplot_number==11) | (subplot_number==17)| (subplot_number==23)
         x_offset=.66;
      elseif (subplot_number==6) | (subplot_number==12) | (subplot_number==18)| (subplot_number==24)
         x_offset=.83;         
      end; 
  case 48    % 6 rows of 8 plots
              %   1   2   3   4   5   6   7   8
              %   9  10  11  12  13  14  15  16
              %  17  18  19  20  21  22  23  24
              %  25  26  27  28  29  30  31  32
              %  33  34  35  36  37  38  39  40
              %  41  42  43  44  45  46  47  48
              %
      main_rect(3)=main_rect(3)/8;
      main_rect(4)=main_rect(4)/6;
      plot_rect(3)=plot_rect(3)/8;
      plot_rect(4)=plot_rect(4)/6;
      left_rect(3)=left_rect(3)/8;
      left_rect(4)=left_rect(4)/6;
      right_rect(3)=right_rect(3)/8;
      right_rect(4)=right_rect(4)/6;
      bottom_rect(3)=bottom_rect(3)/8;
      bottom_rect(4)=bottom_rect(4)/6;   
      
            % shift left slightly
      right_shift=.02;
      main_rect(1)=main_rect(1)-right_shift;
      plot_rect(1)=plot_rect(1)-right_shift;
      left_rect(1)=left_rect(1)-right_shift;
      right_rect(1)=right_rect(1)-right_shift;
      bottom_rect(1)=bottom_rect(1)-right_shift;
      
      if (subplot_number >= 1) & (subplot_number <=8)
         y_offset=.833;
      elseif (subplot_number >= 9) & (subplot_number <=16)
         y_offset=.667;
      elseif (subplot_number >= 17) & (subplot_number <=24)
         y_offset=.5;
      elseif (subplot_number >= 25) & (subplot_number <=32)
         y_offset=.333;
      elseif (subplot_number >= 33) & (subplot_number <=40)
         y_offset=.167;
      elseif (subplot_number >= 41) & (subplot_number <=48)
         y_offset=.0;
      end;
      if (subplot_number==2)|(subplot_number==10)|(subplot_number==18)|(subplot_number==26)|(subplot_number==34)|(subplot_number==42)
         x_offset=.125;
      elseif (subplot_number==3)|(subplot_number==11)|(subplot_number==19)|(subplot_number==27)|(subplot_number==35)|(subplot_number==43)
         x_offset=.25;
      elseif (subplot_number==4)|(subplot_number==12)|(subplot_number==20)|(subplot_number==28)|(subplot_number==36)|(subplot_number==44)
         x_offset=.375;
      elseif (subplot_number==5)|(subplot_number==13)|(subplot_number==21)|(subplot_number==29)|(subplot_number==37)|(subplot_number==45)
         x_offset=.5;
      elseif (subplot_number==6)|(subplot_number==14)|(subplot_number==22)|(subplot_number==30)|(subplot_number==38)|(subplot_number==46)
         x_offset=.625;   
      elseif (subplot_number==7)|(subplot_number==15)|(subplot_number==23)|(subplot_number==31)|(subplot_number==39)|(subplot_number==47)
         x_offset=.75;
      elseif (subplot_number==8)|(subplot_number==16)|(subplot_number==24)|(subplot_number==32)|(subplot_number==40)|(subplot_number==48)
         x_offset=.875;   
      
      end; 

   case 72    % 9 rows of 8 plots
              %   1   2   3   4   5   6   7   8
              %   9  10  11  12  13  14  15  16
              %  17  18  19  20  21  22  23  24
              %  25  26  27  28  29  30  31  32
              %  33  34  35  36  37  38  39  40
              %  41  42  43  44  45  46  47  48
              %  49  50  51  52  53  54  55  56
              %  57  58  59  60  61  62  63  64 
              %  65  66  67  68  69  70  71  72
              %
      main_rect(3)=main_rect(3)/8;
      main_rect(4)=main_rect(4)/6;
      plot_rect(3)=plot_rect(3)/8;
      plot_rect(4)=plot_rect(4)/6;
      left_rect(3)=left_rect(3)/8;
      left_rect(4)=left_rect(4)/6;
      right_rect(3)=right_rect(3)/8;
      right_rect(4)=right_rect(4)/6;
      bottom_rect(3)=bottom_rect(3)/8;
      bottom_rect(4)=bottom_rect(4)/6;   
      
            % shift left slightly
      right_shift=.02;
      main_rect(1)=main_rect(1)-right_shift;
      plot_rect(1)=plot_rect(1)-right_shift;
      left_rect(1)=left_rect(1)-right_shift;
      right_rect(1)=right_rect(1)-right_shift;
      bottom_rect(1)=bottom_rect(1)-right_shift;
      
      if (subplot_number >= 1) & (subplot_number <=8)        % row 1
         y_offset=.888;
      elseif (subplot_number >= 9) & (subplot_number <=16)   % row 2
         y_offset=.777;
      elseif (subplot_number >= 17) & (subplot_number <=24)  % row 3
         y_offset=.666;
      elseif (subplot_number >= 25) & (subplot_number <=32)  % row 4
         y_offset=.555;
      elseif (subplot_number >= 33) & (subplot_number <=40)  % row 5
         y_offset=.444;
      elseif (subplot_number >= 41) & (subplot_number <=48)  % row 6
         y_offset=.333;
      elseif (subplot_number >= 49) & (subplot_number <=56)  % row 7
         y_offset=.222;
      elseif (subplot_number >= 57) & (subplot_number <=64)  % row 8
         y_offset=.111;
      elseif (subplot_number >= 65) & (subplot_number <=72)  % row 9
         y_offset=.0;

      end;
      if (subplot_number==2)|(subplot_number==10)|(subplot_number==18)|(subplot_number==26)|(subplot_number==34)|(subplot_number==42)|(subplot_number==50)|(subplot_number==58)|(subplot_number==66)
         x_offset=.125;  % col 2
      elseif (subplot_number==3)|(subplot_number==11)|(subplot_number==19)|(subplot_number==27)|(subplot_number==35)|(subplot_number==43)|(subplot_number==51)|(subplot_number==59)|(subplot_number==67)
         x_offset=.25;   % col 3
      elseif (subplot_number==4)|(subplot_number==12)|(subplot_number==20)|(subplot_number==28)|(subplot_number==36)|(subplot_number==44)|(subplot_number==52)|(subplot_number==60)|(subplot_number==68)
         x_offset=.375;  % col 4
      elseif (subplot_number==5)|(subplot_number==13)|(subplot_number==21)|(subplot_number==29)|(subplot_number==37)|(subplot_number==45)|(subplot_number==53)|(subplot_number==61)|(subplot_number==69)
         x_offset=.5;    % col 5
      elseif (subplot_number==6)|(subplot_number==14)|(subplot_number==22)|(subplot_number==30)|(subplot_number==38)|(subplot_number==46)|(subplot_number==54)|(subplot_number==62)|(subplot_number==70)
         x_offset=.625;  % col 6
      elseif (subplot_number==7)|(subplot_number==15)|(subplot_number==23)|(subplot_number==31)|(subplot_number==39)|(subplot_number==47)|(subplot_number==55)|(subplot_number==63)|(subplot_number==71)
         x_offset=.75;   % col 7
      elseif (subplot_number==8)|(subplot_number==16)|(subplot_number==24)|(subplot_number==32)|(subplot_number==40)|(subplot_number==48)|(subplot_number==56)|(subplot_number==64)|(subplot_number==72)
         x_offset=.875;  % col 8
      
      end; 


   otherwise
      if errors
         fprintf(error_fid,'Error [raster_figure]. Invalid number of plots per page\n');
      end;
end; % switch
   
main_rect(1)=main_rect(1)+ x_offset;
main_rect(2)=main_rect(2)+ y_offset;
plot_rect(1)=plot_rect(1)+ x_offset;
plot_rect(2)=plot_rect(2)+ y_offset;
left_rect(1)=left_rect(1)+ x_offset;
left_rect(2)=left_rect(2)+ y_offset;
right_rect(1)=right_rect(1)+ x_offset;
right_rect(2)=right_rect(2)+ y_offset;
bottom_rect(1)=bottom_rect(1)+ x_offset;
bottom_rect(2)=bottom_rect(2)+ y_offset;   



if ppp==1
   clf;
end;

% assume the figure has been made and we are pointing at it
if (do_not_move)
   set(gcf,'Color',background_color);
else
   set(gcf,'Position',std_figure_location,'Color',background_color);
end;

% make main axes, make Y axis invisible by assigning white as the color
main_handle=axes('Position',main_rect,'YColor',hide,'TickDir','out');
% make other axes, no visible axis lines
left_handle=axes('Position',left_rect,'YColor',hide,'XColor',hide);
right_handle=axes('Position',right_rect,'YColor',hide,'XColor',hide);
bottom_handle=axes('Position',bottom_rect,'YColor',hide,'XColor',hide);
super_handle=axes('Position',super_rect,'YColor',hide,'XColor',hide);
plot_handle=axes('Position',main_rect,'YColor',hide,'TickDir','out');

handles=[main_handle left_handle right_handle bottom_handle super_handle plot_handle];