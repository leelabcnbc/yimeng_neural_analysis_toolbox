function [response]=metafile(rcmd,params)
%
%   execute a metafile
% Inputs
%   rcmd       command
%   params     parameters for command
% Outputs
%   response   error message, if any
% 
global environment pcoff_argument
global error_fid warning_fid debug_fid
global errors warnings debugs
global meta_fid

[dummy,extension]=strtok(rcmd,'.');  % this will fail if directory name has a "." suffix
if isempty(extension)
   rcmd=[rcmd '.met'];
end;

if meta_fid > 0
   if errors 
      fprintf(error_fid,'Error [metafile]. Two metafiles open at the same time.  Metafiles cannot call metafiles.  \n');
      fprintf(error_fid,'Error [metafile]. Perhaps you have misspelled a command (which is usually interpreted as a metafile). \n');
      fprintf(error_fid,'Error [metafile]. Could also be a file left open from previous failure.  Closing all metafiles now.... \n');
   end;
   fclose(meta_fid);
   meta_fid=-1;
   response=[rcmd '  error trying to execute this metafile'];
   return;
end;

% prepend the path for this metafile
mfile_name=filepath(rcmd,environment.metapath); 
if debugs
   fprintf(debug_fid,'Debug [metafile]. Opening metafile %s \n',mfile_name);
end;
meta_fid=fopen(mfile_name,'rt');  % see if the metafile exists
if meta_fid < 0  % open failure
   response=[rcmd '   no such command or metafile'];
   return;
end;
if debugs
   fprintf(debug_fid,'as file handle %d \n',meta_fid);
end;   
response='';   
  
% determine the replaceable parameters  
P0=upper(rcmd);
[P1,rem]=strtok(params);
[P2,rem]=strtok(rem);
[P3,rem]=strtok(rem);
[P4,rem]=strtok(rem);
[P5,rem]=strtok(rem);
[P6,rem]=strtok(rem);
[P7,rem]=strtok(rem);
[P8,rem]=strtok(rem);
[P9,rem]=strtok(rem);
[PA,rem]=strtok(rem);
[PB,rem]=strtok(rem);
[PC,rem]=strtok(rem);
[PD,rem]=strtok(rem);
[PE,rem]=strtok(rem);
[PF,rem]=strtok(rem);
[PG,rem]=strtok(rem);
[PH,rem]=strtok(rem);
[PI,rem]=strtok(rem);
[PJ,rem]=strtok(rem);
[PK,rem]=strtok(rem);


if debugs
   fprintf(debug_fid,'Debug [metafile]. Replacement parameters for metafile %s:\n',rcmd);
   fprintf(debug_fid,'P1=%s P2=%s P3=%s P4=%s P5=%s P6=%s P7=%s P8=%s P9=%s \n',...
      P1,P2,P3,P4,P5,P6,P7,P8,P9);
   fprintf(debug_fid,'PA=%s PB=%s PC=%s PD=%s PE=%s PF=%s PG=%s PH=%s PI=%s PJ=%s PK=%s \n',...
      PA,PB,PC,PD,PE,PF,PG,PH,PI,PJ,PK);



   fprintf(debug_fid,'\n');  % must be on a separate line in case Pn is empty
end;

rcmd_in_loop=rcmd;   % detect a change in metafile name caused by illegal nesting of metafiles
while ~feof(meta_fid)
   rcmd=fgetl(meta_fid);  % fetch command from meta file
   c=deblank(rcmd);  % check for control commands
   [c,params]=strtok(c);  % separate command name from any parameters
   c=lower(deblank(strjust(c)));  % command to lower case
   next=0;  % use like Perl "next" (C language "continue")
   if strncmp(c,';',1)  % comment
      if debugs
         fprintf(debug_fid,'Debug [metafile]. Comment: %s\n',c);
      end;
      next=1;  % next
   elseif strncmp(c,'end',3)  % END command only closes the current metafile
      if debugs
         fprintf(debug_fid,'Debug [metafile]. END command encountered\n',c);
      end;
      next=1;  % next
   elseif strncmp(c,'break',5)
      if debugs
         fprintf(debug_fid,'Debug [metafile]. BREAK command encountered\n',c);
      end;
      next=1;  % next
   end;
   if ~next
      % metafile replacement variables
      if ~isempty(P0)
         rcmd=strrep(rcmd,[environment.metachar1 '0'],P0);
      end;
      if ~isempty(P1) 
         rcmd=strrep(rcmd,[environment.metachar1 '1'],P1);
      end;
      if ~isempty(P2) 
         rcmd=strrep(rcmd,[environment.metachar1 '2'],P2);
      end;
      if ~isempty(P3) 
         rcmd=strrep(rcmd,[environment.metachar1 '3'],P3);
      end;   
      if ~isempty(P4)
         rcmd=strrep(rcmd,[environment.metachar1 '4'],P4);
      end;
      if ~isempty(P5) 
         rcmd=strrep(rcmd,[environment.metachar1 '5'],P5);
      end;
      if ~isempty(P6)
         rcmd=strrep(rcmd,[environment.metachar1 '6'],P6); 
      end;
      if ~isempty(P7)
         rcmd=strrep(rcmd,[environment.metachar1 '7'],P7);
      end;
      if ~isempty(P8) 
         rcmd=strrep(rcmd,[environment.metachar1 '8'],P8);
      end;
      if ~isempty(P9) 
         rcmd=strrep(rcmd,[environment.metachar1 '9'],P9);  
      end;


      if ~isempty(PA)
         rcmd=strrep(rcmd,[environment.metachar1 'A'],PA);
      end;
      if ~isempty(PB) 
         rcmd=strrep(rcmd,[environment.metachar1 'B'],PB);
      end;
      if ~isempty(PC) 
         rcmd=strrep(rcmd,[environment.metachar1 'C'],PC);
      end;
      if ~isempty(PD) 
         rcmd=strrep(rcmd,[environment.metachar1 'D'],PD);
      end;   
      if ~isempty(PE)
         rcmd=strrep(rcmd,[environment.metachar1 'E'],PE);
      end;
      if ~isempty(PF) 
         rcmd=strrep(rcmd,[environment.metachar1 'F'],PF);
      end;
      if ~isempty(PG)
         rcmd=strrep(rcmd,[environment.metachar1 'G'],PG); 
      end;
      if ~isempty(PH)
         rcmd=strrep(rcmd,[environment.metachar1 'H'],PH);
      end;
      if ~isempty(PI) 
         rcmd=strrep(rcmd,[environment.metachar1 'I'],PI);
      end;
      if ~isempty(PJ) 
         rcmd=strrep(rcmd,[environment.metachar1 'J'],PJ);  
      end;
      if ~isempty(PK) 
         rcmd=strrep(rcmd,[environment.metachar1 'K'],PK);  
      end;

   
      % PCOFF command line replacement variables
      if ~isstr(pcoff_argument.P0) & ~isempty(pcoff_argument.P0) & errors
         fprintf(error_fid,'Internal Error [metafile]. Non-string replacement argument.\n');
         return;
      end;
         
      rcmd=strrep(rcmd,[environment.metachar2 '0'],pcoff_argument.P0);
      rcmd=strrep(rcmd,[environment.metachar2 '1'],pcoff_argument.P1);
      rcmd=strrep(rcmd,[environment.metachar2 '2'],pcoff_argument.P2);
      rcmd=strrep(rcmd,[environment.metachar2 '3'],pcoff_argument.P3);
      rcmd=strrep(rcmd,[environment.metachar2 '4'],pcoff_argument.P4);
      rcmd=strrep(rcmd,[environment.metachar2 '5'],pcoff_argument.P5);
      rcmd=strrep(rcmd,[environment.metachar2 '6'],pcoff_argument.P6); 
      rcmd=strrep(rcmd,[environment.metachar2 '7'],pcoff_argument.P7);
      rcmd=strrep(rcmd,[environment.metachar2 '8'],pcoff_argument.P8);
      rcmd=strrep(rcmd,[environment.metachar2 '9'],pcoff_argument.P9);    
      issue_command(rcmd);
      if meta_fid < 0
         if errors 
            fprintf(error_fid,'Error [metafile]. Cannot continue processing metafile %s.\n',rcmd_in_loop);
         end;
         response=[rcmd_in_loop '   error processing this metafile'];
         return;
      end;

   end; % next
%   if debugs
%     fprintf(debug_fid,'Debug [metafile]. meta_fid= %d \n',meta_fid);
%   end;
end; % while not eof
if isempty(fopen(meta_fid))
   if errors 
      fprintf(error_fid,'Internal error [metafile].  Metafile unexpectedly closed.\n');
   end;
else
   if debugs
      fprintf(debug_fid,'Debug [metafile]. Closing metafile.  meta_fid= %d \n',meta_fid);
   end;
   fclose(meta_fid);
   meta_fid=-1;
end;
if debugs
   fprintf(debug_fid,'Debug [metafile]. Leaving metafile.  meta_fid= %d \n',meta_fid);
end;

