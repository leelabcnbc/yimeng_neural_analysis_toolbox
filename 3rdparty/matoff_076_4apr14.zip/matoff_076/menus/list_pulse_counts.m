function[pulsechannel_counts]=list_pulse_counts
%
%  Extract a list of all the pulse channels that have pulses in the
%  matching search sequence 
%
%  Outputs
%    pulsechannel_counts    two-column matrix:  [pulse_channel  pulse_count]
%

% Get 3 column matrix:
%   [trial_number   pulse_channel   pulse_time]
pulsemap=work_getit('spikemap');

if isempty(pulsemap)
   pulsechannel_counts=[];
   return;
end

% make a list of all pulse channels
a=sort(pulsemap(:,2)');  % place pulse channels in order of channel number

pulsechannel_list=[];
i=1;
while ~isempty(i)
   new_c=a(i(1));
   pulsechannel_list=[pulsechannel_list new_c];
   i=find(a > new_c);
end

spikecount_list=[];
% count the spikes in each channel
for i=1:length(pulsechannel_list)
   spike_count=length(find(pulsemap(:,2)==pulsechannel_list(i)));  % all occurrences of this pulse
   spikecount_list=[spikecount_list spike_count];
end

pulsechannel_counts=[pulsechannel_list'  spikecount_list'];
