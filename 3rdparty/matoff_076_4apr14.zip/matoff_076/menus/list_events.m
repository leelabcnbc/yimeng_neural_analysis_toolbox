function [events]=list_events(trial_number)
%
% Returns a list of events and event times for the specified trial number
%
% Inputs
%    trial number
% Outputs
%    events        row 1          all event codes for this trial
%                  row 2          matching times in milliseconds since start of trial
%
global work_fid work_udef environment
global error_fid warning_fid debug_fid
global errors warnings debugs
global history
global selected_event_data selected_fid selected_file_trials

events=[];

sourcetrials_string=get(findobj('Tag','source'),'String');
source_trials=expand_range_list(number_range_list(sourcetrials_string));
if debugs
   fprintf(debug_fid,'Debug [list_events]. source trial list:\n');
   fprintf(debug_fid,' %d',source_trials);
   fprintf(debug_fid,'\n');
end;

% GUI unit number matches work_udef subscript
unit_number=get(findobj('Tag','unit'),'Value') ;  
% reduce trial list to just the source trials, don't exceed trial list length
highest_trial=length(work_udef(unit_number).trials);  % trial list length
search_trials=source_trials(find(source_trials <= highest_trial)); % limit list length
file_trials=work_udef(unit_number).trials(search_trials);  
% fetch block of event data from file

if (selected_fid==work_fid.event) & (selected_file_trials==file_trials)
   if debugs
      fprintf(debug_fid,'Debug [list_events]. Looking for event data.... found event data in cache\n');
   end;
else
   if debugs
      fprintf(debug_fid,'Debug [list_events]. Looking for event data.... reading from file\n');
   end;
   selected_event_data=read_event_record(work_fid.event,file_trials); 
   selected_fid=work_fid.event;    % mark information that is cached
   selected_file_trials=file_trials;
end;

% number of behavioral trials in this data set (save this for user_history_function)
unit_trials=length(file_trials); 

if isempty(selected_event_data)
   fprintf(warning_fid,'Warning [list_events]. No event data found for this unit.');
   return;
end;

if (trial_number < 1) | (trial_number > unit_trials) 
   fprintf(error_fid,'Error [list_events]. Requested trial number (%d) outside the range of this data set.',trial_number);
   return;
end;

header_marker=selected_event_data(1,(2*trial_number)-1);           % first entry is the trial header
header_file_trial_number=selected_event_data(1,(2*trial_number));
if debugs
   fprintf(debug_fid,'Debug [list_events]. Trial marker: %d    File trial number: %d\n',header_marker,header_file_trial_number);
end;
codes=selected_event_data(2:end,(2*trial_number)-1)' ;   % the remaining entries are the actual events and times
codes=codes(find(~isnan(codes)));                        % NaNs used as padding, remove them
times=selected_event_data(2:end,(2*trial_number))' ;
times=times(find(~isnan(times)));                        
times=times/10;  % convert to milliseconds
events=[codes ; times];
