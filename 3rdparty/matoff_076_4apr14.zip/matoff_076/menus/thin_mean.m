function [average]=thin_mean(data)
%
%  Average the columns of a matrix.  Elements that are NaN will not be included 
%  in the average calculation.  Thus, different points in the average can have 
%  differing number of data points (n) in the average.
%
% Inputs
%   data      NxM matrix.  Columns will be averaged.
% Outputs
%   average   1xM vector of averages.
%

if isempty(data) % average is zero if no data
   average=0;
   return
end

b=data;
b(isnan(b))=0;  % convert all NaN's into a 0

% Average is easy if only one row of data and algorithm below fails 
% with only one row, so make special case here.
if size(b,1)==1  
  average=b;
  return
end

b(~isnan(b))=1;  % convert all non-NaN into a 1

thin_count=sum(b);     % count the number of points being averaged in each column
thin_count(thin_count==0)=1;   % avoid divide by zero on empty columns

b=data;
b(isnan(b))=0;    % replace all NaN with zero
thin_sum=sum(b);  % total the columns (does not work for only one row)

average=thin_sum;  % easy initialization

average(:)=thin_sum(:)./thin_count(:);



