function [response]=store_plot(figure_number)
%
% store_plot  save a plot figure to disk.  See also: print_plot
% 
%  Inputs
%    figure_number   figure number of plot to save = figure handle
%    file_format     one of the listed file formats (see supported())  
%  Outputs
%    response
%
global environment set_process 
global fid fn
global error_fid warning_fid debug_fid
global errors warnings debugs
%

if isempty(environment.graphicsformat)
   environment.graphicsformat='png';
   if warnings
      fprintf(warning_fid,'Warning [store_plot]. No graphics format defined. Using default (PNG).');
   end;
end;
file_format=environment.graphicsformat;

supported(1).format='tiff';  % tiff, packbits compression
supported(1).ext='tif';
supported(2).format='tiffn'; % tiff, no compression
supported(2).ext='tif';
supported(3).format='hpgl';  % HPGL
supported(3).ext='hgl';
supported(4).format='jpeg';  % JPEG, quality=75
supported(4).ext='jpg';
supported(5).format='eps';   % black and white EPS level 1
supported(5).ext='eps';
supported(6).format='ai';    % adobe illustrated
supported(6).ext='ai';
supported(7).format='png';   % portable network graphics
supported(7).ext='png';

valid=0;
for i=1:length(supported)
   if strcmp(supported(i).format,file_format)
      valid=1;
      valid_type=i;
      break;
   end;
end;
if ~valid
   response='requested graphics file format is not supported';
   return;
end;

response='';
if isempty(figure_number)   % this should never happen
   if errors     
      fprintf(error_fid,'Error [store_plot]. How did we get an empty figure number?\n');
   end;
   return;   
end;

if ~ishandle(figure_number)
   if warnings     
      fprintf(warning_fid,'Warning [store_plot]. No such figure number (%d)\n',figure_number);
   end;
   return;
end;

% build plot file name
base_name=get_process_element(set_process.plot,4);   % get file name
base_name=deblank(strjust(base_name,'left'));   % squeeze out spaces
% is the file name fixed or numeric?
if isempty(base_name)
   base_name=sprintf('%d',fn.plot);
   fn.plot=mod(fn.plot+1,9999);
end;
full_name=filepath(base_name,environment.plotpath);
if debugs     
   fprintf(debug_fid,'Debug [store_plot]. Plotting figure >%d< as: >%s<\n',figure_number,full_name);
end;
if strcmp(full_name,'<')
   if warnings     
      fprintf(warning_fid,'Warning [store_plot]. File name error.\n',figure_number);
   end;
   return;
end;


set(figure_number,'PaperOrientation','portrait');
set(figure_number,'PaperUnits','Inches');
set(figure_number,'PaperPosition',[1.0,1.0,5.0,3.0]);
set(figure_number,'PaperPositionMode','Manual');

saveas(figure_number,full_name,file_format);
response=[full_name '.' supported(valid_type).ext];




      