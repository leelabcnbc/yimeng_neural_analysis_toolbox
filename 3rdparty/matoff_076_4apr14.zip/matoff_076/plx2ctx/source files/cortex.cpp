/***************************************************************************
                          cortex.cpp  -  description
                             -------------------
    begin                : Thu Aug 31 2000
    copyright            : (C) 2000 by Todd McAnally
    email                : tmcanally@tkmsoftware.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "cortex.h"
#include <iostream.h>
#include <string.h>
#include "settings.h"

extern Settings settings;
extern eventmap emap;

int DataArray::Add(TIMESTAMP Time, EOG *DataToAdd, int DataToAddSize) {

	// initially allocate the array if necessary

//	cout << "DataToAddSize = " << DataToAddSize << endl;
//	cout << "ExpectedTimestamp = " << ExpectedTimestamp << endl;
//	cout << "Time = " << Time << endl;

	if (!Array) {
		if ((Array = (EOG *)calloc(ARRAYINCREMENT, sizeof(EOG)))) {
			AllocatedSize += ARRAYINCREMENT;
			InitialTime = Time;
			ExpectedTimestamp = Time + (DataToAddSize * TimeIncrement);
		} else {
			return 0;
		}
	} else {
		if (ExpectedTimestamp != Time) {
			cerr << "Analog data not contiguous: expected " << ExpectedTimestamp;
			cerr << " ,got " << Time;
			cerr << " Time Increment = " << TimeIncrement << endl;
		}
			ExpectedTimestamp = Time + (DataToAddSize * TimeIncrement);
	}

	// allocate more if necessary

	while (AllocatedSize < (Size + DataToAddSize)) {
		if (!(Array = (EOG *)realloc( Array, (AllocatedSize + ARRAYINCREMENT) * sizeof(EOG) ))) {	
			return 0;
		}
		AllocatedSize += ARRAYINCREMENT;
//	cout << "Adding " << DataToAddSize << ", " << Size << ", " << AllocatedSize << endl;
	}

	// copy the data

  memcpy(&Array[Size], DataToAdd, DataToAddSize * sizeof(EOG));
	Size += DataToAddSize;
	return 1;
}
EOG DataArray::GetValue(TIMESTAMP Time) {
	unsigned int Index;

	Index = (Time - InitialTime)/TimeIncrement;
	if (Index < Size) {
		return Array[Index];
	}

	return 0;
}

DataNode * DataList::Add(unsigned long Timestamp, unsigned short Data)
{
DataNode * node;

	node = new DataNode;
	node->Timestamp = Timestamp;
	if (emap.TimeDivisor) {	
		node->Timestamp /= emap.TimeDivisor;
	}
	node->Data = Data;
	if (Header == NULL) {
		Header = node;
	}
	if (LastNode != NULL) {
		LastNode->Next = node;
	}
	node->Previous = LastNode;
	LastNode = node;
	Size++;
	return node;
}

DataList::~DataList()
{
	DataNode * node = LastNode;
	DataNode * nextnode;
	
	// delete the elements of the list

	while (node) {
		nextnode = node->Previous;
		delete node;
		node = nextnode;
	}

}

int DataList::Iterate(int (*Func)(unsigned long Timestamp, unsigned short Data))
{
	DataNode * CurrentNode = Header;
  int stop = 0;

	while(!stop && CurrentNode){ // read the block header
		stop = Func(CurrentNode->Timestamp, CurrentNode->Data);
		CurrentNode = CurrentNode->Next;
	}
	return 0;
}

unsigned long * DataList::TimestampArray()
{
int TruncatedSize = (Size <= MAXNUMTIMESTAMPS)?Size:MAXNUMTIMESTAMPS;
unsigned long *Array = new unsigned long[TruncatedSize];
int Index = 0;

	DataNode * CurrentNode = Header;

	while(CurrentNode && (Index < TruncatedSize)){ // read the block header
		Array[Index] = CurrentNode->Timestamp;
		Index++;
		CurrentNode = CurrentNode->Next;
	}

	// if datalist class is working this should never happen

	if (CurrentNode) {
		cerr << "Timestamp array truncated to fit in Cortex file, discarded " << (Size-TruncatedSize) << " timestamps" << endl;
	}
	if (Index != TruncatedSize) {
		cerr << "Size value of data list is larger than actual list" << endl;
	}

	return Array;
}
	
unsigned short * DataList::DataArray()
{
int TruncatedSize = (Size <= MAXNUMEVENTS)?Size:MAXNUMEVENTS;
unsigned short *Array = new unsigned short[TruncatedSize];
int Index = 0;

	DataNode * CurrentNode = Header;

	while(CurrentNode && (Index < TruncatedSize)){ // read the block header
//cout << "Array[" << Index << "] = " << CurrentNode->Data << endl;
		Array[Index] = CurrentNode->Data;
		Index++;
		CurrentNode = CurrentNode->Next;
	}

	// if datalist class is working this should never happen

	if (CurrentNode) {
		cerr << "Event array truncated to fit in Cortex file, discarded " << (Size-TruncatedSize) << " events" << endl;
	}
	if (Index != TruncatedSize) {
		cerr << "Size value of data list is larger than actual list" << endl;
	}
	
	return Array;
}

CortexTrial::CortexTrial(unsigned short zero, unsigned short shift)
{

	Header.length = 0;
	Header.cond_no = 0;
	Header.repeat_no = 0;
	Header.block_no = 0;
	Header.trial_no = 0;
	Header.isi_size = 0;
	Header.code_size = 0;
	Header.eog_size = 0;
	Header.epp_size = 0;
	Header.eye_storage_rate = 0;
	Header.kHz_resolution = 0;
	Header.expected_response = 0;
	Header.response = 0;
	Header.response_error = 0;
	
	TimestampSize = 0;
	EventSize = 0;
	EOGSize = 0;
	EPPSize = 0;
	TimestampArray = NULL;
	EventArray = NULL;
	EOGData = NULL;
	EPPData = NULL;

	EPPZero = zero;
	EPPShift = shift;

}

CortexTrial::~CortexTrial()
{
	if (TimestampArray)
		delete TimestampArray;
	if (EventArray)
		delete EventArray;
	if (EOGData)
		delete EOGData;
	if (EPPData)
		delete EPPData;

}

int CortexTrial::IterateEvents(int (*Func)(TIMESTAMP Timestamp, DATA Data))
{
	return EventList.Iterate(Func);
}

void CortexTrial::AddEvent(TIMESTAMP Timestamp, CODE Event)
{
	EventList.Add(Timestamp, Event);
}

void CortexTrial::AddAnalog(TIMESTAMP Timestamp, TIMEINCREMENT TimeIncrement, CHANNEL Channel, int Size, EOG * Data)
{
//	cout << "Analog: " << Timestamp << ", " << Channel << ", " << Size << endl;
//		cout << "time=" << Time << endl;
	AnalogList[Channel - 1].SetTimeIncrement(TimeIncrement);
	AnalogList[Channel - 1].Add(Timestamp, Data, Size);
}

int CortexTrial::MakeArrays()
{
	unsigned short data;
	EOG value;
	unsigned int i;
	TIMESTAMP time;
	int EOGSize, EPPSize;
	unsigned int EOGTimeSet = 0, EPPTimeSet = 0;
	TIMESTAMP FirstEOGTime = 0, LastEOGTime = 0, FirstEPPTime = 0, LastEPPTime = 0;
	unsigned int TimeIncrement = 0;
	unsigned int NumEPPChannels = 0;

	// make the timestamp array
	TimestampSize = (EventList.Size <= MAXNUMTIMESTAMPS)?EventList.Size:MAXNUMTIMESTAMPS;
	TimestampArray = EventList.TimestampArray();

	// make the event array
	EventSize = (EventList.Size <= MAXNUMEVENTS)?EventList.Size:MAXNUMEVENTS;
	EventArray = EventList.DataArray();

	// allocate the cortex analog arrays
	EOGData = new DataArray();
	EPPData = new DataArray();

	EOGSize = 0;
	EPPSize = 0;

	// go through all collected analog channels
	// decide whether it's EOG or EPP based on the channel number
	// record the earliest and latest EOG and EPP times

	for (i=0; i < MAXANALOGCHANNELS; i++) {

		// skip if no data was collected for this channel
		if (AnalogList[i].Size == 0) continue;

		// is it EOG or EPP?
		if (i <= (LASTEOGCHANNEL - 1)) { // EOG

			if (!EOGTimeSet) {  // first time looking at an EOG channel
				TimeIncrement = AnalogList[i].TimeIncrement;
				EOGTimeSet = 1;
				FirstEOGTime = AnalogList[i].InitialTime;
				LastEOGTime = FirstEOGTime + (AnalogList[i].Size * AnalogList[i].TimeIncrement);
			} else {
				TimeIncrement = AnalogList[i].TimeIncrement;
				if (FirstEOGTime > AnalogList[i].InitialTime) {		
					FirstEOGTime = AnalogList[i].InitialTime;
				}
				if ((AnalogList[i].InitialTime + (AnalogList[i].Size * AnalogList[i].TimeIncrement)) > LastEOGTime) {
					LastEOGTime = AnalogList[i].InitialTime + (AnalogList[i].Size * AnalogList[i].TimeIncrement);
				}
			}
		} else { // EPP

			NumEPPChannels++;

			if (!EPPTimeSet) { // first time looking at an EPP channel
				EPPTimeSet = 1;
				FirstEPPTime = AnalogList[i].InitialTime;
				LastEPPTime = FirstEPPTime + (AnalogList[i].Size * AnalogList[i].TimeIncrement);
			} else {

				// is there an earlier begin time for this channel?		
				if (FirstEPPTime > AnalogList[i].InitialTime) {
					FirstEPPTime = AnalogList[i].InitialTime;
				}


				// is there a later end time for this channel?
				if ((AnalogList[i].InitialTime + (AnalogList[i].Size * AnalogList[i].TimeIncrement)) > LastEPPTime) {
					LastEPPTime = AnalogList[i].InitialTime + (AnalogList[i].Size * AnalogList[i].TimeIncrement);
				}

			} // else (!EPPTimeSet)
		} // else EPP
	} // for, loop through all analog channels

	if (!TimeIncrement) { // no analog data collected
		return 0;
	}

	// number of EOG and EPP values per channel

	if (TimeIncrement) {
		EOGSize = (LastEOGTime - FirstEOGTime) /  TimeIncrement;
		EPPSize = (LastEPPTime - FirstEPPTime) /  TimeIncrement;
	} else {
		EOGSize = 0;
		EPPSize = 0;
	}
	

	unsigned int MaxEOGTime, MaxEPPTime;

	if (LASTEOGCHANNEL) {
		MaxEOGTime = FirstEOGTime + (int (MAXEOGDATAPOINTS/LASTEOGCHANNEL) * TimeIncrement);
	} else {
		MaxEOGTime = 0;
	}

	if (NumEPPChannels) {
		MaxEPPTime = FirstEPPTime + (int(MAXEPPDATAPOINTS/NumEPPChannels) * TimeIncrement);
	} else {
		MaxEPPTime = 0;
	}

	if (MaxEOGTime < LastEOGTime) {
		cerr << "Analog EOG Data truncated" << endl;
	} else {
		MaxEOGTime = LastEOGTime;
	}

	if (MaxEPPTime < LastEPPTime) {
		cerr << "Analog EPP Data truncated" << endl;
		
	} else {
		MaxEPPTime = LastEPPTime;
	}
//cout << "FirstEOGTime = " << FirstEOGTime << endl;
//cout << "LastEOGTime = " << LastEOGTime << endl;


	if (settings.OutputDebug) {
		cout << "Time Increment " << TimeIncrement << endl;
		cout << "MAX EOG Time " << MaxEOGTime << endl;
		cout << "First EPP Time " << FirstEPPTime << endl;
		cout << "MAX EPP Time " << MaxEPPTime << endl;
  	cout << "Needed EOG samples/channel = " << EOGSize << endl;
  	cout << "Needed EPP samples/channel = " << EPPSize << endl;
		cout << NumEPPChannels << " EPP channels being collected" << endl;
	}
	// collect EOG channels into a Cortex EOG array
  // if one of the channels isn't mapped then it will be filled with 0's

	for (time=FirstEOGTime; time < MaxEOGTime; time += TimeIncrement) {
		for (i = 0; i < LASTEOGCHANNEL; i++) {
			if (AnalogList[i].Size) {
				value = AnalogList[i].GetValue(time);
			} else {
				value = 0;
			}
			//cout << "EOG[" << i << "] (" << time << ") = " << (short)value << endl;
			//cout << "EOG " << time << endl;
			EOGData->Add(0, &value, 1);
		}
	}

//	cout << "final eog size = " << EOGData->Size << endl;
	for (time=FirstEPPTime; time < MaxEPPTime; time += TimeIncrement) {
		for (i = LASTEOGCHANNEL; i < MAXANALOGCHANNELS; i++) {
			if (!AnalogList[i].Size) continue;
			if (AnalogList[i].Size) {
				value = AnalogList[i].GetValue(time);
			} else {
				value = 0;
			}
			// add one if EPP channel begins at 1
			//cout << "EPP[" << i - LASTEOGCHANNEL << "] (" << time << ") = " << (short)value << endl;
			long longvalue = (long)value;
			longvalue += EPPZero;
			data =  ((longvalue >> EPPShift) & 0x0FFF) + ((i - LASTEOGCHANNEL) << 12);
			EPPData->Add(0, &data, 1);
		}
	}
//	cout << "final epp size = " << EPPData->Size << endl;
	return 0;
}

CortexFile::CortexFile()
{
	fp = NULL;
}

int CortexFile::create(char *filename)
{
	close();
	fp = fopen(filename, "w+b");
	if (!fp) {
		return 1;
	}
	return 0;
}

void CortexFile::close()
{
	if (fp) {
		fclose(fp);
		fp = NULL;
	}
}

int CortexFile::write(CortexTrial *trial)
{
	trial->MakeArrays();
	trial->Header.length = 0;
	trial->Header.cond_no = 1;
	trial->Header.repeat_no = 1;
	trial->Header.block_no = 1;
	// trial->trial_no is set by data parsing as new trials are created
	trial->Header.isi_size = trial->TimestampSize * sizeof(TIMESTAMP);
	trial->Header.code_size = trial->EventSize * sizeof(CODE);
	trial->Header.eog_size = trial->EOGData->Size * sizeof(EOG);
	trial->Header.epp_size = trial->EPPData->Size * sizeof(EPP);
	trial->Header.eye_storage_rate = 1;
	trial->Header.kHz_resolution = 1;
	trial->Header.expected_response = 1;
	trial->Header.response = 1;
	trial->Header.response_error = 0;

	if (settings.ShowCortexHeaders) {
		cout << "Cortex Trial " << trial->Header.trial_no << endl;
		cout << endl;
		cout << "	Length: " << trial->Header.length << endl;
		cout << "	Condition Number: " << trial->Header.cond_no << endl;
		cout << "	Repeat Number: " << trial->Header.repeat_no << endl;
		cout << "	Block Number: " << trial->Header.block_no << endl;
		cout << "	ISI Size: " << trial->Header.isi_size << endl;
		cout << "	Code Size: " << trial->Header.code_size << endl;
		cout << "	EOG Size: " << trial->Header.eog_size << endl;
		cout << "	EPP Size: " << trial->Header.epp_size << endl;
		cout << "	Eye Storage Rate: " << trial->Header.eye_storage_rate << endl;
		cout << "	kHz Resolution: " << trial->Header.kHz_resolution << endl;
		cout << "	Expected Response: " << trial->Header.expected_response << endl;
		cout << "	Response: " << trial->Header.response << endl;
		cout << "	Response Error: " << trial->Header.response_error << endl;
    cout << endl;

	}

	if (settings.ShowArraySizes) {
		cout << "Collected Data Array Sizes" << endl;
		cout << "	Timestamps: " << trial->EventList.Size << endl;
		cout << "	Events: " << trial->EventList.Size << endl;
		cout << "	EOG: " << trial->EOGData->Size << endl;
		cout << "	EPP: " << trial->EPPData->Size << endl;
	}

	fwrite(&(trial->Header), sizeof(CortexHeader), 1, fp);
	fwrite(trial->TimestampArray, trial->Header.isi_size, 1, fp);
	fwrite(trial->EventArray, trial->Header.code_size, 1, fp);
for (int ii = 0; ii < trial->EventSize; ii++) {
	//cout << "EA[" << ii << "] = " << trial->EventArray[ii] << endl;
}
	if (trial->EOGData->Size) {
		fwrite(trial->EOGData->Array, trial->Header.eog_size, 1, fp);
	}
	if (trial->EPPData->Size) {
		fwrite(trial->EPPData->Array, trial->Header.epp_size, 1, fp);
	}

	return 0;
}

