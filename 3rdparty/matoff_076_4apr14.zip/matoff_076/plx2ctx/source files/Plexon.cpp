/***************************************************************************
                          Plexon.cpp  -  description
                             -------------------
    begin                : Fri Aug 25 2000
    copyright            : (C) 2000 by Todd McAnally
    email                : tmcanally@tkmsoftware.com
 ***************************************************************************/
#include <iostream.h>
#include "Plexon.h"
#include "settings.h"

extern Settings settings;


PlxFile::PlxFile() {
  FileHeader = NULL;
	ChannelHeader = NULL;
	EventHeader = NULL;
  SlowHeader = NULL;
	fp = NULL;
	NumDataBlocks = 0;
}

PlxFile::~PlxFile() {
	if (fp)
		fclose(fp);
}

int PlxFile::open(char *filename) {
	fp = fopen(filename, "rb");	
	if (!fp) {
		return 0;
	}

	return (1);
}

void PlxFile::close() {
	fclose(fp);
	fp = NULL;
}

int PlxFile::ParseData(int (*Func)(PL_DataBlockHeader *, int, short *))
{
	PL_DataBlockHeader db;
	short buf[256];
	int nbuf;
	int stop = 0;
	int numread = 0;

	while(!stop && (feof(fp) == 0)
	     && fread(&db, sizeof(db), 1, fp) == 1){ // read the block header
	//	if (feof(fp)) { break; }
		NumDataBlocks++;
		if(db.NumberOfWaveforms > 0){ // read the waveform after the block
			nbuf = db.NumberOfWaveforms*db.NumberOfWordsInWaveform;
			numread = fread(buf, nbuf*2, 1, fp);
		}
		stop = Func(&db, numread, buf);
	}
//cout << "out of while" << endl;
	return 0;
}

int PlxFile::ParseHeaders(){
	int numread, i;

	if (!is_open()) {
		return 0;
	}

	FileHeader = new PL_FileHeader;

	numread = fread(FileHeader, sizeof(PL_FileHeader), 1, fp);

	if(FileHeader->NumDSPChannels> 0) {
		ChannelHeader = new PL_ChanHeader[FileHeader->NumDSPChannels];
		numread = fread(&ChannelHeader[0], FileHeader->NumDSPChannels*sizeof(PL_ChanHeader), 1, fp);
		for (int i = 0; i < FileHeader->NumDSPChannels; i++) {
			//cout << "HEADER WFRate " << i << ": " << ChannelHeader[i].WFRate << endl;
		}
		//delete ChannelHeader;
	}

	if(FileHeader->NumEventChannels> 0) {
		EventHeader = new PL_EventHeader[FileHeader->NumEventChannels];
		numread = fread(&EventHeader[0], sizeof(PL_EventHeader), FileHeader->NumEventChannels,  fp);
		if (settings.ShowEventHeader) {
			cout << "Event Headers [" << numread << "]" << endl;
			for (i=0; i<numread; i++) {
				cout << "	" << EventHeader[i].Name << ": " << EventHeader[i].Channel << endl;
			}
		}
		//delete EventHeader;
	}

	if(FileHeader->NumSlowChannels> 0) {
		SlowHeader = new PL_SlowChannelHeader[FileHeader->NumSlowChannels];
		numread = fread(&SlowHeader[0], FileHeader->NumSlowChannels*sizeof(PL_SlowChannelHeader), 1, fp);
		for (int i = 0; i < FileHeader->NumSlowChannels; i++) {
			//cout << "HEADER ADFreq: " << i << ": " << SlowHeader[i].ADFreq << endl;
		//	cout << "       Gain  : " << i << ": " << SlowHeader[i].Gain << endl;
		}
		//delete SlowHeader;
	}

	return 1;
}


/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
