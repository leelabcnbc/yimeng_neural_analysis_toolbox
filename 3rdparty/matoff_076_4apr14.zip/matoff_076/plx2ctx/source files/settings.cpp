/***************************************************************************
                          settings.cpp  -  description
                             -------------------
    begin                : Tue Oct 17 2000
    copyright            : (C) 2000 by Todd McAnally
    email                : tmcanally@tkmsoftware.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
#undef HAVE_GETOPT_LONG

#include "settings.h"
extern "C" {
#include "getopt.h"
}
#include <iostream.h>
#include <string.h>
#include <stdlib.h>

int Settings::ParseCmdLine(int argc, char * const * argv) {

int opt;	
int ret = 0;

	opterr = 1;
	while ((opt = getopt(argc, argv, Optstring)) != -1) {
		switch(opt) {
			case 'd':
				OutputDebug = 1;
				break;
			case 'h':
				OutputPlexonHeader = 1;
				break;
			case 'M':
				OutputMap = 1;
				if (optarg) {
					OutputMapFileName = (char *)malloc(strlen(optarg) + 1);
					strcpy(OutputMapFileName, optarg);
				}
				break;
			case 'm':
				if (optarg) {	
					MapFileName = (char *)malloc(strlen(optarg) + 1);
					strcpy(MapFileName, optarg);
				}
				break;
			case 's':
				OutputSettings = 1;
				break;
			case 'c':
				ShowCortexHeaders = 1;
				break;
			case 'a':
				ShowArraySizes = 1;
				break;
			case 'e':
				ShowEventCodes = 1;
				break;
			case 'E':
				ShowEventHeader = 1;
				break;
			case 'v':
				cout << "Version: " << Version << endl;
				exit(0);
				break;
			case '?':
				cerr << "Invalid command line argument " << (char)optopt << endl;
				ret = 1;
				break;
		}
	}

	
	if (optind < argc) { // plexon file name present
		if (strlen(argv[optind]) >= 4) {
			if (!strcmp(&argv[optind][strlen(argv[optind])-4], ".plx")) {
				BaseFileName = (char *)malloc(strlen(argv[optind]) - 3);	
				strncpy(BaseFileName, argv[optind], strlen(argv[optind]) - 4);
				BaseFileName[strlen(argv[optind])-4] = '\0';
			} else { // doesn't have .plx extension
				BaseFileName = (char *)malloc(strlen(argv[optind]) + 1);	
				strcpy(BaseFileName, argv[optind]);
			}
		} else { // no room for .plx extension so it doesn't have one
			BaseFileName = (char *)malloc(strlen(argv[optind]) + 1);	
			strcpy(BaseFileName, argv[optind]);
		}
		PlexonFileName = (char *)malloc(strlen(BaseFileName) + 5);
		strcpy(PlexonFileName, BaseFileName);
		strcat(PlexonFileName, ".plx");
		optind++;
	} else {
		cerr << "Plexon file not present on command line" << endl;
		ret = 2;
	}

	if (optind < argc) { // cortex file name present
		CortexFileName = (char *)malloc(strlen(argv[optind]) + 1);
		strcpy(CortexFileName, argv[optind]);
		optind++;
	} else {
		if (BaseFileName) {
			CortexFileName = (char *)malloc(strlen(BaseFileName) + 1);
			strcpy(CortexFileName, BaseFileName);
		}
	}

	if (!MapFileName && BaseFileName) {
		MapFileName = (char *)malloc(strlen(BaseFileName) + 5);
		strcpy(MapFileName, BaseFileName);
		strcat(MapFileName, ".map");
	}

	if (OutputSettings)
			ShowSettings();

	return ret;
}

char * Settings::GetNextCortexFileName() {
	if (!WholeCortexFileName) {
		WholeCortexFileName = new char[strlen(CortexFileName) + 5];
	}
	CortexFileNumber++;
	sprintf(WholeCortexFileName, "%s.%u", CortexFileName, CortexFileNumber);
	
	return WholeCortexFileName;
}

void Settings::ShowSettings () {
	cout << "Settings:" << endl;

	cout << "	Base File is ";
	if (BaseFileName)
		cout << BaseFileName << endl;
	else
		cout << "MISSING!" << endl;

	cout << "	Plexon File is ";
	if (PlexonFileName)
		cout << PlexonFileName << endl;
	else
		cout << "MISSING!" << endl;

	cout << "	Cortex Base Filename is ";
	if (CortexFileName)
		cout << CortexFileName << endl;
	else
		cout << "MISSING!" << endl;

	cout << "	Map File is ";
	if (MapFileName)
		cout << MapFileName << endl;
	else
		cout << "MISSING!" << endl;

	cout << "	Output Map (M) ";
	if (OutputMap) {
		if (OutputMapFileName) {
			cout << "to " << OutputMapFileName << endl;
		} else {
			cout << "to standard out" << endl;
		}
	} else {
		cout << "Off" << endl;
	}

	cout << "	Output Settings (s) On" << endl;

	cout << "	Debug (d) ";
	if (OutputDebug) {
		cout << "On" << endl;
	}	else {
		cout << "Off" << endl;
	}

	cout << "	Output Plexon Header (h) ";
	if (OutputPlexonHeader) {
		cout << "On" << endl;
	}	else {
		cout << "Off" << endl;
	}

}

void Settings::ShowUsage () {
	cerr << "usage: plx2ctx [options] <plexon file> [<cortex file>]" << endl;
	cerr << endl;
	cerr << "	where options are 0 or more of the following..." << endl;
	cerr << endl;
	cerr << "	-a" << endl;
	cerr << "		Show array sizes for timestamps, events, eog values, and epp values" << endl;
	cerr << "	-c" << endl;
	cerr << "		Show Cortex headers that are being created" << endl;
	cerr << "	-d" << endl;
	cerr << "		Show debug" << endl;
	cerr << "	-E" << endl;
	cerr << "		Show Plexon Event headers" << endl;
	cerr << "	-e" << endl;
	cerr << "		Show events codes seen" << endl;
	cerr << "	-h" << endl;
	cerr << "		Show Plexon header" << endl;
	cerr << "	-m<map file>" << endl;
	cerr << "		Use the given file containing the Plexon to Cortex mapping" << endl;
	cerr << "	-M[<output map file>]" << endl;
	cerr << "		Output the mapping used to the standard out or the given file." << endl;
	cerr << "		The output file is optional.  If no file is given the output goes to the screen" << endl;
	cerr << "		The format is the same as the input map file (-m)." << endl;
	cerr << "	-s" << endl;
	cerr << "		Show the settings used" << endl;
	cerr << "	-v" << endl;
	cerr << "		Show version and exit" << endl;
	cerr << endl;
}
