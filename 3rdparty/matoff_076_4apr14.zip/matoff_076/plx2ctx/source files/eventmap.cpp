/***************************************************************************
                          eventmap.cpp  -  description
                             -------------------
    begin                : Thu Aug 31 2000
    copyright            : (C) 2000 by Todd McAnally
    email                : tmcanally@tkmsoftware.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "eventmap.h"
#include "util.h"
#include <iostream.h>
#include <string.h>

eventmap::eventmap()
{
	AnalogStartEvent = 100;
	AnalogStopEvent = 101;
	CortexStartEvent = 258;
	CortexStopEvent = 259;
	PlexonStartEvent = 258;
	PlexonStopEvent = 259;
	AnalogBits = 16;
	TimeDivisor = 1;

	NumEventsMapped = 0;
	NumSpikesMapped = 0;
	NumAnalogMapped = 0;
	EventMap = new EventNode[MAXEVENTS];
	SpikeMap = new SpikeNode[MAXSPIKES];
	AnalogMap = new AnalogNode[MAXANALOG];
}

eventmap::~eventmap()
{
}

int eventmap::load(char *filename) {

char buffer[255];

	fp = fopen(filename, "r");	
	if (!fp) {
		cerr << "warning: couldn't load map file " << filename << ", using default mapping" << endl;
		return 1;
	}

	while (!feof(fp)) {
		if (!fgets(buffer, sizeof(buffer), fp)) {
			break;
		}

		strip_comments(buffer, COMMENT_CHARS);
		strip_all_spaces(buffer);
		if (*buffer == '\0') continue;
    strupper(buffer);

		//cout << "[" << buffer << "]" << endl;

    if (!strncmp(buffer, PLEXONSTART, strlen(PLEXONSTART))) {
			char *cptr = buffer + strlen(PLEXONSTART);
			sscanf(cptr, ":%hu", &PlexonStartEvent);
			
			//cout << "start " << StartEvent << endl;
			continue;
		}

    if (!strncmp(buffer, TIMEDIVISOR, strlen(TIMEDIVISOR))) {
			char *cptr = buffer + strlen(TIMEDIVISOR);
			sscanf(cptr, ":%hu", &TimeDivisor);
			
			//cout << "timedivisor " << TimeDivisor << endl;
			continue;
		}

    if (!strncmp(buffer, PLEXONSTOP, strlen(PLEXONSTOP))) {
			char *cptr = buffer + strlen(PLEXONSTOP);
			sscanf(cptr, ":%hu", &PlexonStopEvent);
			//cout << "stop " << StopEvent << endl;
			continue;
		}

    if (!strncmp(buffer, CORTEXSTART, strlen(CORTEXSTART))) {
			char *cptr = buffer + strlen(CORTEXSTART);
			sscanf(cptr, ":%hu", &CortexStartEvent);
			
			//cout << "start " << StartEvent << endl;
			continue;
		}

    if (!strncmp(buffer, CORTEXSTOP, strlen(CORTEXSTOP))) {
			char *cptr = buffer + strlen(CORTEXSTOP);
			sscanf(cptr, ":%hu", &CortexStopEvent);
			//cout << "stop " << StopEvent << endl;
			continue;
		}

    if (!strncmp(buffer, ANALOGSTART, strlen(ANALOGSTART))) {
			char *cptr = buffer + strlen(ANALOGSTART);
			sscanf(cptr, ":%hu", &AnalogStartEvent);
			
			//cout << "start " << StartEvent << endl;
			continue;
		}

    if (!strncmp(buffer, ANALOGSTOP, strlen(ANALOGSTOP))) {
			char *cptr = buffer + strlen(ANALOGSTOP);
			sscanf(cptr, ":%hu", &AnalogStopEvent);
			//cout << "stop " << StopEvent << endl;
			continue;
		}

    if (!strncmp(buffer, ANALOGBITS, strlen(ANALOGBITS))) {
			char *cptr = buffer + strlen(ANALOGBITS);
			sscanf(cptr, ":%hu", &AnalogBits);
			if (AnalogBits > 16) AnalogBits = 16;
			//cout << "stop " << StopEvent << endl;
			EPPZero = (2 ^ (AnalogBits-1)) - 1;
			if (AnalogBits > 12) {
				EPPShift = AnalogBits - 12;
			} else {
				EPPShift = 0;
			}
			continue;
		}

    if (!strncmp(buffer, EVENT, strlen(EVENT))) {
			unsigned short channel, event ;
			char *cptr = buffer + strlen(EVENT);
			sscanf(cptr, "%hu:%hu", &channel, &event);
			//cout << "event " << channel << ", " << event << endl;
			EventMap[NumEventsMapped].Channel = channel;
			EventMap[NumEventsMapped].Event = event;
			NumEventsMapped++;
			continue;
		}

    if (!strncmp(buffer, SPIKE, strlen(SPIKE))) {
			unsigned short channel, unit, event;
			char *cptr = buffer + strlen(SPIKE);
			sscanf(cptr, "%hu,%hu:%hu", &channel, &unit, &event);
			//cout << "spike " << channel << ", " << unit << ", " << event << endl;
			SpikeMap[NumSpikesMapped].Channel = channel;
			SpikeMap[NumSpikesMapped].Unit = unit;
			SpikeMap[NumSpikesMapped].Event = event;
			NumSpikesMapped++;
			continue;
		}
		
    if (!strncmp(buffer, ANALOG, strlen(ANALOG))) {
			unsigned short channel, achan;
			char *cptr = buffer + strlen(ANALOG);
			sscanf(cptr, "%hu:%hu", &channel, &achan);
//			cout << "analog " << channel << ": " << achan << endl;
			AnalogMap[NumAnalogMapped].Channel = channel;
			AnalogMap[NumAnalogMapped].AnalogChannel = achan;
			NumAnalogMapped++;
			continue;
		}
		
	}

	return (1);
}

unsigned short eventmap::Event(unsigned short channel)
{
	for (int i=0; i < NumEventsMapped; i++) {
		if (EventMap[i].Channel == channel) {
			return EventMap[i].Event;
		}
	}
	EventMap[NumEventsMapped].Channel = channel;
	EventMap[NumEventsMapped].Event = channel;
	NumEventsMapped++;
	return channel;
}

unsigned short eventmap::Spike(unsigned short channel, unsigned short unit)
{
	for (int i=0; i < NumSpikesMapped; i++) {
		if ( (SpikeMap[i].Channel == channel) && (SpikeMap[i].Unit == unit)) {
			return SpikeMap[i].Event;
		}
	}
	SpikeMap[NumSpikesMapped].Channel = channel;
	SpikeMap[NumSpikesMapped].Unit = unit;
	SpikeMap[NumSpikesMapped].Event = (channel << 9) + (unit << 14);
	NumSpikesMapped++;
	return 0;
}

unsigned short eventmap::Analog(unsigned short channel)
{
	for (int i=0; i < NumAnalogMapped; i++) {
		if (AnalogMap[i].Channel == channel) {
			return AnalogMap[i].AnalogChannel;
		}
	}

	AnalogMap[NumAnalogMapped].Channel = channel;
	AnalogMap[NumAnalogMapped].AnalogChannel = 0;
	NumAnalogMapped++;

	return 0;
}

void eventmap::ShowEventCodes () {
	cout << "Events codes seen" << endl;
	for (int i=0; i < NumEventsMapped; i++) {
		cout << EventMap[i].Channel << endl;
	}
  cout << endl;
	
}

ostream& operator <<  (ostream &s, const eventmap& map) {
	s << "; Plexon Start Event " << endl;
	s << PLEXONSTART << ": " << map.PlexonStartEvent << endl;
	s << "; Plexon Stop Event" << endl;
	s << PLEXONSTOP << ": " << map.PlexonStopEvent << endl;
  s << endl;
	s << "; Cortex Start Event " << endl;
	s << CORTEXSTART << ": " << map.CortexStartEvent << endl;
	s << "; Cortex Stop Event" << endl;
	s << CORTEXSTOP << ": " << map.CortexStopEvent << endl;
  s << endl;
	s << "; Analog Start Event " << endl;
	s << ANALOGSTART << ": " << map.AnalogStartEvent << endl;
	s << "; Analog Stop Event" << endl;
	s << ANALOGSTOP << ": " << map.AnalogStopEvent << endl;
	s << endl;
	s << "; Analog Bits =  # of signed bits for Plexon Slow Channel" << endl;
	s << ANALOGBITS << ": " << map.AnalogBits << endl;
  s << endl;
	s << "; Time Divisor =  # to divide Plexon time by to get Cortex Time" << endl;
	s << TIMEDIVISOR << ": " << map.TimeDivisor << endl;
  s << endl;
	/*
	s << "; Events" << endl;
	for (int i=0; i<map.NumEventsMapped; i++) {
		s << EVENT << " " << map.EventMap[i].Channel << " : " << map.EventMap[i].Event << endl;
	}
  s << endl;
	*/
	s << "; Spikes" << endl;
	for (int i=0; i<map.NumSpikesMapped; i++) {
		s << SPIKE << " " << map.SpikeMap[i].Channel << "," << map.SpikeMap[i].Unit;
		s << " : " << map.SpikeMap[i].Event << endl;
	}
  s << endl;
	s << "; Analog" << endl;
	for (int j=0; j<map.NumAnalogMapped; j++) {
		s << ANALOG << " " << map.AnalogMap[j].Channel;
		s << " : " << map.AnalogMap[j].AnalogChannel << endl;
	}
	
	return s;
}
