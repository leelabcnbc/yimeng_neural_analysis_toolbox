/***************************************************************************
                          settings.h  -  description
                             -------------------
    begin                : Tue Oct 17 2000
    copyright            : (C) 2000 by Todd McAnally
    email                : tmcanally@tkmsoftware.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef _SETTINGS_H
#define _SETTINGS_H

#include <stdio.h>


const static char Version[] = "0.8.01 (Native Windows) 11/11/04";
const static char Optstring[] = "acEedhm:M::sv";

class Settings {

	public:
		unsigned char OutputMap;
		unsigned char OutputPlexonHeader;
		char * OutputMapFileName;
		char * MapFileName;
		char * BaseFileName;
		char * PlexonFileName;
		char * CortexFileName;
		char * WholeCortexFileName;
		unsigned char OutputDebug;
		unsigned char OutputSettings;
		unsigned char ShowCortexHeaders;
		unsigned char ShowArraySizes;
		unsigned char ShowEventCodes;
		unsigned char ShowEventHeader;
		unsigned short CortexFileNumber;
		Settings() {
			OutputMap = 0;
			OutputDebug = 0;
			OutputSettings = 0;
			OutputPlexonHeader = 0;
			ShowCortexHeaders = 0;
			ShowArraySizes = 0;
			ShowEventCodes = 0;
			ShowEventHeader = 0;
			CortexFileNumber = 0;
			MapFileName = NULL;
			OutputMapFileName = NULL;
			BaseFileName = NULL;
			PlexonFileName = NULL;
			CortexFileName = NULL;
			WholeCortexFileName = NULL;
		};
		int ParseCmdLine(int argc, char * const * argv);
		void ShowSettings();
		void ShowUsage ();
		char * GetNextCortexFileName();

};

#endif // _SETTINGS_H
