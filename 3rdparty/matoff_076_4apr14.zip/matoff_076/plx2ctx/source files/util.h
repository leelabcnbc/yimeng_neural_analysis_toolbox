/***************************************************************************
                          util.h  -  description
                             -------------------
    begin                : Thu Aug 31 2000
    copyright            : (C) 2000 by Todd McAnally
    email                : tmcanally@tkmsoftware.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef _UTIL_H
#define _UTIL_H

char *strip_all_spaces(char *str);
char *strip_comments(char *str, const char *comment_chars);
char *strupper(char *str);

#endif //_UTIL_H
