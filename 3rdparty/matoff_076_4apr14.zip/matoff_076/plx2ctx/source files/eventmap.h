/***************************************************************************
                          eventmap.h  -  description
                             -------------------
    begin                : Thu Aug 31 2000
    copyright            : (C) 2000 by Todd McAnally
    email                : tmcanally@tkmsoftware.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef _EVENTMAP_H
#define _EVENTMAP_H

#include <stdio.h>
#include <iostream.h>

const char PLEXONSTART[] = "PLEXONSTART";
const char PLEXONSTOP[] = "PLEXONSTOP";
const char CORTEXSTART[] = "CORTEXSTART";
const char CORTEXSTOP[] = "CORTEXSTOP";
const char ANALOGSTART[] = "ANALOGSTART";
const char ANALOGSTOP[] = "ANALOGSTOP";
const char ANALOGBITS[] = "ANALOGBITS";
const char TIMEDIVISOR[] = "TIMEDIVISOR";
const char EVENT[] = "E";
const char SPIKE[] = "S";
const char ANALOG[] = "A";
const char COMMENT_CHARS[] = ";#";
const int MAXEVENTS = 1024;
const int MAXSPIKES = 255;
const int MAXANALOG = 255;
// note 2 is hard coded into algorithm for creating EOG array, just changing this is not enough
const unsigned int LASTEOGCHANNEL = 2; // 1 and 2 not 0, 1 and 2

// here's how the internal mapping works for eog and epp channels
// The AnalogChannel of the analog node will be a number representing an EOG or EPP channel
// if AnalogChannel <= LASTEOGCHANNEL then it's the actual EOG channel, the lowest being 1, not 0
// if AnalogChannel > LASTEOGCHANNEL then it's EPP with the actual channel number = AnalogChannel -
// LASTEOGCHANNEL
// For example, 1 = EOG channel 1, 4 = EPP channel 2 when LASTEOGCHANNEL = 2

typedef struct EventNode {
	unsigned short Channel;
	unsigned short Event;
} EventNode;

typedef struct SpikeNode {
	unsigned short Channel;
	unsigned short Unit;
	unsigned short Event;
} SpikeNode;

typedef struct AnalogNode {
	unsigned short Channel;
	unsigned short AnalogChannel;
} AnalogNode;

class eventmap {
	private:
		FILE *fp;
		EventNode * EventMap;
		SpikeNode * SpikeMap;
		AnalogNode * AnalogMap;

	public:
		unsigned short PlexonStartEvent;
		unsigned short PlexonStopEvent;
		unsigned short CortexStartEvent;
		unsigned short CortexStopEvent;
		unsigned short AnalogStartEvent;
		unsigned short AnalogStopEvent;
		unsigned short NumEventsMapped;
		unsigned short NumSpikesMapped;
		unsigned short NumAnalogMapped;
		unsigned short TimeDivisor;
		unsigned short AnalogBits;
		unsigned short EPPZero;
		unsigned short EPPShift;
		eventmap();
		~eventmap();

		int load(char *filename);
		friend ostream& operator <<  (ostream &s, const eventmap& map);
	  unsigned short Event(unsigned short channel);
		unsigned short Spike(unsigned short channel, unsigned short unit);
		unsigned short Analog(unsigned short channel);
		void ShowEventCodes();
};

#endif //_EVENTMAP_H

