/***************************************************************************
                          util.cpp  -  description
                             -------------------
    begin                : Thu Aug 31 2000
    copyright            : (C) 2000 by Todd McAnally
    email                : tmcanally@tkmsoftware.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <ctype.h>
#include "util.h"
#include <string.h>

char *strip_all_spaces(char *str)
{
char *real_char_ptr, *lagging_char_ptr;
	for (  real_char_ptr = str, lagging_char_ptr = str;*real_char_ptr; real_char_ptr++) {
		if (!isspace(*real_char_ptr)) {
			*lagging_char_ptr = *real_char_ptr;
			lagging_char_ptr++;
		}
	}

	*lagging_char_ptr = '\0';

	return str;
}

char *strip_comments(char *str, const char *comment_chars)
{
char *sptr;

	sptr = strpbrk(str, comment_chars);
	if (sptr) *sptr = '\0';
	return str;

}

char *strupper(char *str)
{
char *sptr;

	for (sptr = str; *sptr; sptr++) {
		*sptr = toupper(*sptr);
	}

	return str;
}


