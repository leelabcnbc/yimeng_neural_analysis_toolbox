/***************************************************************************
                          cortex.h  -  description
                             -------------------
    begin                : Wed Aug 30 2000
    copyright            : (C) 2000 by Todd McAnally
    email                : tmcanally@tkmsoftware.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef _CORTEX_H
#define _CORTEX_H

#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include "eventmap.h"


typedef struct CortexHeader {
	unsigned short length;
	unsigned short cond_no;
	unsigned short repeat_no;
	unsigned short block_no;
	unsigned short trial_no;
	unsigned short isi_size;
	unsigned short code_size;
	unsigned short eog_size;
	unsigned short epp_size;
	unsigned char eye_storage_rate;
	unsigned char kHz_resolution;
	unsigned short expected_response;
	unsigned short response;
	unsigned short response_error;
}  CortexHeader ;

typedef unsigned long TIMESTAMP;
typedef unsigned short CODE;
typedef unsigned short EOG;
typedef unsigned short EPP;
typedef unsigned short DATA;
typedef unsigned short CHANNEL;
const unsigned int MAXANALOGCHANNELS = 32;
const unsigned int ARRAYINCREMENT = 1000;
typedef unsigned long TIMEINCREMENT;
//const unsigned int LASTEOGCHANNEL = 2;

const int MAXNUMTIMESTAMPS = 16383; // isi_size is a short.  The max number it can hold is 65535.
	//It must hold the number of bytes in the timestamp array.  A timestamp is 4 bytes.  16383 is the max
	// number of timestamps that can be allocated and still fit the count of the number of byte 65532 into
	// a short.
const int MAXNUMEVENTS = MAXNUMTIMESTAMPS;  // same because there's 1 timestamp per event
const int MAXEOGDATAPOINTS = 32766; // max number stored in short divided by sizeof (EOG) (2)
const int MAXEPPDATAPOINTS = 32766; // max number stored in short divided by sizeof (EOG) (2)
	// The analog values are for all channels collectively.


class DataArray {
	unsigned int AllocatedSize;
	TIMESTAMP ExpectedTimestamp;
	public:
		EOG *Array;
		unsigned int TimeIncrement;
		TIMESTAMP InitialTime;
		unsigned int Size;
		DataArray (){
			ExpectedTimestamp = 0;
			AllocatedSize = 0;
			Size = 0;
			InitialTime = 0;
			Array = NULL;
			TimeIncrement = 0;
		}
		~DataArray() { if (Array) { free(Array); Array=NULL; } };
		int Add(TIMESTAMP Time, EOG *DataToAdd, int DataToAddSize);
		int SetTimeIncrement(unsigned int Increment) { TimeIncrement = Increment; return 0;};
		EOG GetValue(TIMESTAMP Time);
};

class DataNode {

	public:
		DataNode * Next; // this really should be protected
		DataNode * Previous;
		TIMESTAMP Timestamp;
		DATA Data;
	  DataNode() { Next = NULL; Previous = NULL; };

};

class DataList {
		private:
			DataNode * Header;
			DataNode * LastNode;
		public:
			int Size;
			DataList() { Size = 0; Header = NULL; LastNode = NULL; Header = NULL; };
			~DataList();
			DataNode * Add(TIMESTAMP Timestamp, DATA Data);
			int Iterate(int (*Func)(TIMESTAMP Timestamp, DATA Data));
			TIMESTAMP * TimestampArray();
			DATA * DataArray();
};

class CortexTrial {
	public:
		CortexHeader Header;
		DataList EventList;
		DataArray AnalogList[MAXANALOGCHANNELS];
		unsigned short TimestampSize;
		unsigned short EventSize;
		unsigned short EOGSize;
		unsigned short EPPSize;
		unsigned short TrialNumber;
		TIMESTAMP * TimestampArray;
		unsigned short EPPZero;
		unsigned short EPPShift;
		CODE * EventArray;
		DataArray * EOGData;
		DataArray * EPPData;

		CortexTrial(unsigned short zero, unsigned short shift);
		~CortexTrial();
		int IterateEvents(int (*Func)(TIMESTAMP Timestamp, DATA Data));
		void AddEvent(TIMESTAMP Timestamp, DATA Event);
		void AddAnalog(TIMESTAMP Timestamp, TIMEINCREMENT TimeIncrement, CHANNEL Channel, int Size, EOG * Data);
		int MakeArrays();
};

class CortexFile {
	private:
		FILE * fp;
	public:
		CortexFile();
		int create(char *filename);
		void close();
		int write(CortexTrial *trial);
};
	


/*
void *read_array(FILE *, unsigned short);


int main(int argc, char *argv[]) 
{
int show_timestamps = 0;
int show_codes = 0;
int show_eog = 0;
int show_epp = 0;

char *filename;
HEADER header;
FILE *cortex_file;
size_t bytes_read;

TIMESTAMP *timestamp;
CODE *code;
EOG *eog;
EPP *epp;

unsigned short num_timestamps, num_codes, num_eog, num_epp;

int i;

	if (argc != 2) {
		fprintf(stderr, "usage: %s <cortex filename>\n", argv[0]);
		return 1;
	}

	filename = argv[1];

	if ((cortex_file = fopen(filename, "rb")) == NULL) {
		fprintf(stderr, "can't open %s\n", filename);
		return 1;
	}

	while (1) {
	if ((bytes_read = fread(&header, sizeof(HEADER), 1, cortex_file)) != 1) {
		//fprintf(stderr, "error reading header %d\n", bytes_read);
		return 1;
	};

	//printf("length: %d\n", header.length);
	printf("cond_no: %d\n", header.cond_no);
	//printf("repeat_no: %d\n", header.repeat_no);
	//printf("block_no: %d\n", header.block_no);
	printf("trial_no: %d\n", header.trial_no);
	//printf("isi_size: %d\n", header.isi_size);
	//printf("code_size: %d\n", header.code_size);
	//printf("eog_size: %d\n", header.eog_size);
	//printf("epp_size: %d\n", header.epp_size);
	//printf("eye_storage_rate: %d\n", header.eye_storage_rate);
	//printf("kHz_resolution: %d\n", header.kHz_resolution);
	//printf("expected_response: %d\n", header.expected_response);
	//printf("response: %d\n", header.response);
	//printf("response_error: %d\n", header.response_error);
	printf("\n");
	// get the timestamp array

	if (header.isi_size > 0) {

		if ((timestamp = (TIMESTAMP *)read_array(cortex_file, header.isi_size)) == NULL) {
			fprintf(stderr, "failure reading timestamps\n");
			return 1;
		}

		if (show_timestamps) {
			num_timestamps = header.isi_size / sizeof(TIMESTAMP);

			for (i=0; i < num_timestamps; i++) {
				printf("[%d]: %u\n", i, timestamp[i]);
			}
		}
	}


	// get the event code array

	if (header.code_size > 0) {

		if ((code = (CODE *)read_array(cortex_file, header.code_size)) == NULL) {
			fprintf(stderr, "failure reading event codes\n");
			return 1;
		}

		if (show_codes) {
			num_codes = header.code_size / sizeof(CODE);

			for (i=0; i < num_codes; i++) {
				printf("[%d]: %u\n", i, code[i]);
			}
		}

	}

	// get the eog array

	if (header.eog_size > 0) {

		if ((eog = (EOG *)read_array(cortex_file, header.eog_size)) == NULL) {

			fprintf(stderr, "failure reading eog values\n");
			return 1;
		}

		if (show_eog) {
			num_eog = header.eog_size / sizeof(EOG);

			for (i=0; i < num_eog; i++) {
				printf("[%d]: %u\n", i, eog[i]);
			}
		}
	}

	// get the epp array
	
	if (header.epp_size > 0) {

		if ((epp = (EPP *)read_array(cortex_file, header.epp_size)) == NULL) {
			fprintf(stderr, "failure reading epp values\n");
			return 1;
		}

		if (show_epp) {
			num_epp = header.epp_size / sizeof(EPP);

			for (i=0; i < num_epp; i++) {
				printf("[%d]: %u\n", i, epp[i]);
			}
		}
	
	}

	}

	return 0;

}
 
void *read_array(FILE *filename, unsigned short size)
{
size_t num_read;

	void *array;

	if ((array = malloc(size) ) != NULL) {
		if ((num_read = fread(array, size, 1, filename)) != 1) {
			free (array);
			array = NULL;
		}
	}

	return array;
}
*/

#endif // _CORTEX_H
