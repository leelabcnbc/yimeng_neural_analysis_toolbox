/***************************************************************************
                          main.cpp  -  description
                             -------------------
    begin                : Fri Aug 25 17:01:32 EDT 2000
    copyright            : (C) 2000 by Todd McAnally
    email                : tmcanally@tkmsoftware.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <fstream.h>
#include <iostream.h>
#include <stdlib.h>
#include "Plexon.h"
#include "eventmap.h"
#include "cortex.h"
//#include <getopt.h>
#include "settings.h"
#include <assert.h>

int printdata(PL_DataBlockHeader * header, int numvalues, short * values)
{
	cout << "Data Block Header" << endl;
	cout << header->TimeStamp << ": " << header->Type << endl;	
	return 0;
}

Settings settings;
eventmap emap;
CortexTrial * Trial = NULL;
unsigned char PlexonTrialValid = 0;
unsigned char PlexonTrialNumber = 0;
unsigned char CollectAnalogData = 0;
PlxFile Pfile;
CortexFile CFile;
unsigned short TrialNum;

int parsedata(PL_DataBlockHeader * header, int numvalues, short * values)
{
	int Freq;
	unsigned short event;
	unsigned short channel;
	if (settings.OutputDebug) {
			//cout << "EVENT type " << header->Type << endl;
	}
	switch (header->Type) {
		case PL_SingleWFType:
				// don't process when Plexon isn't in a trial
				if (!PlexonTrialValid) break;

				event = emap.Spike(header->Channel, header->Unit);

				if (settings.OutputDebug) {
						cout << "Spike " << header->Channel << "," << header->Unit << ": ";
						cout << event << endl;
				}
				if (event == 0) {
					if (settings.OutputDebug)
						cout << "Spike channel=" << header->Channel << ", unit=" << header->Unit << " not mapped" << endl;
					break;
				}
				if (Trial) {
					Trial->AddEvent(header->TimeStamp, event);
				} else {
					if (settings.OutputDebug)
						cout << "previous not added because not in a trial" << endl;
				}
				//cout << "Spike: " << event << endl;
			break;
		case PL_ExtEventType:

				if (header->Channel == PL_StrobedExtChannel) {
					event = emap.Event(header->Unit);
				} else {
					event = emap.Event(header->Channel);
				}

				if ((emap.PlexonStartEvent) && (header->Channel == emap.PlexonStartEvent)) {
					if (settings.OutputDebug) {
						cout << "Begin new Plexon trial" << endl;
					}
						PlexonTrialValid = 1;
						CFile.create(settings.GetNextCortexFileName());
						PlexonTrialNumber++;
				}

				if (settings.OutputDebug) {
					cout << "Event [" << header->Channel << "," << header->Unit << "] " << event << endl;
				}

				// don't process when Plexon isn't in a trial
				if (!PlexonTrialValid) break;

/*
				if (event == 0) {
					event = header->Channel;
				}
*/
				if (event == emap.CortexStartEvent) {
					if (settings.OutputDebug)
						cout << "Begin new Cortex trial" << endl;
					Trial = new CortexTrial(emap.EPPZero, emap.EPPShift);
					Trial->Header.trial_no = TrialNum;
					if (emap.AnalogStartEvent) {
						CollectAnalogData = 0;
					} else {
						CollectAnalogData = 1;
					}
				}

				if (Trial) {
					Trial->AddEvent(header->TimeStamp, event);
				}
				if (event == emap.CortexStopEvent) {
					if (settings.OutputDebug)
						cout << "End Cortex trial" << endl;
					CollectAnalogData = 0;
					if (Trial) {
	  				if (settings.OutputDebug)
							cout << "Cortex TRIAL: " << Trial->EventList.Size << endl;
						CFile.write(Trial);
						delete Trial;
						Trial = NULL;
						TrialNum++;
					}
				}
				if ((emap.PlexonStopEvent) && (header->Channel == emap.PlexonStopEvent)) {
						if (settings.OutputDebug) {
							cout << "End Plexon trial" << endl;
						}
						PlexonTrialValid = 0;
						CFile.close();
						TrialNum = 0;
				}
				if (emap.AnalogStartEvent && (event == emap.AnalogStartEvent)) {
						if (settings.OutputDebug) {
							cout << "Analog START event" << endl;
						}
					CollectAnalogData = 1;
				}
				if (emap.AnalogStopEvent && (event == emap.AnalogStopEvent)) {
						if (settings.OutputDebug) {
							cout << "Analog STOP event" << endl;
						}
					CollectAnalogData = 0;
				}
			break;
		case PL_ADDataType:
			if (!PlexonTrialValid) break;

			if (!CollectAnalogData) break;

			channel = emap.Analog(header->Channel);
			Freq = Pfile.SlowHeader[header->Channel].ADFreq;

			if (settings.OutputDebug) {
				cout << "Analog " << Pfile.FileHeader->ADFrequency / Freq << endl;
				cout << "       " << "Frequency: " << Freq << endl;
				cout << "	" << "Channel: " << header->Channel << ", Unit: " << header->Unit << endl;
		  	cout << "	" << "Time: " << header->TimeStamp << ", Count: " << header->NumberOfWordsInWaveform << endl;
		  	cout << "	" << "Mapped Channel: " << channel << endl;
			}

			if (Trial && channel) {
				Trial->AddAnalog(header->TimeStamp, TIMEINCREMENT(Pfile.FileHeader->ADFrequency/Freq), channel,
					header->NumberOfWordsInWaveform, (EOG *)values);
			}
			break;
		return 0;
	}

	return 0;
}

int main(int argc, char  * const * argv)
{

int result;

//		cout << "option " << (char)ret << ","<< optopt << ":" << optarg << endl;
	if (settings.ParseCmdLine(argc, argv)) {
		settings.ShowUsage();
		return EXIT_FAILURE;
	}

  result = Pfile.open(settings.PlexonFileName);
	if (!result) {
		cout << "Can't open Plexon File " << settings.PlexonFileName << endl;
		return EXIT_FAILURE;
	}

	Pfile.ParseHeaders();

	if (settings.OutputPlexonHeader) {	
		cout << endl;
		cout << "Plexon Header" << endl;
		cout << endl;
		cout << "	Version: " <<	Pfile.FileHeader->Version << endl;	
		cout << "	Comment: " <<	Pfile.FileHeader->Comment << endl;	
		cout << "	A/D Frequency: " << Pfile.FileHeader->ADFrequency << endl;
		cout << "	NumDSPChannels: " << Pfile.FileHeader->NumDSPChannels << endl;
		cout << "	NumEventChannels: " << Pfile.FileHeader->NumEventChannels << endl;
		cout << "	NumSlowChannels: " << Pfile.FileHeader->NumSlowChannels << endl;
		cout << "	NumPointsWave: " << Pfile.FileHeader->NumPointsWave << endl;
		cout << "	NumPointsPreThr: " << Pfile.FileHeader->NumPointsPreThr << endl;
		cout << "	Year: " << Pfile.FileHeader->Year << endl;
		cout << "	Month: " << Pfile.FileHeader->Month << endl;
		cout << "	Day: " << Pfile.FileHeader->Day << endl;
		cout << "	Hour: " << Pfile.FileHeader->Hour << endl;
		cout << "	Minute: " << Pfile.FileHeader->Minute << endl;
		cout << "	Second: " << Pfile.FileHeader->Second << endl;
		cout << "	FastRead: " << Pfile.FileHeader->FastRead << endl;
		cout << "	WaveformFreq: " << Pfile.FileHeader->WaveformFreq << endl;
		cout << "	LastTimestamp: " << Pfile.FileHeader->LastTimestamp << endl;
		cout << "	Name: " << Pfile.EventHeader[4].Name << endl;
		cout << endl;
	}
 	
	result = emap.load(settings.MapFileName);
	if (!result) {
		cout << "Unsuccessful eventmap load" << endl;
		return EXIT_FAILURE;
	}

	TrialNum = 0;
	
	// if the PlexonStartEvent is 0 then preset the collection flag valid and set the trial number
	if (!emap.PlexonStartEvent) {
		PlexonTrialValid = 1;
		PlexonTrialNumber = 1;
		CFile.create(settings.GetNextCortexFileName());
	} else {
		PlexonTrialValid = 0;
		PlexonTrialNumber = 0;
	}
	
	Pfile.ParseData(parsedata);

	CFile.close();
	Pfile.close();

	if (settings.OutputMap) {
		if (settings.OutputMapFileName) {
			ofstream ostr1(settings.OutputMapFileName);
			ofstream out(settings.OutputMapFileName);
			assert(out);
			out << emap << endl;
		} else {
			cout << emap << endl;

		}
	}

	if (settings.ShowEventCodes)
		emap.ShowEventCodes();

  return EXIT_SUCCESS;
}
