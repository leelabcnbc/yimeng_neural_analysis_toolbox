function [newlist]=ce_number_range_list(oldlist)
%    Reformat list of trials or event codes 
%
%   Produce an ordered list where contiguous elements are represented with 
%   dash (-) notation.  Input and output are both string variables.
%
%  Inputs
%    oldlist   Any valid list (string). Can have brackets, but they will be removed.
%  Outputs
%    newlist   Ordered list (string). '@' if the input string is bad (delivered by ce_expand_range_list)
%
%
%  example:
%    newlist=ce_number_range_list('23-24,25,26,27,28,41')
%    newlist is:  '23-28,41'

newlist=[];
if isempty(oldlist)
   return;
end;

expandedlist=ce_expand_range_list(oldlist);
if isempty(expandedlist)
   return;
end;

if strcmp(expandedlist,'@') % illegal list?
   newlist=expandedlist;
   return;
end;
newlist=ce_string_list(expandedlist);
