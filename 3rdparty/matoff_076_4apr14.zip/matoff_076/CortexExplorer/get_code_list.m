function [code_list,selected_index]=get_code_list(handle)

ce_string_list=get(handle,'String');
selected_index=get(handle,'Value');

% convert strings to values
code_list=[];
for i=1:length(ce_string_list)
   code_list=[code_list str2num(char(ce_string_list(i)))];
end;
