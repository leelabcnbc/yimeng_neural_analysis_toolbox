function varargout = code_selection(varargin)
% CODE_SELECTION M-file for code_selection.fig
%      CODE_SELECTION, by itself, creates a new CODE_SELECTION or raises the existing
%      singleton*.
%
%      H = CODE_SELECTION returns the handle to a new CODE_SELECTION or the handle to
%      the existing singleton*.
%
%      CODE_SELECTION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CODE_SELECTION.M with the given input arguments.
%
%      CODE_SELECTION('Property','Value',...) creates a new CODE_SELECTION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before code_selection_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to code_selection_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help code_selection

% Last Modified by GUIDE v2.5 02-Jun-2008 18:07:19

% Begin initialization code - DO NOT EDIT
gui_Singleton = 0;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @code_selection_OpeningFcn, ...
                   'gui_OutputFcn',  @code_selection_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before code_selection is made visible.
function code_selection_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to code_selection (see VARARGIN)

% Choose default command line output for code_selection
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes code_selection wait for user response (see UIRESUME)
% uiwait(handles.h_show_headers);


% --- Outputs from this function are returned to the command line.
function varargout = code_selection_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function h_spikes_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_spikes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in h_spikes.
function h_spikes_Callback(hObject, eventdata, handles)
% hObject    handle to h_spikes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
deselect(handles,[1 3 4]);  % deselect  codes, ignore, all_events

% Hints: contents = get(hObject,'String') returns h_spikes contents as cell array
%        contents{get(hObject,'Value')} returns selected item from h_spikes



% --- Executes during object creation, after setting all properties.
function h_file_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function h_file_Callback(hObject, eventdata, handles)
% hObject    handle to h_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_file as text
%        str2double(get(hObject,'String')) returns contents of h_file as a double
new_input_file(handles);



% --- Executes during object creation, after setting all properties.
function h_define_spikes_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_define_spikes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function h_define_spikes_Callback(hObject, eventdata, handles)
% hObject    handle to h_define_spikes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_define_spikes as text
%        str2double(get(hObject,'String')) returns contents of h_define_spikes as a double
newlist=ce_number_range_list(get(hObject,'String'));
set(hObject,'String',newlist);
ce_apply_rules(handles);

% --- Executes during object creation, after setting all properties.
function h_define_ignore_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_define_ignore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


function h_define_ignore_Callback(hObject, eventdata, handles)
% hObject    handle to h_define_ignore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_define_ignore as text
%        str2double(get(hObject,'String')) returns contents of h_define_ignore as a double
newlist=ce_number_range_list(get(hObject,'String'));
set(hObject,'String',newlist);
ce_apply_rules(handles);


% --- Executes during object creation, after setting all properties.
function h_sequence_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_sequence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


function h_sequence_Callback(hObject, eventdata, handles)
% hObject    handle to h_sequence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_sequence as text
%        str2double(get(hObject,'String')) returns contents of h_sequence as a double


% --- Executes during object creation, after setting all properties.
function h_trial_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_trial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


function h_trial_Callback(hObject, eventdata, handles)
% hObject    handle to h_trial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_trial as text
%        str2double(get(hObject,'String')) returns contents of h_trial as a double

display_trial(handles);


% --- Executes on button press in h_previous.
function h_previous_Callback(hObject, eventdata, handles)
% hObject    handle to h_previous (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
t=str2num(get(handles.h_trial,'String'));
t=t-1;
if t < 1
   t=1;
end;
set(handles.h_trial,'String',num2str(t));
display_trial(handles);


% --- Executes on button press in h_next.
function h_next_Callback(hObject, eventdata, handles)
% hObject    handle to h_next (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
t=str2num(get(handles.h_trial,'String'));
t=t+1;
tf=str2num(get(handles.h_trials_found,'String'));
if t > tf
   t=tf;
end;
set(handles.h_trial,'String',num2str(t));
display_trial(handles);


% --- Executes during object creation, after setting all properties.
function h_event_times_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_event_times (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in h_event_times.
function h_event_times_Callback(hObject, eventdata, handles)
% hObject    handle to h_event_times (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns h_event_times contents as cell array
%        contents{get(hObject,'Value')} returns selected item from h_event_times


% --- Executes on selection change in h_all_codes.
function h_all_codes_Callback(hObject, eventdata, handles)
% hObject    handle to h_all_codes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
deselect(handles,[1 2 3]);  % deselect events, spikes, ignore

% Hints: contents = get(hObject,'String') returns h_all_codes contents as cell array
%        contents{get(hObject,'Value')} returns selected item from h_all_codes


% --- Executes on button press in h_spikes_button.
function h_spikes_button_Callback(hObject, eventdata, handles)
% hObject    handle to h_spikes_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
assign_to(handles,2);


% --- Executes on button press in h_ignore_button.
function h_ignore_button_Callback(hObject, eventdata, handles)
% hObject    handle to h_ignore_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
assign_to(handles,3);


% --- Executes on button press in h_events_button.
function h_events_button_Callback(hObject, eventdata, handles)
% hObject    handle to h_events_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
assign_to(handles,1);


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over h_events_button.
function h_events_button_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to h_events_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over h_spikes_button.
function h_spikes_button_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to h_spikes_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over h_ignore_button.
function h_ignore_button_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to h_ignore_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over h_events.
function h_events_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to h_events (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in h_events.
function h_events_Callback(hObject, eventdata, handles)
% hObject    handle to h_events (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
deselect(handles,[2 3 4]);  % deselect  spikes, ignore, all_events

% Hints: contents = get(hObject,'String') returns h_events contents as cell array
%        contents{get(hObject,'Value')} returns selected item from h_events


% --- Executes on selection change in h_ignore.
function h_ignore_Callback(hObject, eventdata, handles)
% hObject    handle to h_ignore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
deselect(handles,[1 2 4]);  % deselect  spikes, events, all_events

% Hints: contents = get(hObject,'String') returns h_ignore contents as cell array
%        contents{get(hObject,'Value')} returns selected item from h_ignore


% --- Executes on button press in h_clear_button.
function h_clear_button_Callback(hObject, eventdata, handles)
% hObject    handle to h_clear_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
assign_to(handles,4);


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over h_clear_button.
function h_clear_button_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to h_clear_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


function h_event_histogram_Callback(hObject, eventdata, handles)
% hObject    handle to h_event_histogram (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_trial as text
%        str2double(get(hObject,'String')) returns contents of h_trial as a double
spike_histogram(handles,str2num(get(hObject,'String')) )

% --- Executes on button press in h_dir.
function h_dir_Callback(hObject, eventdata, handles)
% hObject    handle to h_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
my_lbox('UserData',handles);
% dir_entry=lbox2;


function h_trial_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to h_trial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_trial as text
%        str2double(get(hObject,'String')) returns contents of h_trial as a double

display_trial(handles);

