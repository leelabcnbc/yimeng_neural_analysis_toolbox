function CortexExplorer();
%
%  This program opens a GUI window for examining Cortex files.  It allows the 
%  user to assign event codes to one of 3 classes: spikes, events, ignored.
%  Then, CortexExplorer will display selected trials in this format:
%
%    41 42 50 {8} 14 122 {5} 33 34 35 {18} 55 58 60
%
%   Numbers in brackets are the number of spike events that occurred at the
%   specified place in the trial. The other numbers are event codes in order.
%   In addition to this display of the trial, all events and spikes not ignored are
%   listed with their time stamps in a separate drop down list.
%
%

verbose=1;
h=guihandles(code_selection);  % open gui

return;

header=1;
% read next trial
cortex_record=ce_read_cortex_record(cortex_index(header),1);
if verbose 
   fprintf(' Cortex_record: event record length  %d \n',length(cortex_record.event_time) );
   fprintf(' Cortex_record: eog record length  %d \n',length(cortex_record.eog) );
   fprintf(' Cortex_record: epp record length  %d \n',length(cortex_record.epp) );
end; 
if isempty(cortex_record) | length(cortex_record.event_time) < 1
   fprintf(' Cortex_record is empty');
end;
fclose(input_fid);
