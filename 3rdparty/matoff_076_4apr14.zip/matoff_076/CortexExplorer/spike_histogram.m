function spike_histogram(h,event)
% Make a distribution of an event (usually a spike channel) across trials

input_file_name=get(h.h_file,'String');
% fetch entire index of cortex file
cortex_index=ce_read_cortex_index(input_file_name);
if isempty(cortex_index)
   fprintf(' Cannot open Cortex data file: %s\n', input_file_name);
   return;
end;

if isempty(event) | event < 1
   fprintf('  Cannot display histogram for empty or negative events\n');
   set(h.h_first_histogram_trial,'String','none');
   set(h.h_last_histogram_trial,'String','   ');
   return;
end;

input_fid = fopen(input_file_name);
C=[];
n=length(cortex_index);
first_trial=0;
last_trial=0;
for trial_number=1:n
   record=ce_read_cortex_record(input_fid,cortex_index(trial_number),0);
   C(trial_number)=length(find(record.event_code==event));
   if C(trial_number) > 0
       if first_trial==0
           first_trial=trial_number;  % mark the first trial the event occurs
       end;
       last_trial=trial_number;  % track the last trial the event occurs
   end;
end;
fclose(input_fid);
if first_trial==0
    fprintf(' No data to display\n');
    set(h.h_first_histogram_trial,'String','none');
    set(h.h_last_histogram_trial,'String','   ');
    return;
end;
fprintf('First trial=%d   Last trial=%d\n',first_trial,last_trial);
set(h.h_first_histogram_trial,'String',num2str(first_trial));
set(h.h_last_histogram_trial,'String',num2str(last_trial));
figure;
bar(1:n,C);
max_c=max(C);
xlabel('Trial Number');
ylabel('Number of Events');
title(['Histogram of event ' num2str(event) ' across all trials']);
set(gca,'Xlim',[0 n]);
set(gca,'Ylim',[0 max_c]);