function ce_apply_rules(h)
%
% Supply the handle of the codes_selection menu
% Get handle this way: h=guihandles(code_selection);
%
% Get list of all codes in file
all_codes=get(h.h_all_codes,'String');
% Get definitions of spikes, ignore (and by exclusion) events
define_spikes=char(get(h.h_define_spikes,'String'));
define_ignore=char(get(h.h_define_ignore,'String'));

events=[];  % clear lists
spikes=[];
ignore=[];

% assign each code to correct list
for i=1:length(all_codes)
   cstring=char(all_codes(i));
   c=str2num(cstring);  % convert string to code value
   % see if code matches a spike
   if is_match(c,define_spikes)
      spikes=[spikes c];  % add to spike list
   elseif is_match(c,define_ignore)
      ignore=[ignore c];  % add to ignore list
   else
      events=[events c];  % add to event list
   end;
end;

% update list boxes
spike_list=cellstr(deblank(strjust(num2str(spikes'),'left')));
event_list=cellstr(deblank(strjust(num2str(events'),'left')));
ignore_list=cellstr(deblank(strjust(num2str(ignore'),'left')));

set(h.h_spikes,'String',spike_list);
set(h.h_events,'String',event_list);
set(h.h_ignore,'String',ignore_list);

   
