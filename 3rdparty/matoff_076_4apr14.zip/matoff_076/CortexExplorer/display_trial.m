function display_trial(h)
%
% open file for reading individual records
% h is the handle of the callback source
% last updated 6 april 2009
%

% Get lists of spikes, ignores, and events
[events,events_selected]=get_code_list(h.h_events); % get existing events
[spikes,spikes_selected]=get_code_list(h.h_spikes); % get existing spikes
[ignore,ignore_selected]=get_code_list(h.h_ignore); % get existing ignore

trial_number= str2num( get(h.h_trial,'String')  ); 
if ~isempty (get(h.h_epp_chan,'String'))
   epp_channel = str2num( get(h.h_epp_chan,'String')  ); 
else
   epp_channel=0;
end

input_file_name=get(h.h_file,'String');
% fetch entire index of cortex file
cortex_index=ce_read_cortex_index(input_file_name);
if isempty(cortex_index)
   fprintf(' Cannot open Cortex data file: %s\n', input_file_name);
   return;
end;

input_fid = fopen(input_file_name);  % open the Cortex file again

% Create an ordered list of each event code that occurs in the requested trial
if (trial_number > length(cortex_index)) | (trial_number < 1)
   fclose(input_fid);
   return;
end;

%   Get one trial of data from the Cortex file
%    record
%        record.event_time[]       time stamps for event codes
%        record.event_code[]       event codes
%        record.eog[:,2]           primary (X) and secondary (Y) channel data
%        record.epp[:]             epp channel data 
%        record.epp_channels[:]    matching channel number for each EPP data point
if get(h.h_show_eog,'Value') > 0 | get(h.h_plot_eog,'Value') > 0 |  get(h.h_print_epp,'Value') > 0 |  get(h.h_plot_epp,'Value') > 0
   exclude_analog=0;
else
   exclude_analog=1;
end;
record=ce_read_cortex_record(input_fid,cortex_index(trial_number),exclude_analog);
fclose(input_fid);
if isempty(record)
   return;
end;

% If the GUI has a check mark to display headers, print the headers on the 
% main Matlab window
if get(h.h_print_headers,'Value') > 0
   fprintf('\n  Header for Trial %d (Cortex header reports trial %d)\n',trial_number,cortex_index(trial_number).trial);
   fprintf('  Expected response=%d  Response=%d  Response error=%d\n',cortex_index(trial_number).expected,...
        cortex_index(trial_number).response,cortex_index(trial_number).response_error);
   fprintf('  length=%d   condition=%d   repeat=%d  block=%d\n', cortex_index(trial_number).length,...
        cortex_index(trial_number).condition,cortex_index(trial_number).repeat,cortex_index(trial_number).block);
   fprintf('  Buffers: Codes=%d  Timestamps=%d  EOG=%d  EPP=%d\n',cortex_index(trial_number).code_size,...
        cortex_index(trial_number).isi_size,cortex_index(trial_number).eog_size,cortex_index(trial_number).epp_size);
   fprintf('  Resolution=%d  Storage rate=%d\n',cortex_index(trial_number).resolution,...
        cortex_index(trial_number).storage_rate);  
end;

% Make sure the events are chronological. This is important for some
% files converted from data acquisition systems other than Cortex.
[a,i]=sort(record.event_time);
record.event_time=record.event_time(i);
record.event_code=record.event_code(i);

% build a list of events and times to
% display in the list box for events.
et={};
for i=1:length(record.event_code)
  if isempty(find(ignore==record.event_code(i)))  % do not include ignore codes
      a=sprintf('%10d      %-5d',record.event_time(i),record.event_code(i));
      et=[et ; {a}];  % build a cell array
  end;
end;
set(h.h_event_times,'String',et);

% build the special display where spike counts are shown in brackets {}
spike_count=0;
event_type=0;
display_events=[];
for i=1:length(record.event_code)
   c=record.event_code(i);
   % what kind of event is this?
   if ~isempty(find(spikes==c))
      spike_count=spike_count+1;  % add to spike list
   elseif ~isempty(find(ignore==c))
      % do nothing 
   elseif ~isempty(find(events==c))
      if spike_count==0
         display_events=[display_events ' ' num2str(c)];  
      else     
         display_events=[display_events ' {' num2str(spike_count) '} '  num2str(c)];  
      end;
      spike_count=0;
   end;
end;

if spike_count>0
   display_events=[display_events ' {' num2str(spike_count) '} '];  
end;
set(h.h_sequence,'String',display_events);

% Get EOG data for display in the eog list box
et={};
if get(h.h_show_eog,'Value') > 0
   if ~isempty(record.eog)
      for i=1:length(record.eog(:,1))
         a=sprintf('%4d  %4d  %4d',i,record.eog(i,1),record.eog(i,2));
         et=[et ; {a}]; % build cell array
      end;
   end
end;

% Get EPP data for dump on main Matlab window
if get(h.h_print_epp,'Value') > 0
   if ~isempty(record.epp)
      fprintf('\n  EPP values for Trial %d \n',trial_number);
      for i=1:length(record.epp)
          fprintf('Sample=%d  Chan= %d   Raw= %d   Value= %d\n',i,record.epp_channels(i),record.epp(i),record.epp(i)-2048);
      end
   else
      fprintf('\n  No EPP data \n');
   end
end


if isempty(et)
    et=[{'     '}; {'     '}];
end;
set(h.h_eog,'String',et);

center=2304;
cross_size=100;

% Plot EOG graph if requested
if get(h.h_plot_eog,'Value') > 0
   if ~isempty(record.eog)
      figure;
      hold on;
      plot(record.eog(:,1),record.eog(:,2));
      plot([center-cross_size,center+cross_size],[center,center],'-r');
      plot([center,center],[center-cross_size,center+cross_size],'-r');
      xlabel('X');
      ylabel('Y');
      title(['EOG X-Y analog data for trial ' num2str(trial_number)]);
      set(gca,'Xlim',[0 2*center]);
      set(gca,'Ylim',[0 2*center]);
      hold off;      
   else
      fprintf('  No EOG to plot\n');
   end   
end;


% Plot EPP graph if requested
if get(h.h_plot_epp,'Value') > 0
   if epp_channel==0
     fprintf('No EPP channel specified\n');
   else
     epp_ndx = find(record.epp_channels==epp_channel);
     if ~isempty(epp_ndx)
        figure;
        hold on;
        plot(record.epp(epp_ndx));
        xlabel('Sample number');
        title(['EPP analog channel ' num2str(epp_channel) ' data for trial ' num2str(trial_number)]);
        hold off; 
     end
  end
end



