function [m]=is_match(code,ds)
%
% See if the integer "code" matches the event definition string "ds"
%
%  Inputs
%   code                 unsigned integer
%   ds                   MatOFF event string, e.g.  2,9,20-30,101-105,107
%
%  Outputs
%    0           No match
%    1           match
%

   m=0;  % assume no match
   if isempty(ds) | ~ischar(ds)
      return;   % no valid definition string, no match
   end;

   while 1
      [def,ds]=strtok(ds,','); % get one definition from definition string

      dash=findstr('-',def);  
      if ~isempty(dash)            % see if this definition is for a range of values
        % see if code c is within the range
        start=str2num(def(1:dash-1));
        stop=str2num(def(dash+1:end));
        if (code >= start) & (code <= stop)
            m=1;         % !! match
            return;   
        end; 
      else                         % just a single value
         if code==str2num(def)
            m=1;        % !! match
            return;
         end;
      end;
      if length(ds) > 1
         ds=ds(2:end);  % jump over token
      else
         return;      % done with all tokens, no match
      end;
   end; % while
