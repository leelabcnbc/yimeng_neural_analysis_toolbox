function assign_to(h,target)
%
%
%  target     1  event
%             2  spike
%             3  ignore
%             4  all_events (clear from other columns)

% get lists of event codes and which ones have been selected
[all_codes,all_selected]=get_code_list(h.h_all_codes);
[events,events_selected]=get_code_list(h.h_events); % get existing events
[spikes,spikes_selected]=get_code_list(h.h_spikes); % get existing spikes
[ignore,ignore_selected]=get_code_list(h.h_ignore); % get existing ignore

% Only one of the selected lists is non-empty
if ~isempty(all_selected) & ~isempty(all_codes)
   selected_codes=all_codes(all_selected);
elseif ~isempty(events_selected) & ~isempty(events)
   selected_codes=events(events_selected);
elseif ~isempty(spikes_selected) & ~isempty(spikes)
   selected_codes=spikes(spikes_selected);
elseif ~isempty(ignore_selected) & ~isempty(ignore)
   selected_codes=ignore(ignore_selected);
else 
   selected_codes=[];
end;

if target==1  % events
   events=[events selected_codes];  % combine selected codes with events lists
   events=ce_remove_duplicates(sort(events));
   [found,remainder,no_match]=ce_find_in_list(spikes,events); % any events in spike list?
   spikes=spikes(remainder);  % remove the matching codes from the spikes list
   [found,remainder,no_match]=ce_find_in_list(ignore,events); % any events in ignore list?
   ignore=ignore(remainder);  % remove the matching codes from the ignore list
elseif target==2  % spikes
   spikes=[spikes selected_codes];  %  % combine selected codes with spikes list
   spikes=ce_remove_duplicates(sort(spikes));
   [found,remainder,no_match]=ce_find_in_list(events,spikes); % any spikes in the event list?
   events=events(remainder);  % remove the matching codes from the events list
   [found,remainder,no_match]=ce_find_in_list(ignore,spikes); % any spikes in ignore list?
   ignore=ignore(remainder);  % remove the matching codes from the ignore list
elseif target==3  % ignore
   ignore=[ignore selected_codes];  % combine selected codes with ignore list
   ignore=ce_remove_duplicates(sort(ignore));
   [found,remainder,no_match]=ce_find_in_list(events,ignore); % any ignores in the event list?
   events=events(remainder);  % remove the matching codes from the events list
   [found,remainder,no_match]=ce_find_in_list(spikes,ignore); % any ignores in spike list?
   spikes=spikes(remainder);  % remove the matching codes from the spikes list
elseif target==4  % remove from all lists
   [found,remainder,no_match]=ce_find_in_list(spikes,selected_codes);  % any of these codes in spike list?
   spikes=spikes(remainder); % remove the matching codes from the spikes list
   [found,remainder,no_match]=ce_find_in_list(events,selected_codes);
   events=events(remainder);  % remove the matching codes from the events list
   [found,remainder,no_match]=ce_find_in_list(ignore,selected_codes); % any of these codes in ignore list?
   ignore=ignore(remainder);  % remove the matching codes from the ignore list   
end;

% update code displays as ascii cell arrays
spike_list=cellstr(deblank(strjust(num2str(spikes'),'left'))); % convert to cell array
set(h.h_spikes,'Value',[]); % deselect, if necessary
set(h.h_spikes,'String',spike_list);  % return to list
event_list=cellstr(deblank(strjust(num2str(events'),'left')));
set(h.h_events,'Value',[]); % deselect, if necessary
set(h.h_events,'String',event_list);  % return to list
ignore_list=cellstr(deblank(strjust(num2str(ignore'),'left')));
set(h.h_ignore,'Value',[]); % deselect, if necessary
set(h.h_ignore,'String',ignore_list);  % return to list

% update definition displays as ascii event lists
spike_list=ce_string_list(spikes);
set(h.h_define_spikes,'String',spike_list);
ignore_list=ce_string_list(ignore);
set(h.h_define_ignore,'String',ignore_list);



