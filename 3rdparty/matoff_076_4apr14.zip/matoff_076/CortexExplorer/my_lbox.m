function varargout = my_lbox(varargin)
% MY_LBOX Application M-file for my_lbox.fig
%   MY_LBOX, by itself, creates a new MY_LBOX or raises the existing
%   singleton*.
%
%   H = MY_LBOX returns the handle to a new MY_LBOX or the handle to
%   the existing singleton*.
%
%   MY_LBOX('CALLBACK',hObject,eventData,handles,...) calls the local
%   function named CALLBACK in MY_LBOX.M with the given input arguments.
%
%   MY_LBOX('Property','Value',...) creates a new MY_LBOX or raises the
%   existing singleton*.  Starting from the left, property value pairs are
%   applied to the GUI before my_lbox_OpeningFunction gets called.  An
%   unrecognized property name or invalid value makes property application
%   stop.  All inputs are passed to my_lbox_OpeningFcn via varargin.
%
%   *See GUI Options - GUI allows only one instance to run (singleton).
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help my_lbox

% Last Modified by GUIDE v2.5 14-Mar-2006 11:29:59

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',          mfilename, ...
                   'gui_Singleton',     gui_Singleton, ...
                   'gui_OpeningFcn',    @my_lbox_OpeningFcn, ...
                   'gui_OutputFcn',     @my_lbox_OutputFcn, ...
                   'gui_LayoutFcn',     [], ...
                   'gui_Callback',      []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    varargout{1:nargout} = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before my_lbox is made visible.
function my_lbox_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to my_lbox (see VARARGIN)

% Choose default command line output for my_lbox
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

if nargin > 3 & strcmpi(varargin{1},'UserData')
    UserData=varargin{2};
    set(handles.listbox1,'UserData',UserData);  % store user data in list box
    initial_dir=pwd;
else
    if nargin == 3,
        initial_dir = pwd;
    elseif nargin > 4    
        if strcmpi(varargin{1},'dir')
            if exist(varargin{2},'dir')
                initial_dir = varargin{2};
            else
                errordlg('Input argument must be a valid directory','Input Argument Error!')
                return
            end

        else
            errordlg('Unrecognized input argument','Input Argument Error!');
            return;
        end
    end;    
end

% Populate the listbox
% set the default extension
if isfield(varargin{2},'default_extension')
   contents = get(handles.h_extension,'String');
   for i=1:length(contents)
      if strcmp(contents{i},varargin{2}.default_extension)
         set(handles.h_extension,'Value',i);
      end
   end
end
load_listbox(initial_dir,handles)
% Return figure handle as first output argument
    
% UIWAIT makes my_lbox wait for user response (see UIRESUME)
% uiwait(handles.h_my_lbox);


% --- Outputs from this function are returned to the command line.
function varargout = my_lbox_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% ------------------------------------------------------------
% Callback for list box - open .fig with guide, otherwise use open
% ------------------------------------------------------------
function varargout = listbox1_Callback(h, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1

get(handles.h_my_lbox,'SelectionType');
if strcmp(get(handles.h_my_lbox,'SelectionType'),'normal')
	index_selected = get(handles.listbox1,'Value');
	file_list = get(handles.listbox1,'String');	
    CortexExplorerHandles=get(handles.listbox1,'UserData');
	filename = file_list{index_selected};
    set(CortexExplorerHandles.h_file,'String',fullfile(pwd,filename));
	if  handles.is_dir(handles.sorted_index(index_selected))
		cd (filename)
		load_listbox(pwd,handles)
    end
end
% ------------------------------------------------------------
% Read the current directory and sort the names
% ------------------------------------------------------------
function load_listbox(dir_path,handles)
cd (dir_path)
dir_struct = dir(dir_path);
set(handles.h_current_path,'String',pwd);
contents = get(handles.h_extension,'String');
filter=contents{get(handles.h_extension,'Value')};
% filter =='.plx';  % must have the dot
% filter == '*';    % special case = all files
% filter == 'PATH'  % special case = list only directories
old_dir_struct=dir_struct;
clear dir_struct;
n=0;
for i=1:length(old_dir_struct)
   if old_dir_struct(i).isdir==1  % directory?
      n=n+1;
      dir_struct(n)=old_dir_struct(i);  % save all 
   elseif  ~strcmp(filter,'PATH')
      [path,name,ext]=fileparts(old_dir_struct(i).name);
      if strcmpi(filter,ext) | strcmpi(filter,'*')
         n=n+1;
         dir_struct(n)=old_dir_struct(i);  % save 
      end;
   end;
end;

[sorted_names,sorted_index] = sortrows({dir_struct.name}');
handles.file_names = sorted_names;
handles.is_dir = [dir_struct.isdir];
handles.sorted_index = [sorted_index];
guidata(handles.h_my_lbox,handles)
set(handles.listbox1,'String',handles.file_names,...
	'Value',1)
% set(handles.text1,'String',pwd)


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on button press in h_my_lbox_close.
function h_my_lbox_close_Callback(hObject, eventdata, handles)
% hObject    handle to h_my_lbox_close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
CortexExplorerHandles=get(handles.listbox1,'UserData');
new_input_file(CortexExplorerHandles);
close(handles.h_my_lbox);

% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over h_my_lbox_close.
function h_my_lbox_close_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to h_my_lbox_close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% my_lbox('h_my_lbox_close_ButtonDownFcn',gcbo,[],guidata(gcbo))
close(handles.h_my_lbox);

% --- Executes during object creation, after setting all properties.
function h_extension_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_extension (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in h_extension.
function h_extension_Callback(hObject, eventdata, handles)
% hObject    handle to h_extension (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns h_extension contents as cell array
%        contents{get(hObject,'Value')} returns selected item from h_extension
load_listbox(pwd,handles);



function h_current_path_Callback(hObject, eventdata, handles)
% hObject    handle to h_current_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_current_path as text
%        str2double(get(hObject,'String')) returns contents of h_current_path as a double
dir_name=get(handles.h_current_path,'String');
try
   cd (dir_name);
   load_listbox(pwd,handles);
catch
   fprintf('%s is not a valid directory name\n',dir_name);
end
set(handles.h_current_path,'String',pwd);

