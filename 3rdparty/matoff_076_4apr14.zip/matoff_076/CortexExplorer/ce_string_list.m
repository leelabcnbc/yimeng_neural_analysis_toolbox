function [new_list]=ce_string_list(numeric_array)
%   Produce an ordered (ASCII) list where contiguous elements are represented with 
%   dash (-) notation from an array of numbers.
%
%  Inputs
%    numeric_array   Matlab array of integers.  
%  Outputs
%    new_list   Ordered list (string). An error will return with '@' (delivered by ce_expand_range_list)
%
%
%  example:
%    new_list=ce_string_list([23 24 25 26 27 28 41]);
%    new_list is:  '23-28,41'
%
%
global error_fid warning_fid debug_fid
global errors warnings debugs

new_list='';

if isempty(numeric_array) 
   return;
end;

if ~isnumeric(numeric_array)
   if warnings
      fprintf(warning_fid,'Warning [ce_string_list].  Array is not numeric.\n');
   end;
   return;
end;

numeric_array=sort(numeric_array);    % sort
listflag=-1;
for i=numeric_array
  if listflag==-1       % just starting
     new_list=[new_list num2str(i)];
     listflag=1;
  elseif (listflag==0)  % recently ended a list or single value
     new_list=[new_list ',' num2str(i)];
     listflag=1;
  elseif (listflag==1)  % have read the first item of a potential list
     if (i==oldi+1)
        listflag=2;     % this will be a list
     else
        new_list=[new_list ',' num2str(i)];  % not a list
        listflag=1;     % could be the start of a new list
     end;
  elseif (listflag==2)  % working on a list
     if (i==oldi+1)     % do nothing, still working on the list
     else
        new_list=[new_list '-' num2str(oldi) ',' num2str(i)];  % end old list, be ready for next
        listflag=1;
     end;
  end; % if listflag
oldi=i;
end; %for i
if (listflag==2) % was working on a list, finish it off
  new_list=[new_list '-' num2str(oldi) ];
end;