function new_input_file(h)
% open file for reading individual records
% h is the handle of the callback source

input_file_name=get(h.h_file,'String');

% fetch entire index of new cortex file
cortex_index=ce_read_cortex_index(input_file_name);
if isempty(cortex_index)
   fprintf(' Cannot open Cortex data file  %s  The index is empty\n', input_file_name);
   return;
end;
fprintf('Opening Cortex file %s\n',input_file_name);


% clear old list data
set(h.h_spikes,'Value',[]); % deselect, if necessary
set(h.h_spikes,'String',cellstr(''));  % return to list
set(h.h_events,'Value',[]); % deselect, if necessary
set(h.h_events,'String',cellstr(''));  % return to list
set(h.h_ignore,'Value',[]); % deselect, if necessary
set(h.h_ignore,'String',cellstr(''));  % return to list
set(h.h_all_codes,'Value',[]); % deselect
set(h.h_sequence,'String',''); % clear trial sequence
set(h.h_event_times,'String','');
set(h.h_define_spikes,'String','');  % clear defines
set(h.h_define_ignore,'String','');
set(h.h_trial,'String',num2str(1));  % set for trial 1

set(h.h_trials_found,'String',num2str(length(cortex_index)));

input_fid=fopen(input_file_name);

fprintf(' Locating all event codes...\n');
% Create an ordered list of each event code that occurs in the data file
all_codes=[];
for trial=1:length(cortex_index);
   record=ce_read_cortex_record(input_fid,cortex_index(trial),1);  % exclude analog
   % extract unique event codes
   if ~isempty(record.event_code)
      event=sort(record.event_code);
      event_list=[event(1)];
      for e= 2:length(event)
         if event(e) ~= event(e-1)
            event_list=[event_list event(e)];
         end;
      end;
      % add only new event codes ones to all_codes
      for e=1:length(event_list)
         if isempty(find(event_list(e)==all_codes))
            all_codes=[all_codes event_list(e)];
         end;
      end;
   end; % if ~isempty(record.event_code)
end;
all_codes=sort(all_codes);
fprintf(' Event codes located.\n');



% place codes into all_codes list as a cell array of strings
all_codes_list=cellstr(deblank(strjust(num2str(all_codes'),'left')));
set(h.h_all_codes,'String',all_codes_list);

fclose(input_fid);