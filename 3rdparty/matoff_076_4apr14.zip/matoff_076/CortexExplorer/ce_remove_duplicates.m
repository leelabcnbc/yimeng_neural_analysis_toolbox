function [lesslist]=ce_remove_duplicates(morelist)
%
%  remove duplicate elements from a sorted list
%
%
if isempty(morelist)
   lesslist=morelist;
   return;
end;
if length(morelist) < 2
   lesslist=morelist;
   return;
end;
lesslist=morelist(1);
for i=2:length(morelist)
   if morelist(i) ~= lesslist(end)
      lesslist=[lesslist morelist(i)];
   end;
end;

