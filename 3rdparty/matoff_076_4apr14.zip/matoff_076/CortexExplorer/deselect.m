function deselect(h,target)
%
%
%  target     1  event
%             2  spike
%             3  ignore
%             4  all
%  Clear the current selection from the listbox
%  Can be multiple list boxes using an array for 'target'
%

if find(target==1)
   set(h.h_events,'Value',[]); 
end;

if find(target==2)
   set(h.h_spikes,'Value',[]); 
end;

if find(target==3)
   set(h.h_ignore,'Value',[]); 
end;

if find(target==4)
   set(h.h_all_codes,'Value',[]); 
end;


