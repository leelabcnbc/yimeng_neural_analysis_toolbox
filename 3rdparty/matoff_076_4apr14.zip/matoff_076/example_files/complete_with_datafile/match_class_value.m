%  match_class_value.m
%  General purpose script that accepts only
%  those trials with a certain class value.
%
%  Example. Accept only trials where class 2 has a class value of 13:
%
%   history on
%   history file match_class_value.m
%   history data 2 13
%   show
%  

list=list_history_data;
history_class = list(1);
class_value   = list(2);

if find_class_value(current_trial,history_class) == class_value
   accept=1;
else
   accept=0;
end;
