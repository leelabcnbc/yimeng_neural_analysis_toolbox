% create_history_classes.m
% 
% History script to create three classes for each trial. Each class
% value indicates the target of a eye movement (saccade). The targets of these
% eye movements are: above, to the right, or to the left of center.
%
% Class  Meaning
%
%  1    Saccade target of current trial 
%  2    Saccade target of previous trial (one trial back in time)
%  3    Saccade target of trial that was two trials back in time
%
%  Values that can be assigned to each class: 
%  42  Saccade was to top target
%  43  Saccade was to right target
%  44  Saccade was to left  target
%  10  Signifies an early trial (trial 1 or trial 2), no previous trial(s) exist.
%
%  The values 42, 43, and 44 are chosen because these match the event codes for
%  top (42), right (43), and left (44).
%
% Example
%   After running this history script, trial 22 might have:  
%            class 1 = 42
%            class 2 = 42
%            class 3 = 42
%   indicating that in trial 22 the monkey made a saccade to the top target 
%   after making saccades to the same target in the prior two trials.
%
 
% Initialize by assiging a value of 10 for trials numbers that are less than 1
response_back_1=10;   % response_back_1 is the eye movement direction of the previous trial
response_back_2=10;   % response_back_2 is the eye movement direction of two trials ago

for trial=1:last_trial     %  Step through each trial for this single unit

   % find the target of the current trial
   alltrialevents=list_events(trial);   % get all event codes and event times for this (current) trial
   alltrialcodes=alltrialevents(1,:);   % use just the event codes

   if     any(find(alltrialcodes==42))     % Search this trial for event code 42 (movement to top target)
      response=42;
   elseif any(find(alltrialcodes==43))     % event code 43 indicates the left target
      response=43;
   elseif any(find(alltrialcodes==44))     % event code 44 indicates the right target
      response=44;  
   else
      response=10;                         % if trial did not have a successful movement
   end

   assign_class_value(trial,1,response);          % current trial response is assigned to class 1
   assign_class_value(trial,2,response_back_1);   % class 2: value from previous trial (=10 if no previous trial)
   assign_class_value(trial,3,response_back_2);   % class 3: value from two trials back

   % now roll the trials back one for the next trial
   response_back_2 = response_back_1;
   response_back_1 = response;

end

% The search sequence was not very important, since all processing took place as soon as
% the first sequence match occurred. Since no other matches are needed, terminate the scan
% altogether.

accept = -1;  % terminate this scan
