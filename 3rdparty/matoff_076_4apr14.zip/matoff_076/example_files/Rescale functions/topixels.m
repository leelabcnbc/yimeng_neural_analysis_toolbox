function topixels(filename)
% to pixels.m
% Convert R11 GUI file from units of points to units of pixels.
% See rescale_matoff_to_pixels
%

fprintf('Rescaling %s from points to pixels\n',filename);

ratio=1.35;   % multiply points to get the correct value for pixels

% select file
% filename='environment_menu.m';

% select location for output and open file
[pathstr,basename,extn]=fileparts(filename);
output_filename=fullfile(pathstr,[basename '.newm']);
fid_tmp=fopen(output_filename,'wt');

% read every line of the file
lines = textread(filename, '%s', 'delimiter', '\n', 'whitespace', '');

% go through each line and decide what to do
for i=1:length(lines)
   line=char(lines(i)); % convert line from structured array to string
   
   % convert 	'Units','points', ...  to  'Units','pixels', ...
   line = strrep(line, '''Units'',''points'',', '''Units'',''pixels'','); 

   % find the original string position array
   a=findstr(line,'''Position''');
   if ~isempty(a)
      left_bracket=findstr('[',line);  % offset of [
      right_bracket=findstr(']',line); % offset of ]
       
      % get existing position array
      positions=str2num(line(left_bracket+1:right_bracket-1));
      % calculate new positions and round to 2 decimal places
      new_positions=positions*ratio; 
      new_positions=(round(new_positions*100))/100;  
   
      % show changes
 %     fprintf('%f %f %f %f\n',positions);  
 %     fprintf('%f %f %f %f\n\n',new_positions);
      
      % form new line
      line=sprintf('\t''Position'',[%6.2f %6.2f %6.2f %6.2f], ...',new_positions);
      
   end
   
   % print line into new file
   fprintf(fid_tmp,'%s\n',line);
end

fclose(fid_tmp);

% Now copy new file over old one
copyfile(output_filename,filename);
delete (output_filename);
