function [event1,event2,time_difference,spike_count] = count_time_spikes(first_event,last_event,trial)
%
% last updated 23 feb 2007
%
%  count_time_spikes.m   
%  This is a function that can be called from a history script.  It counts the elapse time
%  and number of spikes between two events in the selected trial.
%
%  ------- Parameters -----------
%
%  first_event[]
%     This can be a single event number, or a list of event numbers.  
%     The list is checked in order, and the first occurrence of the first event found is used. 
%
%  last_event[]
%     This can be a single event number, or a list of event numbers.  
%     The list is checked in order, and the first occurrence of the event that is found after
%     the time of the first event, is used. 
%
%   trial
%     Trial number to search.  
%
% 
%  ------- Returns -----------
%
%   event1,event2      the first and last events that were found in the trial
%   time_difference    number of milliseconds between two events. A difference of 0 is not allowed.
%   spike_count        number of spikes between the events (inclusive)
%   
%   If for any reason the two events are not found, event1 and event2 will be returned as empty arrays, and
%   the time_difference will be 0 (not a legal value). 
%   
%                           
%  -------- Example usage -------
%
%     first_event=[48 49 50];   % first event will be either 48, 49, or 50
%     last_event=[83 84 85];    % last event will be either 83, 84, or 85      
%     [event1,event2,time_difference,spike_count] = count_time_spikes(first_event,last_event,current_trial);
%
%     if ~isempty(event1)    % check to see if search was successful
%        assign_class_value(current_trial,20,event1);             % store the event number of the first event in class 20
%        assign_class_value(current_trial,21,event2);             % store the event number of the last event in class 21
%        assign_class_value(current_trial,22,time_difference);    % time between events in class 22
%        assign_class_value(current_trial,23,spike_count);        % spike count in class 23
%     end;
%
%
%
event1=[];
event2=[];
time_difference=0;
spike_count=0;

% exit if the supplied parameters are not useful.
if isempty(first_event) || isempty(last_event) || isempty(trial)
   return;
end;

% get all events and times for this trial (not just ones in the search string)
events=list_events(trial);  
acodes=events(1,:);
times =events(2,:);
clear events;

% find the index of the first event
for e=1:length(first_event)   % look for first occurrence from this list
   event1_index=find(acodes==first_event(e));
   if ~isempty(event1_index)
      break;
   end;
end;
if isempty(event1_index)
   return;  % exit if no matching event found
end;

first_event_time=times(event1_index(1));  %  keep only the first instance
event1=acodes(event1_index(1));

% find last event
for e=1:length(last_event)
   % must come after the first event
   event2_index=find( (times > first_event_time) & (acodes==last_event(e))  );

   last_event_time=times(find( (times > first_event_time) & (acodes==last_event(e)) ));
   if ~isempty(last_event_time)
      break;
   end;
end;
if isempty(event2_index)
   event1=[];
   return;  % exit if no matching event found
end;

last_event_time=times(event2_index(1));
event2=acodes(event2_index(1));

% find the time between events
time_difference=last_event_time - first_event_time;

% count the number of spikes between events
all_spike_times=list_spikes(trial); 
spike_index_list=find( (all_spike_times >= first_event_time) & (all_spike_times <= last_event_time));
spike_count = length(spike_index_list);

