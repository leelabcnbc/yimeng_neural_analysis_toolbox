% history_class_dump.m
%  Selectively dump some of the history classes for all trials
%  Create a text file (default name = history_dump.txt)
%  
%  To use:
%
%      history data 2 13 21 31      <--- history classes of interest
%      history file history_class_dump.m
%      scan
% 
%  This will generate a file (history_dump.txt):
%
% Trial Classes: 2 13 21 31 
%   1     1  0  1  X         X indicates "no value assigned"
%   2  7244  2  2  3 
%   3  7642  2  2  2 
%
%  Placeholder for missing values. 
placeholder='   X';
%  File name to create
filename='history_dump.txt';

class_list=list_history_data;   % get list of classes to dump
fid=fopen(filename,'wt');
trials=1:last_trial;
table=trials;   % first row
for i=1:length(class_list);
   table=[table ; find_class_value(trials,class_list(i))]; % add next class values as a new row
end;
% squeeze out columns without any class values
cc=~isnan(table(2:end,:));    % NaN ==> 0
sc=sum(cc,1);                 % sum columns
keep=find(sc > 0);            % keep only trials that have non NaN data
smaller_table=table(:,keep)'; % and transpose

fprintf('Creating %s\n',filename);
fprintf(fid,'Trial    Classes: ');
for i=1:length(class_list)
   fprintf(fid,'%d  ',class_list(i));
end;
fprintf(fid,'\n');
for i=1:length(smaller_table(:,1))  % each row (trial)
   for j=1:length(smaller_table(1,:))  % each column (class)
      if isnan(smaller_table(i,j))
         fprintf(fid,' %s ',placeholder);
      else
         fprintf(fid,' %4d ',smaller_table(i,j));
      end;
   end;
   fprintf(fid,'\n');
end;
fclose(fid);
accept=-1;  % end scan
