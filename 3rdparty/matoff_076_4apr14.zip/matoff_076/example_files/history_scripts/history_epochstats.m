% history_epochstats.m
%
%
%  History script to replace SET EPOCHSTATS KEEP with one exception.
%  The trial number is the absolute trial number of the unit, not the sorted trial number
%  
%
%  requires count_time_spikes.m
%
% Usage:
%
%  history data '<filename> <identifier string>'
%
% Appends to a file:
%
%  <trial number> <delta time> <spike count> <impulses per second> <identifier string>
%
%  Example:
%   history data 'epochdata.txt LEFT NOVEL'
%
% appends to a file epochdata.txt
%   1 0.51 10 20.05 LEFT NOVEL
%   8 0.58 0 0.0 LEFT NOVEL
%   ...
%   
%
[history_data]=list_history_data;
[filename,identifier]=strtok(history_data); 

if center_event < mark_event
   [e1,e2,delta,count] = count_time_spikes(center_event,mark_event,current_trial);
else
   [e1,e2,delta,count] = count_time_spikes(mark_event,center_event,current_trial);
end;
delta=delta/1000;  % convert from msec to seconds

fid=fopen(filename,'at');
if delta ~= 0
   fprintf(fid,'%d %5.3f %d %5.2f %s\n',current_trial,delta,count,count/delta,identifier);
else
   fprintf(fid,'%d %5.3f %d %5.2f %s\n',current_trial,delta,count,0,identifier);
end
fclose(fid);
accept=1;
