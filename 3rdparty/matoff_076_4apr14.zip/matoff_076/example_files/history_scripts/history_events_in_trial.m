% history_events_in_trial.m
%
%  Create a text file called event_dump.txt.
%  Append the event codes for current trial
%  each time this is called.
%
%
event_fid=fopen('event_dump.txt','at');

events=list_events(current_trial);
codes=events(1,:);
times=events(2,:);
fprintf(event_fid,'TRIAL %d\n',current_trial);
for c=1:length(codes)
   fprintf(event_fid,'%7d ',codes(c));
end;
fprintf(event_fid,'\n');
for c=1:length(times)
   fprintf(event_fid,'%7.3f ',times(c)/1000);  % convert to seconds
end;
fprintf(event_fid,'\n');

fclose(event_fid);


% Run only once
accept=1;
