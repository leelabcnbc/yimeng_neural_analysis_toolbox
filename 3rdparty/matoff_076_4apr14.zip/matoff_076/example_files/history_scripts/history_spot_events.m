% history_spot_events.m
%
%  The history spot command will place markers on each raster.
%  The trial and time for each spot is stored as a class value.
%  You will need to reserve N classes to store up to N spots 
%  within one trial.  Reserve these classes using:
%     history spot first <class number>
%     history spot last  <class number + (N-1)>
%
spot_list=[86,87,100,101];  % spot these codes with triangle
spot_first_class=500;       % use Classes 500 to 509 
spot_last_class= 509;       %  = up to 10 spots / trial

events=list_events(current_trial);
codes=events(1,:);
times=events(2,:);

class_number=spot_first_class;
for spot=1:length(spot_list)
   index=find(codes==spot_list(spot));
   for i=1:length(index)
      if class_number <= spot_last_class
         assign_class_value(current_trial,class_number,times(index(i)));
         class_number=class_number+1;
      end;
   end;
end;

% Accept every trial
accept=1;
