% history_validate.m
%
% Mark the range of valid spikes in each raster and histogram
% Using two event codes (start and stop). Then, set up a centering
% class exactly between the two.
%
valid_start_class=100;     % start class for valid spikes
valid_end_class=101;       % end class for valid spikes
centering_class=102;       % center class, located half way point between start and end.
validate_start_event=60;   % start time will be at this event on each trial
validate_end_event=29;     % end time will be at this event on each trial

fprintf('Running: history_validate history script\n');
for T=1:last_trial
   fprintf('Trial %d\n',T);
   events=list_events(T);  % get all events for the trial
   codes=events(1,:);      % array of event codes
   times=events(2,:);      % matching array of event times (miliseconds)
   % find markers for valid spikes
   index_of_start_event=find(codes==validate_start_event);
   if isempty(index_of_start_event)         % can't use this trial
      fprintf('  starting event code not found. this trial will have no valid spikes\n');
      break;
   end
   if length(index_of_start_event) > 1
      fprintf('  start event code %d occurs %d times in trial\n', start_code,length(index_of_start_event));
      index_of_start_event=index_of_start_event(1);   % take only the first occurance of event
   end
   start_time=times(index_of_start_event);
   assign_class_value(T,valid_start_class,start_time);
   
   index_of_end_event=find(codes==validate_end_event);   
   if isempty(index_of_end_event)
      % no ending event code. Use the timestamp of the last spike
      spike_times=list_spikes(T);
      last_spike_time=spike_times(end);
      assign_class_value(T,valid_end_class,last_spike_time);
   else
      if length(index_of_end_event) > 1
         fprintf('  end event code %d occurs %d times in trial\n', end_code,length(index_of_end_event));
         index_of_end_event=index_of_end_event(1); % use just the first one
      end
      end_time=times(index_of_end_event);
      if end_time < start_time
         fprintf('  end event time occurs before start time. No spikes will be validated.\n');
         % We could do something different here. Right now, just put this into the history class. 
      end
      assign_class_value(T,valid_end_class,end_time);
    end % if isempty(index_of_end_event)

    half_way_time= (start_time+end_time) / 2.0;
    assign_class_value(T,centering_class,half_way_time);
end %  for T=1:last_trial


accept=-1;    % done after first match
fprintf(' history_validate history script is finished after %d trials\n',last_trial);
fprintf(' next steps: HISTORY OFF  and then SCAN');
