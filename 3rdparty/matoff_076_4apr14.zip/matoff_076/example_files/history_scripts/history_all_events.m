% history_all_events.m
%
%  Create a text file called event_dump.txt
%  Save the event code and event time for every trial
%

   event_fid=fopen('event_dump.txt','wt');
   for trial=1:last_trial
      events=list_events(trial);
      codes=events(1,:);
      times=events(2,:);
      fprintf(event_fid,'TRIAL %d\n',trial);
      for c=1:length(codes)
         fprintf(event_fid,'%7d ',codes(c));
      end;
      fprintf(event_fid,'\n');
      for c=1:length(times)
         fprintf(event_fid,'%7.3f ',times(c)/1000);  % convert to seconds
      end;
      fprintf(event_fid,'\n');
   end;
   fclose(event_fid);


% Run only once
accept=-1;
