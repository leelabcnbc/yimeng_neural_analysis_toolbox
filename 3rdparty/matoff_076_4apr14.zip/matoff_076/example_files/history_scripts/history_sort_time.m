% history_sort_time.m
%
%  Set up a class for History sort.  Use the time difference between two events
%  as the basis of the sort.  Very similar to Sort time.
%
first_event=[86, 87, 88];   % whichever event matches first
last_event=[99];            % use first match here also
sort_class=499;             % Class that will get sorted values 

for trial=1:last_trial
   events=list_events(trial);
   codes=events(1,:);
   times=events(2,:);
   matchf=[];  % match to first events
   matchl=[];  % match to last events
   for f=1:length(first_event)
      matchf=[ matchf  find(codes==first_event(f)) ];
   end;
   for l=1:length(last_event)
      matchl=[ matchl  find(codes==last_event(l))  ];
   end;
   % measure time between first matches
   if any(matchf) & any(matchl)
      assign_class_value(trial,sort_class,abs(times(matchl(1))-times(matchf(1))));
   end;
end; % for trial

% run only once
accept=-1;
