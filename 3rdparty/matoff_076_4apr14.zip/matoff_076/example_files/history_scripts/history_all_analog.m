% history_all_analog.m
%
%  Create a text file called analog_dump.txt
%  Save the X and Y analog values and analog time time for every trial
%    uses list_analog() with this output:
%    xy_data          row 1   x1  x2  x3  x4  ... xn   x analog values -0.5 to +0.5
%                     row 2   y1  y2  y3  y4  ... yn   y analog values -0.5 to +0.5
%                     row 3   t1  t2  t3  t4  ... tn  (time in millisec)
%  If there is no analog data, returns [ 0
%                                        0
%                                        0  ]
%  If a channel is empty, returns 0 for every analog value in that channel
%
%
%   Code to make this set of commands run only once:
if isempty(find_class_value(1,500))
   assign_class_value(1,500,1);  % was never assigned, must be first time

   analog_fid=fopen('analog_dump.txt','wt');   % over-write any existing file
   for trial=1:last_trial             % cycle through every trial in unit
      [xy_data]=list_analog(trial);   % get all analog values for this trial
      X=xy_data(1,:);                 % array of X values
      Y=xy_data(2,:);                 % array of Y values
      T=xy_data(3,:)/1000;            % array of Time values converted to seconds
      fprintf(analog_fid,'TRIAL %d   SAMPLE TIME X Y  \n',trial);
      for samp=1:length(X)
         fprintf(analog_fid,'%-7d %8.3f %7d %7d\n',samp,T(samp),X(samp),Y(samp));
      end;
      fprintf(analog_fid,'\n');
   end;
   fclose(analog_fid);
end;

% Accept every trial
accept=1;
