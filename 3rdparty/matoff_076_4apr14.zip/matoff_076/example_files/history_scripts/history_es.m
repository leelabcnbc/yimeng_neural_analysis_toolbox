% history_es.m
%
%  Create a text file called es_dump.txt
%  Save the event codes, event times, and spike times for every trial
%
% Each trial has 4 lines in the output:
%
%  trial number as text (e.g. TRIAL 1)
%  list of event codes
%  list of event times since start of trial (in seconds) 
%  list of spike times since start of trial (in seconds)
%  
%   Run this set of commands only once.

es_fid=fopen('es_dump.txt','wt');
for trial=1:last_trial
   % events
   events=list_events(trial);
   codes=events(1,:);
   times=events(2,:);
   fprintf(es_fid,'TRIAL %d\n',trial);
   for c=1:length(codes)
      fprintf(es_fid,'%7d ',codes(c));
   end;
   fprintf(es_fid,'\n');
   for c=1:length(times)
      fprintf(es_fid,'%7.3f ',times(c)/1000);  % convert to seconds
   end;
   fprintf(es_fid,'\n');
   % spikes
   spikes=list_spikes(trial);
   for c=1:length(spikes)
      fprintf(es_fid,'%7.3f ',spikes(c)/1000);  % convert to seconds
   end;   
   fprintf(es_fid,'\n');
end;
fclose(es_fid);

accept=-1;  % run only once
